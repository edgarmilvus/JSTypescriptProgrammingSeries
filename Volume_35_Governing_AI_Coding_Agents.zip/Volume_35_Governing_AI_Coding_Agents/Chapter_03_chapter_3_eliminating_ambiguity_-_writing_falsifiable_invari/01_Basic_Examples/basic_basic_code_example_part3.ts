/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

// src/gateway/admission.ts
import type { ChatRequest, ModelClient, Tokenizer } from './types';

/**
 * Maximum number of tokens a prompt may occupy before the gateway rejects it.
 * Exported so the test suite can assert against the exact same constant.
 */
export const MAX_PROMPT_TOKENS = 8000;

export type AdmissionResult =
  | { kind: 'admitted'; tokenCount: number }
  | {
      kind: 'rejected';
      status: 413;
      reason: 'prompt_too_large';
      tokenCount: number;
    };

// r[impl CHAT-INGEST-001]
export async function admitChatRequest(
  req: ChatRequest,
  deps: { modelClient: ModelClient; tokenizer: Tokenizer },
): Promise<AdmissionResult> {
  const tokenCount = await deps.tokenizer.count(req.prompt);

  if (tokenCount > MAX_PROMPT_TOKENS) {
    return {
      kind: 'rejected',
      status: 413,
      reason: 'prompt_too_large',
      tokenCount,
    };
  }

  return { kind: 'admitted', tokenCount };
}
