/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// src/gateway/admission.test.ts
import { describe, it, expect, vi } from 'vitest';
import { admitChatRequest, MAX_PROMPT_TOKENS } from './admission';
import type { ChatRequest, ModelClient, Tokenizer } from './types';

const makeModelClient = (): ModelClient => ({
  generate: vi.fn().mockResolvedValue({ text: 'ok' }),
});

const makeTokenizer = (count: number): Tokenizer => ({
  count: vi.fn().mockResolvedValue(count),
});

// r[verify CHAT-INGEST-001]
describe('admitChatRequest — CHAT-INGEST-001', () => {
  it('rejects oversized prompts with 413 and never dispatches to the model', async () => {
    const modelClient = makeModelClient();
    const tokenizer = makeTokenizer(MAX_PROMPT_TOKENS + 1);
    const req: ChatRequest = { prompt: 'x'.repeat(100) };

    const result = await admitChatRequest(req, { modelClient, tokenizer });

    expect(result).toEqual({
      kind: 'rejected',
      status: 413,
      reason: 'prompt_too_large',
      tokenCount: MAX_PROMPT_TOKENS + 1,
    });
    // The normative "shall not dispatch" clause, expressed as an assertion.
    expect(modelClient.generate).not.toHaveBeenCalled();
  });

  it('admits prompts at or below the threshold', async () => {
    const modelClient = makeModelClient();
    const tokenizer = makeTokenizer(MAX_PROMPT_TOKENS);
    const req: ChatRequest = { prompt: 'hello' };

    const result = await admitChatRequest(req, { modelClient, tokenizer });

    expect(result).toEqual({
      kind: 'admitted',
      tokenCount: MAX_PROMPT_TOKENS,
    });
  });
});
