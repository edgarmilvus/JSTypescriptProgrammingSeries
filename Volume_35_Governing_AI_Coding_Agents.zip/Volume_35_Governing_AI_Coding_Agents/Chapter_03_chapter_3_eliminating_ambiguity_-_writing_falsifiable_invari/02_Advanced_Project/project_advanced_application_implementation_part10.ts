/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

/** Endpoint paths that participate in the `/v1/*` MFA gate. */
const V1_PREFIX = '/v1/';

/**
 * Requires the `mfa_verified` claim when the tenant has opted into MFA.
 *
 * @remarks
 * Implements {@link REQ-AUTH-003}. The EARS template is
 * **optional-feature**: the invariant is inert when
 * `tenant.features.mfa_required` is false, and it only applies to `/v1/*`
 * paths.
 *
 * The invariant is intentionally narrow: it checks for the *presence* of
 * `mfa_verified === true`. It does not check the strength of the MFA method;
 * that belongs to the identity provider.
 *
 * @param ctx - The request context; `ctx.tenant` and `ctx.claims` must be set.
 * @returns `void` on success; a 401 with `X-MFA-Required: true` on failure.
 *
 * @see REQ-AUTH-003
 */
// r[impl REQ-AUTH-003]
export function enforceMfaPolicy(ctx: RequestContext): void | GatewayRejection {
  const tenant = ctx.tenant;
  const claims = ctx.claims;
  if (!tenant || !claims) {
    return {
      status: 401,
      body: { error: 'unauthorized' },
      headers: {},
      counter: 'auth.no_claims',
    };
  }

  // Optional-feature: short-circuit when the feature is not enabled.
  if (!tenant.features.mfa_required) {
    return undefined;
  }

  // Optional-feature scope: only /v1/* paths are gated.
  if (!ctx.request.path.startsWith(V1_PREFIX)) {
    return undefined;
  }

  if (claims.mfa_verified !== true) {
    return {
      status: 401,
      body: { error: 'mfa_required' },
      headers: { 'X-MFA-Required': 'true' },
      counter: 'auth.mfa_missing',
    };
  }
  return undefined;
}
