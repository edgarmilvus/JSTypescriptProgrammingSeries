/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part11.ts
Description: Advanced Application Implementation
==========================================
*/

/** Endpoint paths that remain reachable while a tenant is suspended. */
const BILLING_ALLOWLIST = new Set<string>([
  '/v1/billing/portal',
  '/v1/billing/invoices',
  '/v1/billing/payment-methods',
]);

/**
 * Denies all non-billing traffic while the tenant is suspended.
 *
 * @remarks
 * Implements {@link REQ-BILL-010}. The EARS template is **state-driven**:
 * the invariant holds for the entire duration of the `SUSPENDED` state.
 *
 * Note the deliberate asymmetry in the response: suspended tenants see a
 * 402, not a 403. This is because the tenant *is* authenticated and *is*
 * authorized in principle — they simply owe money. A 403 would be a
 * false signal to their clients.
 *
 * @param ctx - The request context; `ctx.tenant` must be set.
 * @returns `void` on success; a 402 with `{"error":"billing_suspended"}`.
 *
 * @see REQ-BILL-010
 */
// r[impl REQ-BILL-010]
export function enforceSuspendedState(
  ctx: RequestContext,
): void | GatewayRejection {
  const tenant = ctx.tenant;
  if (!tenant) {
    return {
      status: 401,
      body: { error: 'unauthorized' },
      headers: {},
      counter: 'auth.no_claims',
    };
  }

  if (tenant.billingState !== 'SUSPENDED') {
    return undefined;
  }

  if (BILLING_ALLOWLIST.has(ctx.request.path)) {
    return undefined;
  }

  return {
    status: 402,
    body: { error: 'billing_suspended' },
    headers: {},
    counter: 'billing.suspended_deny',
  };
}
