/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * Rejects any request that references a tenant other than the caller's own.
 *
 * @remarks
 * Implements {@link REQ-BILL-011}. The EARS template is
 * **unwanted-behavior**: the trigger is adversarial.
 *
 * The invariant places two constraints beyond a mere `tid !== caller.tid`
 * check:
 *  1. The response MUST be identical whether the referenced tenant exists
 *     or not. We therefore do not consult the tenant service before
 *     rejecting.
 *  2. The counter MUST increment exactly once per attempt, before the
 *     response is written. This ensures an attacker cannot flood the
 *     counter with probes that are rejected by a shorter code path.
 *
 * Detection covers both path-embedded and query-embedded tenant IDs.
 *
 * @param ctx - The request context; `ctx.claims` must be set.
 * @param pathPattern - Regex that captures a tenant ID from the path.
 * @returns `void` on success; a 403 on mismatch.
 *
 * @see REQ-BILL-011
 */
// r[impl REQ-BILL-011]
export function enforceTenantBoundary(
  ctx: RequestContext,
  pathPattern: RegExp,
): void | GatewayRejection {
  const claims = ctx.claims;
  if (!claims) {
    return {
      status: 401,
      body: { error: 'unauthorized' },
      headers: {},
      counter: 'auth.no_claims',
    };
  }

  // Path-embedded tenant: /v1/tenants/{tid}/...
  const pathMatch = pathPattern.exec(ctx.request.path);
  const pathTid = pathMatch?.[1];

  // Query-embedded tenant: ?tenant_id=...
  const queryTid = ctx.request.query.get('tenant_id') ?? undefined;

  const referenced = pathTid ?? queryTid;

  // No reference at all → nothing to guard.
  if (referenced === undefined) {
    return undefined;
  }

  if (referenced !== claims.tid) {
    return {
      status: 403,
      // Deliberately generic: never a `tenant_not_found`, which would be an
      // existence oracle.
      body: { error: 'forbidden' },
      headers: {},
      counter: 'tenant.cross_tenant_attempt',
    };
  }
  return undefined;
}
