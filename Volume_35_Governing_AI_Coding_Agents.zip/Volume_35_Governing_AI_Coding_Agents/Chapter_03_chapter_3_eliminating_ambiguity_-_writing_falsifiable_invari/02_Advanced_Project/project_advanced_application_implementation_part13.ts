/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part13.ts
Description: Advanced Application Implementation
==========================================
*/

/** A token bucket, one per tenant. */
export interface TokenBucket {
  tokens: number;
  lastRefillMs: number;
}

/**
 * The per-tenant bucket registry. Scoping by `tid` is what makes the
 * invariant "independently per tenant".
 */
export type BucketRegistry = Map<string, TokenBucket>;

/** Capacity and refill parameters. Mirrors the invariant's "100 req/s". */
export const BUCKET_CAPACITY = 100;
export const REFILL_PER_MS = 100 / 1000;

/**
 * Attempts to consume one token from the caller's tenant bucket, refilling
 * continuously.
 *
 * @remarks
 * Implements {@link REQ-RATE-020}. The EARS template is **ubiquitous**: no
 * trigger, no state, no optional feature — every request passes through it.
 *
 * Refill is *continuous* (proportional to elapsed milliseconds), not
 * quantized to the second. This matters because a bursty client on a
 * 100ms-boundary scheduler would otherwise see artificially doubled
 * capacity.
 *
 * @param registry - The process-global bucket registry.
 * @param tid - The caller's tenant ID.
 * @param nowMs - Current epoch milliseconds.
 * @returns `{ ok: true }` if a token was available, else the projected
 *          seconds until one is available.
 *
 * @see REQ-RATE-020, REQ-RATE-021
 */
// r[impl REQ-RATE-020]
// r[impl REQ-RATE-021]
export function tryConsume(
  registry: BucketRegistry,
  tid: string,
  nowMs: number,
): { ok: true } | { ok: false; retryAfterSec: number } {
  let bucket = registry.get(tid);
  if (bucket === undefined) {
    bucket = { tokens: BUCKET_CAPACITY, lastRefillMs: nowMs };
    registry.set(tid, bucket);
  }

  const elapsed = nowMs - bucket.lastRefillMs;
  bucket.tokens = Math.min(
    BUCKET_CAPACITY,
    bucket.tokens + elapsed * REFILL_PER_MS,
  );
  bucket.lastRefillMs = nowMs;

  if (bucket.tokens >= 1) {
    bucket.tokens -= 1;
    return { ok: true };
  }

  const deficit = 1 - bucket.tokens;
  const waitMs = deficit / REFILL_PER_MS;
  return { ok: false, retryAfterSec: Math.ceil(waitMs / 1000) };
}

/**
 * Enforces the per-tenant token bucket.
 *
 * @remarks
 * Implements {@link REQ-RATE-020} and, when the bucket is exhausted,
 * {@link REQ-RATE-021}.
 *
 * @param ctx - The request context; `ctx.claims` must be set.
 * @param registry - The process-global bucket registry.
 * @returns `void` on success; a 429 with `Retry-After` on exhaustion.
 *
 * @see REQ-RATE-020, REQ-RATE-021
 */
// r[impl REQ-RATE-020]
// r[impl REQ-RATE-021]
export function enforceRateLimit(
  ctx: RequestContext,
  registry: BucketRegistry,
): void | GatewayRejection {
  const claims = ctx.claims;
  if (!claims) {
    return {
      status: 401,
      body: { error: 'unauthorized' },
      headers: {},
      counter: 'auth.no_claims',
    };
  }

  const result = tryConsume(registry, claims.tid, ctx.nowMs);
  if (result.ok) {
    return undefined;
  }

  return {
    status: 429,
    body: { error: 'rate_limited' },
    headers: { 'Retry-After': String(result.retryAfterSec) },
    counter: 'rate.exhausted',
  };
}
