/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part14.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * The ordered Lattice middleware chain.
 *
 * @remarks
 * Each element is a middleware that returns either `undefined` (continue)
 * or a {@link GatewayRejection} (short-circuit). The composition primitive
 * {@link runChain} stops at the first rejection.
 *
 * The order is significant and is defined by the EARS templates of the
 * underlying requirements:
 *
 *   1. {@link verifySignature}  — REQ-AUTH-001 (ubiquitous; identity first)
 *   2. {@link enforceIdleExpiry} — REQ-AUTH-002 (event on iat)
 *   3. {@link loadTenant}        — feeds state/optional-feature invariants
 *   4. {@link enforceMfaPolicy}  — REQ-AUTH-003 (optional-feature)
 *   5. {@link enforceSuspendedState} — REQ-BILL-010 (state-driven)
 *   6. {@link enforceTenantBoundary} — REQ-BILL-011 (unwanted-behavior)
 *   7. {@link enforceRateLimit}  — REQ-RATE-020 / REQ-RATE-021
 *
 * @param ctx - The request context.
 * @param deps - Injected dependencies (key resolver, verifier, loader, registry).
 * @returns The first {@link GatewayRejection}, or `undefined` if the request
 *          is admitted.
 */
export async function runChain(
  ctx: RequestContext,
  deps: {
    resolveKey: (kid: string) => Promise<string | null>;
    verify: (token: string, pem: string) => Promise<SessionClaims | null>;
    loadTenant: (tid: string) => Promise<TenantRecord | null>;
    registry: BucketRegistry;
    pathPattern: RegExp;
  },
): Promise<GatewayRejection | undefined> {
  const steps: Array<() => Promise<void | GatewayRejection> | void | GatewayRejection> = [
    () => verifySignature(ctx, deps.resolveKey, deps.verify),
    () => enforceIdleExpiry(ctx, ctx.nowMs),
    () => loadTenant(ctx, deps.loadTenant),
    () => enforceMfaPolicy(ctx),
    () => enforceSuspendedState(ctx),
    () => enforceTenantBoundary(ctx, deps.pathPattern),
    () => enforceRateLimit(ctx, deps.registry),
  ];

  for (const step of steps) {
    const result = await step();
    if (result !== undefined) {
      return result;
    }
  }
  return undefined;
}
