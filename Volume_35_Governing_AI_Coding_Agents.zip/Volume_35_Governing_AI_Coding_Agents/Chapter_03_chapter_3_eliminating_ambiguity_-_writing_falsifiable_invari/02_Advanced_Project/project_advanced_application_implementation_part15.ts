/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part15.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Vitest suites for the Identity & Session Integrity invariants.
 *
 * Every `it()` block in this file carries an `r[verify <UID>]` annotation.
 * The annotation is what makes the test an artifact in the intent graph; a
 * test without one is invisible to `tracey untested`.
 */
import { describe, it, expect, vi } from 'vitest';
import {
  verifySignature,
  enforceIdleExpiry,
  enforceMfaPolicy,
  IDLE_WINDOW_MS,
  type RequestContext,
  type SessionClaims,
} from '../src/middleware';

/** A minimal, valid request context for tests. */
function ctx(overrides: Partial<RequestContext['request']> = {}): RequestContext {
  return {
    request: {
      method: 'GET',
      path: overrides.path ?? '/v1/things',
      query: overrides.query ?? new URLSearchParams(),
      headers: overrides.headers ?? { authorization: 'Bearer T' },
    },
    nowMs: 1_700_000_000_000,
  };
}

/** A canonical claims object, with individual fields overridable. */
function claims(over: Partial<SessionClaims> = {}): SessionClaims {
  return {
    sub: 'user-1',
    tid: 'tenant-a',
    aud: 'lattice',
    iat: 1_700_000_000,
    exp: 1_700_000_900,
    ...over,
  };
}

/**
 * @see REQ-AUTH-001
 */
describe('REQ-AUTH-001 — RS256 Signature Enforcement', () => {
  // r[verify REQ-AUTH-001]
  it('admits a request whose signature verifies', async () => {
    const c = ctx();
    const result = await verifySignature(
      c,
      async () => 'PEM',
      async () => claims(),
    );
    expect(result).toBeUndefined();
    expect(c.claims?.tid).toBe('tenant-a');
  });

  // r[verify REQ-AUTH-001]
  it('rejects a request with no bearer header as 401', async () => {
    const c = ctx({ headers: {} });
    const result = await verifySignature(
      c,
      async () => 'PEM',
      async () => claims(),
    );
    expect(result?.status).toBe(401);
    expect(result?.counter).toBe('auth.missing_bearer');
  });

  // r[verify REQ-AUTH-001]
  it('rejects a request whose kid cannot be resolved', async () => {
    const c = ctx();
    const result = await verifySignature(
      c,
      async () => null, // key resolver misses
      async () => claims(),
    );
    expect(result?.status).toBe(401);
    expect(result?.counter).toBe('auth.unknown_kid');
  });

  // r[verify REQ-AUTH-001]
  it('rejects a request whose signature does not verify', async () => {
    const c = ctx();
    const result = await verifySignature(
      c,
      async () => 'PEM',
      async () => null, // verifier says "no"
    );
    expect(result?.status).toBe(401);
    expect(result?.counter).toBe('auth.signature_invalid');
  });
});

/**
 * @see REQ-AUTH-002
 */
describe('REQ-AUTH-002 — Idle Session Expiry', () => {
  // r[verify REQ-AUTH-002]
  it('admits a request within the idle window', () => {
    const c = ctx();
    c.claims = claims();
    const result = enforceIdleExpiry(
      c,
      c.claims.iat * 1000 + IDLE_WINDOW_MS - 1,
    );
    expect(result).toBeUndefined();
  });

  // r[verify REQ-AUTH-002]
  it('rejects the edge case at exactly the idle window', () => {
    const c = ctx();
    c.claims = claims();
    const result = enforceIdleExpiry(
      c,
      c.claims.iat * 1000 + IDLE_WINDOW_MS + 1,
    );
    expect(result?.status).toBe(401);
    expect(result?.headers['X-Session-Expired']).toBe('true');
  });
});

/**
 * @see REQ-AUTH-003
 */
describe('REQ-AUTH-003 — MFA Enforcement (optional-feature)', () => {
  // r[verify REQ-AUTH-003]
  it('is inert when the tenant has not opted into MFA', () => {
    const c = ctx({ path: '/v1/things' });
    c.claims = claims({ mfa_verified: false });
    c.tenant = {
      id: 'tenant-a',
      billingState: 'ACTIVE',
      features: { mfa_required: false },
      publicKeyPem: 'PEM',
    };
    expect(enforceMfaPolicy(c)).toBeUndefined();
  });

  // r[verify REQ-AUTH-003]
  it('rejects /v1/* when MFA is required and the claim is missing', () => {
    const c = ctx({ path: '/v1/things' });
    c.claims = claims({ mfa_verified: false });
    c.tenant = {
      id: 'tenant-a',
      billingState: 'ACTIVE',
      features: { mfa_required: true },
      publicKeyPem: 'PEM',
    };
    const result = enforceMfaPolicy(c);
    expect(result?.status).toBe(401);
    expect(result?.headers['X-MFA-Required']).toBe('true');
  });

  // r[verify REQ-AUTH-003]
  it('does not gate non-/v1 paths even when MFA is required', () => {
    const c = ctx({ path: '/healthz' });
    c.claims = claims({ mfa_verified: false });
    c.tenant = {
      id: 'tenant-a',
      billingState: 'ACTIVE',
      features: { mfa_required: true },
      publicKeyPem: 'PEM',
    };
    expect(enforceMfaPolicy(c)).toBeUndefined();
  });
});
