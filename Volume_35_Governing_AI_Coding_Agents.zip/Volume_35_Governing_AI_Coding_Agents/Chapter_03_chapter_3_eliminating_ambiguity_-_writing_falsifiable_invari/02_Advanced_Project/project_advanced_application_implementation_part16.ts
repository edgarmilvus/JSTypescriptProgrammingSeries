/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part16.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Vitest suites for the Billing-State Gating and Rate & Fairness
 * invariants.
 */
import { describe, it, expect } from 'vitest';
import {
  enforceSuspendedState,
  enforceTenantBoundary,
  enforceRateLimit,
  tryConsume,
  BUCKET_CAPACITY,
  REFILL_PER_MS,
  type RequestContext,
  type SessionClaims,
  type TenantRecord,
  type BucketRegistry,
} from '../src/middleware';

/**
 * @see REQ-BILL-010
 */
describe('REQ-BILL-010 — Suspended Tenant Deny-All', () => {
  // r[verify REQ-BILL-010]
  it('admits billing endpoints for suspended tenants', () => {
    const c = mk('/v1/billing/portal', 'SUSPENDED');
    expect(enforceSuspendedState(c)).toBeUndefined();
  });

  // r[verify REQ-BILL-010]
  it('rejects non-billing endpoints with 402 for suspended tenants', () => {
    const c = mk('/v1/things', 'SUSPENDED');
    const result = enforceSuspendedState(c);
    expect(result?.status).toBe(402);
    expect(result?.body.error).toBe('billing_suspended');
  });

  // r[verify REQ-BILL-010]
  it('is inert for active tenants', () => {
    const c = mk('/v1/things', 'ACTIVE');
    expect(enforceSuspendedState(c)).toBeUndefined();
  });
});

/**
 * @see REQ-BILL-011
 */
describe('REQ-BILL-011 — Tenant Identifier Mismatch Rejection', () => {
  const pattern = /^\/v1\/tenants\/([^/]+)\//;

  // r[verify REQ-BILL-011]
  it('rejects a path-embedded cross-tenant reference with 403', () => {
    const c = mk('/v1/tenants/tenant-b/things', 'ACTIVE');
    const result = enforceTenantBoundary(c, pattern);
    expect(result?.status).toBe(403);
    expect(result?.counter).toBe('tenant.cross_tenant_attempt');
    // The body must not be an existence oracle.
    expect(result?.body.error).toBe('forbidden');
  });

  // r[verify REQ-BILL-011]
  it('admits a path-embedded same-tenant reference', () => {
    const c = mk('/v1/tenants/tenant-a/things', 'ACTIVE');
    expect(enforceTenantBoundary(c, pattern)).toBeUndefined();
  });

  // r[verify REQ-BILL-011]
  it('rejects a query-embedded cross-tenant reference with 403', () => {
    const c: RequestContext = {
      nowMs: 1_700_000_000_000,
      request: {
        method: 'GET',
        path: '/v1/things',
        query: new URLSearchParams('tenant_id=tenant-b'),
        headers: {},
      },
      claims: claims(),
    };
    const result = enforceTenantBoundary(c, pattern);
    expect(result?.status).toBe(403);
  });
});

/**
 * @see REQ-RATE-020, REQ-RATE-021
 */
describe('REQ-RATE-020 / REQ-RATE-021 — Token Bucket & Retry-After', () => {
  // r[verify REQ-RATE-020]
  it('consumes from an initially full bucket without rejection', () => {
    const registry: BucketRegistry = new Map();
    const result = tryConsume(registry, 'tenant-a', 0);
    expect(result.ok).toBe(true);
  });

  // r[verify REQ-RATE-020]
  it('isolates buckets per tenant', () => {
    const registry: BucketRegistry = new Map();
    for (let i = 0; i < BUCKET_CAPACITY; i += 1) {
      expect(tryConsume(registry, 'tenant-a', 0).ok).toBe(true);
    }
    // tenant-a is exhausted, tenant-b is untouched.
    expect(tryConsume(registry, 'tenant-a', 0).ok).toBe(false);
    expect(tryConsume(registry, 'tenant-b', 0).ok).toBe(true);
  });

  // r[verify REQ-RATE-020]
  it('refills continuously, not in whole-second steps', () => {
    const registry: BucketRegistry = new Map();
    for (let i = 0; i < BUCKET_CAPACITY; i += 1) {
      tryConsume(registry, 'tenant-a', 0);
    }
    // After 100ms, exactly 10 tokens should be available.
    const justEnoughMs = Math.ceil(1 / REFILL_PER_MS);
    const result = tryConsume(registry, 'tenant-a', justEnoughMs);
    expect(result.ok).toBe(true);
  });

  // r[verify REQ-RATE-021]
  it('emits Retry-After as a positive integer number of seconds', () => {
    const registry: BucketRegistry = new Map();
    for (let i = 0; i < BUCKET_CAPACITY; i += 1) {
      tryConsume(registry, 'tenant-a', 0);
    }
    const c: RequestContext = {
      nowMs: 1_700_000_000_000,
      request: {
        method: 'GET',
        path: '/v1/things',
        query: new URLSearchParams(),
        headers: {},
      },
      claims: claims({ tid: 'tenant-a' }),
    };
    // Prime the bucket at the same instant.
    tryConsume(registry, 'tenant-a', c.nowMs);
    tryConsume(registry, 'tenant-a', c.nowMs);
    // Drain it:
    for (let i = 0; i < BUCKET_CAPACITY; i += 1) {
      tryConsume(registry, 'tenant-a', c.nowMs);
    }
    const result = enforceRateLimit(c, registry);
    expect(result?.status).toBe(429);
    const retryAfter = Number(result?.headers['Retry-After']);
    expect(Number.isInteger(retryAfter)).toBe(true);
    expect(retryAfter).toBeGreaterThan(0);
  });
});
