<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: project_advanced_application_implementation_part4.md
Description: Advanced Application Implementation
==========================================
-->

You operate under a formal Software Intent Graph managed by Tracey MCP.
Before writing, refactoring, or deleting any TypeScript under `src/`:

1. Call `tracey_status` to read current coverage for `lattice-gateway`.
2. Call `tracey_uncovered` (prefix filter: `REQ-AUTH.`) to list identity invariants lacking implementations.
3. Call `tracey_rule <UID>` for each requirement you intend to touch, and quote its STATEMENT verbatim in your change description.
4. Ensure every exported middleware function carries `// r[impl <UID>]`.
5. Ensure every Vitest `it()` that validates an invariant carries `// r[verify <UID>]`.
6. Call `tracey_validate` before opening a PR; resolve every warning, not just errors.
