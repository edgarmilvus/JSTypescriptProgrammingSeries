/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Domain types for the Lattice gateway middleware chain.
 *
 * The types in this module are deliberately narrow: every field that an
 * invariant in `docs/spec/lattice.sdoc` reads must be present here, so
 * that a compiler error is the first line of defense against spec drift.
 */

/**
 * The verified, decoded claims of a tenant session.
 *
 * Every field here corresponds to a claim that the gateway reads. If a new
 * invariant needs a new claim, add it here *and* add an `impl` annotation
 * at the point of use.
 */
export interface SessionClaims {
  /** Subject — the human or machine principal. */
  readonly sub: string;
  /** Tenant identifier. Every rate limit and billing gate is scoped to this. */
  readonly tid: string;
  /** Audience — the gateway audience string. Must match the gateway's own AUD. */
  readonly aud: string;
  /** Issued-at, seconds since epoch. Drives REQ-AUTH-002 idle detection. */
  readonly iat: number;
  /** Expiry, seconds since epoch. Absolute upper bound, independent of idle. */
  readonly exp: number;
  /** Present and true only for sessions that completed an MFA challenge. */
  readonly mfa_verified?: boolean;
}

/**
 * The tenant record as materialized from the tenant service.
 *
 * The `billingState` field drives REQ-BILL-010. The `features` bag drives
 * REQ-AUTH-003.
 */
export interface TenantRecord {
  readonly id: string;
  readonly billingState: 'ACTIVE' | 'SUSPENDED' | 'TRIAL' | 'CLOSED';
  readonly features: {
    readonly mfa_required: boolean;
  };
  /** Base64-encoded RS256 public key, PEM body only. */
  readonly publicKeyPem: string;
}

/**
 * A structured rejection. The gateway never throws raw strings — every
 * denial is a `GatewayRejection` so that downstream observability can
 * emit a single, well-typed metric per cause.
 */
export interface GatewayRejection {
  readonly status: 401 | 402 | 403 | 429;
  readonly body: { error: string };
  readonly headers: Record<string, string>;
  /** Counter name to increment exactly once. */
  readonly counter: string;
}

/**
 * The per-request context threaded through every middleware in the chain.
 */
export interface RequestContext {
  readonly request: {
    readonly method: string;
    readonly path: string;
    readonly query: URLSearchParams;
    readonly headers: Record<string, string>;
  };
  readonly nowMs: number;
  /** Populated by {@link verifySignature} (REQ-AUTH-001). */
  claims?: SessionClaims;
  /** Populated by {@link loadTenant} (billing + feature gate). */
  tenant?: TenantRecord;
}
