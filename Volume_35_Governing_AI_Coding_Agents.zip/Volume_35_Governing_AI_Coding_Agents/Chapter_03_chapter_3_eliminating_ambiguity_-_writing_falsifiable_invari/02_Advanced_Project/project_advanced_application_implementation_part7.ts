/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * Verifies the JWT signature of an incoming authenticated request using the
 * tenant-specific RS256 public key resolved from the token's `kid` header.
 *
 * @remarks
 * Implements {@link REQ-AUTH-001}. The invariant is **ubiquitous**: there is
 * no triggering event, no state precondition, and no feature flag. Every
 * authenticated request either presents a valid RS256 signature or it does
 * not reach a downstream handler.
 *
 * The only branch that contributes to the return type is the success path;
 * every failure mode funnels through {@link denySignature}.
 *
 * @param ctx - The mutable request context. On success, `ctx.claims` is set.
 * @param resolveKey - Async key resolver: maps `kid` to a PEM-encoded public key.
 * @param verify - The RS256 verification primitive (injected for testability).
 * @returns `void` on success; a {@link GatewayRejection} on failure.
 *
 * @see REQ-AUTH-001
 */
// r[impl REQ-AUTH-001]
export async function verifySignature(
  ctx: RequestContext,
  resolveKey: (kid: string) => Promise<string | null>,
  verify: (token: string, pem: string) => Promise<SessionClaims | null>,
): Promise<void | GatewayRejection> {
  const header = ctx.request.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return denySignature('auth.missing_bearer');
  }

  const token = header.slice('Bearer '.length);
  const kid = readKid(token);
  if (kid === null) {
    return denySignature('auth.malformed_kid');
  }

  const pem = await resolveKey(kid);
  if (pem === null) {
    return denySignature('auth.unknown_kid');
  }

  const claims = await verify(token, pem);
  if (claims === null) {
    return denySignature('auth.signature_invalid');
  }

  ctx.claims = claims;
  return undefined;
}

/**
 * Reads the `kid` field from a JWT header *without* verifying the signature.
 *
 * @remarks
 * This is safe: the returned `kid` is used only to select a key. A hostile
 * `kid` can cause a key-lookup miss (→ 401) but cannot cause the gateway to
 * trust an unverified token, because {@link verifySignature}'s final step
 * is a cryptographic check.
 *
 * @param token - A compact-serialized JWT.
 * @returns The `kid` string, or `null` if the header is not decodable.
 */
function readKid(token: string): string | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  try {
    const decoded = Buffer.from(parts[0], 'base64url').toString('utf8');
    const parsed = JSON.parse(decoded) as { kid?: string };
    return typeof parsed.kid === 'string' ? parsed.kid : null;
  } catch {
    return null;
  }
}

/**
 * Constructs the canonical 401 rejection for signature-family failures.
 *
 * @param counter - The specific counter name, e.g. `auth.signature_invalid`.
 * @see REQ-AUTH-001
 */
function denySignature(counter: string): GatewayRejection {
  return {
    status: 401,
    body: { error: 'unauthorized' },
    headers: { 'WWW-Authenticate': 'Bearer' },
    counter,
  };
}
