/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.ts
Description: Advanced Application Implementation
==========================================
*/

/** The idle window, in milliseconds. Mirrors the invariant's "15 minutes". */
export const IDLE_WINDOW_MS = 15 * 60 * 1000;

/**
 * Rejects the next request when the presented session has been idle for more
 * than {@link IDLE_WINDOW_MS}.
 *
 * @remarks
 * Implements {@link REQ-AUTH-002}. The EARS template is **event-driven**:
 * the trigger is `iat` crossing the idle threshold, evaluated at request
 * time. The invariant is deliberately conservative — we do not attempt to
 * distinguish "idle" from "sleeping client". Wall clock wins.
 *
 * @param ctx - The request context. `ctx.claims` must be populated.
 * @param nowMs - The current epoch time in milliseconds (injected).
 * @returns `void` on success; a 401 with `X-Session-Expired: true` on
 *          expiry.
 *
 * @see REQ-AUTH-002
 */
// r[impl REQ-AUTH-002]
export function enforceIdleExpiry(
  ctx: RequestContext,
  nowMs: number,
): void | GatewayRejection {
  const claims = ctx.claims;
  if (!claims) {
    // Defensive: the chain guarantees this, but a type-only check keeps
    // the function total.
    return {
      status: 401,
      body: { error: 'unauthorized' },
      headers: {},
      counter: 'auth.no_claims',
    };
  }

  const idleMs = nowMs - claims.iat * 1000;
  if (idleMs > IDLE_WINDOW_MS) {
    return {
      status: 401,
      body: { error: 'session_expired' },
      headers: { 'X-Session-Expired': 'true' },
      counter: 'session.idle_expired',
    };
  }
  return undefined;
}
