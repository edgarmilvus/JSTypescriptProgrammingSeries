/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_the_ambiguity_audit_and_ears_rewrite.ts
Description: Solutions and Explanations
==========================================
*/

// TypeScript encoding of the rewritten auth.sdoc requirements. The SDoc source
// is preserved verbatim inside the template literal so it can be written to
// disk under docs/spec/auth.sdoc without a transformation step.

type EarsPattern =
  | 'ubiquitous'
  | 'event-driven'
  | 'state-driven'
  | 'unwanted-behavior'
  | 'optional-feature';

interface NormativeRequirement {
  readonly uid: string;
  readonly section: 'Core Authentication' | 'Session Lifecycle';
  readonly pattern: EarsPattern;
  readonly statement: string;
  /** Predicate that the Vitest suite must be able to evaluate. */
  readonly testShape: string;
}

export const AUTH_SDOC = `[DOCUMENT]
TITLE: Authentication Gateway
OPTIONS:
  ENABLE_MID: True

[[SECTION]]
TITLE: Core Authentication

[REQUIREMENT]
UID: AUTH-CREDENTIAL-VALID
TITLE: Valid credential login
STATUS: Active
STATEMENT: >>>
When a client submits a username and password pair that matches an active
account, the auth gateway shall respond within 300 milliseconds with an
HTTP 200 status and a sessionToken field containing at least 32 bytes.
<<<
RATIONALE: >>>
The 300 millisecond bound is the p99 latency target agreed with the client
SDK team; the 32-byte floor matches the entropy requirement for the token
signing key.
<<<

[REQUIREMENT]
UID: AUTH-CREDENTIAL-INVALID
TITLE: Invalid credential rejection
STATUS: Active
STATEMENT: >>>
When a client submits a username and password pair that does not match an
active account, the auth gateway shall respond within 300 milliseconds
with HTTP 401 and shall omit the sessionToken field entirely.
<<<

[REQUIREMENT]
UID: AUTH-RATE-LIMIT-BURST
TITLE: Login burst protection
STATUS: Active
STATEMENT: >>>
If a single client IP address initiates more than 10 login requests within
a rolling 60 second window, then the auth gateway shall respond with
HTTP 429 and shall include a Retry-After header whose value is the
remaining cooldown in whole seconds.
<<<
COMMENT: >>>
Chosen unwanted-behavior rather than event-driven because the burst
condition describes adversarial input from an untrusted client, and
unwanted-behavior maps to fault-injection tests rather than happy-path
dispatch tests.
<<<

[REQUIREMENT]
UID: AUTH-ADMIN-PRIVILEGE
TITLE: Administrator user-creation privilege
STATUS: Active
STATEMENT: >>>
Where the authenticated session carries the admin role, the auth gateway
shall permit the client to create another user via POST /admin/users and
shall respond with HTTP 201 when creation succeeds.
<<<
COMMENT: >>>
Chosen optional-feature rather than ubiquitous because the privilege only
applies to sessions holding the admin role; the default session does not
carry it.
<<<

[[/SECTION]]

[[SECTION]]
TITLE: Session Lifecycle

[REQUIREMENT]
UID: AUTH-SESSION-TTL
TITLE: Absolute session lifetime
STATUS: Active
STATEMENT: >>>
When a session token is issued, the auth gateway shall mark the token as
expired 3600 seconds after its issuedAt timestamp, regardless of client
activity.
<<<
RATIONALE: >>>
Absolute TTL is distinct from idle TTL. The legacy prose "should expire
eventually" collapses both into one sentence and is therefore unverifiable.
<<<

[REQUIREMENT]
UID: AUTH-SESSION-IDLE
TITLE: Idle session expiry
STATUS: Active
STATEMENT: >>>
While a session is active, the auth gateway shall consider the session
expired if the last authenticated request was more than 900 seconds
before the current wall-clock time.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: AUTH-SESSION-TTL
<<<

[[/SECTION]]
`;

export const AUTH_REQUIREMENTS: readonly NormativeRequirement[] = [
  {
    uid: 'AUTH-CREDENTIAL-VALID',
    section: 'Core Authentication',
    pattern: 'event-driven',
    statement:
      'When valid credentials are submitted, respond within 300ms with HTTP 200 and a sessionToken.',
    testShape:
      "await expect(loginWith(validCreds)).resolves.toMatchObject({ status: 200, body: { sessionToken: expect.any(String) } })",
  },
  {
    uid: 'AUTH-CREDENTIAL-INVALID',
    section: 'Core Authentication',
    pattern: 'event-driven',
    statement:
      'When invalid credentials are submitted, respond within 300ms with HTTP 401 and no token.',
    testShape:
      "expect(response.status).toBe(401); expect(response.body).not.toHaveProperty('sessionToken')",
  },
  {
    uid: 'AUTH-RATE-LIMIT-BURST',
    section: 'Core Authentication',
    pattern: 'unwanted-behavior',
    statement:
      'If >10 login attempts arrive within 60s from one IP, respond 429 with Retry-After.',
    testShape:
      'await expect(() => fireElevenLogins(ip)).rejects.toMatchObject({ status: 429, headers: { "retry-after": expect.any(String) } })',
  },
  {
    uid: 'AUTH-ADMIN-PRIVILEGE',
    section: 'Core Authentication',
    pattern: 'optional-feature',
    statement:
      'Where the session has the admin role, POST /admin/users returns HTTP 201.',
    testShape:
      "await expect(createUser(adminSession, payload)).resolves.toMatchObject({ status: 201 })",
  },
  {
    uid: 'AUTH-SESSION-TTL',
    section: 'Session Lifecycle',
    pattern: 'event-driven',
    statement: 'When a token is issued, mark it expired 3600s after issuedAt.',
    testShape:
      "const t = issueToken(now); expect(isExpired(t, new Date(now.getTime() + 3_601_000))).toBe(true)",
  },
  {
    uid: 'AUTH-SESSION-IDLE',
    section: 'Session Lifecycle',
    pattern: 'state-driven',
    statement:
      'While a session is active, it is expired if the last authenticated request was >900s ago.',
    testShape:
      "expect(isSessionExpired(sessionWithLastSeen(now - 901_000), now)).toBe(true)",
  },
];

/**
 * Guarantees that every requirement is assigned exactly one EARS pattern.
 * This makes the rewrite explicitly auditable: a missing pattern is a compile
 * error, not a silent spec drift.
 */
export function assertPatternsCovered(
  reqs: readonly NormativeRequirement[],
): Record<EarsPattern, string[]> {
  const byPattern: Record<EarsPattern, string[]> = {
    ubiquitous: [],
    'event-driven': [],
    'state-driven': [],
    'unwanted-behavior': [],
    'optional-feature': [],
  };
  for (const r of reqs) byPattern[r.pattern].push(r.uid);
  return byPattern;
}
