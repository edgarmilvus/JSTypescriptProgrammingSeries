/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_mid_lifecycle_and_stable_identity_under_rename.ts
Description: Solutions and Explanations
==========================================
*/

// Ingest pipeline MID demonstration. The point: a MID is an opaque anchor
// that survives UID churn. The simulation below renumbers the human-readable
// UIDs and shows that MID-keyed lookups keep resolving.

import { randomUUID } from 'node:crypto';

export interface SdocRequirement {
  /** Stable machine identifier. Generated once, never edited. */
  readonly mid: string;
  /** Human-readable identifier. Subject to renumbering. */
  uid: string;
  title: string;
  statement: string;
}

export interface SdocDocument {
  title: string;
  requirements: SdocRequirement[];
}

export const INITIAL_INGEST: SdocDocument = {
  title: 'Data Ingestion Pipeline',
  requirements: [
    {
      mid: randomUUID(),
      uid: 'INGEST-1',
      title: 'Schema validation',
      statement: 'When a record is received, validate it against the active schema.',
    },
    {
      mid: randomUUID(),
      uid: 'INGEST-2',
      title: 'Backpressure handling',
      statement: 'While the sink is saturated, buffer up to 10k records.',
    },
    {
      mid: randomUUID(),
      uid: 'INGEST-3',
      title: 'Retry policy',
      statement: 'If a sink write fails, retry with exponential backoff up to 5 attempts.',
    },
    {
      mid: randomUUID(),
      uid: 'INGEST-4',
      title: 'Dead-letter routing',
      statement: 'When a record exhausts retries, route it to the dead-letter queue.',
    },
    {
      mid: randomUUID(),
      uid: 'INGEST-5',
      title: 'Checkpoint persistence',
      statement: 'When a checkpoint is taken, persist it to disk before acknowledging.',
    },
  ],
};

/**
 * Renumber UIDs in the middle of the pipeline, leaving MIDs untouched.
 * This mimics a real-world section reorganization that inserts requirements.
 */
export function renumberUids(doc: SdocDocument): SdocDocument {
  const remap: Record<string, string> = {
    'INGEST-1': 'INGEST-1',
    'INGEST-2': 'INGEST-3',
    'INGEST-3': 'INGEST-4a',
    'INGEST-4': 'INGEST-4b',
    'INGEST-5': 'INGEST-5',
  };
  return {
    title: doc.title,
    requirements: doc.requirements.map((r) => ({
      ...r,
      uid: remap[r.uid] ?? r.uid,
    })),
  };
}

export function findById(
  doc: SdocDocument,
  key: 'mid' | 'uid',
  value: string,
): SdocRequirement | undefined {
  return doc.requirements.find((r) => r[key] === value);
}

/**
 * MID-based references are durable across renumbering.
 * This is the property that makes MIDs viable for agent consumption: a
 * stateless reader that resolves by MID never needs to know the UID history.
 */
export function midReferenceSurvivesRename(): boolean {
  const before = INITIAL_INGEST;
  const after = renumberUids(before);
  const targetMid = before.requirements[2].mid; // "Retry policy"
  const resolved = findById(after, 'mid', targetMid);
  return resolved !== undefined && resolved.title === 'Retry policy';
}

/**
 * UID-based references do NOT survive renumbering when the UID moves.
 * The comment below is the classic failure: a code annotation pinned to
 * INGEST-3 now resolves to a completely different requirement.
 */
export function uidReferenceBreaksAfterRename(): {
  resolvesToWrongRequirement: boolean;
} {
  const before = INITIAL_INGEST;
  const after = renumberUids(before);
  const staleAnnotationTarget = 'INGEST-3';
  const beforeUid = findById(before, 'uid', staleAnnotationTarget);
  const afterUid = findById(after, 'uid', staleAnnotationTarget);
  return {
    resolvesToWrongRequirement:
      beforeUid !== undefined &&
      afterUid !== undefined &&
      beforeUid.mid !== afterUid.mid,
  };
}

// ---------------------------------------------------------------------------
// MID management invariants. These are policy, expressed in code so they can
// be included in tests that fail loudly when a future change violates them.
// ---------------------------------------------------------------------------

export interface MidPolicy {
  /** A MID is generated once and never regenerated. */
  readonly generateOnce: true;
  /** A MID survives UID churn. */
  readonly stableAcrossRenames: true;
  /** A MID is opaque; it must not encode semantic meaning. */
  readonly opaque: true;
  /** A MID is not reused after the owning requirement is deleted. */
  readonly notReused: true;
}

export const MID_POLICY: MidPolicy = {
  generateOnce: true,
  stableAcrossRenames: true,
  opaque: true,
  notReused: true,
};

/**
 * The correct annotation for downstream code hides the human UID entirely.
 * Tracey's SDoc binding uses the UID for lookups today (because the extractor
 * runs against the SDoc grammar where MID is not yet the primary key), but the
 * spec-side push is always toward MID-as-principal-key, and the code below
 * models that target state.
 */
export function preferredAnnotation(mid: string): string {
  return `// r[impl mid:${mid}]`;
}

export function currentAnnotation(uid: string): string {
  return `// r[impl ${uid}]`;
}
