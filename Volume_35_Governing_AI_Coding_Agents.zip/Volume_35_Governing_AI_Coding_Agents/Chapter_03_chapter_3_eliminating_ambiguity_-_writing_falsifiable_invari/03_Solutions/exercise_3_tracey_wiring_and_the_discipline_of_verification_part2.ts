/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_tracey_wiring_and_the_discipline_of_verification_part2.ts
Description: Solutions and Explanations
==========================================
*/

import { describe, expect, it } from 'vitest';
import {
  isSessionExpired,
  isTokenPastAbsoluteTtl,
  IDLE_WINDOW_MS,
  ABSOLUTE_TTL_MS,
  type Session,
  type IssuedToken,
} from '../../src/session/expiry.js';

const sessionAt = (lastSeenMsAgo: number, now: Date): Session => ({
  id: 's-1',
  lastSeenAt: new Date(now.getTime() - lastSeenMsAgo),
});

describe('isSessionExpired', () => {
  const now = new Date('2026-01-01T00:00:00.000Z');

  it('reports a fresh session as active', () => {
    // r[verify AUTH-SESSION-IDLE]
    // Fresh session: last request 1 second ago. Must not be expired.
    expect(isSessionExpired(sessionAt(1_000, now), now)).toBe(false);
  });

  it('reports a session idle past the window as expired', () => {
    // r[verify AUTH-SESSION-IDLE]
    // Idle for 900_001ms: strictly greater than the window → expired.
    expect(isSessionExpired(sessionAt(IDLE_WINDOW_MS + 1, now), now)).toBe(true);
  });

  it('treats exactly 900_000ms as still active (boundary is exclusive)', () => {
    // r[verify AUTH-SESSION-IDLE]
    // Boundary pin: the requirement says "more than 900 seconds", so
    // exactly 900_000ms is still inside the window.
    expect(isSessionExpired(sessionAt(IDLE_WINDOW_MS, now), now)).toBe(false);
  });
});

describe('isTokenPastAbsoluteTtl', () => {
  const now = new Date('2026-01-01T00:00:00.000Z');
  const tokenAt = (ageMs: number): IssuedToken => ({
    token: 't',
    issuedAt: new Date(now.getTime() - ageMs),
  });

  it('accepts a token below the TTL', () => {
    // r[verify AUTH-SESSION-TTL]
    expect(isTokenPastAbsoluteTtl(tokenAt(ABSOLUTE_TTL_MS - 1), now)).toBe(false);
  });

  it('rejects a token at the TTL boundary', () => {
    // r[verify AUTH-SESSION-TTL]
    // Boundary pin: TTL uses >=, so exactly 3_600_000ms is expired.
    expect(isTokenPastAbsoluteTtl(tokenAt(ABSOLUTE_TTL_MS), now)).toBe(true);
  });
});
