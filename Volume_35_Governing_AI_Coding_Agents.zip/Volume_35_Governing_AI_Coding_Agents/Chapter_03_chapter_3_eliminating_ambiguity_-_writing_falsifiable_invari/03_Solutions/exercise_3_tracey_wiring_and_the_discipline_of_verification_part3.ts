/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_tracey_wiring_and_the_discipline_of_verification_part3.ts
Description: Solutions and Explanations
==========================================
*/

import { describe, expect, it } from 'vitest';
import { isSessionExpired } from '../../src/session/expiry.js';

describe('isSessionExpired (lazy)', () => {
  it('returns a boolean', () => {
    // r[verify AUTH-SESSION-IDLE]
    // DELIBERATELY DISHONEST: asserts the return type, not the semantics.
    // Tracey will count this as a verification because the annotation is
    // present. No query subcommand can detect this.
    const result = isSessionExpired(
      { id: 's-1', lastSeenAt: new Date() },
      new Date(),
    );
    expect(typeof result).toBe('boolean');
  });
});
