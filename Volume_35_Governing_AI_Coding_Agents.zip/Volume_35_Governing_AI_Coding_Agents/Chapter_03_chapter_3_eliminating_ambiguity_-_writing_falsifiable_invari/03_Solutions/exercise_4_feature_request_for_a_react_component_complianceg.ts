/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_feature_request_for_a_react_component_complianceg.ts
Description: Solutions and Explanations
==========================================
*/

// The entitlement map is the *source of truth* for the union type. Adding a
// key here causes TypeScript to permit it in <ComplianceGate>; removing one
// causes every consumer that references it to fail at compile time.
export const ENTITLEMENTS = {
  'reports.export.csv': { tier: 'pro' },
  'reports.export.pdf': { tier: 'pro' },
  'dashboard.custom_widgets': { tier: 'enterprise' },
  'audit.log.retention_365d': { tier: 'enterprise' },
} as const satisfies Record<string, { tier: 'pro' | 'enterprise' }>;

export type EntitlementKey = keyof typeof ENTITLEMENTS;

export type EntitlementTier = (typeof ENTITLEMENTS)[EntitlementKey]['tier'];

export type EntitlementResolution =
  | { readonly status: 'allowed'; readonly tier: EntitlementTier }
  | { readonly status: 'denied'; readonly reason: 'plan' | 'unknown-key' }
  | { readonly status: 'unavailable'; readonly reason: 'service-5xx' | 'timeout' };
