/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_feature_request_for_a_react_component_complianceg_part2.ts
Description: Solutions and Explanations
==========================================
*/

import type { ReactNode } from 'react';
import type { EntitlementKey } from './entitlements.js';

/**
 * Callback shape for the analytics integration. This is opt-in: consumers
 * without an analytics provider must be able to omit it, which is why the
 * analytics emission is a *optional-feature* requirement, not a ubiquitous one.
 */
export interface DeniedEvent {
  readonly entitlementKey: EntitlementKey;
  readonly reason: 'plan' | 'unknown-key' | 'service-5xx' | 'timeout';
  readonly mode: 'dev' | 'prod';
}

export interface ComplianceGateProps {
  /**
   * The content to render when the caller is entitled. Anything React can
   * render is acceptable; the gate does not inspect the children.
   */
  readonly children: ReactNode;

  /**
   * The key to check. Constrained to EntitlementKey via `keyof typeof`
   * inference so that passing an unknown key is a *compile-time* error,
   * not a runtime `undefined`.
   */
  readonly entitlementKey: EntitlementKey;

  /**
   * Rendered when access is denied. Defaults to `null`. `.Null` (rather than
   * `undefined`) makes "we decided to render nothing" explicit and
   * distinguishable from "the caller forgot to pass a fallback."
   */
  readonly fallback?: ReactNode | null;

  /**
   * Optional analytics callback. When omitted, the component is fully
   * functional but emits nothing.
   */
  readonly onDenied?: (event: DeniedEvent) => void;

  /**
   * Test-only override. In production this is derived from
   * `import.meta.env.PROD`; in tests it may be forced to either value to
   * exercise both branches of the fail-open / fail-closed requirement.
   */
  readonly devModeOverride?: boolean;
}

// Compile-time contract. A consumer who writes
//   <ComplianceGate entitlementKey="reports.export.xlsx">...</ComplianceGate>
// gets a red squiggle because "reports.export.xlsx" is not keyof ENTITLEMENTS.
type _UnknownKeyIsRejected = ComplianceGateProps['entitlementKey'] extends
  | 'reports.export.csv'
  | 'reports.export.pdf'
  | 'dashboard.custom_widgets'
  | 'audit.log.retention_365d'
  ? true
  : never;

// Force the assignment to be checked.
const _contract: _UnknownKeyIsRejected = true;
void _contract;
