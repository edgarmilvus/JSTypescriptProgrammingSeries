/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_the_interactive_challenge_drift_detection_under_p.ts
Description: Solutions and Explanations
==========================================
*/

// A minimal in-memory model of Tracey's interest graph. Vertices are
// requirements, impl references, and verify references; edges are the
// association of a reference to a requirement. The functions below are the
// queries the exercise asks you to reason through by hand.

export type Verb = 'impl' | 'verify';

export interface RequirementVertex {
  readonly kind: 'requirement';
  readonly uid: string;
  readonly version: number;
  readonly text: string;
}

export interface ReferenceVertex {
  readonly kind: 'reference';
  readonly verb: Verb;
  /** The UID the annotation names. */
  readonly targetUid: string;
  /** The version the annotation was written against. */
  readonly targetVersion: number;
  /** File and line where the annotation lives. */
  readonly location: string;
}

export interface Graph {
  readonly requirements: RequirementVertex[];
  readonly references: ReferenceVertex[];
}

// ---- Query functions, one per tracey query subcommand. ------------------

export function uncovered(g: Graph): RequirementVertex[] {
  // Requirements with zero impl references.
  const implTargets = new Set(
    g.references.filter((r) => r.verb === 'impl').map((r) => r.targetUid),
  );
  return g.requirements.filter((r) => !implTargets.has(r.uid));
}

export function untested(g: Graph): RequirementVertex[] {
  // Requirements with zero verify references.
  const verifyTargets = new Set(
    g.references.filter((r) => r.verb === 'verify').map((r) => r.targetUid),
  );
  return g.requirements.filter((r) => !verifyTargets.has(r.uid));
}

export function stale(g: Graph): ReferenceVertex[] {
  // References whose target version is lower than the requirement's current.
  const currentVersion = new Map(g.requirements.map((r) => [r.uid, r.version]));
  return g.references.filter((ref) => {
    const current = currentVersion.get(ref.targetUid);
    return current !== undefined && ref.targetVersion < current;
  });
}

export function validate(g: Graph): { errors: string[]; warnings: string[] } {
  const errors: string[] = [];
  const warnings: string[] = [];
  const knownUids = new Set(g.requirements.map((r) => r.uid));
  for (const ref of g.references) {
    if (!knownUids.has(ref.targetUid)) {
      errors.push(
        `Broken reference: ${ref.location} -> ${ref.targetUid} (no such requirement)`,
      );
    }
  }
  return { errors, warnings };
}

// ---- The four events, modeled as graph transitions. --------------------

const baseline: Graph = {
  requirements: [
    {
      kind: 'requirement',
      uid: 'NOTIFY-DEBOUNCE',
      version: 1,
      text: 'When a notification is triggered more than once within a 500ms window, emit only the first and suppress the rest.',
    },
  ],
  references: [
    {
      kind: 'reference',
      verb: 'impl',
      targetUid: 'NOTIFY-DEBOUNCE',
      targetVersion: 1,
      location: 'src/notify/debounce.ts:1',
    },
    {
      kind: 'reference',
      verb: 'verify',
      targetUid: 'NOTIFY-DEBOUNCE',
      targetVersion: 1,
      location: 'tests/notify/debounce.test.ts:5',
    },
  ],
};

// Event A: statement text changes 500ms -> 250ms, version NOT bumped.
// Tracey does not see "text changed without version bump" here unless the
// project runs `tracey pre-commit`, which compares staged spec text against
// the last committed version. In-graph, the only mechanical tell is that
// the reference's targetVersion still matches the requirement's version.
export function eventA_TextChangedNoBump(): { graph: Graph; detectedBy: string[] } {
  const graph: Graph = {
    ...baseline,
    requirements: baseline.requirements.map((r) => ({
      ...r,
      text: r.text.replace('500ms', '250ms'),
      // version deliberately unchanged
    })),
  };
  return {
    graph,
    // No query subcommand fires from this graph alone. Detection requires
    // `tracey pre-commit` against the staged diff, which is outside the graph.
    detectedBy: ['tracey pre-commit'],
  };
}

// Event B: UID rename NOTIFY-DEBOUNCE -> NOTIFY-DEBOUNCE-WINDOW.
// The requirement's uid changes; the code annotation still names the old one.
export function eventB_UidRenamedNoAnnotationUpdate(): {
  graph: Graph;
  detectedBy: string[];
} {
  const graph: Graph = {
    requirements: baseline.requirements.map((r) => ({
      ...r,
      uid: 'NOTIFY-DEBOUNCE-WINDOW',
    })),
    references: baseline.references, // still name NOTIFY-DEBOUNCE
  };
  return {
    graph,
    // `validate` reports broken references (the old UID is now unnameable).
    // `uncovered` and `untested` also fire, because the new UID has zero
    // references of either verb.
    detectedBy: ['validate', 'uncovered', 'untested'],
  };
}

// Event C: a second requirement is added with an impl but no verify.
export function eventC_MissingVerify(): { graph: Graph; detectedBy: string[] } {
  const graph: Graph = {
    requirements: [
      ...baseline.requirements,
      {
        kind: 'requirement',
        uid: 'NOTIFY-QUEUE',
        version: 1,
        text: 'The notification service shall enqueue outbound notifications in FIFO order.',
      },
    ],
    references: [
      ...baseline.references,
      {
        kind: 'reference',
        verb: 'impl',
        targetUid: 'NOTIFY-QUEUE',
        targetVersion: 1,
        location: 'src/notify/queue.ts:1',
      },
    ],
  };
  return {
    graph,
    detectedBy: ['untested'],
  };
}

// Event D: implementation file relocated to a nested folder. Annotation
// preserved. The include glob src/**/*.ts still matches the new path.
export function eventD_FileRelocated(): { graph: Graph; detectedBy: string[] } {
  const graph: Graph = {
    requirements: baseline.requirements,
    references: baseline.references.map((ref) =>
      ref.location === 'src/notify/debounce.ts:1'
        ? { ...ref, location: 'src/notify/internal/debounce.ts:1' }
        : ref,
    ),
  };
  return {
    graph,
    // Nothing fires. The graph is isomorphic to the baseline.
    detectedBy: [],
  };
}

// ---- A helper that a reviewer can eyeball to confirm shape. -------------

export interface GraphShape {
  readonly requirementUids: readonly string[];
  readonly implEdges: readonly string[]; // "REQ <- file:line"
  readonly verifyEdges: readonly string[];
}

export function shapeOf(g: Graph): GraphShape {
  return {
    requirementUids: g.requirements.map((r) => r.uid).sort(),
    implEdges: g.references
      .filter((r) => r.verb === 'impl')
      .map((r) => `${r.targetUid} <- ${r.location}`)
      .sort(),
    verifyEdges: g.references
      .filter((r) => r.verb === 'verify')
      .map((r) => `${r.targetUid} <- ${r.location}`)
      .sort(),
  };
}

// Shape is a *structural* projection: two graphs with the same shape but
// different vertex contents (e.g., Event A after remediation) attest that
// the graph changed without changing its topology.
export function shapeEqual(a: Graph, b: Graph): boolean {
  const sa = shapeOf(a);
  const sb = shapeOf(b);
  return JSON.stringify(sa) === JSON.stringify(sb);
}
