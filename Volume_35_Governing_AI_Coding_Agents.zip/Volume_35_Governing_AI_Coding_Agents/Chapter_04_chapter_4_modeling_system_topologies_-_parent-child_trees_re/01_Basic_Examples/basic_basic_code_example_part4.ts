/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// src/services/UsageRepository.ts
// r[impl BILL-001]
// r[impl BILL-001.1]

import { Pool } from "pg";
import { TenantContextError } from "../errors/TenantContextError";

/**
 * Row shape returned by the usage_records table.
 * @internal
 */
export interface UsageRow {
  tenant_id: string;
  seq: number;
  units: number;
  recorded_at: Date;
}

/**
 * Repository for tenant-scoped usage records.
 *
 * Requirement mapping (see docs/l3_low_level.sdoc):
 *  - BILL-001   : every read/write is tenant-scoped
 *  - BILL-001.1 : mutations without context throw
 */
export class UsageRepository {
  /**
   * @param pool A `pg` connection pool configured for the billing DB.
   */
  constructor(private readonly pool: Pool) {}

  /**
   * Record a batch of usage units for a tenant.
   *
   * Implements BILL-001.1: the first thing this method does is validate
   * that `tenantId` has been provided and is non-trivial. If not we throw
   * TenantContextError before we touch the pool.
   */
  async record(tenantId: string | undefined, units: number): Promise<void> {
    // r[impl BILL-001.1]: guard against missing tenant context
    if (!tenantId || tenantId.length < 8) {
      throw new TenantContextError(
        `tenant_id must be >= 8 characters, received: ${tenantId ?? "undefined"}`,
      );
    }

    // r[impl BILL-001]: always scope the write by tenant_id
    await this.pool.query(
      `INSERT INTO usage_records (tenant_id, seq, units, recorded_at)
       VALUES ($1, nextval($2), $3, NOW())`,
      [tenantId, `usage_seq_${tenantId}`, units],
    );
  }

  /**
   * Read all usage rows for a tenant.
   *
   * Implements BILL-001: the WHERE clause is mandatory and never omitted.
   */
  async listForTenant(tenantId: string): Promise<UsageRow[]> {
    // r[impl BILL-001]
    const result = await this.pool.query<UsageRow>(
      `SELECT tenant_id, seq, units, recorded_at
         FROM usage_records
        WHERE tenant_id = $1
        ORDER BY seq ASC`,
      [tenantId],
    );
    return result.rows;
  }
}
