/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

// src/messaging/UsageBroadcaster.ts
// r[impl BILL-001.2]

import { UsageRow } from "../services/UsageRepository";

/**
 * Broadcasts usage rows to downstream billing consumers.
 *
 * Requirement mapping:
 *  - BILL-001.2 : every outbound row carries a composite <tenant_id>:<seq> key
 */
export class UsageBroadcaster {
  /**
   * @param publish Low-level transport that pushes strings to the broker.
   */
  constructor(private readonly publish: (message: string) => Promise<void>) {}

  /**
   * Emit a single usage row as a broker message.
   *
   * Implements BILL-001.2: the composite key is computed here, in one
   * place, so that no downstream caller can forget the prefix.
   */
  async emit(row: UsageRow): Promise<void> {
    // r[impl BILL-001.2]: composite key ordering is contractual
    const compositeKey = `${row.tenant_id}:${row.seq}`;

    const payload = JSON.stringify({
      key: compositeKey,
      tenant_id: row.tenant_id,
      units: row.units,
      recorded_at: row.recorded_at.toISOString(),
    });

    await this.publish(payload);
  }
}
