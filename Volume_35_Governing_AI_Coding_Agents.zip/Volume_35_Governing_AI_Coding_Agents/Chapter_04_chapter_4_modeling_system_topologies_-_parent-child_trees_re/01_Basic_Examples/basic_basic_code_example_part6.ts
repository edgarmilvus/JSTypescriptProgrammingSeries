/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part6.ts
Description: Basic Code Example
==========================================
*/

// tests/UsageRepository.test.ts
// r[verify BILL-001]
// r[verify BILL-001.1]

import { describe, it, expect, vi } from "vitest";
import { UsageRepository } from "../src/services/UsageRepository";
import { TenantContextError } from "../src/errors/TenantContextError";

/**
 * A minimal in-memory implementation of the `pg` Pool interface
 * sufficient to satisfy UsageRepository during unit tests.
 */
function makeFakePool() {
  const calls: Array<{ sql: string; values: unknown[] }> = [];
  return {
    calls,
    query: vi.fn(async (sql: string, values: unknown[]) => {
      calls.push({ sql, values });
      return { rows: [] };
    }),
  };
}

describe("UsageRepository", () => {
  it("throws TenantContextError when tenantId is missing", async () => {
    // r[verify BILL-001.1]
    const pool = makeFakePool();
    const repo = new UsageRepository(pool as never);

    await expect(repo.record(undefined, 5)).rejects.toThrow(
      TenantContextError,
    );
    expect(pool.calls).toHaveLength(0);
  });

  it("scopes writes by tenant_id", async () => {
    // r[verify BILL-001]
    const pool = makeFakePool();
    const repo = new UsageRepository(pool as never);

    await repo.record("tenant_abcdef", 5);

    expect(pool.calls).toHaveLength(1);
    expect(pool.calls[0].values[0]).toBe("tenant_abcdef");
  });

  it("scopes reads by tenant_id", async () => {
    // r[verify BILL-001]
    const pool = makeFakePool();
    const repo = new UsageRepository(pool as never);

    await repo.listForTenant("tenant_abcdef");

    expect(pool.calls[0].sql).toContain("WHERE tenant_id = $1");
  });
});
