/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file refreshRotation.test.ts
 *
 * Verifies the requirements AUTH-002 and AUTH-003.
 */

import { describe, expect, it } from "vitest";
import {
  rotateRefreshToken,
  RefreshReuseError,
  type RefreshStore,
} from "../src/refreshRotation.js";

/**
 * In-memory refresh store standing in for Redis.
 */
function makeStore(): RefreshStore & { consumed: Set<string> } {
  const consumed = new Set<string>();
  const families = new Map<string, Set<string>>();
  return {
    consumed,
    async markConsumed(jti: string): Promise<void> {
      consumed.add(jti);
    },
    async isConsumed(jti: string): Promise<boolean> {
      return consumed.has(jti);
    },
    async revokeFamily(familyId: string): Promise<void> {
      const members = families.get(familyId) ?? new Set();
      for (const m of members) consumed.add(m);
      families.delete(familyId);
    },
    async put(jti: string, familyId: string): Promise<void> {
      const set = families.get(familyId) ?? new Set();
      set.add(jti);
      families.set(familyId, set);
    },
  };
}

describe("refresh token rotation (AUTH-002)", () => {
  // r[verify AUTH-002]
  // @relation(AUTH-002, role=Verifies, scope=function)
  it("mints a fresh refresh token on first consumption", async () => {
    const store = makeStore();
    const result = await rotateRefreshToken("jti-1", "family-A", store);
    expect(result.previousJti).toBe("jti-1");
    expect(result.nextJti).not.toBe("jti-1");
    expect(await store.isConsumed("jti-1")).toBe(true);
  });

  // r[verify AUTH-002]
  it("revokes the whole family on refresh reuse", async () => {
    const store = makeStore();
    await rotateRefreshToken("jti-1", "family-B", store);
    await expect(
      rotateRefreshToken("jti-1", "family-B", store),
    ).rejects.toBeInstanceOf(RefreshReuseError);
  });
});
