/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file tokenIssuer.ts
 *
 * Identity Service — Session Issuance.
 *
 * This module is the single source of truth for access-token minting.
 * Every exported function carries at least one requirement annotation
 * so that Tracey's coverage table attributes it back to the intent
 * graph in `docs/spec/services/auth-service.sdoc`.
 */

import { createSign } from "node:crypto";
import type { KeyLike } from "node:crypto";

/** A canonical, minimum-viable session descriptor. */
export interface SessionClaims {
  /** Subject — the authenticated principal's stable identifier. */
  readonly sub: string;
  /** Multi-tenant partition key. Never omit. */
  readonly tenantId: string;
  /** Issued-at, as a Unix epoch in seconds. */
  readonly iat: number;
  /** Absolute expiry, as a Unix epoch in seconds. */
  readonly exp: number;
  /** Unique token identifier, used for atomic revocation. */
  readonly jti: string;
}

/** Hard ceiling imposed by AUTH-001. Do not raise without a spec change. */
const MAX_TOKEN_TTL_SECONDS = 3_600;

/**
 * Mints a signed RS256 access token for the given principal.
 *
 * @remarks
 * The function performs three sequential safety checks before signing:
 * it verifies the caller-supplied tenant identifier is a non-empty
 * opaque string, it clips the requested TTL to the AUTH-001 ceiling,
 * and it rejects a missing `jti`. A failure in any check throws a
 * `SessionIssuanceError` and — critically — *does not write to the
 * audit ledger*, because PLAT-002 requires exactly one ledger entry
 * per acknowledged mutation.
 *
 * @param principal - The identity asserting a session.
 * @param privateKey - The RS256 private key from the rotating key ring.
 * @param requestedTtlSeconds - Caller's preference; clipped to 3600.
 * @returns A base64url-encoded JWT string.
 *
 * @throws SessionIssuanceError - On validation failure.
 */
// r[impl AUTH-001]
// @relation(AUTH-001, scope=function)
export function issueAccessToken(
  principal: Pick<SessionClaims, "sub" | "tenantId">,
  privateKey: KeyLike,
  requestedTtlSeconds: number,
): string {
  if (principal.tenantId.length === 0) {
    throw new SessionIssuanceError("missing tenant_id");
  }
  if (principal.sub.length === 0) {
    throw new SessionIssuanceError("missing sub");
  }

  const now = Math.floor(Date.now() / 1000);
  const ttl = Math.min(requestedTtlSeconds, MAX_TOKEN_TTL_SECONDS);
  const claims: SessionClaims = {
    sub: principal.sub,
    tenantId: principal.tenantId,
    iat: now,
    exp: now + ttl,
    jti: crypto.randomUUID(),
  };

  return encodeAndSignJwt(claims, privateKey);
}

/** Internal — do not call outside this module. */
function encodeAndSignJwt(claims: SessionClaims, key: KeyLike): string {
  const header = Buffer.from(JSON.stringify({ alg: "RS256", typ: "JWT" }))
    .toString("base64url");
  const body = Buffer.from(JSON.stringify(claims)).toString("base64url");
  const signingInput = `${header}.${body}`;

  const signer = createSign("RSA-SHA256");
  signer.update(signingInput);
  signer.end();
  const signature = signer.sign(key).toString("base64url");

  return `${signingInput}.${signature}`;
}

/** Stable, typed error class — callers switch on `kind`. */
export class SessionIssuanceError extends Error {
  public readonly kind = "SessionIssuanceError";
  public constructor(message: string) {
    super(message);
    this.name = "SessionIssuanceError";
  }
}
