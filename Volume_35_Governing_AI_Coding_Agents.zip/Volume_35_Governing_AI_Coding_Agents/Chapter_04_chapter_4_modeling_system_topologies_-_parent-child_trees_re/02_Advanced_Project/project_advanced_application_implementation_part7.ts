/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file refreshRotation.ts
 *
 * Implements the single-use refresh cycle mandated by AUTH-002.
 */

import { randomUUID } from "node:crypto";

/** Result of a successful rotation. */
export interface RotatedRefresh {
  readonly previousJti: string;
  readonly nextToken: string;
  readonly nextJti: string;
}

/** Pluggable store contract, satisfied by Redis in production. */
export interface RefreshStore {
  markConsumed(jti: string, familyId: string): Promise<void>;
  isConsumed(jti: string): Promise<boolean>;
  revokeFamily(familyId: string): Promise<void>;
  put(jti: string, familyId: string): Promise<void>;
}

/**
 * Consume an existing refresh token and mint its successor.
 *
 * @remarks
 * The critical security property here is *reuse detection*: if the
 * caller presents a refresh token whose `jti` has already been
 * consumed, the entire session family is revoked. This makes a
 * stolen-refresh-token attack self-limiting — the attacker and
 * the legitimate user cannot both use the token undetected.
 *
 * @param currentJti - The jti extracted from the presented token.
 * @param familyId - The session family this token belongs to.
 * @param store - The refresh store.
 * @returns The rotation result, or throws on reuse.
 */
// r[impl AUTH-002]
// @relation(AUTH-002, scope=function)
export async function rotateRefreshToken(
  currentJti: string,
  familyId: string,
  store: RefreshStore,
): Promise<RotatedRefresh> {
  if (await store.isConsumed(currentJti)) {
    await store.revokeFamily(familyId);
    throw new RefreshReuseError(currentJti, familyId);
  }

  await store.markConsumed(currentJti, familyId);

  const nextJti = randomUUID();
  await store.put(nextJti, familyId);

  return {
    previousJti: currentJti,
    nextToken: nextJti,
    nextJti,
  };
}

export class RefreshReuseError extends Error {
  public readonly kind = "RefreshReuseError";
  public constructor(
    public readonly previousJti: string,
    public readonly familyId: string,
  ) {
    super(`refresh reuse detected for family ${familyId}`);
    this.name = "RefreshReuseError";
  }
}
