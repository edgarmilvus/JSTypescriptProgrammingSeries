/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file webhookReceiver.ts
 *
 * Revenue Service — Webhook Consumption.
 *
 * This module has two requirement objects:
 *   1. It implements PLAT-002's audit obligation (via BILL-002).
 *   2. It derives the concrete verification routine from AUTH-010
 *      (via BILL-010).
 */

import { createHmac, timingSafeEqual } from "node:crypto";

/** The minimal shape we require from the request envelope. */
export interface InboundSessionWebhook {
  readonly rawBody: Buffer;
  readonly signatureHeader: string | undefined;
  readonly tenantId: string;
}

/** The pluggable audit sink. In production this is an append-only store. */
export interface AuditLedger {
  append(entry: {
    sub: string;
    verb: string;
    resourceUid: string;
    sequence: number;
  }): Promise<void>;
}

/** The pluggable secret resolver. */
export interface TenantSecretResolver {
  resolve(tenantId: string): Promise<string>;
}

/**
 * Verify that the `X-Helios-Signature` header matches the HMAC-SHA256
 * digest of the raw body under the tenant-scoped secret.
 *
 * @remarks
 * We deliberately use `timingSafeEqual` — a plain `===` here would
 * leak the digest prefix under a timing oracle attack. If the header
 * is missing, we short-circuit to HTTP 401 without ever invoking the
 * HMAC. If the digest is present but malformed (wrong length), we
 * also return 401 — never 500 — because leaking "you sent a bad
 * digest" vs. "you sent a missing digest" helps an attacker
 * fingerprint the system.
 *
 * @param webhook - The inbound payload.
 * @param secrets - The tenant secret resolver.
 * @returns `true` if and only if the request is authentic.
 *
 * @throws - Never throws. Signature mismatches are returned as `false`.
 */
// r[impl BILL-010]
// @relation(BILL-010, scope=function)
export async function verifySessionWebhookSignature(
  webhook: InboundSessionWebhook,
  secrets: TenantSecretResolver,
): Promise<boolean> {
  if (webhook.signatureHeader === undefined) {
    return false;
  }

  const secret = await secrets.resolve(webhook.tenantId);
  const expected = createHmac("sha256", secret)
    .update(webhook.rawBody)
    .digest("hex");

  const provided = webhook.signatureHeader.toLowerCase();

  if (provided.length !== expected.length) {
    return false;
  }

  return timingSafeEqual(
    Buffer.from(provided, "utf8"),
    Buffer.from(expected, "utf8"),
  );
}

/**
 * Process a session webhook, appending exactly one audit entry.
 *
 * @remarks
 * PLAT-002 requires the audit entry be appended *before* the
 * mutation is acknowledged. We honour that by awaiting the ledger
 * append and only then returning. If the append fails, we propagate
 * the error — better to retry than to acknowledge an unaudited
 * mutation.
 *
 * @param webhook - The inbound payload (already verified).
 * @param payload - The parsed body.
 * @param ledger - The audit sink.
 */
// r[impl BILL-001, BILL-002]
// @relation(BILL-001, BILL-002, scope=function)
export async function processSessionWebhook(
  webhook: InboundSessionWebhook,
  payload: { readonly sub: string; readonly resourceUid: string },
  ledger: AuditLedger,
): Promise<void> {
  const sequence = Date.now();
  await ledger.append({
    sub: payload.sub,
    verb: "session.webhook.received",
    resourceUid: payload.resourceUid,
    sequence,
  });

  // Downstream fan-out would continue here, but the mutation is
  // already durable because the ledger entry exists.
}
