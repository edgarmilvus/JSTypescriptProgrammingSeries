/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file auditDependency.ts
 *
 * Revenue Service — audit ledger adapter.
 *
 * This module *depends on* PLAT-002 — it does not implement it. If
 * PLAT-002 changes, this file must be re-reviewed, but no coverage
 * credit is earned by annotating it.
 */

import type { AuditLedger } from "./webhookReceiver.js";

/**
 * The production audit-ledger adapter, backed by an append-only
 * Postgres table with a row-level write policy.
 */
// r[depends PLAT-002]
// @relation(PLAT-002, role=Implements, scope=class)
export class PostgresAuditLedger implements AuditLedger {
  public constructor(private readonly pool: { query: Function }) {}

  public async append(entry: {
    sub: string;
    verb: string;
    resourceUid: string;
    sequence: number;
  }): Promise<void> {
    await this.pool.query(
      `INSERT INTO audit_ledger (sub, verb, resource_uid, sequence)
       VALUES ($1, $2, $3, $4)`,
      [entry.sub, entry.verb, entry.resourceUid, entry.sequence],
    );
  }
}
