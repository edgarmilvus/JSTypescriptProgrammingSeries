/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_partitioning_a_distributed_system_into_a_multi-do.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * scaffold-topology.ts
 * One-shot scaffold that materialises the multi-document intent graph
 * under docs/spec/. Kept as a script (not a template directory) because
 * the fingerprint comment at the top of README.md must be derived from
 * the same constants that generate the files — a drift-proof invariant.
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const specDir = "docs/spec";
mkdirSync(specDir, { recursive: true });
mkdirSync(".config/tracey", { recursive: true });

// --- Root: platform-wide invariants ---------------------------------------
const platform = `[DOCUMENT]
TITLE: Platform Invariants
PREFIX: PLT-

[[SECTION]]
TITLE: Platform Invariants

[REQUIREMENT]
UID: PLT-001
STATUS: Approved
TITLE: Durable Message Retention
STATEMENT: >>>
Every message accepted by the platform shall be recoverable from durable
storage for at least 30 days.
<<<

[REQUIREMENT]
UID: PLT-002
STATUS: Approved
TITLE: Transport Fabric Invariant
STATEMENT: >>>
The transport fabric shall preserve message ordering per partition.
<<<

[REQUIREMENT]
UID: PLT-003
STATUS: Approved
TITLE: Durability Layer Invariant
STATEMENT: >>>
The durability layer shall acknowledge a write only after the write is
fsynced to a quorum of replicas.
<<<

[REQUIREMENT]
UID: PLT-004
STATUS: Approved
TITLE: Access Layer Invariant
STATEMENT: >>>
The access layer shall authenticate every request before dispatching it
to the transport fabric.
<<<

[/SECTION]
`;

// --- Transport -------------------------------------------------------------
// Each requirement carries exactly one Parent edge to PLT-002.
const transport = `[DOCUMENT]
TITLE: Transport Fabric
PREFIX: TRP-

[[SECTION]]
TITLE: Transport Fabric

[REQUIREMENT]
UID: TRP-001
STATUS: Approved
TITLE: Partition Leader Uniqueness
STATEMENT: >>>
The transport fabric shall assign each partition to exactly one leader
at a time.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: PLT-002

[REQUIREMENT]
UID: TRP-002
STATUS: Approved
TITLE: Replication Factor
STATEMENT: >>>
The transport fabric shall replicate each partition to the configured
replication factor.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: PLT-002

[/SECTION]
`;

// --- Durability ------------------------------------------------------------
// DUR-002 carries two Parents: the retention invariant (PLT-001) and the
// durability invariant (PLT-003) — a cross-cut within a subsystem.
const durability = `[DOCUMENT]
TITLE: Durability Layer
PREFIX: DUR-

[[SECTION]]
TITLE: Durability Layer

[REQUIREMENT]
UID: DUR-001
STATUS: Approved
TITLE: Quorum Fsync
STATEMENT: >>>
The durability layer shall fsync each write to a quorum of replicas
before acknowledging the write.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: PLT-003

[REQUIREMENT]
UID: DUR-002
STATUS: Approved
TITLE: Retention Policy Enforcement
STATEMENT: >>>
The durability layer shall enforce the retention window specified by the
platform invariant.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: PLT-001
- TYPE: Parent
  VALUE: PLT-003

[/SECTION]
`;

// --- Access ----------------------------------------------------------------
// ACC-002 sits at the intersection of access and transport — the
// architecturally required cross-cutting node with two parents.
const access = `[DOCUMENT]
TITLE: Access Layer
PREFIX: ACC-

[[SECTION]]
TITLE: Access Layer

[REQUIREMENT]
UID: ACC-001
STATUS: Approved
TITLE: Token-Based Authentication
STATEMENT: >>>
The access layer shall validate JWT signatures using RS256 before
dispatching any request.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: PLT-004

[REQUIREMENT]
UID: ACC-002
STATUS: Approved
TITLE: Cross-Cutting Dispatch Ordering
STATEMENT: >>>
The access layer shall preserve client request ordering when forwarding
to the transport fabric, so that the per-partition ordering guaranteed
by the transport fabric is not violated by the access layer's dispatch.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: PLT-002
- TYPE: Parent
  VALUE: PLT-004

[/SECTION]
`;

writeFileSync(join(specDir, "platform.sdoc"), platform);
writeFileSync(join(specDir, "transport.sdoc"), transport);
writeFileSync(join(specDir, "durability.sdoc"), durability);
writeFileSync(join(specDir, "access.sdoc"), access);

// --- Tracey config ---------------------------------------------------------
const config = `@schema {id crate:tracey-config@1, cli tracey}

specs (
    {
        name platform
        include (docs/spec/**/*.sdoc)
        impls (
            {
                name rust
                include (crates/**/*.rs)
                exclude (target/**)
            }
            {
                name typescript
                include (packages/**/*.ts)
                exclude (node_modules/**)
                test_include (packages/**/*.test.ts)
            }
        )
    }
)
`;
writeFileSync(".config/tracey/config.styx", config);

// --- Fingerprint -----------------------------------------------------------
// Derived by walking the templates above, not copied. If a template
// changes, these numbers change with it and the assertion in the next
// exercise will trip.
const fingerprint = {
  requirements: 10, // PLT-001..004 + TRP-001,002 + DUR-001,002 + ACC-001,002
  parentEdges: 8,   // TRP×2, DUR-001, DUR-002×2, ACC-001, ACC-002×2
  leafRequirements: 6, // TRP-001,002, DUR-001,002, ACC-001,002
  multiParentRequirements: 2, // DUR-002, ACC-002
};

writeFileSync(
  join(specDir, "README.md"),
  `# Platform Spec Topology Fingerprint

\`\`\`json
${JSON.stringify(fingerprint, null, 2)}
\`\`\`

This fingerprint is generated by \`scaffold-topology.ts\`. Any diff
against these numbers is a topology change and must be reviewed
deliberately.
`,
);
