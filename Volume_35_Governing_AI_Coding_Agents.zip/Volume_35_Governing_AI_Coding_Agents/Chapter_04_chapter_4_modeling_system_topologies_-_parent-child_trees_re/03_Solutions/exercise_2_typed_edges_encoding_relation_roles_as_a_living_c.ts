/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_typed_edges_encoding_relation_roles_as_a_living_c.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * retype-edges.ts
 * One-shot migration: writes the shared grammar, rewires every
 * document to IMPORT_FROM_FILE, and rewrites each RELATIONS block with
 * the role that matches the requirement's intent. Idempotent — safe
 * to run repeatedly against a clean checkout.
 */
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const specDir = "docs/spec";

// --- Shared grammar --------------------------------------------------------
// Single source of truth. Never inlined into a document: if two documents
// declared their own RELATIONS set with the same element name, the index
// would treat them as compatible and a role assignment from one document
// could silently leak into the other.
const grammar = `[GRAMMAR]
ELEMENTS:
- TAG: REQUIREMENT
  FIELDS:
  - TITLE: UID
    TYPE: String
    REQUIRED: True
  - TITLE: STATUS
    TYPE: String
    REQUIRED: True
  - TITLE: TITLE
    TYPE: String
    REQUIRED: True
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
  - TITLE: RATIONALE
    TYPE: String
    REQUIRED: False
  - TITLE: COMMENT
    TYPE: String
    REQUIRED: False
  RELATIONS:
  - TYPE: Parent
    ROLE: Derives
    REVERSE_ROLE: DerivedBy
  - TYPE: Parent
    ROLE: Implements
    REVERSE_ROLE: ImplementedBy
  - TYPE: Parent
    ROLE: Verifies
    REVERSE_ROLE: VerifiedBy
`;

writeFileSync(join(specDir, "platform.sgra"), grammar);

// --- Per-document rewire ---------------------------------------------------
// Every document gets its grammar by reference. The path is relative to
// the project root (where tracey/sdoc are invoked).
const importStanza = `[GRAMMAR]
IMPORT_FROM_FILE: docs/spec/platform.sgra
`;

// Role policy: this object encodes the editorial rule from the exercise.
// It is data, not logic, so it can be diffed and reviewed as content.
// Each entry is `UID -> ROLE` for its parent edges.
const rolePolicy: Record<string, "Derives" | "Implements" | "Verifies"> = {
  // TRP-* implement the transport invariant literally.
  "TRP-001": "Implements",
  "TRP-002": "Implements",
  // DUR-* implement the durability invariant; DUR-002 also derives from
  // the retention invariant because it narrows its scope to durability.
  "DUR-001": "Implements",
  "DUR-002": "Implements",
  // ACC-* are implementations of the access invariant, except ACC-002
  // which is a verification-flavoured cross-cut. It asserts that the
  // access layer preserves a property that the transport invariant
  // guarantees — the honest role is Verifies.
  "ACC-001": "Implements",
  "ACC-002": "Verifies",
};

// The rewrite: insert the IMPORT_FROM_FILE stanza immediately after the
// DOCUMENT header (before the first [[SECTION]]), and for every
// requirement, rewrite its Parent relations with an explicit ROLE.
function rewireDocument(path: string): void {
  const src = readFileSync(path, "utf8");
  const lines = src.split("\n");
  const out: string[] = [];

  let insideDocumentHeader = true;
  for (const line of lines) {
    if (insideDocumentHeader) {
      out.push(line);
      if (line.startsWith("PREFIX:")) {
        out.push("");
        out.push(importStanza.trimEnd());
        insideDocumentHeader = false;
      }
      continue;
    }
    out.push(line);
  }

  // Retype: for each `VALUE: <uid>` line, attach the ROLE for that UID.
  // The Parent edges are the only ones that carry a role in this grammar.
  const retyped = out.map((line) => {
    const m = line.match(/^(\s*)VALUE:\s*([A-Z]{3}-\d+)\s*$/);
    if (!m) return line;
    const role = rolePolicy[m[2]];
    if (!role) return line;
    // Preserve indentation; StrictDoc relies on the two-space value indent.
    return `${m[1]}VALUE: ${m[2]}\n${m[1]}ROLE: ${role}`;
  });

  writeFileSync(path, retyped.join("\n"));
}

for (const doc of ["platform.sdoc", "transport.sdoc", "durability.sdoc", "access.sdoc"]) {
  rewireDocument(join(specDir, doc));
}

// --- Code annotation pair --------------------------------------------------
// The cross-cutting requirement ACC-002 lives in a shared TypeScript
// module. The implementation annotation uses `role=Implements`
// (StrictDoc's uppercase spelling) because that is what the source-side
// relation carries. The Vitest test carries `role=Verifies` and lands
// under the `packages/**/*.test.ts` test_include glob.
const sharedModule = `
// @relation(ACC-002, scope=function, role=Implements)
export function dispatchPreservingOrder<T>(
  batch: readonly T[],
  send: (item: T) => Promise<void>,
): Promise<void> {
  return batch.reduce(
    (chain, item) => chain.then(() => send(item)),
    Promise.resolve(),
  );
}
`;

const vitestFile = `
import { describe, it, expect } from "vitest";
import { dispatchPreservingOrder } from "./dispatch";

// @relation(ACC-002, role=Verifies)
describe("dispatchPreservingOrder", () => {
  it("serialises sends so per-partition ordering is preserved", async () => {
    const seen: number[] = [];
    await dispatchPreservingOrder([1, 2, 3], async (n) => {
      seen.push(n);
    });
    expect(seen).toEqual([1, 2, 3]);
  });
});
`;

writeFileSync("packages/shared/src/dispatch.ts", sharedModule.trimStart());
writeFileSync("packages/shared/src/dispatch.test.ts", vitestFile.trimStart());
