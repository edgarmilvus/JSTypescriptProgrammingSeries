/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_the_topologydriftbadge_react_comp_part2.ts
Description: Solutions and Explanations
==========================================
*/

// packages/ui/src/tracey/TraceyClient.ts
import type {
  CoverageStatus,
  RequirementCoverage,
  RuleDetail,
  StaleRef,
} from "./types";

/**
 * Typed, transport-agnostic façade over Tracey's MCP tool surface.
 * Concrete implementations may speak stdio (Claude Code, Codex) or the
 * HTTP bridge (dashboard). Callers must not know which.
 */
export interface TraceyClient {
  getRule(uid: string): Promise<RuleDetail>;
  getStale(specImpl: string): Promise<StaleRef[]>;
  getStatus(specImpl: string): Promise<CoverageStatus>;
  /**
   * Convenience: aggregated coverage for one requirement in one
   * spec/impl pair. Implementations are free to cache.
   */
  getCoverage(uid: string, specImpl: string): Promise<RequirementCoverage>;
}

// --- Reference implementation speaking the MCP JSON-RPC envelope ----------
import type { RequirementCoverage as RC } from "./types";

interface JsonRpcRequest {
  jsonrpc: "2.0";
  id: number;
  method: "tools/call";
  params: { name: string; arguments: Record<string, unknown> };
}

interface JsonRpcResponse {
  jsonrpc: "2.0";
  id: number;
  result?: { content: Array<{ type: "text"; text: string }> };
  error?: { code: number; message: string };
}

/**
 * The MCP tool responses are human-readable prose. Parsing them is the
 * whole reason this class exists — everywhere else, the rest of the
 * system sees typed shapes.
 */
export class McpTraceyClient implements TraceyClient {
  private nextId = 1;

  constructor(private readonly send: (req: JsonRpcRequest) => Promise<JsonRpcResponse>) {}

  private async callTool<T>(
    name: string,
    args: Record<string, unknown>,
    parse: (text: string) => T,
  ): Promise<T> {
    const id = this.nextId++;
    const res = await this.send({
      jsonrpc: "2.0",
      id,
      method: "tools/call",
      params: { name, arguments: args },
    });
    if (res.error) throw new Error(`Tracey ${name}: ${res.error.message}`);
    const text = res.result?.content?.[0]?.text;
    if (typeof text !== "string") throw new Error(`Tracey ${name}: malformed response`);
    return parse(text);
  }

  async getRule(uid: string): Promise<RuleDetail> {
    return this.callTool("tracey_rule", { uid }, (text) => {
      // Contract: first line is the UID, following lines are references
      // of the form `<path>:<line> [<verb>]`. Parse defensively — a
      // malformed line is dropped, not thrown.
      const lines = text.split("\n").filter((l) => l.trim().length > 0);
      const references: RuleDetail["references"] = [];
      for (const line of lines.slice(1)) {
        const m = line.match(/^(.*?):(\d+)\s+\[(impl|verify|depends|related)\]/);
        if (m) references.push({ path: m[1], line: Number(m[2]), verb: m[3] as RuleDetail["references"][number]["verb"] });
      }
      return { uid, text: lines[0] ?? "", references };
    });
  }

  async getStale(specImpl: string): Promise<StaleRef[]> {
    return this.callTool("tracey_stale", { spec_impl: specImpl }, (text) =>
      text.split("\n")
        .map((line) => line.match(/^(.*?):(\d+)\s+(\S+)\s+v(\d+)->v(\d+)/))
        .filter((m): m is RegExpMatchArray => m !== null)
        .map((m) => ({
          uid: m[3],
          refPath: m[1],
          line: Number(m[2]),
          referencedVersion: Number(m[4]),
          currentVersion: Number(m[5]),
        })),
    );
  }

  async getStatus(specImpl: string): Promise<CoverageStatus> {
    return this.callTool("tracey_status", { spec_impl: specImpl }, (text) => {
      // Contract: a compact line `N total, I implemented, V verified, S stale`.
      const m = text.match(/(\d+)\s+total,\s*(\d+)\s+implemented,\s*(\d+)\s+verified,\s*(\d+)\s+stale/);
      if (!m) throw new Error("tracey_status: unrecognised response shape");
      return { specImpl, total: +m[1], implemented: +m[2], verified: +m[3], stale: +m[4] };
    });
  }

  async getCoverage(uid: string, specImpl: string): Promise<RC> {
    const [rule, stale] = await Promise.all([this.getRule(uid), this.getStale(specImpl)]);
    const implCount = rule.references.filter((r) => r.verb === "impl").length;
    const verifyCount = rule.references.filter((r) => r.verb === "verify").length;
    const staleCount = stale.filter((s) => s.uid === uid).length;
    let state: RC["state"];
    if (staleCount > 0) state = "drifting";
    else if (implCount > 0 && verifyCount > 0) state = "covered";
    else if (implCount > 0) state = "partial";
    else state = "partial"; // implemented nothing, verified nothing — treated as partial, not covered
    return { uid, specImpl, implCount, verifyCount, staleCount, state };
  }
}
