/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_the_topologydriftbadge_react_comp_part3.ts
Description: Solutions and Explanations
==========================================
*/

// packages/ui/src/components/TopologyDriftBadge.tsx
import { useEffect, useState } from "react";
import type { CoverageState, RequirementCoverage } from "../tracey/types";
import type { TraceyClient } from "../tracey/TraceyClient";

export interface TopologyDriftBadgeProps {
  uid: string;
  specImpl: string;
  client: TraceyClient;
}

type Machine =
  | { kind: "idle" }
  | { kind: "loading" }
  | { kind: "loaded"; coverage: RequirementCoverage }
  | { kind: "errored"; message: string };

const color: Record<CoverageState, string> = {
  covered: "#2e7d32",
  partial: "#ed6c02",
  drifting: "#d32f2f",
  unknown: "#757575",
};

export function TopologyDriftBadge({
  uid,
  specImpl,
  client,
}: TopologyDriftBadgeProps): JSX.Element {
  const [state, setState] = useState<Machine>({ kind: "idle" });

  useEffect(() => {
    // Supersession flag: if the effect cleanup runs, ignore the result
    // even if the promise resolves afterwards. Simpler and more
    // reliable than AbortController for non-fetch async work — the
    // MCP client speaks a stream, not a fetch, and cannot be aborted.
    let superseded = false;
    setState({ kind: "loading" });

    client
      .getCoverage(uid, specImpl)
      .then((coverage) => {
        if (superseded) return;
        setState({ kind: "loaded", coverage });
      })
      .catch((err: unknown) => {
        // Transport failure is "unknown", never "drifting".
        if (superseded) return;
        setState({ kind: "errored", message: err instanceof Error ? err.message : String(err) });
      });

    return () => {
      superseded = true;
    };
  }, [uid, specImpl, client]);

  const stateForRender: CoverageState =
    state.kind === "loaded"
      ? state.coverage.state
      : state.kind === "errored" || state.kind === "idle" || state.kind === "loading"
        ? "unknown"
        : "unknown";
  const label =
    state.kind === "loaded"
      ? `Requirement ${uid}: ${state.coverage.state} (impl ${state.coverage.implCount}, verify ${state.coverage.verifyCount}, stale ${state.coverage.staleCount})`
      : `Requirement ${uid}: coverage unknown`;

  return (
    <span
      data-testid="topology-drift-badge"
      role="status"
      aria-label={label}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        padding: "2px 6px",
        borderRadius: 4,
        background: color[stateForRender],
        color: "#fff",
        font: "12px/1.2 system-ui, sans-serif",
      }}
    >
      <span data-testid="topology-drift-badge-state">{stateForRender}</span>
    </span>
  );
}
