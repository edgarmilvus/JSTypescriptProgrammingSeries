/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_the_topologydriftbadge_react_comp_part4.tsx
Description: Solutions and Explanations
==========================================
*/

// packages/ui/src/components/TopologyDriftBadge.test.tsx
import { render, screen, waitFor, act } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { TopologyDriftBadge } from "./TopologyDriftBadge";
import type { TraceyClient } from "../tracey/TraceyClient";
import type { CoverageStatus, RequirementCoverage, RuleDetail, StaleRef } from "../tracey/types";

interface MockOptions {
  latencyByUid?: Record<string, number>;
  errorByUid?: Record<string, string>;
  staleByUid?: Record<string, StaleRef[]>;
}

class MockTraceyClient implements TraceyClient {
  public callCount = 0;
  constructor(
    private readonly coverageByUid: Record<string, RequirementCoverage>,
    private readonly opts: MockOptions = {},
  ) {}

  async getRule(uid: string): Promise<RuleDetail> {
    throw new Error("not used directly");
  }
  async getStale(): Promise<StaleRef[]> {
    return [];
  }
  async getStatus(specImpl: string): Promise<CoverageStatus> {
    return { specImpl, total: 0, implemented: 0, verified: 0, stale: 0 };
  }

  async getCoverage(uid: string, specImpl: string): Promise<RequirementCoverage> {
    this.callCount++;
    const latency = this.opts.latencyByUid?.[uid] ?? 0;
    if (latency > 0) await new Promise((r) => setTimeout(r, latency));
    const err = this.opts.errorByUid?.[uid];
    if (err) throw new Error(err);
    const base = this.coverageByUid[uid];
    if (!base) throw new Error(`no mock for ${uid}`);
    return { ...base, specImpl };
  }
}

const covered = (uid: string): RequirementCoverage => ({
  uid, specImpl: "platform/rust", implCount: 2, verifyCount: 1, staleCount: 0, state: "covered",
});
const partial = (uid: string): RequirementCoverage => ({
  uid, specImpl: "platform/rust", implCount: 1, verifyCount: 0, staleCount: 0, state: "partial",
});
const drifting = (uid: string): RequirementCoverage => ({
  uid, specImpl: "platform/rust", implCount: 3, verifyCount: 1, staleCount: 1, state: "drifting",
});

describe("TopologyDriftBadge", () => {
  it("renders unknown when the client rejects", async () => {
    const client = new MockTraceyClient({}, { errorByUid: { "REQ-A": "daemon unreachable" } });
    render(<TopologyDriftBadge uid="REQ-A" specImpl="platform/rust" client={client} />);
    await waitFor(() =>
      expect(screen.getByTestId("topology-drift-badge-state").textContent).toBe("unknown"),
    );
  });

  it("renders covered when impl > 0 and verify > 0 and stale === 0", async () => {
    const client = new MockTraceyClient({ "REQ-A": covered("REQ-A") });
    render(<TopologyDriftBadge uid="REQ-A" specImpl="platform/rust" client={client} />);
    await waitFor(() =>
      expect(screen.getByTestId("topology-drift-badge-state").textContent).toBe("covered"),
    );
  });

  it("renders partial when impl > 0 and verify === 0", async () => {
    const client = new MockTraceyClient({ "REQ-A": partial("REQ-A") });
    render(<TopologyDriftBadge uid="REQ-A" specImpl="platform/rust" client={client} />);
    await waitFor(() =>
      expect(screen.getByTestId("topology-drift-badge-state").textContent).toBe("partial"),
    );
  });

  it("renders drifting when stale > 0, regardless of impl/verify", async () => {
    const client = new MockTraceyClient({ "REQ-A": drifting("REQ-A") });
    render(<TopologyDriftBadge uid="REQ-A" specImpl="platform/rust" client={client} />);
    await waitFor(() =>
      expect(screen.getByTestId("topology-drift-badge-state").textContent).toBe("drifting"),
    );
  });

  it("does not render REQ-A's state after REQ-B resolves, even when REQ-A resolves last", async () => {
    const client = new MockTraceyClient(
      { "REQ-A": covered("REQ-A"), "REQ-B": partial("REQ-B") },
      { latencyByUid: { "REQ-A": 50, "REQ-B": 5 } },
    );
    const { rerender } = render(
      <TopologyDriftBadge uid="REQ-A" specImpl="platform/rust" client={client} />,
    );
    rerender(<TopologyDriftBadge uid="REQ-B" specImpl="platform/rust" client={client} />);
    await waitFor(() =>
      expect(screen.getByTestId("topology-drift-badge-state").textContent).toBe("partial"),
    );
    // Wait past REQ-A's stale resolution; the badge must not flash "covered".
    await new Promise((r) => setTimeout(r, 100));
    expect(screen.getByTestId("topology-drift-badge-state").textContent).toBe("partial");
  });

  it("does not call the client during render", () => {
    const client = new MockTraceyClient({ "REQ-A": covered("REQ-A") });
    render(<TopologyDriftBadge uid="REQ-A" specImpl="platform/rust" client={client} />);
    expect(client.callCount).toBe(0);
  });

  it("unmounts cleanly when the effect resolves after unmount", async () => {
    const client = new MockTraceyClient(
      { "REQ-A": covered("REQ-A") },
      { latencyByUid: { "REQ-A": 30 } },
    );
    const { unmount } = render(
      <TopologyDriftBadge uid="REQ-A" specImpl="platform/rust" client={client} />,
    );
    unmount();
    await new Promise((r) => setTimeout(r, 60));
    // No assertion needed — vitest fails on setState-after-unmount warnings.
  });
});
