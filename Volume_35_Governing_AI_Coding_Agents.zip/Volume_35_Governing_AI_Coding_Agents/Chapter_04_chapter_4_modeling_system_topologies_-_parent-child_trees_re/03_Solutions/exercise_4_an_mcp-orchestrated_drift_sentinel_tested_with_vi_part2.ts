/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_an_mcp-orchestrated_drift_sentinel_tested_with_vi_part2.ts
Description: Solutions and Explanations
==========================================
*/

// packages/sentinel/src/TraceyClient.ts
import type { SentinelReport } from "./types";

export interface ValidationError {
  uid: string;
  refPath: string;
  line: number;
  reason: string;
}

export interface ValidationResult {
  errors: ValidationError[];
  warnings: ValidationError[];
}

export interface TraceyClient {
  config(): Promise<Array<{ spec: string; impl: string }>>;
  uncovered(specImpl: string): Promise<string[]>;
  untested(specImpl: string): Promise<string[]>;
  stale(specImpl: string): Promise<SentinelReport["stale"]>;
  unmapped(specImpl: string): Promise<string[]>;
  validate(specImpl: string): Promise<ValidationResult>;
}
