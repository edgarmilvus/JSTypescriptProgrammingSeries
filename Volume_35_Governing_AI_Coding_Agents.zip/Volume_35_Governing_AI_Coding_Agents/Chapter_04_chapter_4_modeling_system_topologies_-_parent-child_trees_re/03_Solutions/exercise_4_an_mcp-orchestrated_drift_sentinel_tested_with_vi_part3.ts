/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_an_mcp-orchestrated_drift_sentinel_tested_with_vi_part3.ts
Description: Solutions and Explanations
==========================================
*/

// packages/sentinel/src/sentinel.ts
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import type { SentinelReport, SentinelTransportError } from "./types";
import { SentinelTransportError as TransportError } from "./types";
import type { TraceyClient } from "./TraceyClient";

// Short-circuit reasoning: tracey_validate answers "is the graph
// itself well-formed?" Every other tool answers "given a well-formed
// graph, what is its coverage?" If the graph is malformed, the
// coverage numbers it computes are meaningless — a broken reference
// can hide a covered requirement by failing to resolve the edge that
// would have covered it. So we ask the structural question first and
// refuse to trust anything else until it comes back clean.
export async function runSentinel(
  client: TraceyClient,
  specImpl: string,
): Promise<SentinelReport> {
  const validation = await guard(client, "tracey_validate", () => client.validate(specImpl));

  if (validation.errors.length > 0) {
    return {
      generatedAt: new Date().toISOString(),
      specImpl,
      uncovered: [],
      untested: [],
      stale: [],
      unmapped: [],
      brokenReferences: validation.errors,
      drifted: true,
    };
  }

  const [uncovered, untested, stale, unmapped] = await Promise.all([
    guard(client, "tracey_uncovered", () => client.uncovered(specImpl)),
    guard(client, "tracey_untested", () => client.untested(specImpl)),
    guard(client, "tracey_stale", () => client.stale(specImpl)),
    guard(client, "tracey_unmapped", () => client.unmapped(specImpl)),
  ]);

  const drifted =
    uncovered.length > 0 || untested.length > 0 || stale.length > 0 || unmapped.length > 0;

  return {
    generatedAt: new Date().toISOString(),
    specImpl,
    uncovered,
    untested,
    stale,
    unmapped,
    brokenReferences: [],
    drifted,
  };
}

async function guard<T>(
  _client: TraceyClient,
  tool: string,
  fn: () => Promise<T>,
): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    // Wrap transport failure distinctly so callers can tell "daemon
    // unreachable" from "tool answered with bad news".
    throw new TransportError(tool, err);
  }
}

export interface WriteReportOptions {
  rootDir: string;
}

export function writeReport(report: SentinelReport, opts: WriteReportOptions): string {
  const target = join(opts.rootDir, ".tracey", "sentinel", "report.json");
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, JSON.stringify(report, null, 2) + "\n");
  return target;
}

export async function runSentinelForAllSpecImpls(
  client: TraceyClient,
): Promise<Map<string, SentinelReport>> {
  const pairs = await client.config();
  const out = new Map<string, SentinelReport>();
  for (const { spec, impl } of pairs) {
    const key = `${spec}/${impl}`;
    out.set(key, await runSentinel(client, key));
  }
  return out;
}
