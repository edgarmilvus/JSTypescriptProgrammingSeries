/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_an_mcp-orchestrated_drift_sentinel_tested_with_vi_part4.ts
Description: Solutions and Explanations
==========================================
*/

// packages/sentinel/src/sentinel.test.ts
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { runSentinel, runSentinelForAllSpecImpls, writeReport } from "./sentinel";
import { SentinelTransportError } from "./types";
import type { TraceyClient, ValidationResult } from "./TraceyClient";

/**
 * Scriptable mock: tests declare the exact response text each tool
 * returns and assert the exact order in which tools were called.
 * No network, no filesystem except where explicitly asserted.
 */
class ScriptedTraceyClient implements TraceyClient {
  public callOrder: string[] = [];
  constructor(
    private readonly script: {
      config?: Array<{ spec: string; impl: string }>;
      uncovered?: string[];
      untested?: string[];
      stale?: Array<{ uid: string; refPath: string; line: number; currentVersion: number; referencedVersion: number }>;
      unmapped?: string[];
      validate?: ValidationResult;
      failWith?: Partial<Record<keyof TraceyClient, Error>>;
    },
  ) {}

  private record(tool: string) {
    this.callOrder.push(tool);
  }
  private maybeFail(tool: keyof TraceyClient) {
    const err = this.script.failWith?.[tool];
    if (err) throw err;
  }

  async config() { this.record("config"); this.maybeFail("config"); return this.script.config ?? []; }
  async uncovered() { this.record("uncovered"); this.maybeFail("uncovered"); return this.script.uncovered ?? []; }
  async untested() { this.record("untested"); this.maybeFail("untested"); return this.script.untested ?? []; }
  async stale() { this.record("stale"); this.maybeFail("stale"); return this.script.stale ?? []; }
  async unmapped() { this.record("unmapped"); this.maybeFail("unmapped"); return this.script.unmapped ?? []; }
  async validate() { this.record("validate"); this.maybeFail("validate"); return this.script.validate ?? { errors: [], warnings: [] }; }
}

describe("runSentinel", () => {
  it("clean topology produces drifted === false", async () => {
    const client = new ScriptedTraceyClient({});
    const r = await runSentinel(client, "platform/rust");
    expect(r.drifted).toBe(false);
    expect(r.uncovered).toEqual([]);
    expect(r.brokenReferences).toEqual([]);
  });

  it("single uncovered requirement sets drifted === true and isolates the UID", async () => {
    const client = new ScriptedTraceyClient({ uncovered: ["ACC-002"] });
    const r = await runSentinel(client, "platform/rust");
    expect(r.drifted).toBe(true);
    expect(r.uncovered).toEqual(["ACC-002"]);
    expect(r.untested).toEqual([]);
    expect(r.stale).toEqual([]);
    expect(r.unmapped).toEqual([]);
  });

  it("populates stale entries with currentVersion and referencedVersion", async () => {
    const client = new ScriptedTraceyClient({
      stale: [{ uid: "DUR-001", refPath: "crates/durability/src/lib.rs", line: 42, currentVersion: 3, referencedVersion: 2 }],
    });
    const r = await runSentinel(client, "platform/rust");
    expect(r.drifted).toBe(true);
    expect(r.stale).toEqual([{ uid: "DUR-001", refPath: "crates/durability/src/lib.rs", line: 42, currentVersion: 3, referencedVersion: 2 }]);
  });

  it("short-circuits on validation error: subsequent tools are not called", async () => {
    const client = new ScriptedTraceyClient({
      validate: {
        errors: [{ uid: "ACC-002", refPath: "docs/spec/access.sdoc", line: 55, reason: "unknown parent PLT-005" }],
        warnings: [],
      },
      uncovered: ["ANY"],
    });
    const r = await runSentinel(client, "platform/rust");
    expect(r.drifted).toBe(true);
    expect(r.brokenReferences).toHaveLength(1);
    expect(r.brokenReferences[0].uid).toBe("ACC-002");
    expect(client.callOrder).toEqual(["validate"]);
    expect(client.callOrder).not.toContain("uncovered");
    expect(client.callOrder).not.toContain("stale");
  });

  it("surfaces both paths in a multi-line duplicate-UID error", async () => {
    // The mock returns a pre-split ValidationResult (the client is
    // responsible for parsing). The point of this test is that the
    // sentinel does not collapse the two entries into one.
    const client = new ScriptedTraceyClient({
      validate: {
        errors: [
          { uid: "PLT-002", refPath: "docs/spec/platform.sdoc", line: 15, reason: "duplicate UID" },
          { uid: "PLT-002", refPath: "docs/spec/transport.sdoc", line: 22, reason: "duplicate UID" },
        ],
        warnings: [],
      },
    });
    const r = await runSentinel(client, "platform/rust");
    expect(r.brokenReferences).toHaveLength(2);
    expect(r.brokenReferences.map((b) => b.refPath)).toEqual([
      "docs/spec/platform.sdoc",
      "docs/spec/transport.sdoc",
    ]);
  });

  it("throws SentinelTransportError when a tool call rejects, naming the tool", async () => {
    const client = new ScriptedTraceyClient({ failWith: { validate: new Error("ECONNREFUSED") } });
    await expect(runSentinel(client, "platform/rust")).rejects.toBeInstanceOf(SentinelTransportError);
    await expect(runSentinel(client, "platform/rust")).rejects.toThrow(/tracey_validate/);
  });

  it("does not throw for a well-formed but non-empty response", async () => {
    const client = new ScriptedTraceyClient({
      untested: ["DUR-001"],
      unmapped: ["crates/transport/src/lib.rs"],
    });
    await expect(runSentinel(client, "platform/rust")).resolves.toBeDefined();
  });
});

describe("writeReport", () => {
  let root: string;
  beforeEach(() => { root = mkdtempSync(join(tmpdir(), "sentinel-")); });
  afterEach(() => { rmSync(root, { recursive: true, force: true }); });

  it("writes and round-trips the report", async () => {
    const client = new ScriptedTraceyClient({ untested: ["DUR-001"] });
    const report = await runSentinel(client, "platform/rust");
    const path = writeReport(report, { rootDir: root });
    const parsed = JSON.parse(readFileSync(path, "utf8"));
    expect(parsed).toEqual(report);
  });
});

describe("runSentinelForAllSpecImpls", () => {
  it("returns one report per configured spec/impl, only one drifted", async () => {
    // The mock fabricates a config with two impls; the uncovered list is
    // only populated for the first one via a scripted dispatch.
    const client = new ScriptedTraceyClient({
      config: [
        { spec: "platform", impl: "rust" },
        { spec: "platform", impl: "typescript" },
      ],
    });
    // Override uncovered to drift only for rust:
    const original = client.uncovered.bind(client);
    vi.spyOn(client, "uncovered").mockImplementation(async (specImpl: string) =>
      specImpl === "platform/rust" ? ["ACC-002"] : original(specImpl),
    );
    const reports = await runSentinelForAllSpecImpls(client);
    expect(reports.size).toBe(2);
    expect(reports.get("platform/rust")?.drifted).toBe(true);
    expect(reports.get("platform/typescript")?.drifted).toBe(false);
  });
});
