<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_4_an_mcp-orchestrated_drift_sentinel_tested_with_vi_part5.md
Description: Solutions and Explanations
==========================================
-->

<!-- docs/governance/ci-gate.md — the design document is the deliverable.
     No TypeScript or Styx is written in this challenge. The code block
     below contains the document's raw prose so that it can be reviewed
     as a single artifact. -->

# CI Gate for the Platform Intent Graph

## Reporting Contract

The gate emits a single JSON object to stdout on completion, and the same
object is written to `.tracey/gate/report.json`. Every field is
enumerated here with its type and its determinism class:

| Field             | Type                                                        | Deterministic |
|-------------------|-------------------------------------------------------------|---------------|
| `schemaVersion`   | `1`                                                         | yes           |
| `generatedAt`     | ISO 8601 string                                             | no            |
| `scope`           | `{ mode: "full" \| "specImpl"; specImpl?: string }`         | yes           |
| `sentinel`        | `SentinelReport` (from Exercise 4)                          | yes except `generatedAt`, which is redacted here |
| `severities`      | `{ [dimension: DriftDimension]: "block" \| "allow" }`       | yes           |
| `preconditions`   | `Array<{ name: string; passed: boolean; detail: string }>`  | yes except `detail` strings embedded from tool output |
| `outcome`         | `"clean" \| "soft-allowed" \| "soft-blocked" \| "hard-failure" \| "partial-scope"` | yes |
| `refusal`         | `RefusalPayload \| null`                                    | yes           |

The only permitted nondeterminism before exit is `generatedAt`. Every
other field is a pure function of the repository state and the gate
config. This is enforced by a pre-emit normalisation step that:

- sorts `sentinel.uncovered`, `sentinel.untested`, `sentinel.unmapped`
  lexicographically;
- sorts `sentinel.stale` by `(refPath, line, uid)`;
- sorts `sentinel.brokenReferences` by `(refPath, line, uid, reason)`;
- sorts each `preconditions` entry by `name`;
- redacts any absolute paths to repository-relative paths before
  serialisation, so two developers running the gate on different
  checkouts of the same commit produce byte-identical reports.

## Severity Model

Drift is not one thing. The gate recognises two severities:

**Hard.** A validation error from `tracey_validate`. The graph is
malformed — a duplicate UID, an unknown parent, a broken reference, or a
round-trip mismatch from the StrictDoc precondition. Hard failures block
merge unconditionally. They are not configurable, because a malformed
graph means every downstream number is untrustworthy, and making that
severity configurable would let a team turn off the one check that keeps
the graph well-formed.

**Soft.** Everything else: `uncovered`, `untested`, `stale`, `unmapped`.
These are advisory by default and become blocking only when the gate
config enables them per-dimension. They are configurable because the
right posture varies by phase: a greenfield project legitimately merges
with uncovered requirements, while a release branch must not.

### Worked example — soft drift allowed

A team on `main` at the start of a sprint. `durability.sdoc` gains
`DUR-003` describing a future migration. It is uncovered (`uncovered:
["DUR-003"]`, no impl annotation yet). The gate config for `main`:

\`\`\`styx
gate (
    scope full
    severities (
        uncovered allow
        untested  allow
        stale     block
        unmapped  allow
    )
)
\`\`\`

The sentinel returns `drifted: true` (uncovered is non-empty). The gate
reports `outcome: "soft-allowed"` and exits with the "allowed" code.
Merge proceeds. The report is archived for the next sprint review.

### Worked example — soft drift blocked

Same repository, but the branch is `release/2026.09`. The gate config
for the release branch is stricter:

\`\`\`styx
gate (
    scope full
    severities (
        uncovered block
        untested  block
        stale     block
        unmapped  block
    )
)
\`\`\`

The same `DUR-003` uncovered entry now causes
`outcome: "soft-blocked"`. The gate emits the refusal payload with the
UID `DUR-003` and the dimension `uncovered`. Merge is blocked. The
developer must either add an `impl` annotation to the code that
implements the new requirement, or move the requirement to a different
scope by editing the gate config on the release branch (a deliberate,
reviewed act, not an accident).

## Scope Resolution

The gate accepts `--scope full` (default) or `--scope <spec>/<impl>`.
The trap this avoids: `platform.sdoc` is a single document, but a change
to a `STATEMENT` in it changes the *meaning* of every subsystem
requirement that has a `Parent` edge to the changed node. A naive
scope resolver that maps "file changed" → "document scope" would declare
platform.sdoc's change to be a root-only change.

### Algorithm

1. **Map the request to a spec/impl pair set.** Full scope enumerates
   every pair from `tracey_config`. Explicit scope resolves to exactly
   one pair.

2. **Expand the pair set along incoming `Parent` edges.** For each pair
   `P`, find every requirement in any other pair whose `Parent` chain
   terminates at a node in `P`. `P`'s scope is the transitive closure
   of pairs that depend on it. A change to `platform/rust` therefore
   pulls in `transport/rust`, `durability/rust`, and `access/rust`
   because every subsystem requirement cites a parent in the platform
   document.

3. **Union with the requested scope.** Explicit scope never *narrows*
   the set below what the closure requires; it is a floor, not a ceiling.

4. **Sentinel per pair.** Run `runSentinel(client, pair)` for each pair
   in the resolved set, per Exercise 4.

5. **Mark partial only when the request was narrower than full and the
   closure did not expand to full.** A request for `platform/rust` that
   expands to all pairs is *not* partial — it is a full result under a
   narrower pretext. `outcome: "partial-scope"` fires only when the
   closure is genuinely a strict subset of the configured pairs.

### Worked example

Four documents: `platform.sdoc`, `transport.sdoc`, `durability.sdoc`,
`access.sdoc`. The user requests `--scope platform/rust`. `PLT-002`
(the transport invariant) has three children: `TRP-001`, `TRP-002`,
and the cross-cutting `ACC-002`. `PLT-003` has two: `DUR-001`,
`DUR-002`. `PLT-004` has two: `ACC-001`, `ACC-002`. `PLT-001` has one:
`DUR-002`. Every subsystem has at least one requirement pointing at
a platform node, so the closure is all four documents. The gate reports
under `scope.mode = "full"` even though the command line said
`platform/rust`. If instead the user had requested `--scope access/rust`
and `access.sdoc` had no requirement pointing at a durability node, the
closure would be `{access, transport}` (because `ACC-002` points at
`PLT-002`), and the outcome would be `partial-scope`.

## Exit Codes

| Outcome                             | Exit Code | Blocking | Report Field That Corresponds |
|-------------------------------------|-----------|----------|-------------------------------|
| Clean                               | 0         | no       | `outcome: "clean"`             |
| Soft drift, allowed by config       | 10        | no       | `outcome: "soft-allowed"`      |
| Soft drift, blocked by config       | 20        | yes      | `outcome: "soft-blocked"`      |
| Hard failure                        | 30        | yes      | `outcome: "hard-failure"`      |
| Partial scope, outcome mirrors base | 40 + base | yes if base blocks | `outcome: "partial-scope"` combined with a base outcome |

**Why these codes.** Clean is `0` because CI systems universally treat
`0` as success and any other code as failure; a clean run must be
indistinguishable from any other successful command. Soft-allowed is
`10` — deliberately non-zero. If soft-allowed were `0`, an operator
reading only exit codes could not tell "we ran the gate and it was
clean" from "we ran the gate and it found drift that the config
elected to allow." Those two facts are operationally different: the
first means the intent graph matches the code, the second means it does
not but the team has agreed to defer. The distinction must survive any
log loss.

Soft-blocked is `20`, one decade above soft-allowed, because the two
share a dimension (`soft`) but differ in the block decision. Hard
failure is `30` — strictly above both soft codes, so a shell operator
can distinguish "fail for a business reason" from "fail because the
graph is broken" with a simple `if [ $code -ge 30 ]` test.

Partial scope uses `40 + base`, where `base` is the exit code the same
outcome would have produced under full scope. This encodes both
dimensions — the outcome and the fact that it was scoped — in a single
integer. A caller that cares only about the *outcome* can read `code %
10`; a caller that cares about scope can read `code >= 40`. When a
sixth outcome is added later, it takes the next available decade
(`50+`) and inherits the same strategy of encoding scope as an
offset rather than overloading the base code.

**Why not overload a single code with two meanings.** The temptation is
to reuse `0` for soft-allowed on the grounds that "nothing the operator
needs to act on." That failure mode is well documented in CI systems:
a run that passed with drift becomes indistinguishable from a run that
passed clean, the drift is never mentioned in the on-call handoff, and
the graph rots silently. A distinct code is a small price for a durable
signal. Similarly, hard-failure is not folded into soft-blocked because
they require different remediations: soft-blocked is fixed by
implementing code or by adding a test, hard-failure is fixed by
repairing the spec graph itself.

## Agent Handshake

The gate assumes the agent was set up with `tracey ai` and has the skill
installed at `~/.claude/skills/tracey`. The handshake is a two-message
protocol over the gate's stdin/stdout when invoked with
`--agent-mode`.

**Message 1 — Gate → Agent (announce).** Before doing any work, the
gate emits a single-line JSON object on stdout:

\`\`\`json
{"type":"gate.expectations","severities":{"uncovered":"allow","untested":"allow","stale":"block","unmapped":"allow"},"preconditions":["strictdoc_roundtrip"],"schemaVersion":1}
\`\`\`

This tells the agent, in machine-readable form, what the gate will check
and what it will refuse. The agent is expected to run the same
preconditions locally (via `strictdoc export --formats=sdoc --check` and
`tracey query validate`) against its own working tree, and to fix any
drift it can before requesting the gate. This is a courtesy, not a
substitute for the gate — the gate re-runs everything.

**Message 2 — Gate → Agent (verdict).** On completion, the gate emits
on stdout:

\`\`\`json
{"type":"gate.verdict","outcome":"soft-blocked","exitCode":20,"refusal":{"dimension":"stale","uid":"DUR-001","refPath":"crates/durability/src/lib.rs","line":42,"currentVersion":3,"referencedVersion":2,"hint":"update the code to satisfy the +3 requirement text, then bump the annotation to r[impl DUR-001+3]"}}
\`\`\`

**Refusal payload.** On any blocking outcome, `refusal` is non-null.
It carries exactly five fields:

- `dimension` — the drift dimension being refused (`uncovered`,
  `untested`, `stale`, `unmapped`, or `validation-error`).
- `uid` — the requirement UID in question, when applicable; a synthetic
  string for validation errors that have no single UID.
- `refPath` — the file the agent must look at. Repository-relative.
- `line` — a 1-based line hint, best-effort; `0` when the drift is not
  line-locatable.
- `hint` — a single sentence instructing the *general class* of
  corrective action. The hint is generated from the dimension, not from
  the tool output, so it is stable across runs.

The agent is expected to use the payload as follows: on `stale`, read
the current requirement text via `tracey_rule`, update the named code
site, and bump the annotation. On `uncovered`, either add an `impl`
annotation or annotate a test with `verify` (if the requirement is a
verification-only requirement). On `untested`, add a `verify`
annotation. On `unmapped`, either add a requirement reference to the
file or add it to an `exclude` glob via `tracey_config_exclude` if the
file is genuinely out of scope. On `validation-error`, the agent must
not attempt to fix the graph automatically — it must surface the error
to a human, because graph-shape changes are a design act, not a
mechanical patch.

**Message direction and mutability.** Both messages are gate → agent
only. The agent does not reply on the same stream — it acts, then
re-invokes the gate. This keeps the protocol stateless and idempotent:
invoking the gate twice on the same repository state produces the same
verdict, so an agent that operates in a loop will converge rather than
oscillate.

## Preconditions

Before the first Tracey tool call, the gate runs exactly two commands
in this order:

1. **`strictdoc export . --formats=sdoc --output /tmp/gate-roundtrip`**
   followed by a byte-level diff of the output tree against the input
   tree. This is Exercise 4's data-integrity requirement applied as a
   gate. It catches the class of drift where the in-memory model of a
   document has diverged from its on-disk representation — for example,
   a document edited by a tool that produced a structurally valid but
   semantically lossy write. Tracey reads the on-disk files, so without
   this precondition the gate would be validating a state that no
   writer agrees with. A round-trip mismatch is a hard failure.

2. **`tracey query validate --deny warnings`** invoked via the MCP
   server as the `tracey_validate` tool. (This is technically the
   sentinel's first call, but it is listed here as a precondition
   because the gate treats it as structurally prior to all coverage
   queries.) The gate fails fast on any validation error, before
   calling `tracey_uncovered`, `tracey_untested`, `tracey_stale`, or
   `tracey_unmapped`. This is the same short-circuit as Exercise 4,
   restated for the gate's contract.

If either precondition fails, the gate emits `outcome: "hard-failure"`
with `exitCode: 30` and a `preconditions` array listing the failing
precondition by name. No tracey coverage tool is called. No
scope-resolution step runs. The refusal payload names
`dimension: "validation-error"` (for the validate precondition) or
`dimension: "roundtrip-mismatch"` (for the StrictDoc precondition),
and the `hint` field instructs the agent to stop and request human
review.

The ordering is non-negotiable: the round-trip precondition runs first
because a document whose on-disk form is unstable will produce
different validation output on consecutive runs. Running validate
first would let an unstable document slip past — validate would pass
on one read of the file and fail on the next, and the gate would
report a spurious clean run in between. Running the round-trip check
firsts guarantees the file the gate validates is the file the gate
sees on every subsequent read.
