/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

/**
 * Trial lifecycle and account-identifier helpers for the saas-trial service.
 * Every exported symbol carries a `r[impl <req.id>]` annotation so the
 * Tracey daemon can bind it to a normative statement in docs/spec/.
 */

// r[impl account.email.normalize]
/**
 * Canonicalize a raw email address for storage and comparison.
 *
 * @param raw - The user-supplied email string.
 * @returns The trimmed, lower-cased email string.
 */
export function normalizeEmail(raw: string): string {
  return raw.trim().toLowerCase();
}

/** Duration of the default trial, in days. */
// r[impl trial.duration.default]
export const TRIAL_DAYS = 14;

/** A trial started at a specific instant and ending at another. */
export interface Trial {
  startedAt: Date;
  endsAt: Date;
}

/**
 * Begin a trial that starts at the provided instant.
 *
 * @param now - The instant at which the account was created.
 * @returns A {@link Trial} that ends exactly fourteen days later.
 */
// r[impl trial.duration.default]
export function beginTrial(now: Date): Trial {
  const endsAt = new Date(now.getTime());
  endsAt.setUTCDate(endsAt.getUTCDate() + TRIAL_DAYS);
  return { startedAt: new Date(now.getTime()), endsAt };
}

/**
 * Whether write access should be permitted at the given instant.
 *
 * @param trial - The trial whose window to evaluate.
 * @param now   - The instant to test against the trial window.
 * @returns True when `now` precedes `trial.endsAt`, false otherwise.
 */
// r[impl trial.expiry.enforced]
export function isWriteAllowed(trial: Trial, now: Date): boolean {
  return now.getTime() < trial.endsAt.getTime();
}
