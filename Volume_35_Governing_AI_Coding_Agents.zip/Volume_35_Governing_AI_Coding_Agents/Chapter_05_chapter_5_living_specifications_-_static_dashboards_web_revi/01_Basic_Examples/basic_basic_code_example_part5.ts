/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

import { describe, it, expect } from "vitest";
import {
  normalizeEmail,
  beginTrial,
  isWriteAllowed,
  TRIAL_DAYS,
} from "../src/trial";

// r[verify account.email.normalize]
describe("normalizeEmail", () => {
  it("trims whitespace and lower-cases the input", () => {
    expect(normalizeEmail("  Alice@Example.COM  ")).toBe("alice@example.com");
  });

  it("is idempotent", () => {
    const once = normalizeEmail("Bob@Example.com");
    expect(normalizeEmail(once)).toBe(once);
  });
});

// r[verify trial.duration.default]
describe("beginTrial", () => {
  it("produces a window of exactly TRIAL_DAYS days", () => {
    const start = new Date("2025-01-01T00:00:00Z");
    const { startedAt, endsAt } = beginTrial(start);
    const deltaDays = (endsAt.getTime() - startedAt.getTime()) / 86_400_000;
    expect(deltaDays).toBe(TRIAL_DAYS);
  });

  it("starts at the exact instant it is called", () => {
    const start = new Date("2025-06-15T12:34:56Z");
    const { startedAt } = beginTrial(start);
    expect(startedAt.getTime()).toBe(start.getTime());
  });
});

// r[verify trial.expiry.enforced]
describe("isWriteAllowed", () => {
  it("permits writes inside the trial window", () => {
    const start = new Date("2025-01-01T00:00:00Z");
    const trial = beginTrial(start);
    const justBefore = new Date(trial.endsAt.getTime() - 1);
    expect(isWriteAllowed(trial, justBefore)).toBe(true);
  });

  it("denies writes the millisecond the trial elapses", () => {
    const start = new Date("2025-01-01T00:00:00Z");
    const trial = beginTrial(start);
    expect(isWriteAllowed(trial, trial.endsAt)).toBe(false);
  });
});
