/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part7.ts
Description: Basic Code Example
==========================================
*/

import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { NextResponse } from "next/server";

const run = promisify(execFile);

/**
 * GET /api/review
 *
 * Runs `tracey query validate --deny warnings` in the project root and maps
 * the outcome to a JSON envelope that the review UI (or a GitHub Action)
 * can consume as an approval gate.
 *
 * @returns 200 with `{ approved: true }` when validation is clean,
 *          422 with `{ approved: false, reason: string }` otherwise,
 *          500 when the CLI itself could not be launched.
 */
export async function GET() {
  try {
    await run("tracey", ["query", "validate", "--deny", "warnings"], {
      cwd: process.cwd(),
      timeout: 30_000,
      maxBuffer: 8 * 1024 * 1024,
    });
    return NextResponse.json({ approved: true });
  } catch (error) {
    const detail = error as NodeJS.ErrnoException & {
      stdout?: string;
      stderr?: string;
      code?: number | string;
    };

    // ENOENT ⇒ the CLI is not installed (see pitfalls).
    if (detail.code === "ENOENT") {
      return NextResponse.json(
        { approved: false, reason: "tracey CLI not found on PATH" },
        { status: 500 },
      );
    }

    return NextResponse.json(
      {
        approved: false,
        reason: (detail.stdout ?? detail.stderr ?? String(detail)).trim(),
      },
      { status: 422 },
    );
  }
}
