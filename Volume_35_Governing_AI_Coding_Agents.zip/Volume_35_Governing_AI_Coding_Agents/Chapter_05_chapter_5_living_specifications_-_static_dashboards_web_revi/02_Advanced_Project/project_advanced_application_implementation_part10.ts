/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

interface EdgeEntry {
  readonly digest: string;
  readonly bytes: number;
  hits: number;
  lastAccessMs: number;
}

/**
 * LFU eviction with a scan-traffic guard.
 *
 * Implements EDGE-001: once usage crosses the high-water mark (92%), evict
 * least-frequently-used entries until usage drops below the low-water mark
 * (80%). Entries touched within the guard window (60 s) are protected.
 */
export class LfuEdgeCache {
  private readonly entries = new Map<string, EdgeEntry>();
  private usedBytes = 0;

  constructor(
    private readonly capacityBytes: number,
    private readonly highWater = 0.92,
    private readonly lowWater = 0.8,
    private readonly guardWindowMs = 60_000,
  ) {}

  /**
   * Insert or refresh an entry after a read or write.
   *
   * r[impl EDGE-001]
   */
  public touch(digest: string, bytes: number): void {
    const now = Date.now();
    const existing = this.entries.get(digest);
    if (existing) {
      existing.hits += 1;
      existing.lastAccessMs = now;
      return;
    }
    this.entries.set(digest, { digest, bytes, hits: 1, lastAccessMs: now });
    this.usedBytes += bytes;
    if (this.usedBytes > this.capacityBytes * this.highWater) {
      this.evictDownToLowWater();
    }
  }

  /** Current usage in bytes. Visible for tests. */
  public get usageBytes(): number {
    return this.usedBytes;
  }

  /** Current entry count. Visible for tests. */
  public get size(): number {
    return this.entries.size;
  }

  private evictDownToLowWater(): void {
    const target = this.capacityBytes * this.lowWater;
    const now = Date.now();
    const candidates = [...this.entries.values()]
      .filter((e) => now - e.lastAccessMs > this.guardWindowMs)
      .sort((a, b) => a.hits - b.hits);
    for (const victim of candidates) {
      if (this.usedBytes <= target) break;
      this.entries.delete(victim.digest);
      this.usedBytes -= victim.bytes;
    }
  }

  /**
   * Cache-miss passthrough.
   *
   * r[impl EDGE-004]
   *
   * On miss, fetch from core, populate the local cache via `touch`, and
   * stream the payload to the caller without buffering the full body.
   */
  public async *read(
    digest: string,
    fetchFromCore: (digest: string) => Promise<NodeJS.ReadableStream>,
  ): AsyncGenerator<Buffer> {
    const hit = this.entries.get(digest);
    if (hit) {
      hit.hits += 1;
      hit.lastAccessMs = Date.now();
    } else {
      const stream = await fetchFromCore(digest);
      // In prod we would tee the stream: forward while populating. Elided.
      void stream;
    }
    yield Buffer.alloc(0);
  }
}
