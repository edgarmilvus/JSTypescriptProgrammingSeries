/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part11.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * Shape of the coverage snapshot returned by the Tracey MCP bridge.
 */
export interface CoverageSnapshot {
  readonly totalRequirements: number;
  readonly coveredRequirements: number;
  readonly verifiedRequirements: number;
  readonly staleCount: number;
  readonly capturedAt: string;
}

/**
 * Thin wrapper over the Tracey MCP `tracey_status` tool.
 *
 * Implements ADMIN-001 and ADMIN-002: the admin dashboard polls this
 * client every 15 seconds and re-renders three numeric tiles plus a
 * conditional drift banner.
 */
export class CoverageApi {
  constructor(private readonly mcpEndpoint: string) {}

  /**
   * Fetch a fresh coverage snapshot.
   *
   * r[impl ADMIN-001]
   */
  public async snapshot(): Promise<CoverageSnapshot> {
    const response = await fetch(`${this.mcpEndpoint}/tools/tracey_status`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call" }),
    });
    if (!response.ok) {
      throw new Error(`coverage fetch failed: ${response.status}`);
    }
    const payload = (await response.json()) as { result: CoverageSnapshot };
    return payload.result;
  }

  /**
   * Decide whether the drift banner should be rendered.
   *
   * r[impl ADMIN-002]
   */
  public shouldShowDriftBanner(s: CoverageSnapshot): boolean {
    return s.staleCount > 0;
  }
}
