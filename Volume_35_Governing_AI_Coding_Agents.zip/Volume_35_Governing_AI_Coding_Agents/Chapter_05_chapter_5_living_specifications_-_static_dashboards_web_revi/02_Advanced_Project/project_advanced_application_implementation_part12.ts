/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { QuotaExceededError, SegmentStore } from "../../src/core/segment-store.js";

describe("SegmentStore", () => {
  let root: string;
  let store: SegmentStore;

  beforeEach(async () => {
    root = await mkdtemp(join(tmpdir(), "cacheorbit-"));
    store = new SegmentStore(root, 1);
  });

  afterEach(async () => {
    await rm(root, { recursive: true, force: true });
  });

  // r[verify CACHE-001]
  it("writes a segment and returns 'stored' on first call", async () => {
    const payload = Buffer.from("artifact-bytes");
    const outcome = await store.write("tenant-alpha", payload);
    expect(outcome).toBe("stored");
  });

  // r[verify CACHE-001]
  it("is idempotent: same digest returns 'idempotent'", async () => {
    const payload = Buffer.from("artifact-bytes");
    await store.write("tenant-alpha", payload);
    const second = await store.write("tenant-alpha", payload);
    expect(second).toBe("idempotent");
  });

  // r[verify CACHE-004]
  it("isolates tenants by namespace", async () => {
    const payload = Buffer.from("shared-bytes");
    await store.write("tenant-alpha", payload);
    const digest = store.digestOf(payload);
    await expect(store.read("tenant-beta", digest)).rejects.toThrow();
  });

  // r[verify CACHE-005]
  it("throws QuotaExceededError with byte triple", async () => {
    const err = await store
      .assertQuota("tenant-alpha", 1024, 512)
      .catch((e) => e);
    expect(err).toBeInstanceOf(QuotaExceededError);
    expect(err.currentBytes).toBe(0);
    expect(err.quotaBytes).toBe(512);
    expect(err.requestedBytes).toBe(1024);
  });
});
