/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part13.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it } from "vitest";
import { LfuEdgeCache } from "../../src/edge/lfu-eviction.js";

describe("LfuEdgeCache", () => {
  // r[verify EDGE-001]
  it("evicts least-frequently-used entries down to low-water", () => {
    const cache = new LfuEdgeCache(1_000, 0.92, 0.8, 0);
    for (let i = 0; i < 20; i++) {
      cache.touch(`seg-${i}`, 100);
    }
    expect(cache.usageBytes).toBeLessThanOrEqual(800);
  });

  // r[verify EDGE-001]
  it("protects recently-touched entries from eviction", () => {
    const cache = new LfuEdgeCache(1_000, 0.92, 0.8, 60_000);
    cache.touch("hot", 500);
    for (let i = 0; i < 10; i++) cache.touch(`cold-${i}`, 100);
    // 'hot' was just touched; the guard window keeps it resident.
    expect(cache.size).toBeGreaterThan(0);
  });
});
