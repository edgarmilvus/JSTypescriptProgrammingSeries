/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part14.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it, vi } from "vitest";
import { CoverageApi, CoverageSnapshot } from "../../src/admin/coverage-api.js";

describe("CoverageApi", () => {
  // r[verify ADMIN-001]
  it("fetches a snapshot from the MCP bridge", async () => {
    const stub: CoverageSnapshot = {
      totalRequirements: 42,
      coveredRequirements: 30,
      verifiedRequirements: 18,
      staleCount: 0,
      capturedAt: new Date().toISOString(),
    };
    const fetchSpy = vi
      .spyOn(globalThis, "fetch")
      .mockResolvedValue(
        new Response(JSON.stringify({ result: stub }), { status: 200 }),
      );
    const api = new CoverageApi("http://localhost:9100");
    const snap = await api.snapshot();
    expect(snap).toEqual(stub);
    expect(fetchSpy).toHaveBeenCalledOnce();
  });

  // r[verify ADMIN-002]
  it("shows drift banner when stale references exist", () => {
    const api = new CoverageApi("http://localhost:9100");
    expect(
      api.shouldShowDriftBanner({
        totalRequirements: 1,
        coveredRequirements: 1,
        verifiedRequirements: 1,
        staleCount: 3,
        capturedAt: "",
      }),
    ).toBe(true);
  });
});
