<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: project_advanced_application_implementation_part17.md
Description: Advanced Application Implementation
==========================================
-->

# Tracey Skill for CacheOrbit

You are governed by a formal Software Intent Graph via the Tracey MCP server.

## Mandatory workflow for every coding turn

1. Call `tracey_status` to observe current coverage across all four impls.
2. Call `tracey_uncovered --prefix CLI.` when working on the CLI fragment.
3. Call `tracey_rule <UID>` to retrieve the exact normative text before
   editing any code that touches an annotated function.
4. Ensure every implementation function carries `r[impl <UID>]` in its
   doc-comment and every test carries `r[verify <UID>]`.
5. Run `tracey_validate --deny warnings` before opening a PR.

## Never do

- Never add `r[impl ...]` to a file matched by `test_include`.
- Never bump a version suffix (`+N`) until the underlying implementation has
  been physically updated to match the new rule text.
- Never edit a requirement's STATEMENT without running `tracey bump`.
