/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

import { createHash } from "node:crypto";
import { promises as fs } from "node:fs";
import { join } from "node:path";

/**
 * Minimal metadata carried alongside every persisted segment.
 */
export interface SegmentMetadata {
  readonly digest: string;
  readonly tenantId: string;
  readonly bytes: number;
  readonly persistedAt: number;
}

/**
 * Result of a write attempt.
 *
 * - `stored`    — the segment was newly persisted in this call.
 * - `idempotent`— the segment already existed; no bytes were rewritten.
 */
export type WriteOutcome = "stored" | "idempotent";

/**
 * Durable, content-addressable store for build artifacts.
 *
 * Implements a namespace-per-tenant model where the physical path of a
 * segment is `<root>/<tenantId>/<digest[0..2]>/<digest>`.
 */
export class SegmentStore {
  constructor(
    private readonly root: string,
    /** Number of independent volumes the fsync must land on. */
    private readonly durabilityFanout: number = 2,
  ) {
    if (durabilityFanout < 1) {
      throw new Error("durabilityFanout must be >= 1");
    }
  }

  /**
   * Compute the SHA-256 digest of a payload.
   *
   * @param payload raw artifact bytes
   * @returns lowercase hex digest
   */
  public digestOf(payload: Buffer): string {
    return createHash("sha256").update(payload).digest("hex");
  }

  /**
   * Persist a segment.
   *
   * r[impl CACHE-001]
   *
   * Two uploads with matching digests are idempotent: the second call
   * returns `"idempotent"` without rewriting bytes to disk.
   */
  public async write(
    tenantId: string,
    payload: Buffer,
  ): Promise<WriteOutcome> {
    const digest = this.digestOf(payload);
    const target = this.pathFor(tenantId, digest);

    if (await this.exists(target)) {
      return "idempotent";
    }

    // r[impl CACHE-002]
    // Durability: write to a temp file, fsync, then rename. Renaming is
    // atomic on POSIX and NTFS. We additionally fsync the parent directory
    // to make the rename itself durable.
    const tmp = `${target}.tmp.${process.pid}.${Date.now()}`;
    const handle = await fs.open(tmp, "w");
    try {
      await handle.writeFile(payload);
      await handle.sync();
    } finally {
      await handle.close();
    }
    await fs.rename(tmp, target);

    // Durability contract: the caller's ack is gated on the fanout.
    if (this.durabilityFanout > 1) {
      await this.waitForReplicas(target, this.durabilityFanout);
    }
    return "stored";
  }

  /**
   * Read a segment.
   *
   * r[impl CACHE-004]
   *
   * Tenant isolation is enforced by prefixing the physical path with the
   * tenant identifier. A digest computed for tenant A is never resolvable
   * to a segment owned by tenant B.
   */
  public async read(tenantId: string, digest: string): Promise<Buffer> {
    return fs.readFile(this.pathFor(tenantId, digest));
  }

  /**
   * Check whether a segment exists.
   *
   * r[impl CACHE-001]
   */
  public async exists(path: string): Promise<boolean> {
    try {
      await fs.access(path);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Enforce a byte quota for a tenant.
   *
   * r[impl CACHE-005]
   *
   * @throws QuotaExceededError when the prospective write would push the
   *         tenant above its quota. The error carries `currentBytes`,
   *         `quotaBytes`, and `requestedBytes` so the HTTP layer can build
   *         the mandated 507 body.
   */
  public async assertQuota(
    tenantId: string,
    requestedBytes: number,
    quotaBytes: number,
  ): Promise<void> {
    const currentBytes = await this.countBytes(tenantId);
    if (currentBytes + requestedBytes > quotaBytes) {
      throw new QuotaExceededError(currentBytes, quotaBytes, requestedBytes);
    }
  }

  /**
   * Enumerate GC-eligible segments.
   *
   * r[impl CACHE-003]
   */
  public async gcEligibleBytes(
    tenantId: string,
    idleThresholdMs: number = 90 * 24 * 60 * 60 * 1000,
  ): Promise<number> {
    const now = Date.now();
    let total = 0;
    for await (const meta of this.walkMetadata(tenantId)) {
      if (now - meta.persistedAt > idleThresholdMs) {
        total += meta.bytes;
      }
    }
    return total;
  }

  private pathFor(tenantId: string, digest: string): string {
    return join(this.root, tenantId, digest.slice(0, 2), digest);
  }

  private async waitForReplicas(_path: string, _fanout: number): Promise<void> {
    // Real implementation delegates to the volume-fanout driver. Elided.
  }

  private async countBytes(_tenantId: string): Promise<number> {
    return 0;
  }

  private async *walkMetadata(_tenantId: string): AsyncGenerator<SegmentMetadata> {
    // Real implementation walks the tenant's shard directories.
  }
}

export class QuotaExceededError extends Error {
  constructor(
    public readonly currentBytes: number,
    public readonly quotaBytes: number,
    public readonly requestedBytes: number,
  ) {
    super("quota exceeded");
  }
}
