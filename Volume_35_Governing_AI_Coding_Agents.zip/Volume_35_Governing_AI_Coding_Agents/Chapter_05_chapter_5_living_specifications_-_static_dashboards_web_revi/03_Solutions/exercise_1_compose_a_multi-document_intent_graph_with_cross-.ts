/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_compose_a_multi-document_intent_graph_with_cross-.ts
Description: Solutions and Explanations
==========================================
*/

// scripts/bootstrap-workspace.ts
// Purpose: idempotently materialise the three-repo workspace, the composed
// .sdoc root, the Tracey config, and the verify.sh gate. Run from a clean
// checkout; the script is designed so running it twice is a no-op on an
// already-correct tree.
import { execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync, existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = process.cwd();

/** Write only if the file does not already exist, so re-runs are safe. */
function writeIfAbsent(path: string, contents: string): void {
  if (existsSync(path)) return;
  mkdirSync(join(path, '..'), { recursive: true });
  writeFileSync(path, contents, 'utf8');
}

// ---- 1. Sibling repositories -------------------------------------------------
// UIDs are uppercase + hyphenated so they honour StrictDoc's SDOC-SRS-22 regex
// ([A-Z0-9]+(?:[-_.][A-Z0-9]+)*). Auto-UID is deliberately NOT used: a UID that
// changes when a paragraph is reordered would break cross-repo links.

const coreSdoc = `[DOCUMENT]
TITLE: Core System Intent
PREFIX: CORE-
OPTIONS:
    MARKUP: Markdown

[[SECTION]]
TITLE: Gateway

[REQUIREMENT]
UID: CORE-GW-001
STATUS: Approved
TITLE: JWT signature validation
STATEMENT: >>>
The gateway shall validate JWT signatures using RS256.
<<<

[REQUIREMENT]
UID: CORE-GW-002
STATUS: Approved
TITLE: Token expiry
STATEMENT: >>>
Session tokens shall expire after 24 hours of inactivity.
<<<
[[/SECTION]]
`;

const platformSdoc = `[DOCUMENT]
TITLE: Platform Integration
PREFIX: PLAT-

[GRAMMAR]
ELEMENTS:
- TAG: REQUIREMENT
  FIELDS:
  - TITLE: UID
    TYPE: String
    REQUIRED: False
  - TITLE: TITLE
    TYPE: String
    REQUIRED: False
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: False
  - TITLE: RELATIONS
    TYPE: String
    REQUIRED: False
  RELATIONS:
  - TYPE: Parent
    ROLE: Refines

[[SECTION]]
TITLE: Gateway refinements

[REQUIREMENT]
UID: PLAT-GW-001
STATUS: Approved
TITLE: RS256 key rotation
STATEMENT: >>>
The platform shall rotate RS256 signing keys every 90 days.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: CORE-GW-001
  ROLE: Refines

[REQUIREMENT]
UID: PLAT-GW-002
STATUS: Draft
TITLE: Idle timeout enforcement
STATEMENT: >>>
The platform shall enforce idle timeouts via the session store.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: CORE-GW-002
  ROLE: Refines
[[/SECTION]]
`;

// ---- 2. Firmware rust crate with Tracey annotations -------------------------
// Two annotations for a single function are written on separate lines rather
// than a comma-joined marker. Tracey's matcher treats each `r[...]` as one ref.
const gatewayRs = `// src/gateway.rs
// r[impl CORE-GW-001]
// r[impl PLAT-GW-001]
pub fn validate_jwt(token: &str) -> Result<Claims, AuthError> {
    let claims = decode_with_rotating_keys(token)?;
    Ok(claims)
}

// r[impl CORE-GW-002]
pub fn is_session_live(session: &Session) -> bool {
    session.idle_seconds() < 24 * 60 * 60
}
`;

const gatewayTestRs = `// tests/gateway_test.rs
// r[verify CORE-GW-001]
#[test]
fn rs256_signature_is_enforced() {
    let good = sign_rs256("hello");
    assert!(validate_jwt(&good).is_ok());
    let bad = sign_hs256("hello");
    assert!(validate_jwt(&bad).is_err());
}

// r[verify CORE-GW-002]
#[test]
fn sessions_expire_after_a_day() {
    let s = Session::with_idle_seconds(24 * 60 * 60 + 1);
    assert!(!is_session_live(&s));
}
`;

// ---- 3. Composed root document ---------------------------------------------
// Uses StrictDoc 0.9.0+ [[SECTION]] composite semantics and DOCUMENT_FROM_FILE.
// The composed root has its own UID so downstream LINKs can anchor to it.
const composedSdoc = `[DOCUMENT]
TITLE: Composed Gateway Specification
UID: COMPOSED-GW
VERSION: 1.0.0

[TEXT]
STATEMENT: >>>
This document composes the core intent and its platform refinements. Any
[LINK: PLAT-GW-002] resolves to the platform document because UID anchors are
stable across reorderings.
<<<

[DOCUMENT_FROM_FILE]
FILE: ../spec-core/core.sdoc

[DOCUMENT_FROM_FILE]
FILE: ../spec-platform/platform.sdoc
`;

// ---- 4. Tracey config --------------------------------------------------------
// One implementation group (not three) because the spec surface is the same
// firmware crate; splitting would fragment coverage percentages without adding
// any signal — see README.md justification.
const traceyConfig = `@schema {id crate:tracey-config@1, cli tracey}

specs (
    {
        name core
        source_url https://example.invalid/spec-core
        include (spec-core/**/*.sdoc)
        impls (
            {
                name firmware
                include (impl-firmware/src/**/*.rs)
                test_include (impl-firmware/tests/**/*.rs)
            }
        )
    }
    {
        name platform
        source_url https://example.invalid/spec-platform
        include (spec-platform/**/*.sdoc)
        impls (
            {
                name firmware
                include (impl-firmware/src/**/*.rs)
                test_include (impl-firmware/tests/**/*.rs)
            }
        )
    }
    {
        name firmware
        source_url https://example.invalid/impl-firmware
        include (impl-firmware/spec/**/*.sdoc)
        impls (
            {
                name firmware
                include (impl-firmware/src/**/*.rs)
                test_include (impl-firmware/tests/**/*.rs)
            }
        )
    }
)
`;

// ---- 5. verify.sh — the fail-closed gate ------------------------------------
const verifySh = `#!/usr/bin/env bash
set -euo pipefail
rm -rf output .tracey
strictdoc export --formats=html ./composed
tracey query validate --deny warnings
tracey query status
`;

// ---- 6. Materialise ---------------------------------------------------------
mkdirSync(join(ROOT, 'spec-core'), { recursive: true });
mkdirSync(join(ROOT, 'spec-platform'), { recursive: true });
mkdirSync(join(ROOT, 'impl-firmware', 'src'), { recursive: true });
mkdirSync(join(ROOT, 'impl-firmware', 'tests'), { recursive: true });
mkdirSync(join(ROOT, 'composed'), { recursive: true });
mkdirSync(join(ROOT, '.config', 'tracey'), { recursive: true });

writeIfAbsent('spec-core/core.sdoc', coreSdoc);
writeIfAbsent('spec-platform/platform.sdoc', platformSdoc);
writeIfAbsent('impl-firmware/src/gateway.rs', gatewayRs);
writeIfAbsent('impl-firmware/tests/gateway_test.rs', gatewayTestRs);
writeIfAbsent('composed/specification.sdoc', composedSdoc);
writeIfAbsent('.config/tracey/config.styx', traceyConfig);
writeFileSync('verify.sh', verifySh, { mode: 0o755 });

writeIfAbsent('README.md', `# Why one implementation group
Tracey tracks coverage per (spec, impl) pair. We use a single \`firmware\`
implementation because all three specs are implemented by the same crate; the
three-spec configuration gives us the per-spec attribution we need without
multiplying implementation groups. Multiple groups would only be justified if we
later add a second runtime (e.g. a Go control plane) that implements a
different subset of the same specs.
`);

// ---- 7. Assert the graph is coherent ----------------------------------------
// We deliberately shell out to the real tools rather than reimplementing their
// checks. If either tool exits non-zero, the bootstrap fails loudly.
execFileSync('strictdoc', ['export', '--formats=html', './composed'], {
  stdio: 'inherit',
});
execFileSync('tracey', ['query', 'validate', '--deny', 'warnings'], {
  stdio: 'inherit',
});

// Sanity-check the composed HTML contains the cross-repo anchor.
const specHtml = readFileSync('output/html/composed/specification.html', 'utf8');
if (!specHtml.includes('PLAT-GW-002')) {
  throw new Error(
    'Composed document does not surface PLAT-GW-002 — the [LINK] anchor did not resolve.',
  );
}
console.log('Workspace bootstrapped and validated.');
