/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_build_a_drift_dashboard_that_regenerates_on_every.ts
Description: Solutions and Explanations
==========================================
*/

// src/dashboard/aggregator.ts
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';

// ---------------------------------------------------------------------------
// Contract
// ---------------------------------------------------------------------------
export interface SourceLocation { file: string; line: number; }

export interface DriftRequirement {
  uid: string;
  specName: string;
  currentVersion: number;
  referencedVersion: number;
  stale: boolean;
  implLocations: SourceLocation[];
  verifyLocations: SourceLocation[];
  lastTouchedByCommit?: string;
}

export interface DriftReport {
  revision: string;
  generatedAt: string;
  staleCount: number;
  requirements: DriftRequirement[];
  perSpec: Record<string, { implPercent: number; verifyPercent: number }>;
}

export interface DriftInputs {
  traceyStatus: string;         // raw stdout of `tracey query status`
  traceyUncovered: string;
  traceyUntested: string;
  traceyStale: string;
  traceyUnmapped: string;
  strictdocStatsHtml: string;
  touchedPaths: string[];
}

// ---------------------------------------------------------------------------
// Typed failure. Anything that prevents us from building a complete report is
// fatal — a partially-rendered dashboard is worse than no dashboard.
// ---------------------------------------------------------------------------
export class DriftInputError extends Error {
  constructor(public readonly input: string, message: string) {
    super(`[drift:${input}] ${message}`);
    this.name = 'DriftInputError';
  }
}

// ---------------------------------------------------------------------------
// Parsers. These understand the text output of each tracey query. If the
// upstream format changes, the regex below is the single choke point; make
// the failure loud by throwing when a line that should parse does not.
// ---------------------------------------------------------------------------
interface RawStale { uid: string; spec: string; refVer: number; curVer: number; }

function parseStale(out: string): RawStale[] {
  const rows: RawStale[] = [];
  // Tracey emits lines like:
  //   auth.login (myapp)  v1 -> v2
  // We anchor conservatively and fail on the *first* malformed entry.
  const re = /^\s*([A-Za-z0-9_.-]+)\s+\(([^)]+)\)\s+v(\d+)\s*->\s*v(\d+)\s*$/;
  for (const line of out.split('\n')) {
    const m = re.exec(line);
    if (!m) continue; // headings / blank lines are fine
    const [, uid, spec, refVer, curVer] = m;
    if (!uid || !spec || refVer === undefined || curVer === undefined) {
      throw new DriftInputError('tracey_stale', `unparseable line: ${line}`);
    }
    rows.push({ uid, spec, refVer: Number(refVer), curVer: Number(curVer) });
  }
  return rows;
}

function parseListedUids(out: string): string[] {
  // `tracey query uncovered|untested` emit one UID per line, indented under
  // their spec section header. We accept any line whose only content is a
  // dotted identifier.
  const ids: string[] = [];
  for (const line of out.split('\n')) {
    const t = line.trim();
    if (/^[A-Za-z0-9_][A-Za-z0-9_.-]*$/.test(t)) ids.push(t);
  }
  return ids;
}

interface StatusRow { spec: string; impl: string; implPct: number; verifyPct: number; }

function parseStatus(out: string): StatusRow[] {
  // Expected shape (one per spec/impl pair): `core/firmware  impl 80%  verify 40%`
  const rows: StatusRow[] = [];
  const re = /^\s*([^/\s]+)\/([^\s]+)\s+impl\s+(\d+(?:\.\d+)?)%\s+verify\s+(\d+(?:\.\d+)?)%\s*$/;
  for (const line of out.split('\n')) {
    const m = re.exec(line);
    if (!m) continue;
    const [, spec, impl, implPct, verifyPct] = m;
    if (!spec || !impl || implPct === undefined || verifyPct === undefined) {
      throw new DriftInputError('tracey_status', `unparseable line: ${line}`);
    }
    rows.push({ spec, impl, implPct: Number(implPct), verifyPct: Number(verifyPct) });
  }
  if (rows.length === 0) {
    throw new DriftInputError('tracey_status', 'no spec/impl rows found');
  }
  return rows;
}

// ---------------------------------------------------------------------------
// Aggregator
// ---------------------------------------------------------------------------
export function buildDriftReport(inputs: DriftInputs): DriftReport {
  // 1. Parse Tracey outputs. Each parser throws DriftInputError on a hard
  //    mismatch so the CLI fails closed rather than emitting an empty table.
  const stale = parseStale(inputs.traceyStale);
  const uncovered = new Set(parseListedUids(inputs.traceyUncovered));
  const untested = new Set(parseListedUids(inputs.traceyUntested));
  const status = parseStatus(inputs.traceyStatus);
  void inputs.traceyUnmapped; // parsed by the sources view, not this report

  // 2. Attribute each touched path to the UID(s) it carries. We grep for the
  //    Tracey annotation on each touched file; the regex matches both the
  //    native `r[impl <uid>]` form and the StrictDoc `@relation(<uid>...)`
  //    form, because mixed projects are common.
  const touchedBy = new Map<string, string>();
  const annotationRe =
    /(?:r\[(?:impl|verify)\s+([A-Za-z0-9_.-]+)\]|@relation\(\s*([A-Za-z0-9_.-]+))/;
  for (const path of inputs.touchedPaths) {
    let body: string;
    try {
      body = readFileSync(path, 'utf8');
    } catch {
      // A path that git reported but no longer exists (deleted file) is not
      // an error; skip it.
      continue;
    }
    for (const line of body.split('\n')) {
      const m = annotationRe.exec(line);
      const uid = m?.[1] ?? m?.[2];
      if (uid) touchedBy.set(uid, path);
    }
  }

  // 3. Compose the per-requirement rows. A requirement with no impl reference
  //    must have `stale === false`: "uncovered" and "stale" are distinct
  //    states. Only requirements reported as stale by tracey get stale=true.
  const staleIndex = new Map(stale.map((s) => [s.uid, s]));
  const allUids = new Set<string>([
    ...uncovered,
    ...untested,
    ...stale.map((s) => s.uid),
  ]);

  const requirements: DriftRequirement[] = [...allUids].map((uid) => {
    const s = staleIndex.get(uid);
    const implLocations: SourceLocation[] = [];
    const verifyLocations: SourceLocation[] = [];
    // We only know the file; line is filled in by the sources view. This
    // report is intentionally coarse — see the analysis note below.
    const touched = touchedBy.get(uid);
    if (touched && !uncovered.has(uid)) implLocations.push({ file: touched, line: 0 });
    if (touched && !untested.has(uid)) verifyLocations.push({ file: touched, line: 0 });

    return {
      uid,
      specName: s?.spec ?? 'unknown',
      currentVersion: s?.curVer ?? 1,
      referencedVersion: s?.refVer ?? 1,
      stale: Boolean(s),
      implLocations,
      verifyLocations,
      lastTouchedByCommit: touchedBy.get(uid),
    };
  });

  // 4. Deterministic ordering. Stable sort on specName, then uid. The caller
  //    (and its Vitest test) relies on this exact order for byte-identical
  //    output across runs.
  requirements.sort((a, b) =>
    a.specName < b.specName ? -1 :
    a.specName > b.specName ? 1 :
    a.uid < b.uid ? -1 :
    a.uid > b.uid ? 1 : 0,
  );

  // 5. Per-spec coverage summary. When two implementations exist under one
  //    spec we average the percentages — the report mirrors Tracey's own
  //    coverage view's aggregation.
  const perSpec: Record<string, { implPercent: number; verifyPercent: number }> = {};
  const grouped = new Map<string, StatusRow[]>();
  for (const row of status) {
    const bucket = grouped.get(row.spec) ?? [];
    bucket.push(row);
    grouped.set(row.spec, bucket);
  }
  for (const [spec, rows] of grouped) {
    const n = rows.length;
    perSpec[spec] = {
      implPercent: rows.reduce((acc, r) => acc + r.implPct, 0) / n,
      verifyPercent: rows.reduce((acc, r) => acc + r.verifyPct, 0) / n,
    };
  }

  return {
    revision: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
    generatedAt: new Date().toISOString(),
    staleCount: requirements.filter((r) => r.stale).length,
    requirements,
    perSpec,
  };
}
