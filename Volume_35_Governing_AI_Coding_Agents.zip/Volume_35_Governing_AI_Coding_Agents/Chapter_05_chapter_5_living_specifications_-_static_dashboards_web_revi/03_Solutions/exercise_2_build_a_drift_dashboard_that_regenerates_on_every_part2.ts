/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_build_a_drift_dashboard_that_regenerates_on_every_part2.ts
Description: Solutions and Explanations
==========================================
*/

// src/dashboard/render.ts — single-file HTML, zero external requests.
import type { DriftReport } from './aggregator.js';

function esc(s: string): string {
  return s.replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!),
  );
}

function badgeClass(n: number): string {
  if (n === 0) return 'ok';
  if (n <= 3) return 'warn';
  return 'bad';
}

export function renderDriftHtml(report: DriftReport): string {
  // Sorted stales for the table; the aggregator already sorted, so this is a
  // stable filter rather than a re-sort.
  const stales = report.requirements.filter((r) => r.stale);

  const rows = stales.map((r) => `
    <tr>
      <td>${esc(r.specName)}</td>
      <td><a href="/${esc(r.specName)}/spec#${encodeURIComponent(r.uid)}">${esc(r.uid)}</a></td>
      <td class="num">v${r.referencedVersion}</td>
      <td class="num">v${r.currentVersion}</td>
      <td>${r.lastTouchedByCommit ? esc(r.lastTouchedByCommit) : '&mdash;'}</td>
    </tr>`).join('');

  const coverage = Object.entries(report.perSpec)
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([spec, c]) => `
      <tr>
        <td>${esc(spec)}</td>
        <td class="num">${c.implPercent.toFixed(1)}%</td>
        <td class="num">${c.verifyPercent.toFixed(1)}%</td>
      </tr>`).join('');

  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<title>Drift Report ${esc(report.revision.slice(0, 7))}</title>
<style>
  body{font:14px/1.5 system-ui,sans-serif;margin:2rem;max-width:70rem}
  .badge{display:inline-block;padding:.2rem .6rem;border-radius:1rem;color:#fff}
  .badge.ok{background:#2e7d32}.badge.warn{background:#f9a825}.badge.bad{background:#c62828}
  table{border-collapse:collapse;width:100%;margin:1rem 0}
  td,th{border-bottom:1px solid #ddd;padding:.4rem .6rem;text-align:left}
  .num{text-align:right;font-variant-numeric:tabular-nums}
</style></head><body>
<header>
  <h1>Drift Report</h1>
  <p>Revision <code>${esc(report.revision.slice(0, 7))}</code>
     &middot; generated <time>${esc(report.generatedAt)}</time></p>
  <p>Stale references: <span class="badge ${badgeClass(report.staleCount)}">${report.staleCount}</span></p>
</header>
<h2>Stale references</h2>
${stales.length === 0
  ? '<p>No stale references.</p>'
  : `<table><thead><tr><th>Spec</th><th>UID</th><th>Referenced</th><th>Current</th><th>Last touched by</th></tr></thead><tbody>${rows}</tbody></table>`}
<h2>Coverage by spec</h2>
<table><thead><tr><th>Spec</th><th>Impl</th><th>Verify</th></tr></thead><tbody>${coverage}</tbody></table>
</body></html>`;
}
