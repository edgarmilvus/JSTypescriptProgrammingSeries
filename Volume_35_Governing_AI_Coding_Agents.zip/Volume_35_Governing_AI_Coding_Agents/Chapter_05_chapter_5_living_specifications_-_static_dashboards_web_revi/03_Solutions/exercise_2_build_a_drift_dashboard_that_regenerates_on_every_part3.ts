/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_build_a_drift_dashboard_that_regenerates_on_every_part3.ts
Description: Solutions and Explanations
==========================================
*/

// src/dashboard/build.ts — CLI entry, called from CI.
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { buildDriftReport, DriftInputError } from './aggregator.js';
import { renderDriftHtml } from './render.js';

function tracey(args: string[]): string {
  // Note: --format json is not available on all Tracey builds; we shell out
  // and parse text. If your build supports it, swap the parser for JSON.parse
  // and delete the regexes — the aggregator's contract is unchanged.
  return execFileSync('tracey', args, { encoding: 'utf8' });
}

function main(): void {
  try {
    const inputs = {
      traceyStatus: tracey(['query', 'status']),
      traceyUncovered: tracey(['query', 'uncovered']),
      traceyUntested: tracey(['query', 'untested']),
      traceyStale: tracey(['query', 'stale']),
      traceyUnmapped: tracey(['query', 'unmapped']),
      strictdocStatsHtml: readFileSync('output/html/project_statistics.html', 'utf8'),
      touchedPaths: execFileSync(
        'git',
        ['diff', '--name-only', `${execFileSync('git', ['rev-parse', 'HEAD~1'], { encoding: 'utf8' }).trim()}`, 'HEAD', '--', '*.sdoc', '*.rs'],
        { encoding: 'utf8' },
      ).trim().split('\n').filter(Boolean),
    };

    const report = buildDriftReport(inputs);
    mkdirSync('output', { recursive: true });
    writeFileSync('output/drift.html', renderDriftHtml(report), 'utf8');

    // Exit non-zero on stale entries — this is the CI gate.
    if (report.staleCount > 0) {
      console.error(`Drift detected: ${report.staleCount} stale reference(s).`);
      process.exit(2);
    }
  } catch (err) {
    if (err instanceof DriftInputError) {
      console.error(err.message);
      process.exit(3);
    }
    throw err;
  }
}

main();
