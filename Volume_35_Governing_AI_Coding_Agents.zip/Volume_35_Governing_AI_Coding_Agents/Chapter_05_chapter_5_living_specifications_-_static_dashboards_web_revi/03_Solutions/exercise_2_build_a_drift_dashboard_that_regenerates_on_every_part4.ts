/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_build_a_drift_dashboard_that_regenerates_on_every_part4.ts
Description: Solutions and Explanations
==========================================
*/

// src/dashboard/aggregator.test.ts — Vitest
import { describe, it, expect } from 'vitest';
import { buildDriftReport, DriftInputError } from './aggregator.js';

const fixture = {
  traceyStatus: 'core/firmware impl 80.0% verify 40.0%\n',
  traceyUncovered: 'auth.login\n',
  traceyUntested: '',
  traceyStale: 'auth.login (core) v1 -> v2\n',
  traceyUnmapped: '',
  strictdocStatsHtml: '<html></html>',
  touchedPaths: ['fixtures/auth.rs'],
};

describe('buildDriftReport', () => {
  it('is byte-stable across runs', () => {
    const a = buildDriftReport(fixture);
    const b = buildDriftReport(fixture);
    // Drop the timestamp — everything else, including ordering, must match.
    expect({ ...a, generatedAt: 'X' }).toEqual({ ...b, generatedAt: 'X' });
  });

  it('does not equate uncovered with stale', () => {
    const r = buildDriftReport({ ...fixture, traceyUncovered: 'auth.other\n', traceyStale: '' });
    const other = r.requirements.find((x) => x.uid === 'auth.other')!;
    expect(other.stale).toBe(false);
    expect(other.implLocations).toEqual([]);
  });

  it('throws DriftInputError on truncated status output', () => {
    expect(() =>
      buildDriftReport({ ...fixture, traceyStatus: 'core/firmware impl ' }),
    ).toThrowError(DriftInputError);
  });
});
