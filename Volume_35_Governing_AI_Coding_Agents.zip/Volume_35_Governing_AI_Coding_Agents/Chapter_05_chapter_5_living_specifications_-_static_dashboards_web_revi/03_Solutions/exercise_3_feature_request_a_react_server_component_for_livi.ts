/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_a_react_server_component_for_livi.ts
Description: Solutions and Explanations
==========================================
*/

// lib/tracey/mcpClient.ts
// Minimal JSON-RPC 2.0 client over stdio. We spawn the daemon bridge per
// request rather than keeping a long-lived child, because Next.js Server
// Components run in a short-lived request context and an orphaned `tracey mcp`
// process is exactly the leak we want to avoid. The daemon itself is long-lived
// (Tracey auto-starts it), so the spawn cost is a pipe setup, not a graph build.
import { spawn } from 'node:child_process';

interface RpcResponse<T> {
  jsonrpc: '2.0';
  id: number;
  result?: { content: Array<{ type: 'text'; text: string }> };
  error?: { code: number; message: string };
}

let nextId = 1;

export async function callTraceyTool<T>(
  name: string,
  args: Record<string, unknown> = {},
): Promise<T> {
  const id = nextId++;
  const child = spawn('tracey', ['mcp'], {
    stdio: ['pipe', 'pipe', 'inherit'],
    env: process.env,
  });

  const request = JSON.stringify({
    jsonrpc: '2.0',
    id,
    method: 'tools/call',
    params: { name, arguments: args },
  }) + '\n';

  child.stdin.write(request);
  child.stdin.end();

  let buffer = '';
  const response = await new Promise<RpcResponse<T>>((resolve, reject) => {
    child.stdout.on('data', (chunk: Buffer) => {
      buffer += chunk.toString('utf8');
      // Try to parse each complete line; the final one carries the result.
      for (const line of buffer.split('\n')) {
        if (!line.trim()) continue;
        try {
          const parsed = JSON.parse(line) as RpcResponse<T>;
          if (parsed.id === id) resolve(parsed);
        } catch { /* partial line, keep buffering */ }
      }
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code !== 0 && !buffer) {
        reject(new Error(`tracey mcp exited with code ${code}`));
      }
    });
  });

  if (response.error) {
    throw new Error(`tracey ${name}: ${response.error.message}`);
  }
  // Tracey's MCP responses are human-readable text; we type-narrow here at the
  // boundary so the rest of the codebase sees structured data.
  const text = response.result?.content.find((c) => c.type === 'text')?.text;
  if (!text) throw new Error(`tracey ${name}: empty response`);
  return parseTraceyText<T>(name, text);
}

// Parser is per-tool. Kept here so callers do not re-implement parsing.
function parseTraceyText<T>(tool: string, text: string): T {
  // In a real codebase these parsers live next to their fixtures and are
  // covered by tests. The shape is intentionally narrow.
  if (tool === 'tracey_status') {
    const coverage: { implPercent: number; verifyPercent: number } = {
      implPercent: 0,
      verifyPercent: 0,
    };
    for (const line of text.split('\n')) {
      const m = /^\s*[^/\s]+\/[^\s]+\s+impl\s+(\d+(?:\.\d+)?)%\s+verify\s+(\d+(?:\.\d+)?)%/.exec(line);
      if (m) {
        coverage.implPercent = Number(m[1]);
        coverage.verifyPercent = Number(m[2]);
      }
    }
    return coverage as unknown as T;
  }
  if (tool === 'tracey_uncovered' || tool === 'tracey_untested') {
    const uids = text.split('\n')
      .map((l) => l.trim())
      .filter((l) => /^[A-Za-z0-9_][A-Za-z0-9_.-]*$/.test(l));
    return uids as unknown as T;
  }
  if (tool === 'tracey_stale') {
    const rows: Array<{ uid: string; currentVersion: number; referencedVersion: number }> = [];
    const re = /^\s*([A-Za-z0-9_.-]+)\s+\([^)]+\)\s+v(\d+)\s*->\s*v(\d+)\s*$/;
    for (const line of text.split('\n')) {
      const m = re.exec(line);
      if (m) rows.push({ uid: m[1]!, referencedVersion: Number(m[2]), currentVersion: Number(m[3]) });
    }
    return rows as unknown as T;
  }
  throw new Error(`unknown tracey tool: ${tool}`);
}
