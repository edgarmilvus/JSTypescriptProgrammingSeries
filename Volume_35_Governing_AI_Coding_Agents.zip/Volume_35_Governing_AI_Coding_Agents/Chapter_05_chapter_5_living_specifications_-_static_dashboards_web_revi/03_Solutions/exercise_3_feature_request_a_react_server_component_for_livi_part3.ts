/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_a_react_server_component_for_livi_part3.ts
Description: Solutions and Explanations
==========================================
*/

// lib/tracey/fetchReviewSurface.ts
import { callTraceyTool } from './mcpClient.js';
import type { ReviewSurfaceData } from './types.js';

/**
 * Compute a stable anchor URL for a UID in the StrictDoc static export.
 *
 * NOTE: this lives in the fetcher, not the component, because the component
 * must be a *presenter* of already-typed data. Any derivation that could
 * drift (URL shape, spec name slugging, fallback path when the static export
 * is absent) belongs here so it can be unit tested without a React runtime.
 */
function specUrl(specName: string, uid: string): string {
  const slug = specName.replace(/[^a-z0-9-]/gi, '-').toLowerCase();
  return `/specs/${slug}/static/specification.html#${encodeURIComponent(uid)}`;
}

function implUrl(uid: string): string | null {
  // We do not know the file here; the aggregator (Exercise 2) holds that map.
  // Returning null forces the component to render a "see drift report" link
  // rather than fabricating a likely-wrong URL.
  return null;
}

export async function fetchReviewSurfaceData(
  specName: string,
  commitSha: string,
): Promise<ReviewSurfaceData> {
  // Sequential rather than Promise.all: MCP tool calls over a single stdio
  // pipe are not designed for concurrent multiplexing on the client side, and
  // the four calls are cheap.
  const [coverage, uncovered, untested, stale] = await Promise.all([
    callTraceyTool<{ implPercent: number; verifyPercent: number }>('tracey_status', { spec_impl: specName }),
    callTraceyTool<string[]>('tracey_uncovered', { spec_impl: specName }),
    callTraceyTool<string[]>('tracey_untested', { spec_impl: specName }),
    callTraceyTool<Array<{ uid: string; currentVersion: number; referencedVersion: number }>>(
      'tracey_stale',
      { spec_impl: specName },
    ),
  ]);

  return {
    specName,
    generatedAt: new Date().toISOString(),
    commitSha,
    coverage,
    uncovered: uncovered.map((uid) => ({ uid, specUrl: specUrl(specName, uid) })),
    untested: untested.map((uid) => ({ uid, implUrl: implUrl(uid) })),
    stale,
  };
}
