/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_a_react_server_component_for_livi_part4.tsx
Description: Solutions and Explanations
==========================================
*/

// lib/tracey/renderReviewSurface.tsx
import type { ReactElement } from 'react';
import type { ReviewSurfaceData } from './types.js';

function esc(s: string): string {
  return s.replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!),
  );
}

/**
 * Pure render helper. Kept free of hooks and async so Vitest can call it
 * directly and inspect the returned element tree.
 */
export function renderReviewSurface(data: ReviewSurfaceData): ReactElement {
  return (
    <article>
      <header>
        <h1>{data.specName}</h1>
        <p>
          Commit <code>{data.commitSha.slice(0, 7)}</code> &middot;{' '}
          <time>{data.generatedAt}</time>
        </p>
      </header>

      <section aria-labelledby="h-coverage">
        <h2 id="h-coverage">Coverage</h2>
        <dl>
          <dt>Implementation</dt><dd>{data.coverage.implPercent.toFixed(1)}%</dd>
          <dt>Verification</dt><dd>{data.coverage.verifyPercent.toFixed(1)}%</dd>
        </dl>
        {/*
          Zero verification is a distinct signal from zero implementation:
          a spec nobody has tested is more dangerous than one nobody has
          written yet. Surface the call-to-action only for the verify case.
        */}
        {data.coverage.verifyPercent === 0 && (
          <p>
            <a href={`/specs/${data.specName}/spec`}>
              No verifications exist yet — review the spec definition.
            </a>
          </p>
        )}
      </section>

      <section aria-labelledby="h-uncovered">
        <h2 id="h-uncovered">Uncovered</h2>
        {data.uncovered.length === 0
          ? <p>No uncovered requirements in this spec.</p>
          : <ul>{data.uncovered.map((r) => (
              <li key={r.uid}><a href={r.specUrl}>{r.uid}</a></li>
            ))}</ul>}
      </section>

      <section aria-labelledby="h-untested">
        <h2 id="h-untested">Untested</h2>
        {data.untested.length === 0
          ? <p>No untested requirements in this spec.</p>
          : <ul>{data.untested.map((r) => (
              <li key={r.uid}>
                {r.implUrl
                  ? <a href={r.implUrl}>{r.uid}</a>
                  : <>{r.uid} <a href={`/specs/${data.specName}/drift`}>see drift report</a></>}
              </li>
            ))}</ul>}
      </section>

      <section aria-labelledby="h-stale">
        <h2 id="h-stale">Stale</h2>
        {data.stale.length === 0
          ? <p>No stale references in this spec.</p>
          : <table>
              <thead><tr><th>UID</th><th>Referenced</th><th>Current</th></tr></thead>
              <tbody>
                {data.stale.map((r) => (
                  <tr key={r.uid}>
                    <td><a href={`/specs/${data.specName}/spec#${encodeURIComponent(r.uid)}`}>{r.uid}</a></td>
                    <td>v{r.referencedVersion}</td>
                    <td>v{r.currentVersion}</td>
                  </tr>
                ))}
              </tbody>
            </table>}
      </section>
    </article>
  );
}
void esc; // retained only for callers that pass raw strings in future edits
