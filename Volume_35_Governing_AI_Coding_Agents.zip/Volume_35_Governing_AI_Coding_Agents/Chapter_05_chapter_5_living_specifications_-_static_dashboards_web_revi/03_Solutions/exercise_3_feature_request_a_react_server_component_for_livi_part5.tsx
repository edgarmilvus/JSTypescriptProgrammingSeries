/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_a_react_server_component_for_livi_part5.tsx
Description: Solutions and Explanations
==========================================
*/

// app/specs/[specName]/review/page.tsx
import { unstable_cache } from 'next/cache';
import { fetchReviewSurfaceData } from '@/lib/tracey/fetchReviewSurface';
import { renderReviewSurface } from '@/lib/tracey/renderReviewSurface';

// Server Component — no client hooks, no browser-only APIs. Next.js will
// stream this; the MCP spawn happens inside the request handler and terminates
// before the response is flushed.
export default async function ReviewPage({
  params,
}: {
  params: { specName: string };
}) {
  // The commit SHA is injected by the CI/deploy environment.
  const commitSha = process.env.GIT_COMMIT_SHA ?? 'development';

  // Cache key is (specName, commitSha). Because commitSha changes on every
  // push, the cached entry naturally invalidates on deploy. `revalidate: 60`
  // is a belt-and-braces upper bound in case the SHA is stale (e.g. local
  // development). A webhook could additionally call
  // revalidateTag(`tracey:${params.specName}`) to force invalidation.
  const load = unstable_cache(
    () => fetchReviewSurfaceData(params.specName, commitSha),
    ['tracey', params.specName, commitSha],
    { revalidate: 60, tags: [`tracey:${params.specName}`] },
  );

  const data = await load();
  return renderReviewSurface(data);
}
