/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_a_react_server_component_for_livi_part6.ts
Description: Solutions and Explanations
==========================================
*/

// lib/tracey/renderReviewSurface.test.ts
import { describe, it, expect } from 'vitest';
import { renderReviewSurface } from './renderReviewSurface';
import type { ReviewSurfaceData } from './types';

const base: ReviewSurfaceData = {
  specName: 'core',
  generatedAt: '2026-03-01T00:00:00Z',
  commitSha: 'abc1234',
  coverage: { implPercent: 80, verifyPercent: 40 },
  uncovered: [],
  untested: [],
  stale: [],
};

describe('renderReviewSurface empty states', () => {
  it('renders the uncovered empty state', () => {
    const tree = renderReviewSurface(base);
    expect(JSON.stringify(tree)).toContain('No uncovered requirements in this spec.');
  });

  it('renders a CTA when verifyPercent is zero', () => {
    const tree = renderReviewSurface({ ...base, coverage: { implPercent: 0, verifyPercent: 0 } });
    expect(JSON.stringify(tree)).toContain('No verifications exist yet');
  });

  it('links a stale entry to the UID anchor', () => {
    const tree = renderReviewSurface({
      ...base,
      stale: [{ uid: 'auth.login', currentVersion: 2, referencedVersion: 1 }],
    });
    const s = JSON.stringify(tree);
    expect(s).toContain('auth.login');
    expect(s).toMatch(/#auth\.login/);
  });

  it('rejects a stale fixture missing referencedVersion', () => {
    // Type-level check expressed at runtime: the fetcher must never emit this.
    const bad = { ...base, stale: [{ uid: 'x', currentVersion: 2 }] } as unknown as ReviewSurfaceData;
    expect(() => renderReviewSurface(bad)).toThrow();
  });
});
