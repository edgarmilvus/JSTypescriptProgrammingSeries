/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_simulate_a_multi-reviewer_review_cycle_with_basel.ts
Description: Solutions and Explanations
==========================================
*/

// bin/baseline-diff.ts
// Compares requirement text between two baseline tags. Requirement text is
// sourced from `tracey query rule` at each baseline, NOT from `git diff`. This
// is deliberate: git diff would report raw .sdoc hunks, which include
// reordering noise (a requirement moved between sections is not a change to
// its normative text). Tracey's rule view is the canonical statement of a
// requirement, so the diff is over the same thing the gate cares about.
import { execFileSync } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export interface BaselineDiffEntry {
  uid: string;
  changed: boolean;
  currentVersion: number;
  approvedVersion: number;
  textualDiff: string | null;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function git(args: string[], cwd?: string): string {
  return execFileSync('git', args, { encoding: 'utf8', cwd }).trim();
}

function worktree(tag: string): string {
  const dir = mkdtempSync(join(tmpdir(), `bdiff-${tag}-`));
  git(['worktree', 'add', '--detach', dir, tag]);
  return dir;
}

function releaseWorktree(dir: string): void {
  try {
    git(['worktree', 'remove', '--force', dir]);
  } catch {
    /* best effort */
  }
  try {
    rmSync(dir, { recursive: true, force: true });
  } catch {
    /* best effort */
  }
}

// Minimal line diff — LCS-based, sufficient for our expected payloads and
// deterministic (no locale-sensitive comparisons, no Date dependencies).
function lineDiff(a: string, b: string): string {
  const A = a.split('\n');
  const B = b.split('\n');
  const m = A.length, n = B.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--) {
    for (let j = n - 1; j >= 0; j--) {
      dp[i]![j] = A[i] === B[j] ? dp[i + 1]![j + 1]! + 1 : Math.max(dp[i + 1]![j]!, dp[i]![j + 1]!);
    }
  }
  const out: string[] = [];
  let i = 0, j = 0;
  while (i < m && j < n) {
    if (A[i] === B[j]) { out.push(`  ${A[i]}`); i++; j++; }
    else if (dp[i + 1]![j]! >= dp[i]![j + 1]!) { out.push(`- ${A[i]}`); i++; }
    else { out.push(`+ ${B[j]}`); j++; }
  }
  while (i < m) out.push(`- ${A[i++]}`);
  while (j < n) out.push(`+ ${B[j++]}`);
  return out.join('\n');
}

// ---------------------------------------------------------------------------
// The public function — pure over its arguments, hermetic.
// ---------------------------------------------------------------------------
export function baselineDiff(
  approvedTag: string,
  currentTag: string,
  repoCwd: string = process.cwd(),
): BaselineDiffEntry[] {
  const approvedDir = worktreeAt(approvedTag, repoCwd);
  const currentDir = worktreeAt(currentTag, repoCwd);

  try {
    // Enumerate UIDs from the current baseline (the authoritative set —
    // deleted UIDs are not a concern for drift detection).
    const uids = enumerateUids(currentDir);

    const entries: BaselineDiffEntry[] = [];
    for (const uid of uids) {
      const approved = ruleAt(approvedDir, uid);
      const current = ruleAt(currentDir, uid);
      if (!current) continue;
      const changed = approved?.text !== current.text;
      entries.push({
        uid,
        changed,
        currentVersion: current.version,
        approvedVersion: approved?.version ?? 0,
        textualDiff: changed ? lineDiff(approved?.text ?? '', current.text) : null,
      });
    }

    // Deterministic order, independent of filesystem iteration order.
    entries.sort((a, b) => (a.uid < b.uid ? -1 : a.uid > b.uid ? 1 : 0));
    return entries;
  } finally {
    releaseWorktree(approvedDir);
    releaseWorktree(currentDir);
  }
}

// ---------------------------------------------------------------------------
// Internals
// ---------------------------------------------------------------------------
function worktreeAt(tag: string, cwd: string): string {
  const dir = mkdtempSync(join(tmpdir(), `bdiff-${tag}-`));
  execFileSync('git', ['worktree', 'add', '--detach', dir, tag], { cwd, stdio: 'pipe' });
  return dir;
}

function enumerateUids(worktree: string): string[] {
  // `tracey query status` from within the worktree gives us the spec corpus
  // root without an extra config lookup. We then ask for every rule.
  const out = execFileSync('tracey', ['query', 'unmapped', '--path', '.'], {
    cwd: worktree, encoding: 'utf8',
  });
  // Fallback: parse UIDs from the status/uncovered/untested union.
  const ids = new Set<string>();
  for (const line of out.split('\n')) {
    const m = /^\s*([A-Za-z0-9_][A-Za-z0-9_.-]*)\b/.exec(line);
    if (m) ids.add(m[1]!);
  }
  return [...ids];
}

interface RuleView { text: string; version: number; }

function ruleAt(worktree: string, uid: string): RuleView | null {
  try {
    const out = execFileSync('tracey', ['query', 'rule', uid], {
      cwd: worktree, encoding: 'utf8',
    });
    // Rule text is emitted between two horizontal rules; version appears in
    // the header as `version N`. The regexes below are the format assumption;
    // they are covered by the fixture tests.
    const version = Number(/version\s+(\d+)/.exec(out)?.[1] ?? '1');
    const textMatch = /---\n([\s\S]*?)\n---/.exec(out);
    return { text: textMatch?.[1] ?? out, version };
  } catch {
    return null; // UID absent at this baseline
  }
}
