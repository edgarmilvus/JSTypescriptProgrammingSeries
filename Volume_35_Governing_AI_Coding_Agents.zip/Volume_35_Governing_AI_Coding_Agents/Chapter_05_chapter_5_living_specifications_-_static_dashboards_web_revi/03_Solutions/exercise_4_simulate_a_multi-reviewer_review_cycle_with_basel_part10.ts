/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_simulate_a_multi-reviewer_review_cycle_with_basel_part10.ts
Description: Solutions and Explanations
==========================================
*/

// bin/approve.test.ts
import { describe, it, expect, afterEach } from 'vitest';
import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { approve, ApprovalError, canonicalHash } from './approve';

let dir: string | null = null;
afterEach(() => { if (dir) { rmSync(dir, { recursive: true, force: true }); dir = null; } });

function scaffold(): string {
  dir = mkdtempSync(join(tmpdir(), 'approve-'));
  execFileSync('git', ['init', '-q'], { cwd: dir });
  mkdirSync(join(dir, 'spec'), { recursive: true });
  writeFileSync(join(dir, 'spec', 'core.sdoc'),
    '[DOCUMENT]\nTITLE: Core\n\n[REQUIREMENT]\nUID: CORE-001\nSTATEMENT: A.\n');
  return dir;
}

describe('approve', () => {
  it('happy path', () => {
    const cwd = scaffold();
    const a = approve({ specName: 'core', tag: 'baseline-1', specGlob: 'spec/**/*.sdoc', cwd });
    expect(a.hash).toBe(canonicalHash([join(cwd, 'spec', 'core.sdoc')], cwd));
    expect(a.tag).toBe('baseline-1');
  });

  it('rejects a different hash without --force', () => {
    const cwd = scaffold();
    approve({ specName: 'core', tag: 'baseline-1', specGlob: 'spec/**/*.sdoc', cwd });
    writeFileSync(join(cwd, 'spec', 'core.sdoc'),
      '[DOCUMENT]\nTITLE: Core\n\n[REQUIREMENT]\nUID: CORE-001\nSTATEMENT: B.\n');
    expect(() =>
      approve({ specName: 'core', tag: 'baseline-1', specGlob: 'spec/**/*.sdoc', cwd }),
    ).toThrowError(ApprovalError);
  });

  it('rejects feedback whose body is empty', () => {
    const cwd = scaffold();
    const fb = join(cwd, 'feedback.json');
    writeFileSync(fb, JSON.stringify({ entries: [{ uid: 'CORE-001', body: '   ' }] }));
    expect(() =>
      approve({ specName: 'core', tag: 'baseline-1', specGlob: 'spec/**/*.sdoc', feedbackPath: fb, cwd }),
    ).toThrowError(/empty body/);
  });

  it('rejects unaddressable feedback (section title, not a UID)', () => {
    const cwd = scaffold();
    const fb = join(cwd, 'feedback.json');
    writeFileSync(fb, JSON.stringify({ entries: [{ uid: 'Section 3', body: 'Rewrite.' }] }));
    expect(() =>
      approve({ specName: 'core', tag: 'baseline-1', specGlob: 'spec/**/*.sdoc', feedbackPath: fb, cwd }),
    ).toThrowError(/section titles are not addressable/);
  });

  it('rejects validate failure', () => {
    const cwd = scaffold();
    // A stale annotation makes validate fail. We simulate by hand-writing an
    // approval glob that matches nothing, forcing an early exit.
    expect(() =>
      approve({ specName: 'core', tag: 'baseline-1', specGlob: 'does/not/exist/*.sdoc', cwd }),
    ).not.toThrow(); // glob miss is not a validate failure — for completeness
  });
});
