/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_simulate_a_multi-reviewer_review_cycle_with_basel_part4.ts
Description: Solutions and Explanations
==========================================
*/

// tests/fixtures/review-cycle/helpers.ts — per-test hermetic workspace
import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export interface Workspace { dir: string; commitAll: (msg: string) => void; tag: (name: string) => void; }

export function makeWorkspace(): Workspace {
  const dir = mkdtempSync(join(tmpdir(), 'review-cycle-'));
  const run = (args: string[]) => execFileSync('git', args, { cwd: dir, stdio: 'pipe' });
  run(['init', '-q', '-b', 'main']);
  run(['config', 'user.email', 'test@example.invalid']);
  run(['config', 'user.name', 'Test']);
  // Fixed dates so commit hashes are stable.
  process.env.GIT_AUTHOR_DATE = '2026-01-01T00:00:00Z';
  process.env.GIT_COMMITTER_DATE = '2026-01-01T00:00:00Z';
  return {
    dir,
    commitAll: (msg) => { run(['add', '-A']); run(['commit', '-q', '-m', msg]); },
    tag: (name) => run(['tag', '-f', name]),
  };
}

export function cleanup(ws: Workspace): void {
  rmSync(ws.dir, { recursive: true, force: true });
}

export function writeSpec(dir: string, body: string): void {
  mkdirSync(join(dir, 'spec'), { recursive: true });
  writeFileSync(join(dir, 'spec', 'core.sdoc'), body, 'utf8');
}

export function writeRs(dir: string, body: string): void {
  mkdirSync(join(dir, 'src'), { recursive: true });
  writeFileSync(join(dir, 'src', 'auth.rs'), body, 'utf8');
}
