/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_simulate_a_multi-reviewer_review_cycle_with_basel_part5.ts
Description: Solutions and Explanations
==========================================
*/

// tests/review-cycle.test.ts
import { describe, it, expect, afterEach } from 'vitest';
import { execFileSync } from 'node:child_process';
import { makeWorkspace, cleanup, writeSpec, writeRs, type Workspace } from './fixtures/review-cycle/helpers';
import { baselineDiff } from '../bin/baseline-diff';

const SPEC_V1 = `[DOCUMENT]
TITLE: Core

[REQUIREMENT]
UID: CORE-001
STATEMENT: The system shall validate JWT signatures using RS256.
`;

const SPEC_V2_BUMPED = `[DOCUMENT]
TITLE: Core

[REQUIREMENT]
UID: CORE-001+2
STATEMENT: The system shall validate JWT signatures using EdDSA.
`;

const SPEC_V2_NOTA_BUMPED = `[DOCUMENT]
TITLE: Core

[REQUIREMENT]
UID: CORE-001
STATEMENT: The system shall validate JWT signatures using EdDSA.
`;

const RS_V1 = `// src/auth.rs
// r[impl CORE-001]
pub fn validate_jwt(_t: &str) -> bool { true }
`;

const RS_V2_BUMPED = `// src/auth.rs
// r[impl CORE-001+2]
pub fn validate_jwt(_t: &str) -> bool { true }
`;

const RS_V2_NOTBUMPED = `// src/auth.rs
// r[impl CORE-001]
pub fn validate_jwt(_t: &str) -> bool { true }
`;

let ws: Workspace | null = null;
afterEach(() => { if (ws) { cleanup(ws); ws = null; } });

function tracey(cwd: string, args: string[]): { code: number; stderr: string } {
  try {
    execFileSync('tracey', args, { cwd, encoding: 'utf8' });
    return { code: 0, stderr: '' };
  } catch (e) {
    const err = e as { status?: number; stderr?: Buffer | string };
    return { code: err.status ?? 1, stderr: String(err.stderr ?? '') };
  }
}

describe('review cycle counterfactuals', () => {
  it('A: text changed, version bumped, annotation bumped → pipeline passes', () => {
    ws = makeWorkspace();
    writeSpec(ws.dir, SPEC_V1); writeRs(ws.dir, RS_V1); ws.commitAll('v1'); ws.tag('baseline-1');
    writeSpec(ws.dir, SPEC_V2_BUMPED); writeRs(ws.dir, RS_V2_BUMPED); ws.commitAll('v2'); ws.tag('baseline-2');

    const diff = baselineDiff('baseline-1', 'baseline-2', ws.dir);
    expect(diff.find((d) => d.uid === 'CORE-001')?.changed).toBe(true);

    const stale = tracey(ws.dir, ['query', 'stale']);
    expect(stale.code).toBe(0);
    expect(stale.stderr).not.toContain('CORE-001');
  });

  it('B: text changed, version NOT bumped → pre-commit fails naming the UID', () => {
    ws = makeWorkspace();
    writeSpec(ws.dir, SPEC_V1); writeRs(ws.dir, RS_V1); ws.commitAll('v1'); ws.tag('baseline-1');
    writeSpec(ws.dir, SPEC_V2_NOTA_BUMPED); ws.commitAll('v2'); ws.tag('baseline-2');

    const result = tracey(ws.dir, ['pre-commit']);
    expect(result.code).not.toBe(0);
    expect(result.stderr).toContain('CORE-001');
  });

  it('C: text + version bumped, annotation NOT bumped → pipeline fails closed', () => {
    ws = makeWorkspace();
    writeSpec(ws.dir, SPEC_V1); writeRs(ws.dir, RS_V1); ws.commitAll('v1'); ws.tag('baseline-1');
    writeSpec(ws.dir, SPEC_V2_BUMPED); writeRs(ws.dir, RS_V2_NOTBUMPED); ws.commitAll('v2'); ws.tag('baseline-2');

    const stale = tracey(ws.dir, ['query', 'stale']);
    // Stale query exits 0 but reports the UID; the gate turns that into a
    // failure via --deny warnings.
    expect(stale.stderr + String(stale.code)).toContain('CORE-001');

    const validate = tracey(ws.dir, ['query', 'validate', '--deny', 'warnings']);
    expect(validate.code).not.toBe(0);
    // Pin the upstream message. If Tracey ever changes the wording, this test
    // fails loudly, which is exactly when we want to re-examine our gate.
    expect(validate.stderr).toContain('must be changed to match updated rule text');
  });
});
