<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_4_simulate_a_multi-reviewer_review_cycle_with_basel_part7.md
Description: Solutions and Explanations
==========================================
-->

<!-- docs/approval-gate.md (excerpt, ≥400 words full document) -->
# Approval Gate

## Artefact format

An approval is a JSON file at `approvals/<specName>/<tag>.json`. It contains:

    {
      "specName": "core",
      "tag": "baseline-2026-03-01",
      "hash": "<blake3 of canonicalised spec set>",
      "hashAlgorithm": "blake3",
      "approvedAt": "2026-03-01T12:00:00Z",
      "approvedBy": ["reviewer-r1@example.invalid"],
      "acknowledgements": ["CORE-GW-004"],
      "signatures": [
        { "reviewer": "reviewer-r1@example.invalid", "keyId": "r1@2026", "sig": "base64…" }
      ]
    }

The file lives in the repository so any pipeline can recompute the hash and
verify the signature without a database.

## Hash canonicalisation

The hash covers the sorted list of `.sdoc` files included by the spec, plus,
for each file, its full byte content. Sort order is by repository-relative
path, bytewise. Line endings are normalised to LF before hashing, and UTF-8 BOM
is stripped. The choice of bytewise sort (rather than locale-aware) is
deliberate: locale-aware sort produces different results on machines with
different `LANG`, which would break reproducibility. Normalising line endings
and BOM means a reviewer approving on Windows and a reviewer approving on Linux
agree on the hash of the same logical content.

## Feedback addressing

Reviewer feedback is a separate artefact, `approvals/<specName>/<tag>.feedback.json`:

    {
      "specName": "core",
      "tag": "baseline-2026-03-01",
      "entries": [
        { "uid": "CORE-GW-004", "body": "Signature algorithm must be pinned to EdDSA." }
      ]
    }

Every entry must name a UID that exists in the current spec. Feedback bodies
that name only a section title are rejected by the pipeline: `bin/approve.ts`
looks up each entry's UID via `tracey query rule` and refuses to proceed if any
UID is unknown. This is the mechanism that keeps feedback addressable and
routable — a section title is not a stable address across versions, whereas a
UID is.

## MCP tools in the loop

The reviewer dashboard uses `tracey_status`, `tracey_uncovered`,
`tracey_untested`, `tracey_stale`, `tracey_rule`, and `tracey_config` to build
its view. `tracey_validate` is reserved for the pipeline gate: it is not
exposed to the dashboard because validation is a correctness property, not a
review-time action.
