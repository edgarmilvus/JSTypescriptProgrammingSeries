/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_simulate_a_multi-reviewer_review_cycle_with_basel_part8.ts
Description: Solutions and Explanations
==========================================
*/

// bin/approve.ts
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, relative } from 'node:path';
import { sign as edSign, createPrivateKey } from 'node:crypto';
import { globSync } from 'glob';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
export interface ApprovalArtefact {
  specName: string;
  tag: string;
  hash: string;
  hashAlgorithm: 'blake3';
  approvedAt: string;
  approvedBy: string[];
  acknowledgements: string[];
  signatures: Array<{ reviewer: string; keyId: string; sig: string }>;
}

export interface FeedbackEntry { uid: string; body: string; }

export class ApprovalError extends Error {
  constructor(message: string, public readonly kind: string) { super(message); }
}

// ---------------------------------------------------------------------------
// Canonical hash. The rules here are the reproducibility contract of the gate:
// any change to sort order, line-ending normalisation, or BOM stripping is a
// breaking change to every stored approval.
// ---------------------------------------------------------------------------
export function canonicalHash(specFiles: string[], cwd = process.cwd()): string {
  const h = createHash('blake3');
  const sorted = [...specFiles].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  for (const f of sorted) {
    const rel = relative(cwd, f).split('\\').join('/'); // Windows → POSIX
    let body = readFileSync(f);
    if (body.length >= 3 && body[0] === 0xef && body[1] === 0xbb && body[2] === 0xbf) {
      body = body.subarray(3); // strip UTF-8 BOM
    }
    const text = body.toString('utf8').replace(/\r\n/g, '\n');
    h.update(rel + '\n');
    h.update(text);
  }
  return h.digest('hex');
}

// ---------------------------------------------------------------------------
// Validation gate. Called first; if it fails, we refuse to approve.
// ---------------------------------------------------------------------------
function validateTracey(cwd: string): void {
  try {
    execFileSync('tracey', ['query', 'validate', '--deny', 'warnings'], { cwd, stdio: 'pipe' });
  } catch (e) {
    const err = e as { stderr?: Buffer | string };
    throw new ApprovalError(
      `tracey validate failed: ${String(err.stderr ?? '')}`,
      'VALIDATE_FAILED',
    );
  }
}

// ---------------------------------------------------------------------------
// Feedback must be UID-addressable. A section title is never acceptable.
// ---------------------------------------------------------------------------
function assertFeedbackAddressable(entries: FeedbackEntry[], cwd: string): void {
  for (const entry of entries) {
    if (!/^[A-Za-z0-9_][A-Za-z0-9_.-]*$/.test(entry.uid)) {
      throw new ApprovalError(
        `feedback must name a UID (got "${entry.uid}"); section titles are not addressable`,
        'UNRESOLVABLE_UID',
      );
    }
    if (!entry.body.trim()) {
      throw new ApprovalError(`feedback for ${entry.uid} has an empty body`, 'EMPTY_BODY');
    }
    try {
      execFileSync('tracey', ['query', 'rule', entry.uid], { cwd, stdio: 'pipe' });
    } catch {
      throw new ApprovalError(`feedback references unknown UID ${entry.uid}`, 'UNKNOWN_UID');
    }
  }
}

// ---------------------------------------------------------------------------
// Signatures (stretch: multi-reviewer quorum). Two distinct ed25519 signers
// must be present. The keys are read from the environment; the public keys are
// committed under approvals/keys/.
// ---------------------------------------------------------------------------
function signArtefact(artefact: ApprovalArtefact, reviewerKeys: string[]): ApprovalArtefact {
  const canonical = JSON.stringify({
    specName: artefact.specName, tag: artefact.tag, hash: artefact.hash,
  });
  const signatures = reviewerKeys.map((path) => {
    const key = createPrivateKey(readFileSync(path));
    const sig = edSign(null, Buffer.from(canonical), key).toString('base64');
    return { reviewer: `${path}@local`, keyId: path.split('/').pop()!, sig };
  });
  const distinct = new Set(signatures.map((s) => s.keyId));
  if (distinct.size < 2) {
    throw new ApprovalError('quorum requires two distinct reviewer keys', 'QUORUM_NOT_MET');
  }
  return { ...artefact, signatures };
}

// ---------------------------------------------------------------------------
// Main entry
// ---------------------------------------------------------------------------
export interface ApproveOptions {
  specName: string;
  tag: string;
  specGlob: string;
  feedbackPath?: string;
  keyPaths?: string[];
  force?: boolean;
  cwd?: string;
}

export function approve(opts: ApproveOptions): ApprovalArtefact {
  const cwd = opts.cwd ?? process.cwd();
  const artefactsDir = join(cwd, 'approvals', opts.specName);
  const artefactPath = join(artefactsDir, `${opts.tag}.json`);

  // Refuse to overwrite a prior approval for the same tag with a different
  // hash unless --force is passed. This is the gate's fail-closed behaviour.
  const incomingHash = canonicalHash(globSync(opts.specGlob, { cwd, absolute: true }), cwd);
  if (existsSync(artefactPath)) {
    const prev = JSON.parse(readFileSync(artefactPath, 'utf8')) as ApprovalArtefact;
    if (prev.hash !== incomingHash && !opts.force) {
      throw new ApprovalError(
        `existing approval has hash ${prev.hash}, new content hashes to ${incomingHash}; ` +
        `pass --force to overwrite (previous will be printed)`,
        'HASH_MISMATCH',
      );
    }
    if (prev.hash !== incomingHash && opts.force) {
      console.error(`--force: replacing ${prev.hash}\n     with ${incomingHash}`);
    }
  }

  validateTracey(cwd);

  if (opts.feedbackPath) {
    const feedback = JSON.parse(readFileSync(opts.feedbackPath, 'utf8')) as { entries: FeedbackEntry[] };
    assertFeedbackAddressable(feedback.entries, cwd);
  }

  let artefact: ApprovalArtefact = {
    specName: opts.specName,
    tag: opts.tag,
    hash: incomingHash,
    hashAlgorithm: 'blake3',
    approvedAt: new Date().toISOString(),
    approvedBy: (opts.keyPaths ?? []).slice(),
    acknowledgements: [],
    signatures: [],
  };
  if (opts.keyPaths && opts.keyPaths.length > 0) {
    artefact = signArtefact(artefact, opts.keyPaths);
  }

  mkdirSync(artefactsDir, { recursive: true });
  writeFileSync(artefactPath, JSON.stringify(artefact, null, 2) + '\n', 'utf8');
  return artefact;
}
