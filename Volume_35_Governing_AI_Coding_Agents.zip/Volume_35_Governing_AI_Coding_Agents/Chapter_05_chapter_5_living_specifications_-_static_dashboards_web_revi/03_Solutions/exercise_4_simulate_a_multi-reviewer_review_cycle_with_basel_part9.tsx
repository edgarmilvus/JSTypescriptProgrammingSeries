/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_simulate_a_multi-reviewer_review_cycle_with_basel_part9.tsx
Description: Solutions and Explanations
==========================================
*/

// reviewer/dashboard.tsx
// React Server Component. Renders the reviewer's view of the gate: what is
// uncovered, untested, stale, or changed since the previous baseline, plus a
// feedback form bound to a UID.
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

interface DashboardProps {
  specName: string;
  baselineTag: string;
  previousBaselineTag: string | null;
}

interface RuleRef { uid: string; }

function tracey(cwd: string, args: string[]): string {
  return execFileSync('tracey', args, { cwd, encoding: 'utf8' });
}

function parseStale(out: string): Array<{ uid: string; currentVersion: number; referencedVersion: number }> {
  const rows: Array<{ uid: string; currentVersion: number; referencedVersion: number }> = [];
  const re = /^\s*([A-Za-z0-9_.-]+)\s+\([^)]+\)\s+v(\d+)\s*->\s*v(\d+)\s*$/;
  for (const line of out.split('\n')) {
    const m = re.exec(line);
    if (m) rows.push({ uid: m[1]!, referencedVersion: Number(m[2]), currentVersion: Number(m[3]) });
  }
  return rows;
}

function parseUids(out: string): string[] {
  return out.split('\n').map((l) => l.trim())
    .filter((l) => /^[A-Za-z0-9_][A-Za-z0-9_.-]*$/.test(l));
}

async function loadDashboardData(props: DashboardProps) {
  const cwd = process.cwd();
  const uncovered = parseUids(tracey(cwd, ['query', 'uncovered', '--spec_impl', props.specName]));
  const untested = parseUids(tracey(cwd, ['query', 'untested', '--spec_impl', props.specName]));
  const stale = parseStale(tracey(cwd, ['query', 'stale', '--spec_impl', props.specName]));

  // Current approval, if any.
  const approvalPath = join(cwd, 'approvals', props.specName, `${props.baselineTag}.json`);
  const approval = existsSync(approvalPath)
    ? JSON.parse(readFileSync(approvalPath, 'utf8')) as { hash: string; signatures: unknown[] }
    : null;

  // Tamper detection: recompute the hash from the working tree and compare.
  // This is the difference between a decorative dashboard and a gate.
  const currentHash = approval
    ? execFileSync(process.execPath, [
        'bin/approve.js', '--print-hash', props.specName, props.baselineTag,
      ], { cwd, encoding: 'utf8' }).trim()
    : null;
  const tampered = approval !== null && currentHash !== approval.hash;

  return { uncovered, untested, stale, approval, tampered };
}

export default async function ReviewerDashboard(props: DashboardProps) {
  const data = await loadDashboardData(props);

  return (
    <main>
      <h1>{props.specName} @ {props.baselineTag}</h1>

      {data.approval === null
        ? <p>No approval artefact for this baseline. Run <code>bin/approve.ts</code> to create one.</p>
        : data.tampered
          ? <p role="alert">
              Approval hash does not match the working tree. The spec has been modified since approval.
            </p>
          : <p>Approved. Signatures: {data.approval.signatures.length}.</p>}

      <section><h2>Uncovered</h2>
        {data.uncovered.length === 0
          ? <p>None.</p>
          : <ul>{data.uncovered.map((uid) => (
              <li key={uid}>
                <code>{uid}</code>{' '}
                <details>
                  <summary>Attach feedback</summary>
                  {/*
                    The form posts to /api/feedback. The hidden input carries
                    the UID; the server rejects bodies whose UID is not present
                    in the current spec, which is what keeps feedback addressable.
                  */}
                  <form action="/api/feedback" method="post">
                    <input type="hidden" name="uid" value={uid} />
                    <input type="hidden" name="tag" value={props.baselineTag} />
                    <textarea name="body" required />
                    <button type="submit">Submit</button>
                  </form>
                </details>
              </li>
            ))}</ul>}
      </section>

      <section><h2>Untested</h2>
        {data.untested.length === 0
          ? <p>None.</p>
          : <ul>{data.untested.map((uid) => <li key={uid}><code>{uid}</code></li>)}</ul>}
      </section>

      <section><h2>Stale</h2>
        {data.stale.length === 0
          ? <p>None.</p>
          : <table>
              <thead><tr><th>UID</th><th>Referenced</th><th>Current</th></tr></thead>
              <tbody>{data.stale.map((r) => (
                <tr key={r.uid}><td>{r.uid}</td><td>v{r.referencedVersion}</td><td>v{r.currentVersion}</td></tr>
              ))}</tbody>
            </table>}
      </section>
    </main>
  );
}
