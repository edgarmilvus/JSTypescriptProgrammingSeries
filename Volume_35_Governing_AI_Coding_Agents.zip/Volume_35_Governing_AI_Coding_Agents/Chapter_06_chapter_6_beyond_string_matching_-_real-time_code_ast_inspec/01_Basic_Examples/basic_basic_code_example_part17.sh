# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part17.sh
# Description: Basic Code Example
# ==========================================

# 1. Install tracey (pre-built binary).
curl --proto '=https' --tlsv1.2 -LsSf \
  https://github.com/bearcove/tracey/releases/latest/download/tracey-installer.sh | sh

# 2. Register the MCP server and the bundled skill with Claude Code and Codex.
tracey ai

# 3. From the repo root, start the daemon and open the dashboard.
tracey web --open

# 4. In another terminal, verify the graph loads cleanly.
tracey query validate --deny warnings

# 5. Install the pre-commit hook so version bumps cannot be forgotten.
cat > .git/hooks/pre-commit <<'HOOK'
#!/bin/sh
set -e
tracey pre-commit
HOOK
chmod +x .git/hooks/pre-commit
