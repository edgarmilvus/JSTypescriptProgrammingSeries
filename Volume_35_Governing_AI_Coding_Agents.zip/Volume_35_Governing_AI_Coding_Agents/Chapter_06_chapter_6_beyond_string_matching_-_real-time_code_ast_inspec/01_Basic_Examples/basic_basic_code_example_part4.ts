/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// src/auth/session.ts
// Runtime helpers for validating RS256 session tokens on the Acme gateway.
// The comments below carry Tracey annotations. Do not strip them.

import { createVerify, timingSafeEqual } from "node:crypto";
import { jwtVerify, importJWK, type JWTPayload } from "jose";

/** Result of a successful session validation. */
export interface SessionContext {
  readonly tenantId: string;
  readonly subject: string;
  readonly issuedAt: Date;
}

/** Error raised when a token fails any gate. */
export class SessionValidationError extends Error {
  constructor(public readonly reason: string) {
    super(reason);
    this.name = "SessionValidationError";
  }
}

const MAX_TOKEN_AGE_SECONDS = 3600;

// r[impl AUTH-SESSION-001]
// r[depends AUTH-SESSION-002]
/**
 * Verify an RS256-signed session token and enforce the 3600-second age limit.
 *
 * This is the *only* function in the gateway allowed to produce a
 * `SessionContext`. Every other module treats that value as the
 * authorization boundary.
 *
 * @param rawToken  The compact JWT string from the Authorization header.
 * @param publicJwk The public JWK for the tenant's signing key.
 * @param clock     Injected clock; defaults to `Date.now` in production.
 */
export async function validateSessionToken(
  rawToken: string,
  publicJwk: Record<string, unknown>,
  clock: () => number = Date.now,
): Promise<SessionContext> {
  // Structural sanity check first — cheapest failure path.
  if (typeof rawToken !== "string" || rawToken.split(".").length !== 3) {
    throw new SessionValidationError("malformed-token");
  }

  // Import the JWK into a CryptoKey we can hand to jose.
  const key = await importJWK(publicJwk, "RS256");

  // Signature + claim verification. `jwtVerify` rejects `alg: none` by
  // default and is not susceptible to the classic key-confusion attack
  // because we pinned "RS256" above.
  const { payload } = await jwtVerify(rawToken, key, {
    algorithms: ["RS256"],
  });

  // Enforce the max-age invariant defined by AUTH-SESSION-001.
  assertFresh(payload, clock());

  return toSessionContext(payload);
}

// r[impl AUTH-SESSION-001]
function assertFresh(payload: JWTPayload, now: number): void {
  if (typeof payload.iat !== "number") {
    throw new SessionValidationError("missing-iat");
  }
  const ageSeconds = now / 1000 - payload.iat;
  if (ageSeconds < 0 || ageSeconds > MAX_TOKEN_AGE_SECONDS) {
    throw new SessionValidationError("stale-token");
  }
}

// r[impl AUTH-SESSION-002]
export function assertTenantMatch(
  ctx: SessionContext,
  requestHost: string,
): void {
  const expected = tenantFromHost(requestHost);
  // Constant-time comparison avoids a subtle cross-tenant timing oracle.
  const a = Buffer.from(ctx.tenantId, "utf8");
  const b = Buffer.from(expected, "utf8");
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    throw new SessionValidationError("tenant-mismatch");
  }
}

function tenantFromHost(host: string): string {
  // acme-acme.billing.example.com -> "acme"
  const label = host.split(".")[0] ?? "";
  const dash = label.indexOf("-");
  return dash === -1 ? label : label.slice(0, dash);
}

function toSessionContext(payload: JWTPayload): SessionContext {
  if (typeof payload.sub !== "string" || typeof payload.tenant_id !== "string") {
    throw new SessionValidationError("missing-claims");
  }
  return {
    subject: payload.sub,
    tenantId: payload.tenant_id,
    issuedAt: new Date((payload.iat as number) * 1000),
  };
}
