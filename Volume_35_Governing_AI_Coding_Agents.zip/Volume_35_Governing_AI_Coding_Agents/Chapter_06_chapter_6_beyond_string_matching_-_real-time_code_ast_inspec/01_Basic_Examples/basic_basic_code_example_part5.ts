/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

// tests/auth/session.test.ts
import { describe, expect, it, vi } from "vitest";
import { SignJWT, generateKeyPair } from "jose";
import {
  assertTenantMatch,
  SessionValidationError,
  validateSessionToken,
  type SessionContext,
} from "../../src/auth/session.js";

const jwkOf = async () => {
  const { publicKey, privateKey } = await generateKeyPair("RS256");
  return { publicJwk: await (await import("jose")).exportJWK(publicKey), privateKey };
};

const signToken = async (
  privateKey: CryptoKey,
  claims: Record<string, unknown>,
  ageSeconds = 0,
) =>
  new SignJWT(claims)
    .setProtectedHeader({ alg: "RS256" })
    .setIssuedAt(Math.floor(Date.now() / 1000) - ageSeconds)
    .sign(privateKey);

describe("validateSessionToken", () => {
  // r[verify AUTH-SESSION-001]
  it("accepts a fresh, correctly-signed token", async () => {
    const { publicJwk, privateKey } = await jwkOf();
    const token = await signToken(privateKey, {
      sub: "user-42",
      tenant_id: "acme",
    });
    const ctx = await validateSessionToken(token, publicJwk);
    expect(ctx.subject).toBe("user-42");
    expect(ctx.tenantId).toBe("acme");
  });

  // r[verify AUTH-SESSION-001]
  it("rejects a token older than 3600 seconds", async () => {
    const { publicJwk, privateKey } = await jwkOf();
    const token = await signToken(
      privateKey,
      { sub: "user-42", tenant_id: "acme" },
      3601,
    );
    await expect(validateSessionToken(token, publicJwk)).rejects.toThrow(
      /stale-token/,
    );
  });

  // r[verify AUTH-SESSION-001]
  it("rejects a structurally malformed token before any crypto work", async () => {
    const { publicJwk } = await jwkOf();
    await expect(
      validateSessionToken("not.a.jwt", publicJwk),
    ).rejects.toThrow(/malformed-token/);
  });
});

describe("assertTenantMatch", () => {
  // r[verify AUTH-SESSION-002]
  it("passes when the host-derived tenant matches the claim", () => {
    const ctx: SessionContext = {
      tenantId: "acme",
      subject: "user-42",
      issuedAt: new Date(),
    };
    expect(() => assertTenantMatch(ctx, "acme-eu.billing.example.com")).not.toThrow();
  });

  // r[verify AUTH-SESSION-002]
  it("throws on cross-tenant mismatch", () => {
    const ctx: SessionContext = {
      tenantId: "acme",
      subject: "user-42",
      issuedAt: new Date(),
    };
    expect(() => assertTenantMatch(ctx, "globex-eu.billing.example.com")).toThrow(
      /tenant-mismatch/,
    );
  });
});
