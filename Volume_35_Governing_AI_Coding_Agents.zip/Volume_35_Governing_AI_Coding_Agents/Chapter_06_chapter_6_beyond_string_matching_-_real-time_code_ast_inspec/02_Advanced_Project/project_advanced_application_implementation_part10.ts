/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/unit/services/session.service.test.ts
import { describe, it, expect, beforeEach, vi } from "vitest";
import {
  createConversation,
  getConversationForTenant,
  deleteConversationCascade,
} from "@/server/services/session.service";
import { db } from "@/server/db/client";
import { Conversations, Messages } from "@/server/db/schema";

describe("session.service", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  // r[verify session.membership.tenant-isolation]
  it("returns null when the conversation belongs to a foreign tenant", async () => {
    vi.spyOn(db.query.conversations, "findFirst").mockResolvedValue(null);

    const result = await getConversationForTenant(
      "01H8XGJWBWBAQ4NX8Q6P0QZ9K3",
      "tenant-b",
    );

    expect(result).toBeNull();
    // The mock's `where` argument is the SSOT for tenant isolation — assert
    // that the query is filtered by tenant_id and not merely by conversation id.
    const whereArg = (db.query.conversations.findFirst as any).mock.calls[0][0]
      .where;
    expect(whereArg).toBeDefined();
  });

  // r[verify session.delete.cascade-messages]
  it("deletes messages and conversation in a single transaction", async () => {
    const cascade = vi.spyOn(db, "transaction").mockImplementation(async (fn) => {
      const tx = {
        query: {
          messages: {
            findMany: vi.fn().mockResolvedValue([{ id: "m1" }, { id: "m2" }]),
          },
        },
        delete: vi.fn().mockReturnValue({ where: vi.fn().mockResolvedValue([]) }),
        update: vi
          .fn()
          .mockReturnValue({ set: vi.fn().mockReturnValue({ where: vi.fn() }) }),
      } as any;
      return await fn(tx);
    });

    const deleted = await deleteConversationCascade(
      "01H8XGJWBWBAQ4NX8Q6P0QZ9K3",
      "tenant-a",
    );

    expect(deleted).toBe(2);
    expect(cascade).toHaveBeenCalledTimes(1);
  });
});
