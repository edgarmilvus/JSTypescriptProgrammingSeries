/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part11.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/integration/actions/send-message.action.test.ts
import { describe, it, expect, beforeAll, afterAll, vi } from "vitest";
import { sendMessage } from "@/server/actions/chat/send-message.action";
import { persistMessage } from "@/server/db/repositories/message.repository";
import { streamFromProvider } from "@/server/services/ai/provider";
import { assertNoPII } from "@/server/services/guard/pii";

describe("sendMessage Server Action (integration)", () => {
  beforeAll(() => {
    vi.mock("@/server/auth", () => ({
      auth: async () => ({ tenantId: "tenant-a", userId: "user-a" }),
    }));
  });

  afterAll(() => {
    vi.restoreAllMocks();
  });

  // r[verify session.persist.at-least-once]
  it("persists the user message before yielding any delta", async () => {
    const persistOrder: string[] = [];
    vi.spyOn({ persistMessage }, "persistMessage" as any).mockImplementation(
      async () => {
        persistOrder.push("persist");
        return { id: "msg-1" };
      },
    );
    vi.mock("@/server/services/ai/provider", () => ({
      streamFromProvider: async function* () {
        persistOrder.push("stream");
        yield { kind: "text", text: "hi" };
      },
    }));

    const gen = sendMessage({
      conversationId: "c-1",
      content: "hello world",
    });

    const first = await gen.next();
    expect(first.value).toMatchObject({ kind: "message_ack" });
    expect(persistOrder).toEqual(["persist", "stream"]);
  });

  // r[verify stream.transport.delta-chunking]
  it("emits ordered deltas and terminates with finish_reason", async () => {
    vi.mock("@/server/services/ai/provider", () => ({
      streamFromProvider: async function* () {
        yield { kind: "text", text: "Hel" };
        yield { kind: "text", text: "lo" };
        yield { kind: "finish", finishReason: "stop" };
      },
    }));
    vi.mock("@/server/services/guard/pii", () => ({
      assertNoPII: async () => undefined,
    }));

    const chunks = [];

    for await (const delta of sendMessage({
      conversationId: "c-1",
      content: "hello",
    })) {
      chunks.push(delta);
    }

    const lastChunk = chunks[chunks.length - 1];
    expect(lastChunk).toMatchObject({ kind: "finish", finishReason: "stop" });
  });

  // r[verify stream.cancel.propagate-upstream]
  it("tears down upstream when the consumer aborts mid-stream", async () => {
    const teardown = vi.fn();
    vi.mock("@/server/services/ai/provider", () => ({
      streamFromProvider: async function* () {
        try {
          yield { kind: "text", text: "a" };
          yield { kind: "text", text: "b" };
        } finally {
          teardown();
        }
      },
    }));

    const gen = sendMessage({ conversationId: "c-1", content: "x" });
    await gen.next();
    await gen.return(undefined);

    expect(teardown).toHaveBeenCalledTimes(1);
  });
});
