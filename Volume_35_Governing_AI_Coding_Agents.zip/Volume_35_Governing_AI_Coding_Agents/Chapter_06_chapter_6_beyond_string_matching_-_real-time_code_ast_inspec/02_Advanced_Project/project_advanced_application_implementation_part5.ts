/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part5.ts
Description: Advanced Application Implementation
==========================================
*/

// src/server/services/session.service.ts
import { db } from "../db/client";
import { Conversations, Messages } from "../db/schema";
import { and, eq, isNull } from "drizzle-orm";
import { randomUUIDv7 } from "../util/uuid";

/**
 * Result type returned by session creation. Modelled as a discriminated union
 * rather than a thrown error so Server Actions can serialize it across the
 * network boundary without losing the failure reason.
 */
export type CreateConversationResult =
  | { ok: true; conversationId: string }
  | { ok: false; reason: "quota_exhausted"; retryAfterSeconds: number };

/**
 * Creates a new conversation for the authenticated user.
 *
 * The function performs three duties in one transaction:
 *
 *   1. Verifies the tenant has not exhausted its monthly quota. The check
 *      reads a materialized counter that is updated by a background job; the
 *      counter is allowed to lag by up to 60 seconds under load, which is
 *      documented in the SLA.
 *   2. Inserts a Conversation row with a UUIDv7 primary key so that range
 *      scans on `created_at` can be replaced by primary-key cursors.
 *   3. Returns a discriminated-union result rather than throwing, so the
 *      Server Action layer can map the failure directly onto an HTTP status.
 *
 * @param userId        - Authenticated user identifier from the session cookie.
 * @param tenantId      - Tenant identifier resolved from the user row.
 * @returns A discriminated union describing success or the typed failure.
 */
// r[impl session.create]
export async function createConversation(
  userId: string,
  tenantId: string,
): Promise<CreateConversationResult> {
  const quota = await db.query.quotaCounters.findFirst({
    where: eq(quotaCounters.tenantId, tenantId),
  });

  if (quota && quota.monthlySent >= quota.monthlyLimit) {
    return {
      ok: false,
      reason: "quota_exhausted",
      retryAfterSeconds: 60 * 60 * 24,
    };
  }

  const conversationId = randomUUIDv7();

  await db.transaction(async (tx) => {
    await tx.insert(Conversations).values({
      id: conversationId,
      tenantId,
      createdBy: userId,
    });
  });

  return { ok: true, conversationId };
}

/**
 * Reads a conversation by ID with tenant isolation enforced at the query
 * level. Note the deliberate choice of `404` over `403` when the row exists
 * for a different tenant — this is a requirement, not a stylistic choice, and
 * the test suite asserts it explicitly.
 *
 * @param conversationId - The conversation UUIDv7 from the route segment.
 * @param tenantId       - The tenant making the request, resolved from auth.
 * @returns The conversation row, or `null` if it does not exist for this tenant.
 */
// r[impl session.membership.tenant-isolation]
export async function getConversationForTenant(
  conversationId: string,
  tenantId: string,
): Promise<Conversation | null> {
  const row = await db.query.conversations.findFirst({
    where: and(
      eq(Conversations.id, conversationId),
      eq(Conversations.tenantId, tenantId),
      isNull(Conversations.deletedAt),
    ),
  });
  return row ?? null;
}

/**
 * Deletes a conversation and all of its messages atomically. Messages are
 * removed in the same transaction as the conversation so that a mid-flight
 * failure leaves no orphan rows visible to readers.
 *
 * The foreign key on `messages.conversation_id` declares `ON DELETE CASCADE`,
 * but we delete explicitly because the audit-log exporter needs the pre-delete
 * message count and must run inside the same transaction as the deletes.
 *
 * @param conversationId - Conversation to delete.
 * @param tenantId       - Tenant performing the delete.
 * @returns The number of messages that were deleted along with the parent.
 */
// r[impl session.delete.cascade-messages]
export async function deleteConversationCascade(
  conversationId: string,
  tenantId: string,
): Promise<number> {
  return await db.transaction(async (tx) => {
    const messages = await tx.query.messages.findMany({
      where: eq(Messages.conversationId, conversationId),
    });

    await tx.delete(Messages).where(eq(Messages.conversationId, conversationId));
    await tx
      .update(Conversations)
      .set({ deletedAt: new Date() })
      .where(
        and(
          eq(Conversations.id, conversationId),
          eq(Conversations.tenantId, tenantId),
        ),
      );

    return messages.length;
  });
}
