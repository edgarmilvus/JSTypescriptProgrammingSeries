/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

// src/server/actions/chat/send-message.action.ts
"use server";

import { auth } from "@/server/auth";
import { persistMessage } from "@/server/db/repositories/message.repository";
import { streamFromProvider } from "@/server/services/ai/provider";
import { assertNoPII } from "@/server/services/guard/pii";
import type { Delta } from "@/shared/types/streaming";

/**
 * Sends a user message and streams back assistant deltas.
 *
 * The flow is deliberately structured so that persistence happens *before*
 * the first delta is emitted. This is what the requirement
 * `session.persist.at-least-once` demands: if the client aborts after the
 * first delta arrives but before the final one, the user has still seen a
 * message that is guaranteed to exist in the database.
 *
 * Cancellation is honoured two ways. If the client disconnects, the
 * `AbortSignal` on the request is fired and the upstream provider connection
 * is torn down within 500 ms. If the user explicitly clicks "stop", the
 * Client Component invokes a cancel endpoint that flips a Redis flag the
 * generator polls on every iteration.
 *
 * @param input - Discriminated-union payload. The `attachments` field is
 *                optional; when present, it is validated against the file
 *                allow-list before anything else runs.
 * @yields Delta chunks in wire order, terminated by `finish_reason`.
 */
// r[impl stream.transport.delta-chunking]
// r[impl stream.cancel.propagate-upstream]
// r[impl session.persist.at-least-once]
export async function* sendMessage(input: {
  conversationId: string;
  content: string;
  attachments?: ReadonlyArray<{ mime: string; url: string }>;
}): AsyncGenerator<Delta, void, void> {
  const session = await auth();
  if (!session) {
    throw new Error("unauthenticated");
  }

  // Guard rail runs first. It is annotated separately because its requirement
  // has a different verification method (unit) than the streaming pipeline.
  await assertNoPII(input.content);

  const persisted = await persistMessage({
    conversationId: input.conversationId,
    tenantId: session.tenantId,
    role: "user",
    content: input.content,
  });

  yield { kind: "message_ack", messageId: persisted.id };

  for await (const delta of streamFromProvider({
    conversationId: input.conversationId,
    attachmentUrls: input.attachments?.map((a) => a.url) ?? [],
    userMessageId: persisted.id,
  })) {
    yield delta;
  }
}
