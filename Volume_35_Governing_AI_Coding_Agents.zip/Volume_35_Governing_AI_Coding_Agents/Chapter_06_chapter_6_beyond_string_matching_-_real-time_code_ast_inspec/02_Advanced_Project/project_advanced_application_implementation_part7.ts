/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

// src/server/services/guard/pii.ts
import { piiDetector } from "../ml/pii-detector";
import { GuardError } from "./errors";

/**
 * Asserts that the incoming text does not contain detected PII.
 *
 * The detector is a small on-premises classifier; the platform never sends
 * user text to a third-party PII service because that would itself be a data
 * transfer the SOC 2 addendum forbids. The detector is loaded lazily so that
 * cold start of the API route does not pay the model-load cost.
 *
 * @param text - Raw user input, exactly as sent from the Client Component.
 * @throws GuardError if PII is detected. The error carries a redacted
 *         snippet for logging and the detector's confidence score.
 */
// r[impl guard.pii.detect-on-input]
export async function assertNoPII(text: string): Promise<void> {
  const result = await piiDetector.classify(text);
  if (result.hasPII) {
    throw new GuardError({
      kind: "pii_detected",
      confidence: result.confidence,
      redactedSnippet: result.redactedSnippet,
    });
  }
}
