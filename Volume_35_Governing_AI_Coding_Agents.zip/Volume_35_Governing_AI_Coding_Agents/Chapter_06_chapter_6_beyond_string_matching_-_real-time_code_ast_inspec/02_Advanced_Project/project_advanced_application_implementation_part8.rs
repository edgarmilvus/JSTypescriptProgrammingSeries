/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.rs
Description: Advanced Application Implementation
==========================================
*/

// crates/tokenizer/src/lib.rs
use tiktoken_rs::cl100k_base;
use once_cell::sync::Lazy;

static BPE: Lazy<tiktoken_rs::CoreBPE> = Lazy::new(|| {
    cl100k_base().expect("cl100k_base vocabulary is bundled at compile time")
});

/// Counts tokens for the given text using the cl100k_base BPE vocabulary.
///
/// This function is deliberately cheap: the vocabulary is loaded once into a
/// process-wide `Lazy` and reused for every call. Callers that need to count
/// frequently should batch inputs through `count_tokens_batch` to amortise
/// the per-call FFI overhead.
///
/// The function is annotated with `r[impl stream.backpressure.bounded-buffer]`
/// because the token count is the primary signal the TypeScript layer uses to
/// decide whether the client buffer is approaching its bound.
///
/// # Panics
///
/// Never. The vocabulary is validated once at process startup via `Lazy`.
// r[impl stream.backpressure.bounded-buffer]
pub fn count_tokens(text: &str) -> u32 {
    BPE.encode_with_special_tokens(text).len() as u32
}

/// Pre-tokenizes text into a `Vec<u32>` token id stream.
///
/// Emits token ids in the exact order that the model provider will receive
/// them, which lets the TypeScript streaming layer emit *provider-native*
/// token-level deltas without a second tokenization pass. This is required by
/// `stream.transport.delta-chunking`: chunks must be contiguous on the same
/// vocabulary the provider uses.
// r[impl stream.transport.delta-chunking]
pub fn pretokenize(text: &str) -> Vec<u32> {
    BPE.encode_with_special_tokens(text)
}
