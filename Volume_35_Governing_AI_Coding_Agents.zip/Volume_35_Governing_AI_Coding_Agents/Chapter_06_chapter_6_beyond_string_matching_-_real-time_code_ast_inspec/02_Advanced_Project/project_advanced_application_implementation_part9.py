# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_implementation_part9.py
# Description: Advanced Application Implementation
# ==========================================

# services/analytics/retention.py
from dataclasses import dataclass
from datetime import datetime, timedelta

from services.analytics.db import fetch_message_counts


@dataclass(frozen=True)
class RetentionWindow:
    """One row of the retention report: a 30-day bucket and its message count."""

    bucket_start: datetime
    message_count: int


# r[impl session.persist.at-least-once]
def compute_retention_windows(tenant_id: str) -> list[RetentionWindow]:
    """Compute 30-day retention windows for one tenant.

    The report is used by the compliance dashboard to demonstrate that the
    platform retains user messages for the contractual 90-day minimum. The
    function is intentionally a pure read: it does not write anything, does
    not mutate the audit log, and can be re-run idempotently.

    Annotated with `r[impl session.persist.at-least-once]` because a
    retention report is only meaningful if every message is durable.

    Args:
        tenant_id: The tenant whose report is being computed.

    Returns:
        A list of `RetentionWindow` rows ordered by descending bucket_start.
    """
    now = datetime.utcnow()
    windows: list[RetentionWindow] = []
    for offset_days in range(0, 90, 30):
        bucket_end = now - timedelta(days=offset_days)
        bucket_start = bucket_end - timedelta(days=30)
        count = fetch_message_counts(tenant_id, bucket_start, bucket_end)
        windows.append(
            RetentionWindow(bucket_start=bucket_start, message_count=count)
        )
    return windows
