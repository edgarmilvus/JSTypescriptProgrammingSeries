/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_ast-aware_spec_anchoring_for_a_react_component_li.tsx
Description: Solutions and Explanations
==========================================
*/

// ============================================================
// Exercise 1 — AST-Aware Spec Anchoring for <DataTable>
// All deliverables are exported as typed constants so an instructor
// can `import` them and diff them against reference artifacts.
// ============================================================

/**
 * 1) StrictDoc specification fragment.
 *    - three requirements
 *    - one multiline STATEMENT
 *    - one Parent RELATIONS block
 */
export const DATATABLE_SDOC = `[DOCUMENT]
TITLE: DataTable Component Specification
OPTIONS:
  MARKUP: Markdown

[[SECTION]]
TITLE: Rendering

[REQUIREMENT]
UID: REQ-DATATABLE-RENDER-ROWS
STATUS: Approved
TITLE: Render one row per data element
STATEMENT: >>>
The DataTable component shall render exactly one row for each element
of the \`data\` array passed to it. Each rendered row shall be keyed
using the value returned by the \`rowKey\` accessor. Rows MUST NOT be
keyed by array index, because the index is not stable across sorts
or filter operations.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: REQ-DATATABLE
[/SECTION]

[[SECTION]]
TITLE: States

[REQUIREMENT]
UID: REQ-DATATABLE-EMPTY-STATE
STATUS: Approved
TITLE: Empty state
STATEMENT: When the \`data\` array is empty, the DataTable shall render the
\`emptyState\` slot instead of an empty table body.
RELATIONS:
- TYPE: Parent
  VALUE: REQ-DATATABLE

[REQUIREMENT]
UID: REQ-DATATABLE-SORT-A11Y
STATUS: Approved
TITLE: Sort column accessibility
STATEMENT: When a column is sortable, the header cell shall expose
\`aria-sort\` with one of \`ascending\`, \`descending\`, or \`none\`.
RELATIONS:
- TYPE: Parent
  VALUE: REQ-DATATABLE
`;

/**
 * 2) Tracey configuration in Styx syntax.
 */
export const TRACEY_CONFIG_STYX = `@schema {id crate:tracey-config@1, cli tracey}

specs (
    {
        name datatable
        source_url https://github.com/example/datatable
        include (docs/spec/**/*.sdoc)
        impls (
            {
                name typescript
                include (src/**/*.ts src/**/*.tsx)
                exclude (dist/** node_modules/**)
                test_include (src/**/*.spec.ts src/**/*.test.tsx)
            }
        )
    }
)
`;

/**
 * 2b) Prose rationale for the test_include contract.
 *     Tracey enforces test-file semantics at *validation* time,
 *     not at parse time. The worker sees a file; the supervisor
 *     sees the config; only the supervisor can reject.
 */
export const TEST_INCLUDE_RATIONALE = `
Why test_include is a hard constraint
-------------------------------------
test_include marks a glob as implementation-only for *test* semantics.
Tracey's contract (see the annotating-code guide) is:

  - files matched by test_include may contain only \`verify\` verbs;
  - files NOT matched by test_include may contain \`impl\`, \`depends\`,
    and \`related\`, and may contain \`verify\` but are not required to.

Two symmetric violations exist and both are hard errors surfaced by
\`tracey_validate\` (or, in the LSP, as severity=Error diagnostics):

  - \`impl\` annotation in a file matched by test_include
      → error message: "impl annotation in a file matched by test_include"
  - \`verify\` annotation on a file that the grammar/config otherwise
    treats as a pure spec anchor is *not* an error, but a verify
    annotation on a function that is not a test function will be
    reported by tracey_unmapped as an unmapped unit.

The reason the constraint is not syntactic is that Tracey cannot tell
from a single file whether "this function is a test". Only the config
knows that. Therefore the enforcement point is the supervisor that
combines the config with the per-file worker result.
`;

/**
 * 3) Refactor resilience narrative.
 *    We demonstrate three ordered refactors on component.tsx.
 */
export const REFACTOR_NARRATIVE = `
================================================================
Refactor 1 — Extract useTableRows(data)
----------------------------------------------------------------
Before:

  // src/DataTable.tsx
  // r[impl REQ-DATATABLE-RENDER-ROWS]
  export function DataTable({ data, rowKey }: Props) {
    return <tbody>{data.map((row, i) => <tr key={i}>...</tr>)}</tbody>;
  }

After:

  // src/DataTable.tsx
  // r[impl REQ-DATATABLE-RENDER-ROWS]
  export function DataTable({ data, rowKey }: Props) {
    const rows = useTableRows(data);
    return <tbody>{rows.map((r) => <tr key={r.key}>...</tr>)}</tbody>;
  }

  // src/hooks/useTableRows.ts
  // r[impl REQ-DATATABLE-RENDER-ROWS]
  export function useTableRows(data: Row[]) { /* ... */ }

DECISION: DUPLICATE.
The annotation attaches to the *nearest following language construct*,
not to a line. Because the row-mapping responsibility moved into the
hook, both the JSX call site and the hook are now implementation
anchors for the same requirement. Tracey allows multiple functions
to implement one requirement, so duplication is correct, not drift.

================================================================
Refactor 2 — Rename prop rows -> dataRows (codemod)
----------------------------------------------------------------
Before:  <DataTable rows={r} rowKey="id" />
After:   <DataTable dataRows={r} rowKey="id" />

DECISION: UNTOUCHED.
The annotation on DataTable references a *function*, not a prop name.
Because Tracey parses the AST, the anchor is the FunctionDeclaration
node. Renaming a prop is a change to a Parameter or ObjectPattern
node, which is a descendant of the same function node. The anchor
survives verbatim.

================================================================
Refactor 3 — Add src/DataTable.test.tsx with a verify annotation
----------------------------------------------------------------
  // src/DataTable.test.tsx
  // r[verify REQ-DATATABLE-EMPTY-STATE]
  it("renders the emptyState slot when data is empty", () => {
    render(<DataTable data={[]} emptyState={<span>none</span>} />);
  });

DECISION: ADD. THE FILE IS IN test_include.
The verify annotation is legal *only* because this file matches
test_include. If it were placed in src/DataTable.tsx (which is not
a test file) the annotation would still parse, but the requirement
would not gain coverage for verification — Tracey would surface it
via tracey_untested for the *impl* file and via tracey_unmapped
for the non-test file.
`;

/**
 * 4) Drift detection analysis.
 */
export const DRIFT_ANALYSIS = `
================================================================
Drift detection for REQ-DATATABLE-RENDER-ROWS
----------------------------------------------------------------
Chronology:

  t0: spec says "one row per element, keying undefined".
  t1: code @ impl anchors on DataTable + useTableRows.
  t2: spec text is edited to append:
        "Rows MUST be keyed by a stable rowKey prop and MUST NOT be
         keyed by array index."
      and is version-bumped: REQ-DATATABLE-RENDER-ROWS+2.

At t2, the existing code-side annotations on the two functions
still say \`r[impl REQ-DATATABLE-RENDER-ROWS]\`, which resolves to
version 1. Tracey's traceability graph holds a stale reference
edge for both anchors. The exact wording surfaced by tracey_stale
and by the LSP hover diagnostics is verbatim:

  "Implementation must be changed to match updated rule text —
   and ONLY ONCE THAT'S DONE must the code annotation be bumped."

Remediation sequence (must be in this order):
  1. Update the implementation: key rows by rowKey, remove index
     keying, add a vitest that exercises a reorder.
  2. THEN bump the annotation to \`+2\` on both anchors:
        // r[impl REQ-DATATABLE-RENDER-ROWS+2]

Why the order matters:
  - Bumping first and updating second would mark a semantically
    wrong implementation as covered. The +2 annotation is a
    *human statement* that the author has reviewed the diff. If the
    author bumps without reviewing, they are lying to the graph.
  - Also, stale references are not counted as covered while they
    lag. So an early bump *gains* coverage for wrong code, which
    is exactly the failure mode Tracey's staleness feature exists
    to prevent.
`;

/**
 * 5) Vitest skeleton. One file, three verify annotations,
 *    one per requirement. No assertions required.
 */
export const DATATABLE_TEST_SKELETON = `// src/DataTable.test.tsx
import { render } from "@testing-library/react";
import { DataTable } from "./DataTable";

// r[verify REQ-DATATABLE-RENDER-ROWS]
it("renders one row per element in the data array", () => {
  // TODO: render a table with N rows, assert row count == N
});

// r[verify REQ-DATATABLE-EMPTY-STATE]
it("renders the emptyState slot when the data array is empty", () => {
  // TODO: render with data=[], assert emptyState is visible
});

// r[verify REQ-DATATABLE-SORT-A11Y]
it("exposes aria-sort on sortable column headers", () => {
  // TODO: render sortable column, assert aria-sort attr
});
`;
