/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_incremental_intent_graph_updates_and_immutable_st.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================
// Exercise 2 — Incremental Intent Graph
// ============================================================

/** Monotonic revision. Every delta carries the revision it produces. */
export type Revision = number & { readonly __brand: "Revision" };

export type RequirementUID = string & { readonly __brand: "RequirementUID" };
export type SourcePath = string & { readonly __brand: "SourcePath" };
export type SpecPath = string & { readonly __brand: "SpecPath" };

/** Byte range within a source file, 0-indexed, end-exclusive. */
export interface ByteRange {
  readonly startByte: number;
  readonly endByte: number;
  readonly startLine: number;
  readonly endLine: number;
}

/** The AST scope an anchor is attached to. */
export type AnchorScope =
  | { kind: "function"; name: string }
  | { kind: "class"; name: string }
  | { kind: "file" }
  | { kind: "line" }
  | { kind: "range" };

export type TraceyVerb = "impl" | "verify" | "depends" | "related";

/** 1) Discriminated union of all mutations produced by re-parsing one file. */
export type GraphDelta =
  | {
      readonly tag: "spec.requirement.added";
      readonly file: SpecPath;
      readonly uid: RequirementUID;
      readonly text: string;
      readonly version: number;
      readonly revision: Revision;
    }
  | {
      readonly tag: "spec.requirement.removed";
      readonly file: SpecPath;
      readonly uid: RequirementUID;
      readonly revision: Revision;
    }
  | {
      readonly tag: "spec.requirement.modified";
      readonly file: SpecPath;
      readonly uid: RequirementUID;
      readonly oldText: string;
      readonly newText: string;
      readonly oldVersion: number;
      readonly newVersion: number;
      /** All anchors that were previously fresh become stale. */
      readonly invalidatedAnchors: ReadonlyArray<AnchorRef>;
      readonly revision: Revision;
    }
  | {
      readonly tag: "anchor.added";
      readonly file: SourcePath;
      readonly uid: RequirementUID;
      readonly verb: TraceyVerb;
      readonly scope: AnchorScope;
      readonly range: ByteRange;
      readonly revision: Revision;
    }
  | {
      readonly tag: "anchor.removed";
      readonly file: SourcePath;
      readonly uid: RequirementUID;
      readonly verb: TraceyVerb;
      readonly range: ByteRange;
      readonly revision: Revision;
    }
  | {
      readonly tag: "anchor.rescoped";
      readonly file: SourcePath;
      readonly uid: RequirementUID;
      readonly verb: TraceyVerb;
      readonly oldRange: ByteRange;
      readonly newRange: ByteRange;
      readonly oldScope: AnchorScope;
      readonly newScope: AnchorScope;
      readonly revision: Revision;
    };

/** Stable reference to an anchor, independent of byte offsets. */
export interface AnchorRef {
  readonly file: SourcePath;
  readonly uid: RequirementUID;
  readonly verb: TraceyVerb;
  readonly range: ByteRange;
}

/** 5) Anchor with explicit staleness discriminant. */
export type AnchorStaleness =
  | { readonly kind: "fresh"; readonly specVersion: number }
  | {
      readonly kind: "stale";
      readonly annotatedVersion: number;
      readonly currentVersion: number;
      /** Word-level diff produced by the spec writer. */
      readonly diff: ReadonlyArray<{ removed: string[]; added: string[] }>;
    };

export interface AnchorRecord extends AnchorRef {
  readonly staleness: AnchorStaleness;
  readonly scope: AnchorScope;
}

/* ------------------------------------------------------------
 * 3) useTraceyGraph signature (types only).
 *    The hook subscribes to a GraphDelta stream and exposes
 *    coverage that is a stable reference when revision is
 *    unchanged. `useMemo` alone is insufficient because it
 *    cannot observe external data arrival; the revision key
 *    is the dependency that forces recomputation.
 * ------------------------------------------------------------ */
export interface CoverageView {
  readonly revision: Revision;
  readonly impl: ReadonlySet<RequirementUID>;
  readonly verify: ReadonlySet<RequirementUID>;
  readonly stale: ReadonlySet<RequirementUID>;
  readonly uncovered: ReadonlySet<RequirementUID>;
  readonly untested: ReadonlySet<RequirementUID>;
}

export interface UseTraceyGraphResult {
  readonly coverage: CoverageView;
  readonly revision: Revision;
  /** Resolves the requirement record for a given UID. */
  readonly rule: (uid: RequirementUID) => {
    readonly uid: RequirementUID;
    readonly text: string;
    readonly version: number;
    readonly anchors: ReadonlyArray<AnchorRecord>;
  } | null;
}

export declare function useTraceyGraph(
  endpoint: string
): UseTraceyGraphResult;

/* ------------------------------------------------------------
 * 4) Debounce policy.
 * ------------------------------------------------------------ */
export interface DebouncePolicy {
  /** Time from last filesystem event to first rebuild. */
  readonly quietWindowMs: number;
  /** Hard upper bound: rebuild even if events keep arriving. */
  readonly maxBatchMs: number;
  /** Collapse bursts whose revision distance is < this. */
  readonly collapseThresholdRevisions: number;
}

export const DEFAULT_DEBOUNCE: DebouncePolicy = {
  quietWindowMs: 150,
  maxBatchMs: 750,
  collapseThresholdRevisions: 1,
};
