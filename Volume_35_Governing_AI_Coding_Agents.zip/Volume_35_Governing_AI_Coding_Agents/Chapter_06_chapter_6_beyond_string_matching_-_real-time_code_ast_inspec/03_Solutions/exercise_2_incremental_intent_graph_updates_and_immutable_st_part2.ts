/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_incremental_intent_graph_updates_and_immutable_st_part2.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================
// Exercise 2 (continued) — Prose essay, kept as a typed export
// ============================================================

export const PERSISTENT_GRAPH_ESSAY = `
============================================================================
Why the graph must be persistent, not merely immutable
============================================================================

"Immutable" and "persistent" are often conflated. An immutable structure
is one that is never mutated in place; a persistent structure is one that
*retains every prior version* while sharing storage between versions. A
Tracey-like daemon needs both properties simultaneously, because two
different clients (the LSP bridge and the MCP bridge) can be at two
different revisions at the same wall-clock moment, and both must be able
to answer queries without blocking the other.

Consider the LSP bridge. A developer is typing. The bridge receives a
snapshot at revision N, computes hover information for the function under
the cursor, and returns it. While it is computing, the daemon observes a
save and advances to revision N+1. If the graph were *mutable* — even if
it were "immutable by convention" but backed by a shared HashMap — the
LSP's snapshot would silently start reflecting N+1 mid-query, producing a
torn read: half the coverage numbers from N, half from N+1. A torn read is
not a performance bug; it is a correctness bug. The developer sees a
"covered" mark that flickers back to "uncovered" a moment later, which
erodes trust in the tool.

A persistent graph fixes this by definition. When the daemon receives a
GraphDelta at revision N+1, it does not modify the node at revision N. It
constructs a new root that reuses every unchanged subtree — file trees,
requirement records, anchor sets — and references them by pointer. Only
the nodes on the path from the root to the changed file's edge are
re-allocated. This is structural sharing, and it is what makes persistence
cheap. For a repository with 12,000 requirements and 40,000 anchors,
touching a single file changes O(depth) nodes, not O(n). The old revision
remains fully valid: the LSP bridge holds the latest revision it was
granted, and when it is done it atomically swaps its pointer forward. Any
queries issued against the older pointer return the older answer, and that
answer is at least internally consistent.

There is a second, subtler benefit. Under persistence, "staleness" becomes
a *derived* property rather than a mutation. When a spec requirement's text
changes, we do not walk all anchors and set a stale flag. We record a
spec.requirement.modified delta and let a selector compute, on demand,
whether each anchor's annotated version lags the current spec version. This
is why the anchor type below carries a `staleness` discriminant that is
computed by a fold over deltas, not stored. Mutating every anchor would
re-introduce the torn-read problem: an anchor half-marked stale is worse
than an anchor not yet marked.

The third benefit is history and auditability. Because each revision is a
value, a client can ask "what did coverage look like at revision N-3?"
without any extra machinery. This is exactly the pattern the dashboard uses
when it shows a delta ("3 newly covered requirements") after an edit: the
delta is a set difference between two persistent snapshots. If the graph
were mutable, the dashboard would need its own shadow copy. Persistence
eliminates the shadow copies.

Memory is bounded because of structural sharing plus garbage collection.
Old revisions are dropped once no reader holds a pointer: the LSP bridge
releases revision N as soon as it swaps to N+1, the MCP bridge releases its
own snapshots at the end of each RPC, and the daemon keeps only the current
revision plus any that a client has explicitly pinned. The default
retention window — the daemon's 10-minute idle timer — is generous enough
that no realistic human or agent session runs out of path layers. In
practice, a burst of 200 file edits in 400ms collapses to *one* new
revision under the debounce policy below, because the daemon batches
filesystem events during the quiet window before rebuilding.

The practical consequence is that the daemon's inner loop can be written as
a pure function:

    applyRevision(current: Graph, deltas: GraphDelta[]): Graph

Every bridge receives an immutable snapshot as the return value of that
function. There is no lock, no reader-writer mutex, no atomic-swap dance on
the query path. Concurrency falls out of the data structure rather than
being bolted onto it.
`;
