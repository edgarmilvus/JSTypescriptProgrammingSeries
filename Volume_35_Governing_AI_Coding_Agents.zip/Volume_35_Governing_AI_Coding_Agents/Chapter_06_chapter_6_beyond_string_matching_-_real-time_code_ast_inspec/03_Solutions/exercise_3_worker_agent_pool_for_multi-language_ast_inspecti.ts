/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_worker_agent_pool_for_multi-language_ast_inspecti.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================
// Exercise 3 — Worker Agent Pool
// ============================================================

export type Language =
  | "rust" | "typescript" | "tsx" | "javascript" | "jsx"
  | "python" | "go" | "c" | "cpp" | "objectivec" | "objcpp"
  | "java" | "kotlin" | "scala" | "groovy" | "csharp"
  | "zig" | "php" | "yaml" | "json5" | "swift";

/** 1) Supervisor state machine. */
export type SupervisorState =
  | { tag: "Idle"; lastRevision: Revision }
  | {
      tag: "Parsing";
      revision: Revision;
      submitted: number;
      completed: number;
      activeWorkers: number;
    }
  | { tag: "Draining"; revision: Revision; pending: number }
  | { tag: "Failed"; revision: Revision; reason: string; file: SourcePath };

export interface BatchHandle {
  readonly revision: Revision;
  readonly batchId: string;
}

export interface Progress {
  readonly submitted: number;
  readonly completed: number;
  readonly skipped: number;
  readonly errors: number;
}

export interface Supervisor {
  /** Enqueue a batch of file paths for a given revision. */
  submit(paths: ReadonlyArray<SourcePath>, revision: Revision): BatchHandle;
  /** Non-blocking progress query. */
  progress(handle: BatchHandle): Progress;
  /** Drain results for a completed batch; consumes the batch. */
  drain(handle: BatchHandle): Promise<ReadonlyArray<WorkerResult>>;
  readonly state: SupervisorState;
}

/**
 * Bounded concurrency. Parse work is CPU-bound, so the useful bound is
 * `min(os.cpus().length, MAX_WORKERS)`. We cap at 2 * cores to allow
 * one worker to be blocked on a directory read while the other parses;
 * spawning per-file is wasteful (process/thread creation dominates for
 * small files) and spawning one worker total serializes the monorepo.
 */
export const MAX_WORKERS = Math.max(2, Math.min(32, (globalThis.navigator as any)?.hardwareConcurrency ?? 8));

/* ------------------------------------------------------------
 * 2) Language-specialized worker.
 * ------------------------------------------------------------ */

export interface LanguageWorker {
  readonly language: Language;
  readonly extensionMatchers: ReadonlyArray<RegExp>;
  /** Reject if this worker is the wrong specialization. */
  accepts(path: SourcePath): boolean;
  /** Parse and extract. Throws on unrecoverable parser failure. */
  run(path: SourcePath, bytes: Uint8Array): WorkerResult;
}

/**
 * Annotations extracted from a single file. The `scope` field is the
 * AST node the annotation attached to (function, class, file, range),
 * *not* the line it happened to sit on.
 */
export interface ExtractedAnnotation {
  readonly verb: TraceyVerb;
  readonly uid: RequirementUID;
  readonly scope: AnchorScope;
  readonly range: ByteRange;
}

/** A code unit with no requirement reference — feeds tracey_unmapped. */
export interface UnmappedUnit {
  readonly kind: "function" | "class" | "struct" | "item";
  readonly name: string;
  readonly range: ByteRange;
  /** Canonical Python-style path for cross-file disambiguation. */
  readonly qualifiedName: string;
}

/** 3) The worker result type. */
export interface WorkerResult {
  readonly file: SourcePath;
  readonly language: Language;
  readonly annotations: ReadonlyArray<ExtractedAnnotation>;
  /** Consumed by tracey_unmapped: "units without requirement refs". */
  readonly unmapped: ReadonlyArray<UnmappedUnit>;
  readonly parseError: boolean;
  readonly parseErrorMessage?: string;
  /** How the file was classified by the supervisor. */
  readonly classification: "impl" | "test" | "spec" | "excluded";
}

/* ------------------------------------------------------------
 * 3b) How tracey_unmapped consumes the result.
 * ------------------------------------------------------------ */

export function traceyUnmapped(
  results: ReadonlyArray<WorkerResult>,
  filter?: { prefix?: string; path?: string }
): ReadonlyArray<UnmappedUnit & { file: SourcePath }> {
  return results
    .filter((r) => !r.parseError && r.classification !== "excluded")
    .filter((r) => (filter?.path ? r.file.startsWith(filter.path) : true))
    .flatMap((r) =>
      r.unmapped
        .filter((u) =>
          filter?.prefix ? u.qualifiedName.startsWith(filter.prefix) : true
        )
        .map((u) => ({ ...u, file: r.file }))
    );
}

/* ------------------------------------------------------------
 * 4) test_include enforcement.
 * ------------------------------------------------------------ */

export class TestIncludeViolation extends Error {
  constructor(
    public readonly file: SourcePath,
    public readonly line: number,
    public readonly uid: RequirementUID
  ) {
    super(
      `impl annotation in a file matched by test_include (${file}:${line}, ` +
      `uid=${uid}). Move the impl anchor to a production file, or ` +
      `convert it to a verify annotation if the code is a test.`
    );
    this.name = "TestIncludeViolation";
  }
}

/**
 * The supervisor combines the config (test_include globs) with the
 * worker result. The worker cannot do this: it sees one file.
 */
export function enforceTestInclude(
  config: { testInclude: ReadonlyArray<RegExp> },
  result: WorkerResult
): void {
  const isTestFile = config.testInclude.some((re) => re.test(result.file));
  if (!isTestFile) return;
  for (const a of result.annotations) {
    if (a.verb === "impl") {
      throw new TestIncludeViolation(result.file, a.range.startLine, a.uid);
    }
  }
}

/* ------------------------------------------------------------
 * 5) Generated-file handling.
 * ------------------------------------------------------------ */

export interface ExcludePolicy {
  /**
   * The union of: static `exclude` globs, `.gitignore` rules
   * discovered by the walker, and dynamically-appended globs from
   * the `tracey_config_exclude` MCP tool. The supervisor must consult
   * this union *before* submitting a path to a worker.
   */
  readonly globs: ReadonlyArray<RegExp>;
}

export function shouldSkip(path: SourcePath, policy: ExcludePolicy): boolean {
  return policy.globs.some((re) => re.test(path));
}
