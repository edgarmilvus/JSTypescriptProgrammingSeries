/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_real-time_ide_feedback_with_lsp_diagnostics_and_c.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================
// Exercise 4 — LSP Diagnostics and Completions
// ============================================================

/** 1) Diagnostic categories with severities and concrete messages. */
export type DiagnosticSeverity = "Error" | "Warning" | "Information";

export interface Diagnostic {
  readonly severity: DiagnosticSeverity;
  readonly code:
    | "unknown-requirement"
    | "unknown-prefix"
    | "unknown-verb"
    | "stale-reference"
    | "duplicate-definition"
    | "impl-in-test-file";
  readonly file: SourcePath;
  readonly range: ByteRange;
  readonly message: string;
}

/** Sample concrete messages, matching the documented error strings. */
export const DIAGNOSTIC_EXAMPLES: ReadonlyArray<Diagnostic> = [
  {
    severity: "Error",
    code: "unknown-requirement",
    file: "src/auth.ts" as SourcePath,
    range: { startByte: 0, endByte: 0, startLine: 12, endLine: 12 },
    message:
      "Unknown requirement 'auth.token.validaton'. Did you mean " +
      "'auth.token.validation'?",
  },
  {
    severity: "Error",
    code: "unknown-prefix",
    file: "src/auth.ts" as SourcePath,
    range: { startByte: 0, endByte: 0, startLine: 30, endLine: 30 },
    message: "Unknown prefix 'x'. Available prefixes: r, m, h2",
  },
  {
    severity: "Warning",
    code: "unknown-verb",
    file: "src/auth.ts" as SourcePath,
    range: { startByte: 0, endByte: 0, startLine: 44, endLine: 44 },
    message:
      "Unknown verb 'implement'. Valid verbs: impl, verify, depends, related",
  },
  {
    severity: "Warning",
    code: "stale-reference",
    file: "src/auth.ts" as SourcePath,
    range: { startByte: 0, endByte: 0, startLine: 60, endLine: 60 },
    message:
      "Implementation must be changed to match updated rule text — and " +
      "ONLY ONCE THAT'S DONE must the code annotation be bumped.",
  },
  {
    severity: "Error",
    code: "duplicate-definition",
    file: "docs/spec/auth.sdoc" as SourcePath,
    range: { startByte: 0, endByte: 0, startLine: 100, endLine: 100 },
    message:
      "Duplicate definition of 'auth.login'. First defined in " +
      "docs/spec/other.sdoc:42.",
  },
  {
    severity: "Error",
    code: "impl-in-test-file",
    file: "src/auth.spec.ts" as SourcePath,
    range: { startByte: 0, endByte: 0, startLine: 5, endLine: 5 },
    message:
      "impl annotation in a file matched by test_include. Test files may " +
      "only contain verify annotations.",
  },
];

/* ------------------------------------------------------------
 * 1b) "Did you mean" suggestion.
 * ------------------------------------------------------------ */

/**
 * Uses a normalized Levenshtein / Jaro-Winkler similarity. Tracey's
 * crate ecosystem uses `strsim`, which exposes both. We expose a
 * small compatible signature. The suggestion is only emitted when
 * the top score clears a threshold (0.8), otherwise the diagnostic
 * is emitted without a suggestion.
 */
export function suggestRequirement(
  unknown: string,
  known: ReadonlyArray<string>
): string | null {
  const scored = known
    .map((k) => ({ k, score: jaroWinkler(unknown, k) }))
    .sort((a, b) => b.score - a.score);
  return scored[0] && scored[0].score >= 0.8 ? scored[0].k : null;
}

declare function jaroWinkler(a: string, b: string): number;

/* ------------------------------------------------------------
 * 2) Virtual filesystem overlay.
 * ------------------------------------------------------------ */

export interface OverlayEntry {
  readonly uri: string;
  readonly languageId: string;
  readonly version: number;
  readonly text: string;
}

export interface Overlay {
  /** Register or update a buffer. Bumps version. */
  didOpen(entry: OverlayEntry): void;
  /** Replace content; invalidates all cached diagnostics for the uri. */
  didChange(uri: string, newText: string): void;
  /** Drop buffer; subsequent queries fall back to disk. */
  didClose(uri: string): void;
  /** Return the overlay content if present, else null. */
  read(uri: string): OverlayEntry | null;
  /** Enumerate all open buffers currently tracked. */
  open(): ReadonlyArray<OverlayEntry>;
}

/**
 * The daemon watches the filesystem. Unsaved buffers never hit the
 * filesystem (until save), so the overlay is the *only* place the
 * LSP can see unsaved edits. This is why the overlay is not
 * optional: without it, diagnostics would only appear after save.
 */

/* ------------------------------------------------------------
 * 3) Debounce and cancellation.
 * ------------------------------------------------------------ */

export interface DiagnosticScheduler {
  /**
   * Schedule a diagnostic run for a URI. Cancels any in-flight run
   * for the same URI and replaces it with a token-guarded run.
   */
  schedule(uri: string, delayMs: number): void;
  /** Cancel the run for a URI, if any. */
  cancel(uri: string): void;
  /** Fires when a run completes; the token identifies the run. */
  readonly onResult: (
    cb: (uri: string, token: number, diags: ReadonlyArray<Diagnostic>) => void
  ) => void;
}

export const DIAGNOSTIC_DEBOUNCE_MS = 180;

/**
 * Token scheme: each schedule() increments a per-URI counter.
 * The async computation captures the counter it started with. On
 * completion, if the counter no longer matches, the result is
 * discarded (the read was stale, but we still resolve the promise
 * so the caller can GC).
 */
export let __diagnosticToken = 0;

/* ------------------------------------------------------------
 * 4) Completion provider.
 * ------------------------------------------------------------ */

export type CompletionTrigger = "[" | "." | " ";

export interface CompletionContext {
  /** True only if the cursor is inside a comment token. */
  readonly inComment: boolean;
  /** The prefix detected before the cursor, e.g. "r[", "r[impl ". */
  readonly prefix: string;
  /** Parsed prefix token (r, m, h2) if any. */
  readonly prefixToken: string | null;
  /** The partial UID the user has typed. */
  readonly partialUid: string;
  /** True if the file is matched by test_include. */
  readonly isTestFile: boolean;
}

export interface CompletionItem {
  readonly label: string;
  readonly kind: "requirement" | "verb";
  readonly detail: string;
}

/**
 * Ranking: requirement UID completions are scored by fuzzy match on
 * the partial UID. Verb completions are filtered by file context:
 * `impl`/`depends`/`related` are omitted in test files; `verify`
 * is always present.
 */
export function completions(
  ctx: CompletionContext,
  allUids: ReadonlyArray<{ uid: RequirementUID; text: string }>
): ReadonlyArray<CompletionItem> {
  if (!ctx.inComment) return [];
  if (!ctx.prefix.startsWith(`${ctx.prefixToken ?? "r"}[`)) return [];

  const items: CompletionItem[] = [];

  const verbs: TraceyVerb[] = ctx.isTestFile
    ? ["verify"]
    : ["impl", "verify", "depends", "related"];
  for (const v of verbs) {
    if (v.startsWith(ctx.partialUid)) {
      items.push({
        label: v,
        kind: "verb",
        detail: `Tracey verb: ${v}`,
      });
    }
  }

  for (const { uid, text } of allUids) {
    if (uid.startsWith(ctx.partialUid)) {
      items.push({
        label: uid,
        kind: "requirement",
        detail: text.slice(0, 120),
      });
    }
  }

  return items;
}
