/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_real-time_ide_feedback_with_lsp_diagnostics_and_c_part2.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================
// Exercise 4 (continued) — Vitest test plan (prose, as a typed export)
// ============================================================

export const LSP_TEST_PLAN = `
============================================================================
Vitest test plan for the LSP diagnostic pipeline (mock daemon)
============================================================================

Shared mock daemon: a Proxy that intercepts the JSON-RPC methods the LSP
calls (\`getGraph\`, \`queryRule\`, \`queryStale\`, \`queryUncovered\`), returns
canned snapshots per test, and records received snapshots for assertions.

Test 1 — unknown-requirement
  Arrange: mock daemon returns a snapshot with only \`auth.login\` and
    \`auth.token-expiry\` defined; buffer contains
    \`// r[impl auth.token.validaton]\`.
  Assert: exactly one diagnostic, severity=Error, code=unknown-requirement,
    message contains "Did you mean 'auth.token.validation'?".
  Also assert the mock daemon received a snapshot at the current revision.

Test 2 — unknown-prefix
  Arrange: daemon snapshot lists prefixes r, m, h2; buffer contains
    \`// x[impl auth.login]\`.
  Assert: one Error, code=unknown-prefix, message equals
    "Unknown prefix 'x'. Available prefixes: r, m, h2".

Test 3 — unknown-verb
  Arrange: buffer contains \`// r[implement auth.login]\`.
  Assert: one Warning, code=unknown-verb, message lists valid verbs.

Test 4 — stale-reference
  Arrange: daemon snapshot has \`auth.login+2\` as current version, and the
    anchor says \`// r[impl auth.login+1]\`.
  Assert: one Warning, code=stale-reference, and the message includes the
    verbatim phrase "ONLY ONCE THAT'S DONE must the code annotation be
    bumped". Assert coverage for auth.login is NOT counted as covered.

Test 5 — duplicate-definition
  Arrange: daemon snapshot contains two spec.requirement.added deltas with
    the same UID but different file paths.
  Assert: one Error, code=duplicate-definition, and the message names the
    file that "won" the first definition.

Test 6 — impl-in-test-file
  Arrange: config testInclude matches \`src/**/*.spec.ts\`; buffer URI is
    \`src/auth.spec.ts\`; buffer contains \`// r[impl auth.login]\`.
  Assert: one Error, code=impl-in-test-file.

Test 7 — stale after spec text change
  Arrange: start with a fresh anchor at +1. Deliver a spec.edit delta that
    modifies the requirement text and bumps to +2. Deliberately race the
    delta arrival with the debounce window.
  Assert: after the debounce fires, the diagnostic is stale-reference with
    the expected message. Assert the run for the pre-edit token was
    discarded (spy on the scheduler's onResult calls).

Test 8 — clean file, no diagnostics
  Arrange: buffer content has correct annotations for every function and
    the daemon snapshot has matching UIDs and versions.
  Assert: diagnostics array is empty. Also assert that the LSP did not
    emit a diagnostic for a helper function that genuinely implements
    nothing — the mock daemon should include that helper in the
    "unmapped" list rather than the LSP inventing a diagnostic.

Test 9 — cancellation
  Arrange: schedule a diagnosis, then, before debounce fires, change the
    buffer. Assert that only one result is emitted and it reflects the
    *second* buffer content.

Test 10 — completion context detection
  Arrange: buffer \`// r[auth.tok\` inside a comment; daemon snapshot
    contains \`auth.token-expiry\`.
  Assert: completions include \`auth.token-expiry\` and \`tiny\` fuzzy matches
    are excluded by the ranking threshold.

Test 11 — completion verb filtering for test files
  Arrange: same buffer, but URI matches test_include.
  Assert: completions after \`r[\` include only \`verify\` among verbs.
`;
