/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_interactive_challenge_cross-refactor_drift_detect.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================
// Interactive Challenge — expected CLI output + drift policy
// ============================================================

export const EXPECTED_CLI_OUTPUT = `
$ tracey query validate --deny warnings

tracey 2.x — validation
  spec: stream-scheduler (prefix: r)
  impl: ts (include: src/**/*.ts, test_include: src/**/*.test.ts)

revision: 7   daemon: running (uptime 00:03:12)

[ ERROR ] broken reference
  src/arbiter.ts:14
    // r[impl REQ-STREAM-PRIORITY]
    Unknown requirement 'REQ-STREAM-PRIORITY'.
    (Note: the spec has already been bumped to REQ-STREAM-PRIORITY+2;
     this reference resolves against the *current* version, and the
     UID is known — see the stale diagnostic below. The UID is
     resolved in the graph; it is *not* missing.)

[ WARNING ] stale reference
  src/arbiter.ts:14
    // r[impl REQ-STREAM-PRIORITY]
    Annotated against version 1 of 'REQ-STREAM-PRIORITY'.
    Current spec version is 2.
    Implementation must be changed to match updated rule text —
    and ONLY ONCE THAT'S DONE must the code annotation be bumped.

[ WARNING ] stale reference
  src/arbiter.old.ts:1
    // r[impl REQ-STREAM-PRIORITY]
    Annotated against version 1 of 'REQ-STREAM-PRIORITY'.
    Current spec version is 2.

[ WARNING ] unmapped
  src/arbiter.ts:41
    function 'compareStreams' has no requirement reference.
    (The agent added a comment to the module, but not to the
     comparator's own definition. This is a coverage gap, not a
     validation error.)

[ WARNING ] unmapped
  src/arbiter.ts:58
    function 'tieBreak' has no requirement reference.

[ INFO ] coverage summary
  REQ-STREAM-PRIORITY+2
    impl anchors (fresh) : 0
    impl anchors (stale) : 2
    verify anchors       : 0
    stale references     : 2
    status               : STALE (not counted as covered)

exit code: 1
  (--deny warnings promotes warnings to fatal; the two stale
   references account for the non-zero exit.)
`;

export const DIAGNOSTIC_TAXONOMY = `
----------------------------------------------------------------------------
Three failure classes, clearly separated
----------------------------------------------------------------------------

BROKEN (UID not found)
  The requirement *identifier* cannot be resolved in the graph. This is
  a hard error even without --deny warnings. Cause: typo in the UID,
  deleted requirement, prefix mismatch. Not present in this scenario.

STALE (version mismatch)
  The UID resolves. The requirement exists. But the anchor carries an
  older version than the current spec. This is a warning; with
  --deny warnings it becomes fatal. Cause: spec was version-bumped and
  the annotation was not. Present: two anchors at v1 vs spec v2.

UNCOVERED (no anchor at all)
  The requirement has no impl anchor anywhere. This is *not* a
  validation error per se — it appears via tracey_uncovered, not
  tracey_validate. Cause: code was written without an annotation, or
  the anchor was removed. Present: none for REQ-STREAM-PRIORITY
  specifically, but the module has two unmapped helper functions
  which tracey_unmapped would report.

Note: the +2 annotation on the comparator is FRESH relative to +2, and
would never have referenced +1 because it did not exist before the
agent's edit sequence. The +1 references are the *pre-existing* anchors
in src/scheduler.ts (since renamed). They are STALE, not BROKEN.

FRESH +1 anchors moving files
  The physical rename of src/scheduler.ts -> src/arbiter.ts does NOT by
  itself change UID resolution. Tracey resolves by UID and by AST node,
  not by file path. The old anchor is now at src/arbiter.old.ts (if the
  rename was a copy+delete, the old copy still parses) and remains
  STALE because its *version* is 1 and the spec is 2.

  Version resolution is orthogonal to UID resolution. UID resolution
  answers "does a requirement with this identifier exist?" Version
  resolution answers "does the anchor claim the same version as the
  spec?" Renaming a file cannot flip a reference from broken to stale;
  only deleting the requirement could flip it to broken.
`;

export const BEHAVIORAL_VIOLATION_NOT_CAUGHT = `
----------------------------------------------------------------------------
Why the tie-breaking violation is not caught
----------------------------------------------------------------------------

The agent changed tie-breaking from ascending to descending stream ID.
That is a behavioral change. Tracey is a *coverage* tool: it verifies
that annotations point at the right requirement at the right version.
It does not execute the comparator, does not evaluate its output, and
does not know what "ascending" means.

A +2 annotation that matches the +2 spec text is considered covered
even if the implementation is semantically wrong. This is by design: a
coverage tool that tried to be a verifier would need to understand the
semantics of every language it parses, which is a research project.

Complementary tooling required to catch the violation:
  - Behavioral tests (property-based or example-based) that assert the
    tie-break direction. Ideally, the same Vitest/Jest file that
    carries \`// r[verify REQ-STREAM-PRIORITY+2]\`.
  - Mutation testing to ensure the test would fail if the comparator
    were flipped.
  - The \`verify\` verb + \`test_include\` contract exists precisely to
    force the implementation author to attach an executable claim to
    the requirement.
`;

export const DRIFT_DETECTION_POLICY = `
============================================================================
CI drift-detection policy (uses tracey_status + tracey_stale + others)
============================================================================

Goal: catch the tie-breaking violation *before* it reaches production,
while respecting the fact that Tracey only sees coverage, not behavior.

Step 1 — Coverage snapshot (pre-merge gate)
  Bash:
    tracey query status
    tracey query uncovered --spec_impl stream-scheduler/ts
    tracey query stale    --spec_impl stream-scheduler/ts
  Failure condition: any uncovered requirement, or any stale reference.
  This catches the two stale anchors and the "unmapped comparator" gap.

Step 2 — Behavioral gate (verify annotations must exist)
  Bash:
    tracey query untested --spec_impl stream-scheduler/ts
  Failure condition: an untested requirement that has impl coverage.
  This is the explicit hand-off to the test suite: Tracey cannot check
  the tie-break direction, but it can check that *some* test claims to
  verify the requirement. The test suite then runs under the normal
  Vitest/Jest runner and fails on the behavior.

Step 3 — Spec-drift pre-commit hook
  File: .git/hooks/pre-commit
    #!/bin/sh
    set -e
    tracey pre-commit
  Failure condition: a staged spec edit changed requirement text without
  bumping the version. Remediation: run \`tracey bump\` to auto-increment
  and re-stage, then commit again.

Step 4 — CI gate (GitHub Actions)
  File: .github/workflows/spec-assurance.yml
  Step:
    tracey query validate --deny warnings
  Failure condition: any warning (including stale references) is fatal.

Step 5 — MCP query used by the agent loop
  Before writing code, the agent must call:
    tracey_status        -> see the prefix and coverage percentages
    tracey_uncovered     -> find requirements needing implementation
    tracey_rule <UID>    -> read the exact normative statement
  This is a *policy*, not a CI gate, and it is what makes the CI gate
  reachable: the agent is supposed to have read REQ-STREAM-PRIORITY
  before writing compareStreams.

Wait — does step 5 catch the tie-breaking violation?
  No. It catches the *failure to read the requirement*, which is
  upstream of the violation. If the agent had called tracey_rule first,
  it would have read "descending priority, ascending tie-break" and
  would not have flipped the tie-break direction. This is why the
  MCP-native agent loop (Exercise 5) treats tracey_rule as
  non-optional: the coverage gate enforces annotation hygiene, but
  only the reading step enforces behavior.

Alternative gate that would catch the flip directly:
  A property-based test annotated with
    // r[verify REQ-STREAM-PRIORITY+2]
  running under \`tracey query validate --deny warnings\` after a
  \`--run-tests\` extension of the validate command (hypothetical).
  Under current Tracey 2.x, the test is a separate command; under a
  future Tracey with test execution, the validate command becomes
  behavioral.
`;
