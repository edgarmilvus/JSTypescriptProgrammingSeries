/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_stretch_mcp-native_agent_loop_with_governed_tool.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================
// Exercise 5 — MCP-Native Agent Loop
// ============================================================

/** 1) .cursor/mcp.json — the file, as an exported data object. */
export const CURSOR_MCP_JSON = {
  mcpServers: {
    tracey: {
      command: "tracey",
      args: ["mcp"],
    },
  },
} as const;

/** The same file as it would appear on disk. */
export const CURSOR_MCP_JSON_TEXT = JSON.stringify(CURSOR_MCP_JSON, null, 2) + "\n";

/**
 * 1b) What \`tracey mcp\` starts.
 *
 * \`tracey mcp\` starts a stdio bridge process (a child of Cursor) that
 * speaks JSON-RPC over stdin/stdout of the Cursor process. The bridge
 * is NOT the daemon; it is a thin client. It connects to the persistent
 * daemon over the Unix domain socket at \`.tracey/daemon.sock\` (on
 * Windows, a named pipe). If the daemon is not running, the bridge
 * auto-starts it (the daemon writes \`.tracey/daemon.pid\` and logs to
 * \`.tracey/daemon.log\`). This is why the timing of daemon startup
 * matters: the first tool call may pay a cold-start cost, and the
 * bridge's first RPC will block until the daemon accepts connections.
 * Subsequent tool calls are served from the daemon's in-memory graph.
 */

/** 2) System prompt fragment, verbatim. */
export const SYSTEM_PROMPT_FRAGMENT = `
You are governed by a formal Software Intent Graph via the Tracey MCP server.

BEFORE writing or refactoring any code, you MUST:
1. Call \`tracey_status\` to inspect current coverage and discover the
   active spec prefixes.
2. Call \`tracey_uncovered\` to discover requirements that require
   implementation.
3. Call \`tracey_rule\` with the specific requirement UID to extract the
   exact normative statement before touching any code that implements
   it. Do not guess the requirement text.
4. Annotate every function that implements a normative requirement with
   \`// r[impl REQ-ID]\` or, if the project uses StrictDoc-native
   annotations, \`// @relation(REQ-ID, scope=function)\`.
5. Annotate every test function with \`// r[verify REQ-ID]\` or
   \`// @relation(REQ-ID, role=Verifies)\`. Test files matched by
   \`test_include\` may NOT contain \`impl\` annotations.
6. Call \`tracey_validate\` before declaring the task complete. If it
   returns warnings about stale references, you MUST NOT bump the
   annotation until you have updated the implementation to match the
   new rule text.

You MUST NOT create annotations for helper functions that implement
nothing normative. Coverage is a claim about the spec, not a decoration
for every function you touch.
`;

/** 3) Termination condition. */
export type Termination =
  | { tag: "success"; revision: number; coverageDelta: CoverageDelta }
  | { tag: "stale-blocked"; uids: RequirementUID[] }
  | { tag: "budget-exhausted"; turns: number }
  | { tag: "validate-failed"; errors: Diagnostic[] };

export interface CoverageDelta {
  readonly implCoveredDelta: number;
  readonly verifyCoveredDelta: number;
  readonly staleCount: number;
}

/**
 * The loop terminates successfully only when:
 *   - \`tracey_validate --deny warnings\` returns zero diagnostics,
 *   - \`tracey_status\` shows a positive delta in the target metric
 *     (impl or verify coverage) versus the loop's starting snapshot.
 *
 * If \`tracey_validate\` returns a stale-reference warning, the agent
 * MUST transition to \`stale-blocked\` and must update the implementation
 * before bumping any annotation. The loop does not permit a "bump now,
 * fix later" shortcut; the MCP response for \`tracey_stale\` is worded to
 * forbid it, and the harness below asserts the ordering.
 */

/* ------------------------------------------------------------
 * 4) Failure modes and mitigations.
 * ------------------------------------------------------------ */

export interface NaiveAgentFailureModes {
  readonly overAnnotation: {
    symptom: string;
    mitigation: string;
  };
  readonly prematureVersionBump: {
    symptom: string;
    mitigation: string;
  };
}

export const FAILURE_MODES: NaiveAgentFailureModes = {
  overAnnotation: {
    symptom:
      "Agent annotates every function it touches, including private " +
      "helpers that implement no requirement. This inflates coverage " +
      "numbers and hides real gaps.",
    mitigation:
      "MCP responses for \`tracey_unmapped\` include a hint that names " +
      "the *specific* uncovered requirement UIDs and their sections, " +
      "steering the agent to annotate against a requirement rather " +
      "than against a function. The response format also reports a " +
      "\`delta\` after each operation, so over-annotation shows up " +
      "immediately as an impl-coverage jump that does not correspond " +
      "to a newly uncovered rule disappearing.",
  },
  prematureVersionBump: {
    symptom:
      "Agent sees a stale warning and immediately bumps the annotation " +
      "to the current version *without* reviewing the implementation. " +
      "The coverage number returns to green while the code is wrong.",
    mitigation:
      "The \`tracey_stale\` MCP response carries the verbatim warning " +
      "\"Implementation must be changed to match updated rule text — " +
      "and ONLY ONCE THAT'S DONE must the code annotation be bumped.\" " +
      "The response also includes the word-level diff so the agent can " +
      "see *what* changed, and the \`hints\` field instructs the agent " +
      "to read \`tracey_rule <UID>\` next. The harness test below " +
      "asserts that no bump tool is called before a code-edit tool.",
  },
};

/* ------------------------------------------------------------
 * 5) Vitest harness — typed mock of the MCP tool surface.
 * ------------------------------------------------------------ */

export interface TraceyMcpClient {
  tracey_status(input: {}): Promise<{
    specs: Array<{ name: string; prefix: string }>;
    coverage: Array<{ specImpl: string; implPct: number; verifyPct: number }>;
    hints: string[];
  }>;
  tracey_uncovered(input: {
    spec_impl?: string;
    prefix?: string;
  }): Promise<{ uids: RequirementUID[]; hints: string[] }>;
  tracey_untested(input: {
    spec_impl?: string;
    prefix?: string;
  }): Promise<{ uids: RequirementUID[]; hints: string[] }>;
  tracey_stale(input: {
    spec_impl?: string;
  }): Promise<{
    references: Array<{
      file: SourcePath;
      uid: RequirementUID;
      annotatedVersion: number;
      currentVersion: number;
      warning: string;
    }>;
    hints: string[];
  }>;
  tracey_unmapped(input: {
    spec_impl?: string;
    path?: string;
  }): Promise<{ units: UnmappedUnit[]; hints: string[] }>;
  tracey_rule(input: {
    uid: RequirementUID;
  }): Promise<{
    uid: RequirementUID;
    title: string;
    statement: string;
    version: number;
    references: Array<{ file: SourcePath; verb: TraceyVerb }>;
  }>;
  tracey_validate(input: {
    spec_impl?: string;
    deny_warnings?: boolean;
  }): Promise<{
    errors: Diagnostic[];
    warnings: Diagnostic[];
  }>;
}

/**
 * Tool-call log used by the harness. The harness asserts on the *order*
 * of tool names, not just the final state.
 */
export interface ToolCallLog {
  readonly calls: ReadonlyArray<{ tool: keyof TraceyMcpClient; args: unknown }>;
  record(tool: keyof TraceyMcpClient, args: unknown): void;
}

/* ------------------------------------------------------------
 * Harness test cases (prose).
 * ------------------------------------------------------------ */

export const HARNESS_TEST_PLAN = `
============================================================================
Vitest harness — governance assertions for the agent loop
============================================================================

Setup:
  - Build a \`MockDaemon\` that implements the tool surface with scriptable
    responses per test.
  - Wrap each tool in a spy that appends to a shared ToolCallLog.
  - Instantiate a \`ScriptedAgent\` that replays a fixed tool-call sequence
    per test (we are testing the *loop*, not an LLM).

Test A — empty repo, no requirements
  Script: status -> uncovered -> validate -> done.
  Assert: agent terminates with \`success\`, delta 0-0, no annotations
    added, validate returns zero diagnostics.

Test B — one uncovered requirement, agent implements it correctly
  Script: status -> uncovered -> rule("r.x") -> editFunction ->
    annotate("r.x") -> validate.
  Assert: log order is exactly the above; validate returns zero errors;
    status delta is implCoveredDelta == 1.

Test C — agent skips tracey_rule
  Script: status -> uncovered -> editFunction -> annotate -> validate.
  Assert: harness fails with AssertionError
    "governance: tracey_rule must be called before editing any
     function that implements a requirement. Logged order was: ...".
  This is the non-bypassable governance test: if the agent can skip
  reading the requirement, the loop is aspirational, not real.

Test D — stale reference encountered
  Script: status -> stale -> [bump("r.x+2")]  <-- deliberately out of order.
  Assert: harness fails with
    "governance: annotation must not be bumped before implementation
     is updated. Bump attempted at turn N before any code edit."

Test E — stale reference, correct ordering
  Script: status -> stale -> rule("r.x") -> editFunction ->
    bumpAnnotation("r.x+2") -> validate.
  Assert: harness succeeds; validate returns zero diagnostics;
    status delta implCoveredDelta == 0 (the anchor was already
    counted before), staleCount delta == -1.

Test F — impl annotation placed in a test file
  Script: ... -> annotateImpl("src/foo.spec.ts", "r.y") -> validate.
  Assert: validate returns one Error with code impl-in-test-file; the
    loop transitions to \`validate-failed\` and does NOT retry by
    silently deleting the annotation.

Test G — over-annotation
  Script: ... -> annotateImpl("src/helper.ts", "r.x") ->
    annotateImpl("src/helper2.ts", "r.x") -> validate.
  Assert: harness does NOT fail on governance (there is no rule
    against two anchors for one requirement), but it asserts that
    \`tracey_status\` reports an implCoveredDelta that is *larger than
    the number of newly uncovered requirements disappearing*. If the
    delta is larger, the harness emits a warning-level annotation
    "possible over-annotation" for human review.

Test H — premature version bump after a spec text change
  Script: specEdit("r.x", newText, +2) -> bump("r.x+2") ->
    editFunction -> validate.
  Assert: harness fails with
    "governance: bump happened before code edit after a spec text
     change at revision R. Bump turn T1, code-edit turn T2, T1 < T2."
`;

/** Example mock skeleton (types only, no runnable logic). */
export declare function buildMockDaemon(): TraceyMcpClient;
export declare function runHarness(
  agent: (client: TraceyMcpClient, log: ToolCallLog) => Promise<Termination>,
  script: ReadonlyArray<{ tool: keyof TraceyMcpClient; args: unknown }>
): Promise<{ termination: Termination; log: ToolCallLog }>;
