/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

// src/billing/invoicer.ts
//
// CloudMeter billing engine — the only module allowed to mint invoices.
//
// Two independent in-source grammars live side-by-side below:
//   - `@relation(...)`  — StrictDoc-native, functional scope bound to SDOC-BILL-* UIDs.
//   - `r[...]`          — Tracey-native, lightweight inline tag bound to a Markdown rule id.

/**
 * A single billable usage sample emitted by the metering pipeline.
 * Deliberately minimal: the invoicer only needs amount + timestamps,
 * never raw payloads.
 */
export interface UsageEvent {
  readonly tenantId: string;
  readonly planId: string;
  /** ISO-8601 timestamp of when the call actually occurred. */
  readonly occurredAt: string;
  /** Pre-normalized amount in cents. Metering already did the unit math. */
  readonly amountCents: number;
}

/** The immutable artifact the invoicer returns. */
export interface Invoice {
  readonly tenantId: string;
  readonly periodStart: string;
  readonly periodEnd: string;
  readonly totalCents: number;
  /** Deterministic per (tenant, month) so retries collapse to a single row. */
  readonly idempotencyKey: string;
}

/**
 * Generates one invoice for a tenant for a given billing window.
 *
 * @param tenantId - the tenant whose usage we are summing.
 * @param events   - all usage events for the tenant, already filtered to the
 *                   retention window so we never touch the deleted tail.
 * @param periodStart - inclusive ISO-8601 lower bound of the billing window.
 * @param periodEnd   - exclusive ISO-8601 upper bound of the billing window.
 * @returns the immutable Invoice, or a zero-value invoice if no events match.
 */
// @relation(SDOC-BILL-001, scope=function)
// r[impl billing.invoice.generate]
export function generateInvoice(
  tenantId: string,
  events: readonly UsageEvent[],
  periodStart: string,
  periodEnd: string,
): Invoice {
  // Deterministic tuple that a retry can collide against in Postgres.
  const idempotencyKey = `${tenantId}:${periodStart}:${periodEnd}`;

  const startMs = Date.parse(periodStart);
  const endMs = Date.parse(periodEnd);

  // Guard against a caller passing an inverted window. We fail loudly here
  // because silent inversion has historically masked the "empty invoice" bug.
  if (startMs >= endMs) {
    throw new RangeError(
      `invoicer: periodStart (${periodStart}) must precede periodEnd (${periodEnd})`,
    );
  }

  // Single-pass reduction. A pre-sorted stream is not required, and we
  // deliberately avoid `.filter().reduce()` because that allocates a new
  // array per tenant in the hot path (see the V8 pitfall below).
  let totalCents = 0;
  for (const event of events) {
    const at = Date.parse(event.occurredAt);

    // Half-open interval [start, end). This is the invariant that SDOC-BILL-001
    // cares about — no double-counting across midnight boundaries.
    if (at >= startMs && at < endMs) {
      totalCents += event.amountCents;
    }
  }

  return {
    tenantId,
    periodStart,
    periodEnd,
    totalCents,
    idempotencyKey,
  };
}

/**
 * Applies mid-cycle proration across two plans.
 *
 * @param baseAmountCents - the monthly list price of the outgoing plan, in cents.
 * @param newAmountCents  - the monthly list price of the incoming plan, in cents.
 * @param upgradeDay      - day-of-month the upgrade became effective (1-based).
 * @param daysInMonth     - the length of the billing month (28..31).
 * @returns the blended amount in cents, banker's-rounded to the nearest cent.
 */
// @relation(SDOC-BILL-002, scope=function)
// r[impl billing.proration.upgrade]
export function prorateUpgrade(
  baseAmountCents: number,
  newAmountCents: number,
  upgradeDay: number,
  daysInMonth: number,
): number {
  if (upgradeDay < 1 || upgradeDay > daysInMonth) {
    throw new RangeError(
      `prorateUpgrade: upgradeDay (${upgradeDay}) out of [1, ${daysInMonth}]`,
    );
  }

  // Days spent on each tier. The upgrade day itself belongs to the outgoing
  // tier so that a same-day upgrade is not counted twice.
  const outgoingDays = upgradeDay - 1;
  const incomingDays = daysInMonth - outgoingDays;

  const outgoing = (baseAmountCents * outgoingDays) / daysInMonth;
  const incoming = (newAmountCents * incomingDays) / daysInMonth;

  return bankersRound(outgoing + incoming);
}

/**
 * Banker's rounding (round-half-to-even). We cannot use `Math.round` because
 * it rounds `0.5` consistently upward, which over-counts across thousands of
 * tenants and drifts the ledger.
 */
function bankersRound(value: number): number {
  const floor = Math.floor(value);
  const diff = value - floor;
  if (diff < 0.5) return floor;
  if (diff > 0.5) return floor + 1;
  // Exactly .5 — pick the even neighbor.
  return floor % 2 === 0 ? floor : floor + 1;
}
