/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// tests/billing/invoicer.test.ts
import { describe, expect, it } from 'vitest';
import {
  generateInvoice,
  prorateUpgrade,
  type UsageEvent,
} from '../../src/billing/invoicer.js';

// Two verifications on the SAME test function — one per grammar.
// @relation(SDOC-BILL-001, role=Verifies)
// r[verify billing.invoice.generate]
describe('generateInvoice', () => {
  it('sums only events inside the half-open [start, end) window', () => {
    const events: UsageEvent[] = [
      {
        tenantId: 't_acme',
        planId: 'pro',
        occurredAt: '2025-01-01T00:00:00.000Z',
        amountCents: 100,
      },
      {
        tenantId: 't_acme',
        planId: 'pro',
        occurredAt: '2025-01-31T23:59:59.999Z',
        amountCents: 200,
      },
      {
        tenantId: 't_acme',
        planId: 'pro',
        // Outside — must be excluded.
        occurredAt: '2025-02-01T00:00:00.000Z',
        amountCents: 999,
      },
    ];

    const invoice = generateInvoice(
      't_acme',
      events,
      '2025-01-01T00:00:00.000Z',
      '2025-02-01T00:00:00.000Z',
    );

    expect(invoice.totalCents).toBe(300);
    expect(invoice.idempotencyKey).toBe(
      't_acme:2025-01-01T00:00:00.000Z:2025-02-01T00:00:00.000Z',
    );
  });

  it('is idempotent for a repeated call with the same key', () => {
    const invoiceA = generateInvoice('t_acme', [], '2025-01-01T00:00:00.000Z', '2025-02-01T00:00:00.000Z');
    const invoiceB = generateInvoice('t_acme', [], '2025-01-01T00:00:00.000Z', '2025-02-01T00:00:00.000Z');
    expect(invoiceA.idempotencyKey).toBe(invoiceB.idempotencyKey);
    expect(invoiceA).toEqual(invoiceB);
  });
});

// Verifies SDOC-BILL-002 / billing.proration.upgrade.
// @relation(SDOC-BILL-002, role=Verifies)
// r[verify billing.proration.upgrade]
describe('prorateUpgrade', () => {
  it('blends an upgrade on day 16 of a 31-day month', () => {
    // 15 days at $10.00 + 16 days at $20.00 over a 31-day month.
    const blended = prorateUpgrade(1000, 2000, 16, 31);
    // 15/31*1000 + 16/31*2000 = 483.870... + 1032.258... = 1516.129... → 1516
    expect(blended).toBe(1516);
  });

  it("uses banker's rounding at exact half-cents", () => {
    // Construct a value that lands exactly on x.5 at the cent boundary.
    // 2 days out of 4 at 1 cent + 2 days out of 4 at 2 cents = 1.5 → 2 (even).
    expect(prorateUpgrade(1, 2, 3, 4)).toBe(2);
  });

  it('rejects an upgrade day outside the month', () => {
    expect(() => prorateUpgrade(1000, 2000, 0, 31)).toThrow(RangeError);
    expect(() => prorateUpgrade(1000, 2000, 32, 31)).toThrow(RangeError);
  });
});
