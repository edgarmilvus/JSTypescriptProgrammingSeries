<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: project_advanced_application_implementation_part11.md
Description: Advanced Application Implementation
==========================================
-->

# Agent Contract — Tenant Orchestrator

You are governed by a formal Software Intent Graph via Tracey MCP.

## Before writing or refactoring any code:
1. Call `tracey_status` to inspect current coverage across `backend` and
   `shared-contracts`.
2. Call `tracey_uncovered` and `tracey_untested` to enumerate the work.
3. Call `tracey_rule <UID>` for each requirement you intend to touch, and
   quote the STATEMENT back in your reasoning.
4. Call `tracey_unmapped --path services/orchestrator/src` to find code
   without anchors.

## Annotation policy — choose the right grammar
- For a *concrete language element* (class, function, interface) that
  implements a UID, prefer `@relation(UID, scope=function)`. This keeps
  the edge visible to StrictDoc-native tooling.
- For a *cross-cutting behavior* or an inline test, prefer `r[impl UID]`
  / `r[verify UID]`. The lightweight form survives reformatting and does
  not require a scope clause.
- For a function that implements *several* UIDs, use a single
  `@relation(UID1, UID2, UID3, scope=function)`. Do not stack multiple
  `r[impl ...]` comments on the same line — the multi-UID form is more
  audit-friendly.
- Never use `impl` inside a file matched by `test_include`. Only `verify`
  is legal there.
- Never reference a version suffix in new annotations unless the spec
  carries one. When in doubt, drop the suffix.

## After writing code
- Run `tracey_validate` and fix every error before returning.
- Run `tracey_query status` and report the delta in coverage.
