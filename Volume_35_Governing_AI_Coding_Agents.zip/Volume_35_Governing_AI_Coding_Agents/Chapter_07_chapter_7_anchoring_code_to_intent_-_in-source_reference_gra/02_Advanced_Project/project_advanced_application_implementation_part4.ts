/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part4.ts
Description: Advanced Application Implementation
==========================================
*/

// packages/event-contracts/src/index.ts

/**
 * Canonical domain event envelope.
 *
 * @typeParam T - the payload shape carried by this event. Callers are expected
 *   to derive a domain-specific alias (e.g. `TenantProvisionedEvent`) rather
 *   than use `DomainEvent<unknown>` directly.
 *
 * @remarks
 * Anchored to `TSO-EVENT-100` via StrictDoc's `@relation(...)` grammar. We
 * choose `@relation` here because the annotation is attached to a *type
 * declaration*, and StrictDoc's matcher has first-class language-element
 * semantics for TypeScript interfaces. A bare `r[impl ...]` comment would
 * also parse, but we prefer the `@relation` form for exported contracts
 * because it makes the scope explicit and survives tooling that reads
 * language-element markers directly.
 */
// @relation(TSO-EVENT-100, scope=function)
export interface DomainEvent<T> {
  /** Stable discriminator. e.g. `tenant.provisioned`. */
  readonly type: string;
  /** Monotonically increasing per-emitter sequence number. */
  readonly sequence: number;
  /** ISO-8601 timestamp of the mutation that produced this event. */
  readonly occurredAt: string;
  /** Typed payload, parameterized by the caller. */
  readonly payload: T;
}

/**
 * Convenience alias for the "system-scoped" event variant. Downstream
 * consumers use this to distinguish events that intentionally lack a
 * tenant ID from events that accidentally forgot one.
 */
export interface SystemScopedPayload {
  readonly scope: 'system';
}
