/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part5.ts
Description: Advanced Application Implementation
==========================================
*/

// services/orchestrator/src/provisioning/idempotency-store.ts

/**
 * Generic idempotency store.
 *
 * @typeParam Req - the request shape used to derive the idempotency key.
 * @typeParam Res - the persisted result shape that is replayed to callers.
 *
 * @remarks
 * Two anchoring grammars are used here on purpose to demonstrate coexistence:
 *
 * - `@relation(TSO-TENANT-001, scope=function)` attaches the interface
 *   contract to the requirement using StrictDoc grammar. The scope is
 *   `function` because the interface is a callable contract.
 * - `r[impl TSO-TENANT-001]` is the Tracey-native form. Tracey will see
 *   *both* and count them as a single implementation edge.
 *
 * Annotating twice is not strictly necessary — one grammar is sufficient.
 * We do it to illustrate that a codebase which has evolved from a
 * markdown-only Tracey setup into a StrictDoc-first setup can carry both
 * forms without coverage double-counting or validation failures.
 */
// @relation(TSO-TENANT-001, scope=function)
export interface IdempotentStore<Req, Res> {
  /**
   * Look up a previously persisted response by its derived key.
   * Returns `undefined` if no prior execution is recorded.
   */
  lookup(req: Req): Promise<Res | undefined>;

  /**
   * Persist a response against the derived key. Must be atomic with
   * respect to concurrent callers sharing the same key.
   */
  commit(req: Req, res: Res): Promise<void>;
}

/**
 * Derive the deterministic idempotency key from a request. Kept as a
 * pure function so it can be unit-tested and audited independently.
 */
export function deriveIdempotencyKey(req: {
  organizationId: string;
  correlationId: string;
}): string {
  return `provision:${req.organizationId}:${req.correlationId}`;
}

/**
 * A concrete in-memory implementation used in tests. Production uses a
 * Redis-backed implementation with `SET NX EX` semantics, but this
 * satisfies the same interface, so the coverage edge holds either way.
 *
 * @remarks
 * `r[impl TSO-TENANT-001]` — the concurrent-safe path is what discharges
 * the requirement. `r[verify ...]` for it lives in the test file.
 */
// r[impl TSO-TENANT-001]
export class InMemoryIdempotentStore<Req extends object, Res>
  implements IdempotentStore<Req, Res>
{
  private readonly memo = new Map<string, Res>();

  constructor(private readonly keyFn: (req: Req) => string) {}

  async lookup(req: Req): Promise<Res | undefined> {
    return this.memo.get(this.keyFn(req));
  }

  async commit(req: Req, res: Res): Promise<void> {
    this.memo.set(this.keyFn(req), res);
  }
}
