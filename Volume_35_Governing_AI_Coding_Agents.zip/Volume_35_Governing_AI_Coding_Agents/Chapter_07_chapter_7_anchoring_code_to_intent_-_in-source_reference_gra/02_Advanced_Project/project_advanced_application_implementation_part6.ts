/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

// services/orchestrator/src/provisioning/pipeline.ts

import type { DomainEvent } from '@example/event-contracts';

/**
 * A single step in the tenant provisioning pipeline.
 *
 * @typeParam In - the payload shape this step accepts.
 * @typeParam Out - the payload shape this step produces on success.
 *
 * @remarks
 * The compensation contract is the *hard* part of `TSO-TENANT-002`. A step
 * that commits a downstream effect must be able to undo it. We encode that
 * as a required `compensate` method on the interface rather than an
 * optional one — the compiler refuses to let us forget it.
 *
 * Anchoring choice: `r[impl TSO-TENANT-002]` here, not `@relation`. The
 * requirement's scope is a *cross-cutting behavior* (sequential
 * compensation) rather than a specific language element. The lightweight
 * inline marker keeps the annotation close to the type parameter list
 * without cluttering the declaration with a scope clause.
 */
// r[impl TSO-TENANT-002]
export interface ProvisioningStep<In, Out> {
  readonly name: string;
  run(input: In): Promise<Out>;
  compensate(input: In, output: Out): Promise<void>;
}

/**
 * The typed failure surfaced to callers when a step fails and compensation
 * has been applied.
 */
export class ProvisioningFailure extends Error {
  constructor(
    public readonly failedStep: string,
    public readonly compensated: readonly string[],
    public readonly cause: unknown,
  ) {
    super(
      `Provisioning failed at step "${failedStep}" after compensating ` +
        `${compensated.length} step(s).`,
    );
    this.name = 'ProvisioningFailure';
  }
}

/**
 * Execute a list of steps sequentially, compensating in reverse order on
 * any failure.
 *
 * @throws {ProvisioningFailure} when any step throws.
 *
 * @remarks
 * The reverse-order compensation is the core of `TSO-TENANT-002`. Note the
 * `finally` block: even if compensation itself throws, we rethrow the
 * original error with a `compensationErrors` field attached, so operators
 * can see which compensations failed. This is a deliberate resilience
 * pattern — the alternative (silently swallowing compensation failures)
 * produces an orchestrator that reports success while leaking orphan
 * resources, which is precisely the failure mode the requirement exists
 * to prevent.
 */
// @relation(TSO-TENANT-002, scope=function)
export async function runPipeline<InitialInput>(
  initialInput: InitialInput,
  steps: readonly ProvisioningStep<any, any>[],
): Promise<void> {
  const completed: Array<{
    step: ProvisioningStep<any, any>;
    input: unknown;
    output: unknown;
  }> = [];

  let cursor: unknown = initialInput;

  try {
    for (const step of steps) {
      const output = await step.run(cursor);
      completed.push({ step, input: cursor, output });
      cursor = output;
    }
  } catch (error) {
    const compensated: string[] = [];
    const compensationErrors: Array<{ step: string; error: unknown }> = [];

    for (const { step, input, output } of [...completed].reverse()) {
      try {
        await step.compensate(input, output);
        compensated.push(step.name);
      } catch (compensationError) {
        compensationErrors.push({
          step: step.name,
          error: compensationError,
        });
      }
    }

    const failure = new ProvisioningFailure(
      (error as Error).message ?? 'unknown',
      compensated,
      error,
    );
    if (compensationErrors.length > 0) {
      Object.assign(failure, { compensationErrors });
    }
    throw failure;
  }
}
