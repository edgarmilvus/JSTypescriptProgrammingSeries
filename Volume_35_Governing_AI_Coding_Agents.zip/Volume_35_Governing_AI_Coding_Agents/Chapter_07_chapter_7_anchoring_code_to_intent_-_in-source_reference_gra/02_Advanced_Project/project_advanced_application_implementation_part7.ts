/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

// services/orchestrator/src/orchestrator.ts

import type { DomainEvent } from '@example/event-contracts';
import {
  IdempotentStore,
  deriveIdempotencyKey,
} from './provisioning/idempotency-store';
import {
  ProvisioningFailure,
  ProvisioningStep,
  runPipeline,
} from './provisioning/pipeline';

/**
 * Request shape accepted by the orchestrator. Kept minimal so it can be
 * logged safely without redaction rules.
 */
export interface ProvisionTenantRequest {
  readonly organizationId: string;
  readonly correlationId: string;
  readonly planId: string;
}

/**
 * Response shape returned to the caller. Includes the correlation ID for
 * trace back through logs.
 */
export interface ProvisionTenantResponse {
  readonly tenantId: string;
  readonly planId: string;
  readonly correlationId: string;
  readonly replayed: boolean;
}

/**
 * Emits domain events. Abstracted so tests can capture and assert.
 */
export interface EventEmitter {
  emit<T>(event: DomainEvent<T>): Promise<void>;
}

/**
 * The top-level provisioning entry point.
 *
 * @remarks
 * This method discharges three requirements simultaneously:
 *
 * - `TSO-TENANT-001` (idempotent tenant creation) — the `IdempotentStore`
 *   is looked up *before* the pipeline runs and committed after it
 *   succeeds. A replayed request short-circuits at `lookup` and never
 *   charges the pipeline.
 * - `TSO-TENANT-002` (atomic composition) — by delegating to
 *   `runPipeline`, which owns compensation.
 * - `TSO-EVENT-101` (at-least-once emission) — the event is emitted *after*
 *   the idempotency commit, which itself happens after every downstream
 *   side effect. This ordering ensures that a caller who observed the
 *   response has already had the event scheduled.
 *
 * Anchoring choice: `@relation(...)` with an explicit multi-UID list. A
 * single function satisfies multiple UIDs, and StrictDoc's grammar lets us
 * express that in one annotation. Tracey expands this to one edge per UID.
 */
// @relation(TSO-TENANT-001, TSO-TENANT-002, TSO-EVENT-101, scope=function)
export class TenantOrchestrator {
  constructor(
    private readonly store: IdempotentStore<
      ProvisionTenantRequest,
      ProvisionTenantResponse
    >,
    private readonly emitter: EventEmitter,
    private readonly buildSteps: (
      req: ProvisionTenantRequest,
    ) => readonly ProvisioningStep<any, any>[],
  ) {}

  async provision(
    req: ProvisionTenantRequest,
  ): Promise<ProvisionTenantResponse> {
    const cached = await this.store.lookup(req);
    if (cached) {
      return { ...cached, replayed: true };
    }

    const steps = this.buildSteps(req);
    await runPipeline(req, steps);

    const response: ProvisionTenantResponse = {
      tenantId: `tnt_${req.organizationId}`,
      planId: req.planId,
      correlationId: req.correlationId,
      replayed: false,
    };

    await this.store.commit(req, response);

    await this.emitter.emit({
      type: 'tenant.provisioned',
      sequence: Date.now(),
      occurredAt: new Date().toISOString(),
      payload: {
        tenantId: response.tenantId,
        planId: response.planId,
        correlationId: response.correlationId,
      },
    });

    return response;
  }
}

/**
 * Re-export the derive helper so callers constructing their own store have
 * a single canonical key derivation.
 */
export { deriveIdempotencyKey, ProvisioningFailure };
