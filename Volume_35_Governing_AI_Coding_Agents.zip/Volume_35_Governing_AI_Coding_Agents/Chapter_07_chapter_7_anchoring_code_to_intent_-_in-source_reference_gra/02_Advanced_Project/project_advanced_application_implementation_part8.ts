/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.ts
Description: Advanced Application Implementation
==========================================
*/

// services/orchestrator/src/plans/transition.ts

/**
 * Result of a plan transition attempt. Modeled as a discriminated union so
 * callers must handle the rejection branch.
 */
export type PlanTransitionResult =
  | {
      readonly kind: 'Applied';
      readonly invoiceLineItem: { readonly amountCents: number; readonly currency: 'USD' };
    }
  | {
      readonly kind: 'Rejected';
      readonly reason: 'UNPAID_BALANCE' | 'PLAN_NOT_FOUND';
    };

/**
 * Looks up the tenant's outstanding balance in integer cents. Kept as an
 * injected port so tests can stub it.
 */
export interface BalancePort {
  getUnpaidBalanceCents(tenantId: string): Promise<number>;
}

/**
 * Computes a prorated charge using whole remaining days at the source
 * plan's daily rate.
 *
 * @param daysRemaining - whole days remaining in the current billing cycle.
 * @param sourcePlanDailyRateCents - the source plan's daily rate in cents.
 * @returns the prorated charge in cents, floored to the nearest cent.
 *
 * @remarks
 * Pure function; carries its own `r[impl TSO-PLAN-010]` anchor because
 * the proration *math* is the specific behavior the requirement pins
 * down. We could have anchored the whole module, but requirement-level
 * granularity matters — a future refactor that moves the math elsewhere
 * should drag the annotation with it.
 */
// r[impl TSO-PLAN-010]
export function computeProratedCents(
  daysRemaining: number,
  sourcePlanDailyRateCents: number,
): number {
  if (daysRemaining <= 0) return 0;
  return Math.floor(daysRemaining * sourcePlanDailyRateCents);
}

/**
 * Applies a plan transition, subject to the unpaid balance ceiling.
 *
 * @remarks
 * `@relation(TSO-PLAN-011, scope=function)` — the rejection branch is the
 * direct implementation of the "reject on unpaid balance" rule. Using the
 * StrictDoc grammar here lets us later attach a role such as
 * `role=Implements` or `role=Verifies` without rewriting the annotation.
 */
// @relation(TSO-PLAN-011, scope=function)
export async function applyPlanTransition(
  args: {
    tenantId: string;
    sourcePlanDailyRateCents: number;
    daysRemaining: number;
    unpaidBalanceCeilingCents: number;
  },
  balancePort: BalancePort,
): Promise<PlanTransitionResult> {
  const balance = await balancePort.getUnpaidBalanceCents(args.tenantId);
  if (balance > args.unpaidBalanceCeilingCents) {
    return { kind: 'Rejected', reason: 'UNPAID_BALANCE' };
  }

  const amountCents = computeProratedCents(
    args.daysRemaining,
    args.sourcePlanDailyRateCents,
  );

  return {
    kind: 'Applied',
    invoiceLineItem: { amountCents, currency: 'USD' },
  };
}
