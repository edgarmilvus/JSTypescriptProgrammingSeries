/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

// services/orchestrator/tests/orchestrator.test.ts

import { describe, expect, it, vi } from 'vitest';
import {
  InMemoryIdempotentStore,
  deriveIdempotencyKey,
} from '../src/provisioning/idempotency-store';
import {
  ProvisioningFailure,
  type ProvisioningStep,
} from '../src/provisioning/pipeline';
import {
  TenantOrchestrator,
  type EventEmitter,
  type ProvisionTenantRequest,
  type ProvisionTenantResponse,
} from '../src/orchestrator';

/**
 * A test-only step that records calls and can be configured to fail.
 */
function mkStep<T>(
  name: string,
  behavior: () => Promise<T>,
): ProvisioningStep<unknown, T> & {
  runCalls: number;
  compensateCalls: number;
} {
  const state = { runCalls: 0, compensateCalls: 0 };
  return {
    name,
    async run() {
      state.runCalls++;
      return behavior();
    },
    async compensate() {
      state.compensateCalls++;
    },
    get runCalls() {
      return state.runCalls;
    },
    get compensateCalls() {
      return state.compensateCalls;
    },
  };
}

describe('TenantOrchestrator', () => {
  /**
   * Verifies idempotent tenant creation.
   *
   * @remarks
   * Second call with the same `(organizationId, correlationId)` must
   * short-circuit: zero pipeline step invocations, and the response carries
   * `replayed: true`.
   *
   * Anchored via StrictDoc grammar to mirror production-code style, with
   * explicit role=Verifies.
   */
  // @relation(TSO-TENANT-001, scope=function, role=Verifies)
  it('does not re-run pipeline on duplicate correlation id', async () => {
    const step = mkStep('identity-provider', async () => 'idp-created');
    const store = new InMemoryIdempotentStore<
      ProvisionTenantRequest,
      ProvisionTenantResponse
    >(deriveIdempotencyKey);

    const emitted: unknown[] = [];
    const emitter: EventEmitter = {
      async emit(event) {
        emitted.push(event);
      },
    };

    const orchestrator = new TenantOrchestrator(store, emitter, () => [step]);

    const req: ProvisionTenantRequest = {
      organizationId: 'org_a',
      correlationId: 'corr_1',
      planId: 'plan_basic',
    };

    const first = await orchestrator.provision(req);
    const second = await orchestrator.provision(req);

    expect(first.replayed).toBe(false);
    expect(second.replayed).toBe(true);
    expect(step.runCalls).toBe(1);
    // Event emitted exactly once even though provision was called twice.
    expect(emitted).toHaveLength(1);
  });

  /**
   * Verifies atomic composition with reverse-order compensation.
   *
   * @remarks
   * Two steps succeed, the third fails. Both prior steps must be
   * compensated in reverse order, and the caller must receive a
   * ProvisioningFailure naming the failed step.
   *
   * Anchored via Tracey's lightweight `verify` verb — chosen here to
   * demonstrate coexistence with the `@relation` form in the previous
   * test, and because the test's *identity* is a property of the test
   * declaration rather than a language element inside it.
   */
  // r[verify TSO-TENANT-002]
  it('compensates completed steps in reverse order on failure', async () => {
    const order: string[] = [];

    const stepA: ProvisioningStep<unknown, string> = {
      name: 'A',
      async run() {
        order.push('run:A');
        return 'a';
      },
      async compensate() {
        order.push('compensate:A');
      },
    };
    const stepB: ProvisioningStep<string, string> = {
      name: 'B',
      async run() {
        order.push('run:B');
        return 'b';
      },
      async compensate() {
        order.push('compensate:B');
      },
    };
    const stepC: ProvisioningStep<string, string> = {
      name: 'C',
      async run() {
        order.push('run:C');
        throw new Error('boom');
      },
      async compensate() {
        order.push('compensate:C');
      },
    };

    const { runPipeline } = await import('../src/provisioning/pipeline');

    let caught: unknown;
    try {
      await runPipeline({}, [stepA, stepB, stepC]);
    } catch (e) {
      caught = e;
    }

    expect(caught).toBeInstanceOf(ProvisioningFailure);
    expect(order).toEqual(['run:A', 'run:B', 'run:C', 'compensate:B', 'compensate:A']);
    expect((caught as ProvisioningFailure).compensated).toEqual(['B', 'A']);
  });
});

describe('PlanTransitions', () => {
  /**
   * Verifies the proration math.
   */
  // r[verify TSO-PLAN-010]
  it('applies whole-day proration at source daily rate', async () => {
    const { computeProratedCents } = await import('../src/plans/transition');
    expect(computeProratedCents(7, 500)).toBe(3500);
    expect(computeProratedCents(0, 500)).toBe(0);
    expect(computeProratedCents(-3, 500)).toBe(0);
  });

  /**
   * Verifies the rejection discriminator on unpaid balance.
   */
  // @relation(TSO-PLAN-011, role=Verifies)
  it('rejects plan transition when unpaid balance exceeds ceiling', async () => {
    const { applyPlanTransition } = await import('../src/plans/transition');
    const result = await applyPlanTransition(
      {
        tenantId: 'org_a',
        sourcePlanDailyRateCents: 500,
        daysRemaining: 10,
        unpaidBalanceCeilingCents: 100,
      },
      { async getUnpaidBalanceCents() { return 250; } },
    );
    expect(result).toEqual({ kind: 'Rejected', reason: 'UNPAID_BALANCE' });
  });
});
