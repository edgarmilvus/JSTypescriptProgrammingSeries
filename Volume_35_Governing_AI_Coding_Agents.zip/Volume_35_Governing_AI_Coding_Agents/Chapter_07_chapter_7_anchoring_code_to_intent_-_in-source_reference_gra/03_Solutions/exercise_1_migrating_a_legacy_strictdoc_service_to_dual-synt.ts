/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_migrating_a_legacy_strictdoc_service_to_dual-synt.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * tests/session.test.ts — Exercise 1 dual-syntax placement harness.
 *
 * These tests do NOT exercise business logic. They pin the *placement* of the
 * two in-source grammars so that tracey's tree-sitter extractor and the legacy
 * DOORS gateway both see the same function-span edges.
 *
 * On-disk artifacts this harness depends on:
 *
 * ── docs/spec/session.sdoc ─────────────────────────────────────────────────────
 *   [DOCUMENT]
 *   TITLE: Session Vault Requirements
 *   OPTIONS:
 *       ENABLE_MID: True
 *
 *   [REQUIREMENT]
 *   UID: SESS-001
 *   TITLE: Token issuance with RS256 signature
 *   STATEMENT: The system shall issue session tokens signed with RS256.
 *
 *   [REQUIREMENT]
 *   UID: SESS-002
 *   TITLE: Inactivity expiry
 *   STATEMENT: The system shall expire a session token after 24 hours of inactivity.
 *
 *   [REQUIREMENT]
 *   UID: SESS-003
 *   TITLE: Refresh rotation
 *   STATEMENT: The system shall rotate the refresh token on every use.
 *
 *   [REQUIREMENT]
 *   UID: SESS-004
 *   TITLE: Revocation propagation
 *   STATEMENT: The system shall propagate revocation within 5 seconds.
 *
 * ── .config/tracey/config.styx ─────────────────────────────────────────────────
 *   specs (
 *     {
 *       name sessionvault
 *       source_url https://github.com/example/sessionvault
 *       include (docs/spec/**/*.sdoc)
 *       impls (
 *         {
 *           name typescript
 *           include (src/**/*.ts)
 *           test_include (tests/**/*.ts)
 *           exclude (node_modules/** dist/**)
 *         }
 *       )
 *     }
 *   )
 */

import { describe, it, expect } from 'vitest';
import * as fs from 'node:fs';
import * as path from 'node:path';

const ROOT = path.resolve(__dirname, '..');
const read = (p: string): string => fs.readFileSync(path.join(ROOT, p), 'utf8');

// Accept a `// @relation(UID, scope=function)` line — any UID, fixed scope.
const RELATION_FUNCTION = /\/\/\s*@relation\(\s*([A-Z0-9-]+)\s*,\s*scope=function\s*\)/;
const TRACEY_IMPL = /\/\/\s*r\[impl\s+([A-Za-z0-9_.-]+)\]/;
const TRACEY_VERIFY = /\/\/\s*r\[verify\s+([A-Za-z0-9_.-]+)\]/;

describe('Exercise 1 — dual-syntax traceability invariants', () => {
  const spec = read('docs/spec/session.sdoc');
  const config = read('.config/tracey/config.styx');
  const src = read('src/session.ts');
  const testSrc = fs.readFileSync(__filename, 'utf8');

  it('declares SESS-001..004 with EARS-style normative statements', () => {
    for (const uid of ['SESS-001', 'SESS-002', 'SESS-003', 'SESS-004']) {
      expect(spec).toContain(`UID: ${uid}`);
    }
    // EARS ubiquitous form: "The system shall ..."
    const statements = spec.match(/STATEMENT:.*/g) ?? [];
    expect(statements.length).toBe(4);
    for (const s of statements) {
      expect(s).toMatch(/The system shall /);
    }
  });

  it('every @relation on a function is immediately followed by r[impl <same-uid>]', () => {
    const lines = src.split('\n');
    let checked = 0;
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(RELATION_FUNCTION);
      if (!m) continue;
      checked += 1;
      const uid = m[1];
      // Adjacent line, not merely nearby — the extractor scopes by proximity.
      expect(lines[i + 1]).toBe(`// r[impl ${uid}]`);
    }
    expect(checked).toBeGreaterThan(0);
  });

  it('every test-side @relation carries role=Verifies and never role=Implements', () => {
    for (const line of testSrc.split('\n')) {
      if (!line.includes('@relation(')) continue;
      expect(line).toMatch(/role=Verifies/);
      // A bare @relation defaults to impl, which is a hard error in test_include.
      expect(line).not.toMatch(/role=Implements/);
      expect(line).not.toMatch(/@relation\([A-Z0-9-]+\s*\)/); // no role at all
    }
  });

  it('every r[verify ...] in the test file has a matching r[impl ...] in src', () => {
    const impls = new Set<string>();
    for (const line of src.split('\n')) {
      const m = line.match(TRACEY_IMPL);
      if (m) impls.add(m[1]);
    }
    for (const line of testSrc.split('\n')) {
      const m = line.match(TRACEY_VERIFY);
      if (m) expect(impls).toContain(m[1]);
    }
  });

  it('tracey config routes .sdoc specs and isolates test_include from include', () => {
    expect(config).toContain('include (docs/spec/**/*.sdoc)');
    expect(config).toContain('include (src/**/*.ts)');
    expect(config).toContain('test_include (tests/**/*.ts)');
    expect(config).toContain('exclude (node_modules/** dist/**)');
    expect(config).toContain('name sessionvault');
  });

  it('demonstrates the intent-pinning behaviour of the four session functions', () => {
    // These tests fail against the real implementation until it exists — that
    // is the *correct* starting state: a failing suite is the graph asking
    // what still needs to be built.
    const { issueToken, isTokenValid, rotateRefresh, revokeSession } = require('../src/session');
    expect(() => issueToken('bad-token')).toThrow(/RS256|signature/i);
    expect(isTokenValid({ ageMs: 25 * 60 * 60 * 1000 })).toBe(false);
    expect(rotateRefresh('old')).not.toBe('old');
    expect(() => revokeSession('')).toThrow();
  });
});
