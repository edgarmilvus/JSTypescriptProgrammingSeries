/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_requirementbadge_react_component_backed_by_mcp_tr.tsx
Description: Solutions and Explanations
==========================================
*/

/**
 * tests/RequirementBadge.test.tsx — Exercise 2 state-machine specification.
 *
 * The component does not exist yet; these tests ARE the specification.
 * The contract is fixed by RequirementBadgeProps and the MCP response union.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import React from 'react';

// ─── Contract types ────────────────────────────────────────────────────────────

interface RequirementBadgeProps {
  prefix: string;
  ruleId: string;
  /** verb is REQUIRED: the same rule can carry one impl *and* one verify edge. */
  verb: 'impl' | 'verify' | 'depends' | 'related';
  version?: number;
  onNavigate?: (href: string) => void;
  copyOnClick?: boolean;
}

interface RuleDetails {
  uid: string;
  title: string;
  statement: string;
  sourceUrl?: string;
  specName: string;
  implRefs: number;
  verifyRefs: number;
  currentVersion: number;
}

// Discriminated union of every MCP response shape the badge must render.
type RuleResponse =
  | { kind: 'fresh'; rule: RuleDetails }
  | { kind: 'stale'; rule: RuleDetails; previousStatement: string; currentStatement: string }
  | { kind: 'uncovered'; rule: RuleDetails }
  | { kind: 'unknown_rule'; suggestions: string[] }
  | { kind: 'transport_error'; message: string };

// Mock the bridge but keep the type visible for the test reader.
declare global {
  interface Window {
    __intent_mcp: {
      invoke: (tool: string, args: Record<string, unknown>) => Promise<unknown>;
    };
  }
}

// RequirementBadge is imported lazily so the tests still run (and fail loudly)
// before the implementation exists. Every test that depends on it is marked
// `it.todo` in the pre-implementation world; we keep them as real assertions
// here to pin the contract.
import RequirementBadge from '../src/components/RequirementBadge';

// ─── Fixtures ──────────────────────────────────────────────────────────────────

const BASE_RULE: RuleDetails = {
  uid: 'auth.login',
  title: 'Password authentication',
  statement: 'The system shall authenticate a username and password.',
  sourceUrl: 'https://github.com/example/app',
  specName: 'app',
  implRefs: 2,
  verifyRefs: 1,
  currentVersion: 3,
};

const FRESH: RuleResponse = { kind: 'fresh', rule: BASE_RULE };
const STALE: RuleResponse = {
  kind: 'stale',
  rule: { ...BASE_RULE, statement: 'Users MUST authenticate using OAuth 2.0.' },
  previousStatement: 'Users must authenticate with a username and password.',
  currentStatement: 'Users MUST authenticate using OAuth 2.0.',
};
const UNCOVERED: RuleResponse = { kind: 'uncovered', rule: { ...BASE_RULE, implRefs: 0 } };
const UNKNOWN: RuleResponse = {
  kind: 'unknown_rule',
  suggestions: ['auth.token.validation'],
};
const TRANSPORT: RuleResponse = { kind: 'transport_error', message: 'daemon unreachable' };

// ─── Harness ───────────────────────────────────────────────────────────────────

const mockInvoke = vi.fn<[string, Record<string, unknown>], Promise<RuleResponse>>();

beforeEach(() => {
  mockInvoke.mockReset();
  (window as unknown as { __intent_mcp: { invoke: typeof mockInvoke } }).__intent_mcp = {
    invoke: mockInvoke,
  };
  Object.defineProperty(navigator, 'clipboard', {
    configurable: true,
    value: { writeText: vi.fn().mockResolvedValue(undefined) },
  });
});

afterEach(() => {
  vi.useRealTimers();
});

const renderBadge = (overrides: Partial<RequirementBadgeProps> = {}) =>
  render(
    <RequirementBadge
      prefix="r"
      ruleId="auth.login"
      verb="impl"
      {...overrides}
    />,
  );

// ─── State-machine tests ───────────────────────────────────────────────────────

describe('RequirementBadge — fresh', () => {
  it('renders the rule title, statement and coverage badges', async () => {
    mockInvoke.mockResolvedValue(FRESH);
    renderBadge();
    await waitFor(() => expect(screen.getByText(/Password authentication/)).toBeInTheDocument());
    expect(screen.getByText(/authenticate a username and password/)).toBeInTheDocument();
    // The verb prop selects which edge is highlighted: impl, not verify.
    expect(screen.getByTestId('coverage-impl')).toHaveTextContent('2');
    expect(screen.getByTestId('coverage-verify')).toHaveTextContent('1');
    expect(screen.getByRole('link')).toHaveAttribute(
      'href',
      expect.stringContaining('github.com/example/app'),
    );
    // The rule_id argument is uppercased, version-suffixed when supplied.
    expect(mockInvoke).toHaveBeenCalledWith('tracey_rule', { rule_id: 'auth.login' });
  });

  it('passes an explicit version through to the MCP rule_id argument', async () => {
    mockInvoke.mockResolvedValue(FRESH);
    renderBadge({ version: 2 });
    await waitFor(() => expect(mockInvoke).toHaveBeenCalled());
    expect(mockInvoke).toHaveBeenCalledWith('tracey_rule', { rule_id: 'auth.login+2' });
  });
});

describe('RequirementBadge — stale', () => {
  it('renders a word-level diff with <del> and <strong> markers', async () => {
    mockInvoke.mockResolvedValue(STALE);
    renderBadge({ version: 2 });
    await waitFor(() => expect(screen.getByTestId('stale-diff')).toBeInTheDocument());
    // At least one removed and one added word segment must be marked up.
    expect(screen.getByTestId('stale-diff').querySelector('del')).not.toBeNull();
    expect(screen.getByTestId('stale-diff').querySelector('strong')).not.toBeNull();
  });
});

describe('RequirementBadge — uncovered', () => {
  it('renders an uncovered affordance but still shows the rule text', async () => {
    mockInvoke.mockResolvedValue(UNCOVERED);
    renderBadge();
    await waitFor(() => expect(screen.getByTestId('uncovered-marker')).toBeInTheDocument());
    expect(screen.getByText(/authenticate a username and password/)).toBeInTheDocument();
  });
});

describe('RequirementBadge — unknown_rule', () => {
  it('renders suggestions shaped like the LSP diagnostic', async () => {
    mockInvoke.mockResolvedValue(UNKNOWN);
    renderBadge();
    await waitFor(() => expect(screen.getByTestId('did-you-mean')).toBeInTheDocument());
    expect(screen.getByText(/auth\.token\.validation/)).toBeInTheDocument();
    // No coverage badge may be rendered for an unresolved rule.
    expect(screen.queryByTestId('coverage-impl')).toBeNull();
  });
});

describe('RequirementBadge — transport_error', () => {
  it('retries with exponential backoff and gives up after three attempts', async () => {
    vi.useFakeTimers();
    mockInvoke.mockRejectedValue(new Error('daemon unreachable'));
    renderBadge();
    // First attempt fires on mount.
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });
    expect(mockInvoke).toHaveBeenCalledTimes(1);

    // Retry 1 — 250 ms backoff.
    await act(async () => {
      await vi.advanceTimersByTimeAsync(250);
    });
    expect(mockInvoke).toHaveBeenCalledTimes(2);

    // Retry 2 — 500 ms backoff.
    await act(async () => {
      await vi.advanceTimersByTimeAsync(500);
    });
    expect(mockInvoke).toHaveBeenCalledTimes(3);

    // Retry 3 would be 1000 ms — component gives up after three total attempts
    // and shows a manual retry control.
    await act(async () => {
      await vi.advanceTimersByTimeAsync(1000);
    });
    expect(mockInvoke).toHaveBeenCalledTimes(3);
    expect(screen.getByRole('button', { name: /retry/i })).toBeInTheDocument();
  });
});

describe('RequirementBadge — copyOnClick', () => {
  it('copies "prefix + ruleId" to the clipboard when copyOnClick is true', async () => {
    mockInvoke.mockResolvedValue(FRESH);
    const { container } = renderBadge({ copyOnClick: true });
    await waitFor(() => expect(screen.getByText(/Password authentication/)).toBeInTheDocument());
    fireEvent.click(container.firstChild as HTMLElement);
    await waitFor(() =>
      expect(navigator.clipboard.writeText).toHaveBeenCalledWith('rauth.login'),
    );
  });

  it('does not copy when copyOnClick is false', async () => {
    mockInvoke.mockResolvedValue(FRESH);
    const { container } = renderBadge({ copyOnClick: false });
    await waitFor(() => expect(screen.getByText(/Password authentication/)).toBeInTheDocument());
    fireEvent.click(container.firstChild as HTMLElement);
    expect(navigator.clipboard.writeText).not.toHaveBeenCalled();
  });
});

describe('RequirementBadge — prefix contract', () => {
  it('accepts a non-default prefix and uses it verbatim in the copy payload', async () => {
    mockInvoke.mockResolvedValue(FRESH);
    const { container } = renderBadge({ prefix: 'h2', copyOnClick: true });
    await waitFor(() => expect(screen.getByText(/Password authentication/)).toBeInTheDocument());
    fireEvent.click(container.firstChild as HTMLElement);
    await waitFor(() =>
      expect(navigator.clipboard.writeText).toHaveBeenCalledWith('h2auth.login'),
    );
  });
});
