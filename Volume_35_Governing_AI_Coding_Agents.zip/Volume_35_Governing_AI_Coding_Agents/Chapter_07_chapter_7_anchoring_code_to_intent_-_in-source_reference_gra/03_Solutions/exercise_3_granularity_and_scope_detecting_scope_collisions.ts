/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_granularity_and_scope_detecting_scope_collisions.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * tests/scope-detector.test.ts — Exercise 3.
 *
 * Pure-function signature + tests. No parser is written; the detector operates
 * on already-parsed records (as produced by tracey's tree-sitter extractor).
 */

import { describe, it, expect } from 'vitest';

// ─── The record shape the detector consumes ────────────────────────────────────

/** Normalised equivalent of a single source annotation. */
export interface AnnotationRecord {
  filePath: string;
  /** A verb normalised from either grammar: r[...] verbs or @relation roles. */
  verb: 'impl' | 'verify' | 'depends' | 'related';
  /** Full UID as written (case preserved). */
  ruleId: string;
  /** Prefix — synthetic `r` for .sdoc-derived rules, else whatever the code wrote. */
  prefix: string;
  /** Requested scope. Tracey's matcher ignores @relation's scope field. */
  requestedScope: 'function' | 'file' | 'line' | 'range' | 'inferred';
  /** Resolved span, in file-local 1-based lines. Tracey's *actual* scope. */
  span: { startLine: number; endLine: number; kind: 'function' | 'file' | 'line' | 'range' };
}

export interface Collision {
  ruleId: string;
  prefix: string;
  verb: AnnotationRecord['verb'];
  spans: AnnotationRecord['span'][];
}

// The detector's contract — this test file pins it without an implementation.
export type DetectScopeCollisions = (records: AnnotationRecord[]) => Collision[];

// ─── Fixtures lifted from the problem statement ────────────────────────────────

const r = (
  filePath: string,
  verb: AnnotationRecord['verb'],
  requestedScope: AnnotationRecord['requestedScope'],
  span: AnnotationRecord['span'],
  ruleId = 'AUTH-042',
  prefix = 'r',
): AnnotationRecord => ({ filePath, verb, ruleId, prefix, requestedScope, span });

const FILE1 = r('auth/token.ts', 'impl', 'function', { startLine: 1, endLine: 4, kind: 'function' });
const FILE2 = r('auth/routes.ts', 'impl', 'file', { startLine: 1, endLine: 200, kind: 'file' });
const FILE3 = r('auth/middleware.ts', 'impl', 'inferred', { startLine: 5, endLine: 20, kind: 'function' });
const FILE4 = r('auth/middleware.ts', 'impl', 'inferred', { startLine: 5, endLine: 20, kind: 'function' });
const FILE5 = r('auth/replay.ts', 'depends', 'inferred', { startLine: 3, endLine: 3, kind: 'line' });

// ─── Tests ─────────────────────────────────────────────────────────────────────

describe('detectScopeCollisions — positive cases', () => {
  it('flags the same (rule, verb) attached to two different function spans in one file', () => {
    const records: AnnotationRecord[] = [FILE3, { ...FILE3, span: { startLine: 40, endLine: 60, kind: 'function' } }];
    const collisions = (globalThis as any).detectScopeCollisions(records) as Collision[];
    expect(collisions).toHaveLength(1);
    expect(collisions[0].ruleId).toBe('AUTH-042');
    expect(collisions[0].spans).toHaveLength(2);
    expect(collisions[0].spans[0].startLine).toBe(5);
    expect(collisions[0].spans[1].startLine).toBe(40);
  });

  it('does NOT flag a rule that spans a file marker and a function marker (different spans, same verb)', () => {
    // File2 (whole-file) and File1 (function) are different *spans* but they also
    // live in different files — we scope the detector per-file to avoid this.
    const collisions = (globalThis as any).detectScopeCollisions([FILE1, FILE2]) as Collision[];
    expect(collisions).toHaveLength(0);
  });
});

describe('detectScopeCollisions — negative cases', () => {
  it('does NOT flag impl + depends on the same rule', () => {
    const collisions = (globalThis as any).detectScopeCollisions([FILE3, FILE5]) as Collision[];
    expect(collisions).toHaveLength(0);
  });

  it('does NOT flag impl + verify on the same rule', () => {
    const verify = r('auth/middleware.test.ts', 'verify', 'function', {
      startLine: 1,
      endLine: 10,
      kind: 'function',
    });
    const collisions = (globalThis as any).detectScopeCollisions([FILE3, verify]) as Collision[];
    expect(collisions).toHaveLength(0);
  });

  it('does NOT flag duplicate annotations on the same span (deduplication is separate)', () => {
    // Two adjacent lines both resolving to the same function span are the
    // Exercise-1 dual-syntax case — the graph collapses them into one edge.
    const collisions = (globalThis as any).detectScopeCollisions([FILE3, FILE4]) as Collision[];
    expect(collisions).toHaveLength(0);
  });

  it('does NOT flag the same rule under two different prefixes (r vs h2)', () => {
    const internal = r('src/internal.ts', 'impl', 'inferred', { startLine: 1, endLine: 3, kind: 'function' }, 'api.format', 'r');
    const vendor = r('src/vendor.ts', 'impl', 'inferred', { startLine: 1, endLine: 3, kind: 'function' }, 'api.format', 'h2');
    const collisions = (globalThis as any).detectScopeCollisions([internal, vendor]) as Collision[];
    expect(collisions).toHaveLength(0);
  });
});

describe('detectScopeCollisions — File 3 vs File 4 paradox', () => {
  it('collapses File 3 and File 4 to the same edge but preserves the trailing intent as metadata', () => {
    // The trailing text after `]` is ignored by the parser, so these are the
    // same graph edge. If the author needs to distinguish "the whole function"
    // from "just the header-parsing branch", they must add a range marker:
    //   // @relation(AUTH-042, scope=line) // range start
    //   ...
    //   // @relation(AUTH-042, scope=line) // range end
    // which produces a `kind: 'range'` span, not a `kind: 'function'` span.
    const rangeStart = r('auth/middleware.ts', 'impl', 'line', { startLine: 20, endLine: 20, kind: 'line' });
    const rangeEnd = r('auth/middleware.ts', 'impl', 'line', { startLine: 34, endLine: 34, kind: 'line' });
    const collisions = (globalThis as any).detectScopeCollisions([FILE3, rangeStart, rangeEnd]) as Collision[];
    // The function-span impl and the range-span impl still collide: same verb,
    // same rule, same file, different spans. That is exactly the trap the
    // exercise wants surfaced.
    expect(collisions).toHaveLength(1);
    expect(collisions[0].spans.map((s) => s.kind)).toContain('range');
  });
});

describe('detectScopeCollisions — @relation vs r[...] equivalence', () => {
  it.each([
    ['scope=function', 'impl', 'function'],
    ['scope=file', 'impl', 'file'],
    ['scope=line', 'impl', 'line'],
    ['role=Implements', 'impl', 'inferred'],
    ['role=Verifies', 'verify', 'inferred'],
  ] as const)(
    'normalises StrictDoc form %s to verb=%s, requestedScope=%s',
    (strictDocForm, expectedVerb, expectedScope) => {
      // These assertions pin the normalisation rules so that a future parser
      // can be written against this test and produce the correct records.
      const normalised: AnnotationRecord['verb'] = expectedVerb;
      expect(normalised).toMatch(/^(impl|verify|depends|related)$/);
      expect(expectedScope).toMatch(/^(function|file|line|range|inferred)$/);
      // The StrictDoc `scope=` is *not* used by tracey's matcher — it is
      // forwarded to StrictDoc tooling only. The `requestedScope` field is
      // therefore advisory metadata, not a graph discriminator.
      expect(strictDocForm).toBeDefined();
    },
  );

  it('does not silently normalise role=Refines — the analyser must emit a warning', () => {
    // role=Refines has no tracey verb equivalent. The detector must not invent
    // one; the validator surfaces the warning and the record is skipped.
    const refines = { ...FILE1, verb: 'impl' as const };
    // The pure detector accepts any record — the warning lives in the parser.
    // This test documents the boundary: the detector sees `impl` and genuinely
    // believes it. Only the parser knows the source said `Refines`.
    expect(refines.verb).toBe('impl');
  });
});
