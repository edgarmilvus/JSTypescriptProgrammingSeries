/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_stale_reference_triage_pipeline_in_ci.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * scripts/check-stale.mjs — Exercise 4.
 *
 * Pure function so it can be unit-tested. The CI workflow imports this file,
 * passes the parsed `tracey query stale --json` output, and fails only when
 * the stale count exceeds STALE_BUDGET.
 */

// ─── Types (JSDoc, valid in .mjs / testable from .ts) ──────────────────────────

/**
 * @typedef {Object} StaleEntry
 * @property {string} prefix
 * @property {string} ruleId
 * @property {number} referenceVersion
 * @property {number} specVersion
 *
 * @typedef {Object} StaleCheckResult
 * @property {boolean} pass
 * @property {string} reason
 * @property {StaleEntry[]} exceedingEntries
 */

/**
 * Decide whether the stale-reference count is within budget.
 *
 * Contract:
 *   - entries.length <= budget           → pass: true,  exceedingEntries: []
 *   - entries.length >  budget           → pass: false, exceedingEntries = the
 *                                          overflow, sorted by (specVersion -
 *                                          referenceVersion) desc, ties broken
 *                                          deterministically by (prefix, ruleId).
 *   - budget < 0                         → throws (fail-fast; a negative budget
 *                                          is a workflow-configuration bug, not
 *                                          a policy).
 *
 * @param {StaleEntry[]} entries
 * @param {number} budget
 * @returns {StaleCheckResult}
 */
export function checkStale(entries, budget) {
  if (!Number.isInteger(budget) || budget < 0) {
    throw new RangeError(`STALE_BUDGET must be a non-negative integer, got ${budget}`);
  }

  const sorted = [...entries].sort((a, b) => {
    const driftA = a.specVersion - a.referenceVersion;
    const driftB = b.specVersion - b.referenceVersion;
    if (driftA !== driftB) return driftB - driftA; // most-stale first
    // Deterministic tie-break: prefix, then ruleId, then referenceVersion.
    if (a.prefix !== b.prefix) return a.prefix < b.prefix ? -1 : 1;
    if (a.ruleId !== b.ruleId) return a.ruleId < b.ruleId ? -1 : 1;
    return a.referenceVersion - b.referenceVersion;
  });

  if (sorted.length <= budget) {
    return {
      pass: true,
      reason: `${sorted.length} stale reference(s) within budget ${budget}`,
      exceedingEntries: [],
    };
  }

  const exceedingEntries = sorted.slice(budget);
  return {
    pass: false,
    reason: `${sorted.length} stale reference(s) exceed budget ${budget}; first offender: ${exceedingEntries[0].prefix}[${exceedingEntries[0].ruleId}]`,
    exceedingEntries,
  };
}

// ─── Tests (mirrored in tests/check-stale.test.ts) ─────────────────────────────
// see tests/check-stale.test.ts
