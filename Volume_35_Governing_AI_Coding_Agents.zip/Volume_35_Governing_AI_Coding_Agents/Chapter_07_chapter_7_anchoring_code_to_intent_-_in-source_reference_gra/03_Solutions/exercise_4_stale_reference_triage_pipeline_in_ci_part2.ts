/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_stale_reference_triage_pipeline_in_ci_part2.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * tests/check-stale.test.ts — Exercise 4.
 */

import { describe, it, expect } from 'vitest';
import { checkStale } from '../scripts/check-stale.mjs';

const entry = (
  prefix: string,
  ruleId: string,
  referenceVersion: number,
  specVersion: number,
) => ({ prefix, ruleId, referenceVersion, specVersion });

describe('checkStale — empty and boundary inputs', () => {
  it('passes with empty input and a zero budget', () => {
    const r = checkStale([], 0);
    expect(r.pass).toBe(true);
    expect(r.exceedingEntries).toEqual([]);
    expect(r.reason).toMatch(/within budget/);
  });

  it('passes exactly at budget', () => {
    const entries = [entry('r', 'a.x', 1, 2), entry('r', 'b.y', 1, 2)];
    const r = checkStale(entries, 2);
    expect(r.pass).toBe(true);
    expect(r.exceedingEntries).toEqual([]);
    expect(r.exceedingEntries).not.toContain(entries[0]);
  });
});

describe('checkStale — overflow behaviour', () => {
  it('fails one over budget and returns exactly the overflow', () => {
    const entries = [
      entry('r', 'a.x', 1, 3), // drift 2
      entry('r', 'b.y', 1, 2), // drift 1
      entry('r', 'c.z', 1, 2), // drift 1
    ];
    const r = checkStale(entries, 2);
    expect(r.pass).toBe(false);
    expect(r.exceedingEntries).toHaveLength(1);
    // The most-stale entry is the one that crosses the budget first.
    expect(r.exceedingEntries[0].ruleId).toBe('a.x');
    // Negative assertion: the in-budget entries are not reported.
    expect(r.exceedingEntries).not.toContain(entries[1]);
    expect(r.exceedingEntries).not.toContain(entries[2]);
  });

  it('sorts exceedingEntries by drift descending', () => {
    const entries = [
      entry('r', 'small', 1, 2),   // drift 1
      entry('r', 'big', 1, 10),    // drift 9
      entry('r', 'mid', 1, 5),     // drift 4
    ];
    const r = checkStale(entries, 0);
    expect(r.pass).toBe(false);
    expect(r.exceedingEntries.map((e) => e.ruleId)).toEqual(['big', 'mid', 'small']);
  });

  it('breaks drift ties deterministically by (prefix, ruleId)', () => {
    const entries = [
      entry('h2', 'zeta', 1, 2),
      entry('r', 'alpha', 1, 2),
      entry('r', 'beta', 1, 2),
    ];
    const r = checkStale(entries, 0);
    // All drifts equal 1 → tie broken by prefix, then ruleId.
    expect(r.exceedingEntries.map((e) => `${e.prefix}:${e.ruleId}`)).toEqual([
      'h2:zeta',
      'r:alpha',
      'r:beta',
    ]);
    // Negative assertion: preserve order identity across two invocations.
    const r2 = checkStale(entries, 0);
    expect(r2.exceedingEntries.map((e) => e.ruleId)).toEqual(
      r.exceedingEntries.map((e) => e.ruleId),
    );
  });
});

describe('checkStale — invalid configuration', () => {
  it('throws on a negative budget rather than silently treating it as zero', () => {
    expect(() => checkStale([], -1)).toThrow(RangeError);
    expect(() => checkStale([], -1)).toThrow(/STALE_BUDGET/);
  });

  it('throws on a non-integer budget', () => {
    expect(() => checkStale([], 1.5)).toThrow(RangeError);
    expect(() => checkStale([], NaN)).toThrow(RangeError);
  });
});
