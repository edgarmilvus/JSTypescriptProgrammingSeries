/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_multi-spec_prefix_routing_and_cross-workspace_res.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * src/http2/serialize.ts — Exercise 5.
 *
 * Shared code that implements an internal requirement and an external protocol
 * requirement. Both references are on adjacent lines so they resolve to the
 * same function span.
 *
 * ⚠ Prefix routing note (do not extract as annotations — backticks hide it):
 *
 *   If a developer writes `h2[impl frame.encode]`, the LSP emits the
 *   "Unknown requirement" diagnostic because prefix `h2` routes to the HTTP/2
 *   spec, and `frame.encode` is only defined in the internal spec (prefix `r`).
 *   Conversely, `r[impl H2-FRAME-ENCODE]` fails because the internal spec does
 *   not contain that UID. The prefix *and* the UID must belong to the same
 *   spec; the routing is by prefix, and the UID is matched within that spec.
 *
 *   `.sdoc` files carry a synthetic `r` prefix (because StrictDoc has no
 *   `PREFIX[...]` marker), so the vendor `H2-FRAME-ENCODE` requirement is
 *   referenced either as `r[impl H2-FRAME-ENCODE]` (synthetic prefix, StrictDoc
 *   UID) or through the StrictDoc-native `@relation(H2-FRAME-ENCODE, scope=function)`
 *   form. We choose the explicit `h2` prefix only when a second spec contributes
 *   a markdown `h2[...]` marker; here the vendor spec is `.sdoc`, so we use
 *   `r[impl H2-FRAME-ENCODE]`.
 */

// r[impl frame.encode]
// r[impl H2-FRAME-ENCODE]
export interface Frame {
  type: number;
  flags: number;
  streamId: number;
  payload: Uint8Array;
}

export function serializeFrame(frame: Frame): Uint8Array {
  // HTTP/2 frame header is 9 bytes: length(3) | type(1) | flags(1) | streamId(4).
  const out = new Uint8Array(9 + frame.payload.byteLength);
  const length = frame.payload.byteLength;
  out[0] = (length >>> 16) & 0xff;
  out[1] = (length >>> 8) & 0xff;
  out[2] = length & 0xff;
  out[3] = frame.type & 0xff;
  out[4] = frame.flags & 0xff;
  // Stream ID is 31 bits; the top bit is reserved and must be cleared.
  out[5] = (frame.streamId >>> 24) & 0x7f;
  out[6] = (frame.streamId >>> 16) & 0xff;
  out[7] = (frame.streamId >>> 8) & 0xff;
  out[8] = frame.streamId & 0xff;
  out.set(frame.payload, 9);
  return out;
}
