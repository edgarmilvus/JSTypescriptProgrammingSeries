/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_multi-spec_prefix_routing_and_cross-workspace_res_part2.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * tests/routing.test.ts — Exercise 5 routing-table invariants.
 *
 * The routing table is a hand-constructed literal that mirrors what
 * `tracey_config` should surface from .config/tracey/config.styx. These tests
 * pin the invariants a well-formed multi-spec config must satisfy.
 */

import { describe, it, expect } from 'vitest';

interface ImplConfig {
  name: string;
  include: string[];
  exclude?: string[];
  testInclude?: string[];
}

interface SpecConfig {
  name: string;
  prefix: string; // inferred from the spec's markers, but recorded here
  include: string[];
  sourceUrl?: string;
  impls: ImplConfig[];
}

// Hand-constructed routing table — the test's fixture, not parsed from styx.
const ROUTING_TABLE: SpecConfig[] = [
  {
    name: 'internal',
    prefix: 'r',
    include: ['docs/spec/internal/**/*.md'],
    impls: [
      {
        name: 'typescript',
        include: ['src/**/*.ts'],
        testInclude: ['tests/**/*.ts'],
        exclude: ['node_modules/**', 'dist/**'],
      },
    ],
  },
  {
    name: 'http2',
    prefix: 'h2',
    sourceUrl: 'https://github.com/http2/spec',
    include: ['vendor/http2-spec/**/*.sdoc'],
    impls: [
      {
        name: 'typescript',
        include: ['src/http2/**/*.ts', '../shared-crate/src/**/*.ts'],
        exclude: ['../shared-crate/target/**'],
        testInclude: ['../shared-crate/tests/**/*.ts'],
      },
    ],
  },
];

describe('routing-table invariants', () => {
  it('every spec has at least one implementation', () => {
    for (const spec of ROUTING_TABLE) {
      expect(spec.impls.length).toBeGreaterThan(0);
    }
  });

  it('every spec has a non-empty include set', () => {
    for (const spec of ROUTING_TABLE) {
      expect(spec.include.length).toBeGreaterThan(0);
    }
  });

  it('every implementation has a non-empty include set', () => {
    for (const spec of ROUTING_TABLE) {
      for (const impl of spec.impls) {
        expect(impl.include.length).toBeGreaterThan(0);
      }
    }
  });

  it('no two specs share the same include glob — overlap is almost always a mistake', () => {
    const seen = new Map<string, string>();
    for (const spec of ROUTING_TABLE) {
      for (const glob of spec.include) {
        // The assertion that fires when two specs share a glob.
        expect(seen.has(glob)).toBe(false);
        seen.set(glob, spec.name);
      }
    }
    // Negative assertion that pins the cross-spec disjointness of the fixture.
    expect(seen.get('docs/spec/internal/**/*.md')).toBe('internal');
    expect(seen.get('vendor/http2-spec/**/*.sdoc')).toBe('http2');
  });

  it('spec prefixes are unique — routing is by prefix and ambiguity breaks it', () => {
    const prefixes = ROUTING_TABLE.map((s) => s.prefix);
    expect(new Set(prefixes).size).toBe(prefixes.length);
    expect(prefixes).toContain('r');
    expect(prefixes).toContain('h2');
  });

  it('every spec that declares source_url exposes it for dashboard attribution', () => {
    const http2 = ROUTING_TABLE.find((s) => s.name === 'http2');
    expect(http2?.sourceUrl).toBe('https://github.com/http2/spec');
    // Negative assertion: the internal spec deliberately omits source_url.
    const internal = ROUTING_TABLE.find((s) => s.name === 'internal');
    expect(internal?.sourceUrl).toBeUndefined();
  });

  it('cross-workspace relative includes carry a matching relative exclude', () => {
    const http2 = ROUTING_TABLE.find((s) => s.name === 'http2')!;
    const impl = http2.impls[0];
    const relativeIncludes = impl.include.filter((g) => g.startsWith('../'));
    const relativeExcludes = (impl.exclude ?? []).filter((g) => g.startsWith('../'));
    // If a spec reaches outside the project root, it should also exclude the
    // build artifacts of that external workspace, or the walker will scan
    // `../shared-crate/target/` and slow the daemon to a crawl.
    expect(relativeIncludes.length).toBeGreaterThan(0);
    expect(relativeExcludes.length).toBeGreaterThan(0);
    expect(relativeExcludes.some((g) => g.includes('target'))).toBe(true);
  });

  it('test_include globs are disjoint from include globs within a spec', () => {
    for (const spec of ROUTING_TABLE) {
      const includeSet = new Set(spec.impls.flatMap((i) => i.include));
      for (const impl of spec.impls) {
        for (const t of impl.testInclude ?? []) {
          expect(includeSet.has(t)).toBe(false);
        }
      }
    }
  });
});

describe('serializeFrame — HTTP/2 frame header conformance', () => {
  // h2[verify H2-FRAME-ENCODE]
  it('writes the 9-byte header with the reserved bit cleared', async () => {
    const { serializeFrame } = await import('../src/http2/serialize');
    const frame = {
      type: 0x0,
      flags: 0x1,
      // top bit set to prove it is masked off
      streamId: 0xffffffff,
      payload: new Uint8Array([0xde, 0xad]),
    };
    const bytes = serializeFrame(frame);
    expect(bytes.byteLength).toBe(11);
    expect(bytes[0]).toBe(0x00);
    expect(bytes[1]).toBe(0x00);
    expect(bytes[2]).toBe(0x02); // 2-byte payload
    expect(bytes[5]).toBe(0x7f); // reserved bit cleared
    expect(Array.from(bytes.slice(9))).toEqual([0xde, 0xad]);
  });
});
