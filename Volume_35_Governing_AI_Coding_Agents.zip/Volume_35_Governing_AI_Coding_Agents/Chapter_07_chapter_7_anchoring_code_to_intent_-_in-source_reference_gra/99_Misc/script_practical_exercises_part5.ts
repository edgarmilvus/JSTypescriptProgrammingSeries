/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: script_practical_exercises_part5.ts
Description: Practical Exercises
==========================================
*/

// File 1: auth/token.ts
// @relation(AUTH-042, scope=function)
export function validateToken(t: string) { /* ... */ }

// File 2: auth/routes.ts
// @relation(AUTH-042, scope=file)
// (a whole file, top-of-file comment)

// File 3: auth/middleware.ts
// r[impl AUTH-042]
export function authMiddleware(req: Request) { /* ... */ }

// File 4: auth/middleware.ts
// r[impl AUTH-042]: only the header-parsing branch satisfies the timing constraint
export function authMiddleware(req: Request) { /* ... */ }

// File 5: auth/replay.ts
// r[depends AUTH-042]
const CLOCK_SKEW_MS = 5000;
