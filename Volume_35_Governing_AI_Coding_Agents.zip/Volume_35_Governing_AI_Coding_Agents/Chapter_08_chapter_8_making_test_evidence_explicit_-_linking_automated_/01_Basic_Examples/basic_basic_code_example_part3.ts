/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

/**
 * @file Multi-tenant SaaS onboarding.
 *
 * This module is the single source of truth for the three onboarding
 * rules defined in `docs/spec/tenant.sdoc`. Each exported function below
 * carries a Tracey `r[impl ...]` annotation that binds it to exactly one
 * requirement UID.
 *
 * The annotation is NOT a doc string — it must live in a real line
 * comment (`//`) so that Tracey's tree-sitter comment scanner can see
 * it. Placing it inside the JSDoc block would hide it from the scanner.
 */

// --- Domain validation -----------------------------------------------------

/**
 * Disposable email providers that signup must reject. Kept as a frozen
 * set so that accidental mutation from callers cannot weaken the rule.
 */
const DISPOSABLE_DOMAIN_BLOCKLIST: ReadonlySet<string> = new Set([
  "mailinator.com",
  "10minutemail.com",
  "guerrillamail.com",
  "tempmail.dev",
]);

/**
 * Extract the lowercased domain portion of an email address. Returns
 * `null` on inputs that do not contain a single `@` separator.
 */
function extractDomain(email: string): string | null {
  const atIndex = email.lastIndexOf("@");
  if (atIndex <= 0 || atIndex === email.length - 1) return null;
  return email.slice(atIndex + 1).toLowerCase();
}

/**
 * Validate that a candidate signup email uses a business domain.
 *
 * @param email - Raw signup email from the request body.
 * @returns `true` when the domain is acceptable, `false` otherwise.
 */
// r[impl saas.tenant.email-domain]
export function validateEmailDomain(email: string): boolean {
  const domain = extractDomain(email);
  if (domain === null) return false;
  return !DISPOSABLE_DOMAIN_BLOCKLIST.has(domain);
}

// --- API key issuance ------------------------------------------------------

/** Base62 alphabet used for the random suffix of every issued key. */
const BASE62_ALPHABET =
  "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

/** Length (in characters) of the random suffix appended to `sk_live_`. */
const API_KEY_SUFFIX_LENGTH = 43;

/** Number of days between issuance and expiry, as required by the spec. */
const API_KEY_TTL_DAYS = 90;

/**
 * Generate `length` cryptographically-random base62 characters.
 *
 * Uses the Web Crypto API, which is available in Node 18+ without any
 * flags. `crypto.getRandomValues` fills a `Uint8Array` with uniform
 * bytes; we then map each byte onto the 62-character alphabet. The
 * modulo bias here is vanishingly small for suffix length 43, but the
 * rejection-sampling version is a two-line change if you need perfect
 * uniformity.
 */
function randomBase62(length: number): string {
  const bytes = new Uint8Array(length);
  globalThis.crypto.getRandomValues(bytes);
  let out = "";
  for (let i = 0; i < length; i += 1) {
    out += BASE62_ALPHABET[bytes[i] % BASE62_ALPHABET.length];
  }
  return out;
}

/** A fully-formed, freshly-issued API key plus its expiry timestamp. */
export interface IssuedApiKey {
  /** The on-the-wire secret value. Format: `sk_live_` + 43 base62 chars. */
  readonly key: string;
  /** UTC ISO 8601 timestamp exactly 90 days from issuance. */
  readonly expiresAt: string;
}

/**
 * Issue a new API key for a freshly-onboarded tenant.
 *
 * @param now - Optional clock injection for deterministic tests.
 * @returns The key material and its expiry timestamp.
 */
// r[impl saas.tenant.api-key-format]
// r[impl saas.tenant.api-key-expiry]
export function issueApiKey(now: Date = new Date()): IssuedApiKey {
  const key = `sk_live_${randomBase62(API_KEY_SUFFIX_LENGTH)}`;
  const expiresAt = new Date(
    now.getTime() + API_KEY_TTL_DAYS * 24 * 60 * 60 * 1000,
  ).toISOString();
  return { key, expiresAt };
}
