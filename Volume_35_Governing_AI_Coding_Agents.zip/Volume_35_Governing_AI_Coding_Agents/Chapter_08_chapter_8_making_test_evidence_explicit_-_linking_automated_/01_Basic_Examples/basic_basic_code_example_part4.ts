/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

/**
 * @file Vitest suite that turns automated assertions into Tracey
 * verification evidence.
 *
 * Every `r[verify ...]` annotation in this file is a machine-readable
 * claim: "the tests inside the following describe block exercise the
 * named requirement." Tracey's `tracey_untested` query will list any
 * requirement UID in the spec that has no matching verify annotation
 * anywhere in the configured test_include globs.
 */

import { describe, expect, it } from "vitest";
import {
  issueApiKey,
  validateEmailDomain,
} from "../../src/tenant/onboarding.js";

// ---------------------------------------------------------------------------
// Requirement: saas.tenant.email-domain
// ---------------------------------------------------------------------------

// r[verify saas.tenant.email-domain]
describe("saas.tenant.email-domain", () => {
  it("accepts a business email", () => {
    expect(validateEmailDomain("alice@acme.example")).toBe(true);
  });

  it("rejects a disposable email", () => {
    expect(validateEmailDomain("bob@mailinator.com")).toBe(false);
  });

  it("is case-insensitive on the domain portion", () => {
    expect(validateEmailDomain("carol@MAILINATOR.COM")).toBe(false);
  });

  it("rejects input without a viable @ separator", () => {
    expect(validateEmailDomain("not-an-email")).toBe(false);
    expect(validateEmailDomain("@nope.example")).toBe(false);
    expect(validateEmailDomain("dave@")).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// Requirement: saas.tenant.api-key-format
// ---------------------------------------------------------------------------

// r[verify saas.tenant.api-key-format]
describe("saas.tenant.api-key-format", () => {
  it("prefixes the key with sk_live_", () => {
    const { key } = issueApiKey();
    expect(key.startsWith("sk_live_")).toBe(true);
  });

  it("has exactly 43 base62 characters after the prefix", () => {
    const { key } = issueApiKey();
    const suffix = key.slice("sk_live_".length);
    expect(suffix).toHaveLength(43);
    expect(suffix).toMatch(/^[0-9A-Za-z]{43}$/);
  });

  it("produces distinct keys across invocations", () => {
    const a = issueApiKey().key;
    const b = issueApiKey().key;
    expect(a).not.toEqual(b);
  });
});

// ---------------------------------------------------------------------------
// Requirement: saas.tenant.api-key-expiry
// ---------------------------------------------------------------------------

// r[verify saas.tenant.api-key-expiry]
describe("saas.tenant.api-key-expiry", () => {
  it("expires exactly 90 days after issuance", () => {
    const issuedAt = new Date("2026-01-01T00:00:00.000Z");
    const { expiresAt } = issueApiKey(issuedAt);
    const expected = new Date("2026-04-01T00:00:00.000Z").toISOString();
    expect(expiresAt).toBe(expected);
  });

  it("returns an ISO 8601 UTC timestamp", () => {
    const { expiresAt } = issueApiKey();
    expect(expiresAt).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
  });
});
