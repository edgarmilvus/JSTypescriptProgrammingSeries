# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part5.sh
# Description: Basic Code Example
# ==========================================

# 1. Start the daemon (auto-started by every bridge, but running it
#    explicitly is useful when diagnosing).
tracey status

# 2. Validate — catches broken references, unknown prefixes, stale
#    versions, duplicate UIDs, and `impl` inside a `test_include` file.
tracey query validate --deny warnings

# 3. Coverage overview — shows impl and verify percentages for the
#    saas-platform/typescript pair.
tracey query status

# 4. Requirements that have no `impl` reference anywhere.
tracey query uncovered

# 5. Requirements that have `impl` but no `verify` — this is the
#    crucial query for the current chapter. If the test suite ever
#    loses an annotation, the UID reappears here.
tracey query untested

# 6. The full text and every reference for one specific UID.
tracey query rule saas.tenant.email-domain
