/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

// r[impl REQ-INV-001]
// r[impl REQ-INV-002]
import { requireTenant } from '../tenant/tenant-context.js';

export interface Plan {
  readonly planId: string;
  readonly monthlyMinorUnits: number;
}

export interface Proration {
  readonly fromPlan: Plan;
  readonly toPlan: Plan;
  readonly effectiveAt: number;
  readonly periodEnd: number;
}

/**
 * Compute the prorated amount owed when a subscription changes plan
 * mid-cycle.
 *
 * The rule is symmetric: unused time on the old plan is credited; used time
 * on the new plan is charged. Both sides use the same daily rate.
 */
export class InvoiceService {
  public computeProration(p: Proration): {
    creditMinorUnits: number;
    chargeMinorUnits: number;
    netMinorUnits: number;
  } {
    requireTenant();

    const DAY_MS = 24 * 60 * 60 * 1000;
    const cycleMs = 30 * DAY_MS;
    const remainingMs = Math.max(0, p.periodEnd - p.effectiveAt);
    const remainingFraction = Math.min(1, remainingMs / cycleMs);

    const creditMinorUnits = Math.round(
      p.fromPlan.monthlyMinorUnits * remainingFraction,
    );
    const chargeMinorUnits = Math.round(
      p.toPlan.monthlyMinorUnits * remainingFraction,
    );
    return {
      creditMinorUnits,
      chargeMinorUnits,
      netMinorUnits: chargeMinorUnits - creditMinorUnits,
    };
  }
}
