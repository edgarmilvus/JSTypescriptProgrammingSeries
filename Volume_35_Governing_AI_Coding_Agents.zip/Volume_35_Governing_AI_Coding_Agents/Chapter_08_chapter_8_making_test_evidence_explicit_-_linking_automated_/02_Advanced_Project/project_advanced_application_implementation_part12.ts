/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it } from 'vitest';
import {
  IdempotencyConflictError,
  IdempotencyStore,
  InvalidIdempotencyKeyError,
} from '../../src/payments/idempotency-store.js';

const VALID_KEY = 'idem_2024_11_acme_invoice_42';

describe('IdempotencyStore', () => {
  // r[verify REQ-PAY-001]
  it('rejects keys shorter than 16 characters', () => {
    const store = new IdempotencyStore<{ ok: true }>();
    expect(() => store.assertKeyShape('short')).toThrow(
      InvalidIdempotencyKeyError,
    );
  });

  // r[verify REQ-PAY-001]
  it('rejects keys containing illegal characters', () => {
    const store = new IdempotencyStore<{ ok: true }>();
    expect(() => store.assertKeyShape('idem key with spaces!!!!')).toThrow(
      InvalidIdempotencyKeyError,
    );
  });

  // r[verify REQ-PAY-002]
  it('returns the stored result on replay of a completed key', async () => {
    const store = new IdempotencyStore<{ chargeId: string }>();
    const acquired = await store.acquire(VALID_KEY, 'fp-1');
    if (acquired.kind !== 'acquired') throw new Error('expected acquisition');
    await store.commit(acquired.leaseId, { chargeId: 'ch_123' });

    const replay = await store.acquire(VALID_KEY, 'fp-1');
    expect(replay.kind).toBe('replay');
    if (replay.kind === 'replay') {
      expect(replay.record.result).toEqual({ chargeId: 'ch_123' });
    }
  });

  // r[verify REQ-PAY-003]
  it('evicts records older than the idempotency window', async () => {
    let now = 1_000_000;
    const store = new IdempotencyStore<{ n: number }>(100, () => now);
    const acquired = await store.acquire(VALID_KEY, 'fp-1');
    if (acquired.kind !== 'acquired') throw new Error('expected acquisition');
    await store.commit(acquired.leaseId, { n: 1 });

    // Advance the clock past the window.
    now += 1_000;

    const reacquired = await store.acquire(VALID_KEY, 'fp-1');
    expect(reacquired.kind).toBe('acquired');
  });

  // r[verify REQ-PAY-004]
  it('raises IdempotencyConflictError for concurrent acquisition', async () => {
    const store = new IdempotencyStore<{ ok: true }>();
    await store.acquire(VALID_KEY, 'fp-1');
    await expect(store.acquire(VALID_KEY, 'fp-1')).rejects.toBeInstanceOf(
      IdempotencyConflictError,
    );
  });
});
