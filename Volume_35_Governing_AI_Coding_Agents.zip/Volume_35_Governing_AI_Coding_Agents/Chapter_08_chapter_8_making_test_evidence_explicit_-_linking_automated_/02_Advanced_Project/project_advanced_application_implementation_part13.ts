/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part13.ts
Description: Advanced Application Implementation
==========================================
*/

import { createHmac } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import {
  WebhookHandler,
  WebhookReplayError,
  WebhookSignatureError,
} from '../../src/webhooks/webhook-handler.js';

const SECRET = 'whsec_test_secret_value';

function sign(body: Buffer): string {
  return createHmac('sha256', SECRET).update(body).digest('hex');
}

const FROZEN_NOW = 1_700_000_000;

describe('WebhookHandler', () => {
  // r[verify REQ-WHK-001]
  it('accepts a payload whose HMAC signature verifies', () => {
    const handler = new WebhookHandler(SECRET, () => FROZEN_NOW);
    const body = Buffer.from(
      JSON.stringify({
        id: 'evt_1',
        subscriptionId: 'sub_1',
        created: FROZEN_NOW,
        type: 'invoice.paid',
      }),
    );
    const event = handler.verifyAndParse({
      rawBody: body,
      signatureHeader: sign(body),
      timestampHeader: String(FROZEN_NOW),
    });
    expect(event.type).toBe('invoice.paid');
  });

  // r[verify REQ-WHK-001]
  it('rejects a payload whose signature has a single flipped byte', () => {
    const handler = new WebhookHandler(SECRET, () => FROZEN_NOW);
    const body = Buffer.from(
      JSON.stringify({
        id: 'evt_1',
        subscriptionId: 'sub_1',
        created: FROZEN_NOW,
        type: 'invoice.paid',
      }),
    );
    const good = sign(body);
    const tampered = (good[0] === 'a' ? 'b' : 'a') + good.slice(1);
    expect(() =>
      handler.verifyAndParse({
        rawBody: body,
        signatureHeader: tampered,
        timestampHeader: String(FROZEN_NOW),
      }),
    ).toThrow(WebhookSignatureError);
  });

  // r[verify REQ-WHK-002]
  it('rejects events whose timestamp is more than five minutes in the past', () => {
    const handler = new WebhookHandler(SECRET, () => FROZEN_NOW);
    const body = Buffer.from(
      JSON.stringify({
        id: 'evt_1',
        subscriptionId: 'sub_1',
        created: FROZEN_NOW - 600,
        type: 'invoice.paid',
      }),
    );
    expect(() =>
      handler.verifyAndParse({
        rawBody: body,
        signatureHeader: sign(body),
        timestampHeader: String(FROZEN_NOW - 600),
      }),
    ).toThrow(WebhookReplayError);
  });

  // r[verify REQ-WHK-003]
  it('orders a batch of events by their created timestamp', () => {
    const handler = new WebhookHandler(SECRET, () => FROZEN_NOW);
    const ordered = handler.orderEvents([
      { id: 'a', subscriptionId: 's', created: 300, type: 't' },
      { id: 'b', subscriptionId: 's', created: 100, type: 't' },
      { id: 'c', subscriptionId: 's', created: 200, type: 't' },
    ]);
    expect(ordered.map((e) => e.id)).toEqual(['b', 'c', 'a']);
  });
});
