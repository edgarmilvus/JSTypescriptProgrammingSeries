/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

// r[impl REQ-TNT-001]
// r[impl REQ-TNT-002]
import { AsyncLocalStorage } from 'node:async_hooks';

/**
 * Request-scoped identity for a tenant.
 *
 * This context is propagated using Node.js's `AsyncLocalStorage`, which
 * threads the context through the entire async call graph without requiring
 * explicit parameter passing. This is what makes it safe to call
 * `requireTenant()` from deep inside the invoice service without worrying
 * about who currently holds the request.
 */
export interface TenantContext {
  readonly tenantId: string;
  readonly correlationId: string;
  readonly authenticatedAt: number;
}

/**
 * Typed error thrown when a handler attempts to read the tenant context
 * outside of a request boundary.
 */
export class TenantContextMissingError extends Error {
  public readonly code = 'TENANT_CONTEXT_MISSING';

  public constructor() {
    super(
      'Tenant context was requested outside of a request boundary. ' +
        'Wrap the call in runWithTenant() before use.',
    );
    this.name = 'TenantContextMissingError';
  }
}

const storage = new AsyncLocalStorage<TenantContext>();

/**
 * Run `fn` inside a new tenant scope.
 *
 * This is the *only* sanctioned way to establish a tenant context. Every
 * inbound HTTP handler must call this before touching business logic.
 *
 * @param context - The tenant context to establish.
 * @param fn      - The callback to run inside the context.
 * @returns Whatever `fn` resolves to.
 */
export function runWithTenant<T>(
  context: TenantContext,
  fn: () => Promise<T>,
): Promise<T> {
  if (!context.tenantId || context.tenantId.trim().length === 0) {
    throw new TypeError('runWithTenant requires a non-empty tenantId');
  }
  return storage.run(context, fn);
}

/**
 * Retrieve the current tenant context or fail closed.
 *
 * This function deliberately does not return `undefined`. Callers that
 * genuinely need an "optional tenant" read should use `tryTenant()`.
 *
 * @throws {TenantContextMissingError} if no context has been established.
 */
export function requireTenant(): TenantContext {
  const ctx = storage.getStore();
  if (ctx === undefined) {
    throw new TenantContextMissingError();
  }
  return ctx;
}

/**
 * Retrieve the current tenant context if one exists, otherwise return
 * `undefined`. Reserved for telemetry and health-check code paths.
 */
export function tryTenant(): TenantContext | undefined {
  return storage.getStore();
}
