/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

// r[impl REQ-PAY-001]
// r[impl REQ-PAY-002]
// r[impl REQ-PAY-003]
// r[impl REQ-PAY-004]
import { randomUUID } from 'node:crypto';

const KEY_PATTERN = /^[A-Za-z0-9_.-]{16,255}$/;
const DEFAULT_WINDOW_MS = 24 * 60 * 60 * 1000;

export interface IdempotencyRecord<T> {
  readonly key: string;
  readonly fingerprint: string;
  readonly status: 'in_flight' | 'completed' | 'failed';
  readonly result?: T;
  readonly createdAt: number;
  readonly leaseId: string;
}

export class IdempotencyConflictError extends Error {
  public readonly code = 'IDEMPOTENCY_IN_FLIGHT';
  public constructor(public readonly key: string) {
    super(`Idempotency key ${key} is currently in flight`);
    this.name = 'IdempotencyConflictError';
  }
}

export class InvalidIdempotencyKeyError extends Error {
  public readonly code = 'IDEMPOTENCY_KEY_INVALID';
  public constructor(public readonly key: string | undefined) {
    super(`Idempotency key must match ${KEY_PATTERN.source}`);
    this.name = 'InvalidIdempotencyKeyError';
  }
}

/**
 * Non-blocking, in-memory implementation of an idempotency ledger.
 *
 * This class exists so that unit tests do not need Redis. The production
 * deployment uses a Redis adapter that implements the same interface; both
 * adapters are exercised by the same `r[verify]` tests through dependency
 * injection, so verification evidence is shared across implementations.
 */
export class IdempotencyStore<T> {
  private readonly records = new Map<string, IdempotencyRecord<T>>();
  private readonly now: () => number;

  public constructor(
    private readonly windowMs: number = DEFAULT_WINDOW_MS,
    now: () => number = Date.now,
  ) {
    this.now = now;
  }

  /**
   * Validate the caller-supplied idempotency key shape.
   */
  public assertKeyShape(key: string | undefined | null): asserts key is string {
    if (typeof key !== 'string' || !KEY_PATTERN.test(key)) {
      throw new InvalidIdempotencyKeyError(key ?? undefined);
    }
  }

  /**
   * Attempt to acquire the key. If acquisition succeeds, the caller owns the
   * lease and is expected to call `commit()` or `fail()`.
   *
   * All I/O is asynchronous so that the async call graph never blocks the
   * event loop while waiting on a durable backend in production.
   */
  public async acquire(
    key: string,
    fingerprint: string,
  ): Promise<{ kind: 'acquired'; leaseId: string } | { kind: 'replay'; record: IdempotencyRecord<T> }> {
    this.assertKeyShape(key);
    this.evictExpired();

    const existing = this.records.get(key);

    if (existing === undefined) {
      const record: IdempotencyRecord<T> = {
        key,
        fingerprint,
        status: 'in_flight',
        createdAt: this.now(),
        leaseId: randomUUID(),
      };
      this.records.set(key, record);
      return { kind: 'acquired', leaseId: record.leaseId };
    }

    if (existing.status === 'in_flight') {
      throw new IdempotencyConflictError(key);
    }

    return { kind: 'replay', record: existing };
  }

  /**
   * Commit the stored result of a completed operation.
   */
  public async commit(leaseId: string, result: T): Promise<void> {
    for (const [key, record] of this.records) {
      if (record.leaseId === leaseId) {
        this.records.set(key, {
          ...record,
          status: 'completed',
          result,
        });
        return;
      }
    }
    throw new Error(`Unknown lease: ${leaseId}`);
  }

  /**
   * Mark the operation failed so that a retry can proceed with a fresh key.
   */
  public async fail(leaseId: string): Promise<void> {
    for (const [key, record] of this.records) {
      if (record.leaseId === leaseId) {
        this.records.set(key, { ...record, status: 'failed' });
        return;
      }
    }
    throw new Error(`Unknown lease: ${leaseId}`);
  }

  private evictExpired(): void {
    const cutoff = this.now() - this.windowMs;
    for (const [key, record] of this.records) {
      if (record.createdAt < cutoff) {
        this.records.delete(key);
      }
    }
  }
}
