/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.ts
Description: Advanced Application Implementation
==========================================
*/

// r[impl REQ-PAY-001]
// r[impl REQ-PAY-002]
import type { IdempotencyStore } from './idempotency-store.js';
import { requireTenant } from '../tenant/tenant-context.js';

export interface ChargeRequest {
  readonly customerId: string;
  readonly amountMinorUnits: number;
  readonly currency: 'USD' | 'EUR' | 'GBP';
}

export interface ChargeResult {
  readonly chargeId: string;
  readonly capturedAt: number;
}

export interface UpstreamProcessor {
  charge(req: ChargeRequest): Promise<ChargeResult>;
}

/**
 * The orchestration layer for idempotent charging.
 *
 * The gateway deliberately knows nothing about the wire format of the
 * payment processor. It composes a `IdempotencyStore` with an
 * `UpstreamProcessor` and enforces the idempotency contract around them.
 */
export class PaymentGateway {
  public constructor(
    private readonly store: IdempotencyStore<ChargeResult>,
    private readonly processor: UpstreamProcessor,
    private readonly fingerprint: (req: ChargeRequest) => string,
  ) {}

  public async charge(
    idempotencyKey: string,
    req: ChargeRequest,
  ): Promise<ChargeResult> {
    // Touching the tenant here is deliberate: it forces the request
    // boundary to have been established upstream.
    requireTenant();

    const fingerprint = this.fingerprint(req);
    const outcome = await this.store.acquire(idempotencyKey, fingerprint);

    if (outcome.kind === 'replay') {
      if (outcome.record.status !== 'completed') {
        throw new Error('Replay of non-completed record');
      }
      return outcome.record.result as ChargeResult;
    }

    try {
      const result = await this.processor.charge(req);
      await this.store.commit(outcome.leaseId, result);
      return result;
    } catch (err) {
      await this.store.fail(outcome.leaseId);
      throw err;
    }
  }
}
