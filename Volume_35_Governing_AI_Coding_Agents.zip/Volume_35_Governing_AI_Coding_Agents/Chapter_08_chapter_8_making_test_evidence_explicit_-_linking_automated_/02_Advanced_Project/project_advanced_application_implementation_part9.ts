/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

// r[impl REQ-WHK-001]
// r[impl REQ-WHK-002]
// r[impl REQ-WHK-003]
import { createHmac, timingSafeEqual } from 'node:crypto';

export interface WebhookRequest {
  readonly rawBody: Buffer;
  readonly signatureHeader: string | undefined;
  readonly timestampHeader: string | undefined;
}

export interface WebhookEvent {
  readonly id: string;
  readonly subscriptionId: string;
  readonly created: number;
  readonly type: string;
}

export class WebhookSignatureError extends Error {
  public readonly code = 'WEBHOOK_SIGNATURE_INVALID';
  public constructor() {
    super('Webhook signature did not verify');
    this.name = 'WebhookSignatureError';
  }
}

export class WebhookReplayError extends Error {
  public readonly code = 'WEBHOOK_REPLAY';
  public constructor(public readonly skewSeconds: number) {
    super(`Webhook timestamp skew of ${skewSeconds}s exceeds maximum`);
    this.name = 'WebhookReplayError';
  }
}

const MAX_SKEW_SECONDS = 300;

/**
 * Handles inbound webhooks from the payment processor.
 *
 * Non-blocking I/O is used throughout: the signature verification is
 * synchronous CPU work (HMAC of a buffer), but dispatch to the downstream
 * event bus is async so that a slow consumer cannot stall the HTTP response.
 */
export class WebhookHandler {
  public constructor(
    private readonly secret: string,
    private readonly clock: () => number = () => Math.floor(Date.now() / 1000),
  ) {}

  public verifyAndParse(req: WebhookRequest): WebhookEvent {
    this.verifySignature(req);
    const event = this.parseEvent(req.rawBody);
    this.verifyTimestamp(event.created);
    return event;
  }

  /**
   * Constant-time HMAC verification.
   *
   * Note the use of `timingSafeEqual` rather than `===`. The signature
   * comparison must not depend on the number of matching bytes, or the
   * endpoint becomes vulnerable to timing attacks.
   */
  private verifySignature(req: WebhookRequest): void {
    if (!req.signatureHeader) {
      throw new WebhookSignatureError();
    }
    const expected = createHmac('sha256', this.secret)
      .update(req.rawBody)
      .digest('hex');

    const expectedBuf = Buffer.from(expected, 'hex');
    const actualBuf = Buffer.from(req.signatureHeader, 'hex');

    if (
      expectedBuf.length !== actualBuf.length ||
      !timingSafeEqual(expectedBuf, actualBuf)
    ) {
      throw new WebhookSignatureError();
    }
  }

  private verifyTimestamp(createdSeconds: number): void {
    const skew = Math.abs(this.clock() - createdSeconds);
    if (skew > MAX_SKEW_SECONDS) {
      throw new WebhookReplayError(skew);
    }
  }

  private parseEvent(body: Buffer): WebhookEvent {
    const parsed = JSON.parse(body.toString('utf8')) as unknown;
    if (
      typeof parsed !== 'object' ||
      parsed === null ||
      typeof (parsed as { id?: unknown }).id !== 'string' ||
      typeof (parsed as { subscriptionId?: unknown }).subscriptionId !== 'string' ||
      typeof (parsed as { created?: unknown }).created !== 'number' ||
      typeof (parsed as { type?: unknown }).type !== 'string'
    ) {
      throw new Error('Malformed webhook payload');
    }
    return parsed as WebhookEvent;
  }

  /**
   * Re-order a batch of events for a single subscription by their `created`
   * timestamp, so that out-of-order network delivery cannot reorder the
   * business outcome.
   */
  public orderEvents(events: readonly WebhookEvent[]): WebhookEvent[] {
    return [...events].sort((a, b) => a.created - b.created);
  }
}
