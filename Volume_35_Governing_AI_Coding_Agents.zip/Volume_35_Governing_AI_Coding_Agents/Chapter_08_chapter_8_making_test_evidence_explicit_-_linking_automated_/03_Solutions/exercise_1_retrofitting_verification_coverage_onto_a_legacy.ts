/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_retrofitting_verification_coverage_onto_a_legacy.ts
Description: Solutions and Explanations
==========================================
*/

// .config/tracey/config.styx (declared inline as TS string constant for reference)
//
// WHY test_include matters: files matched by this glob are gated by Tracey to
// contain ONLY `verify` annotations. Any `impl` annotation inside a test file
// is a hard error, not a warning. This is the single guardrail that keeps the
// implementation graph honest — without it, an intern can slap `r[impl ...]`
// on a test that mocks out the very function it claims to implement.
export const CONFIG_STYX = `
@schema {id crate:tracey-config@1, cli tracey}

specs (
  {
    name auth
    source_url https://github.com/example/payments-service
    include (docs/spec/**/*.md)
    impls (
      {
        name typescript
        include (src/**/*.ts)
        test_include (tests/**/*.test.ts)
        exclude (node_modules/** dist/**)
      }
    )
  }
)
`;

// scripts/retrofit-verification.ts
// Walks every untested requirement returned by `tracey query untested`,
// resolves its title via `tracey query rule`, and emits a gap-analysis row.
// The script never writes annotations itself — annotation placement is a
// reviewable human decision because tree-sitter scope is invisible to grep.

import { execFileSync } from "node:child_process";
import { writeFileSync, mkdirSync } from "node:fs";
import { resolve } from "node:path";

interface UntestedEntry {
  uid: string;
  section: string;
}

interface RuleDetails {
  uid: string;
  title: string;
  statement: string;
  version: number;
  references: Array<{ file: string; line: number; verb: string; version: number }>;
}

interface GapRow {
  uid: string;
  title: string;
  candidateTests: string[];
  justification: string;
  needsFollowUp: boolean;
}

// A caller-supplied registry mapping requirement UID prefixes to the Vitest
// files most likely to cover them. Kept in TS rather than discovered
// automatically so that reviewers can see the mapping in code review.
const HEURISTIC_TEST_MAP: Record<string, string[]> = {
  "auth.login": ["tests/auth/login.test.ts"],
  "auth.token": ["tests/auth/token-rotation.test.ts"],
  "auth.rate-limiting": ["tests/auth/rate-limit.test.ts"],
  "auth.mfa": ["tests/auth/mfa.test.ts"],
  "auth.session": ["tests/auth/session-revocation.test.ts"],
  "auth.password": ["tests/auth/password-policy.test.ts"],
  "auth.account.soft-deleted": ["tests/auth/login.test.ts", "tests/auth/session-revocation.test.ts"],
};

function tracey(args: string[]): string {
  // execFileSync avoids shell interpolation so a UID with punctuation
  // (e.g. `auth.token-expiry`) cannot be reinterpreted by /bin/sh.
  return execFileSync("tracey", args, { encoding: "utf8" }).trim();
}

function parseUntested(raw: string): UntestedEntry[] {
  // `tracey query untested` groups output by spec section heading.
  // We only care about the UID lines; headings are retained as context.
  const entries: UntestedEntry[] = [];
  let currentSection = "(root)";
  for (const line of raw.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    if (trimmed.startsWith("#")) {
      currentSection = trimmed.replace(/^#+\s*/, "");
      continue;
    }
    // A UID is any bare token matching the dot-separated convention.
    if (/^[a-z][a-z0-9]*(\.[a-z0-9_-]+)+$/i.test(trimmed)) {
      entries.push({ uid: trimmed, section: currentSection });
    }
  }
  return entries;
}

function fetchRule(uid: string): RuleDetails {
  // `tracey query rule <uid>` prints a human-readable block. We parse the
  // TITLE line and every `file:line` reference line. This is intentionally
  // brittle — if Tracey changes its output format, this parser is the
  // canary rather than the CI gate itself.
  const raw = tracey(["query", "rule", uid]);
  const titleMatch = raw.match(/^TITLE:\s*(.+)$/m);
  const versionMatch = raw.match(/\+(\d+)\b/);
  const refs: RuleDetails["references"] = [];
  const refRegex = /^(\S+\.(?:ts|tsx)):(\d+)\s+\[(\w+)\]/gm;
  let m: RegExpExecArray | null;
  while ((m = refRegex.exec(raw)) !== null) {
    refs.push({ file: m[1], line: Number(m[2]), verb: m[3], version: versionMatch ? Number(versionMatch[1]) : 1 });
  }
  return {
    uid,
    title: titleMatch ? titleMatch[1] : uid,
    statement: raw,
    version: versionMatch ? Number(versionMatch[1]) : 1,
    references: refs,
  };
}

function classify(uid: string, rule: RuleDetails): GapRow {
  const candidates = Object.entries(HEURISTIC_TEST_MAP)
    .filter(([prefix]) => uid.startsWith(prefix))
    .flatMap(([, files]) => files);

  // Deployment-topology requirements cannot be satisfied by a Vitest test
  // without either a real cluster or a mocking layer so elaborate that the
  // test stops being evidence. Flag those explicitly rather than faking it.
  const UNVERIFIABLE_PREFIXES = ["auth.deploy.", "auth.infra.", "auth.tls.cert-rotation"];
  const unverifiable = UNVERIFIABLE_PREFIXES.some((p) => uid.startsWith(p));

  return {
    uid,
    title: rule.title,
    candidateTests: candidates,
    justification: unverifiable
      ? "Deployment-topology requirement; no automated test possible in this repo. Raise follow-up."
      : `Existing test at ${candidates[0] ?? "<new test>"} exercises this path; see audit doc for assertion reference.`,
    needsFollowUp: unverifiable,
  };
}

function emitAudit(gaps: GapRow[], gitSha: string, timestampIso: string): string {
  const table = [
    "| Requirement UID | Title | Candidate Test(s) | Justification | Follow-up |",
    "| --- | --- | --- | --- | --- |",
    ...gaps.map((g) =>
      `| \`${g.uid}\` | ${g.title.replace(/\|/g, "\\|")} | ${g.candidateTests
        .map((t) => `\`${t}\``)
        .join(", ") || "_new test needed_"} | ${g.justification} | ${g.needsFollowUp ? "**yes**" : "no"} |`,
    ),
  ].join("\n");

  return `# Auth Verification Coverage — Baseline

- Git SHA: \`${gitSha}\`
- Captured at: ${timestampIso}
- Spec under audit: \`docs/spec/auth.md\`
- Implementation: \`auth/typescript\`

## \`tracey query status\`

\`\`\`
${tracey(["query", "status"])}
\`\`\`

## \`tracey query uncovered --spec_impl auth/typescript\`

\`\`\`
${tracey(["query", "uncovered", "--spec_impl", "auth/typescript"])}
\`\`\`

## \`tracey query untested --spec_impl auth/typescript\`

\`\`\`
${tracey(["query", "untested", "--spec_impl", "auth/typescript"])}
\`\`\`

## Gap Analysis

${table}

## Orphaned Tests and Spec Gaps

Any Vitest file under \`tests/auth/\` whose assertions do not trace to a
requirement in \`docs/spec/auth.md\` is listed here. Each entry states the
corrective action: **(a)** raise a new requirement, **(b)** delete as dead
code, or **(c)** leave unannotated as defensive.

- \`tests/auth/helpers/clock.test.ts\` — tests a clock-skew helper that no
  current requirement mentions. **Action (c):** leave unannotated. The
  helper is defensive infrastructure for time-based expiry logic and
  removing it would silently weaken the suite.

## Validation

\`tracey query validate --deny warnings\` must exit 0. See CI workflow for
continuous enforcement.
`;
}

function main(): void {
  const gitSha = execFileSync("git", ["rev-parse", "--short", "HEAD"], { encoding: "utf8" }).trim();
  const untested = parseUntested(tracey(["query", "untested", "--spec_impl", "auth/typescript"]));
  const gaps = untested.map((u) => classify(u.uid, fetchRule(u.uid)));

  mkdirSync("docs/audit", { recursive: true });
  writeFileSync(
    resolve("docs/audit/auth-verification-baseline.md"),
    emitAudit(gaps, gitSha, new Date().toISOString()),
  );

  // Print the gaps that need a human decision before computing is done.
  const followUps = gaps.filter((g) => g.needsFollowUp);
  if (followUps.length > 0) {
    console.error(`${followUps.length} requirement(s) require manual follow-up:`);
    for (const f of followUps) console.error(`  - ${f.uid}`);
  }
}

main();

// ---------------------------------------------------------------------------
// Example of the annotation pattern applied during the retrofit.
// THIS is what the retrofit script above advises humans to write by hand.
// ---------------------------------------------------------------------------
//
// tests/auth/login.test.ts
//
// import { describe, it, expect } from "vitest";
// import { login } from "../../src/auth/login";
// import { softDeleteUser } from "../fixtures/users";
//
// describe("auth.login", () => {
//   // One requirement per line, directly above the it() that proves it.
//   // Do NOT place these above a beforeEach — tree-sitter will attach the
//   // annotation to the hook, and coverage will silently lie.
//   // r[verify auth.login]
//   // r[verify auth.account.soft-deleted]
//   it("rejects a login attempt for a soft-deleted account", async () => {
//     const user = await softDeleteUser("alice@example.com");
//     await expect(login(user.email, "correct-password")).rejects.toThrow(/deleted/);
//   });
// });
//
// ---------------------------------------------------------------------------
// .github/workflows/spec-assurance.yml — enforcement gate
// ---------------------------------------------------------------------------
//
// name: Specification Assurance Gate
// on: [push, pull_request]
// jobs:
//   verify-intent:
//     runs-on: ubuntu-latest
//     steps:
//       - uses: actions/checkout@v4
//         with: { fetch-depth: 0 }
//       - name: Install Tracey
//         run: |
//           curl --proto '=https' --tlsv1.2 -LsSf \
//             https://github.com/bearcove/tracey/releases/latest/download/tracey-installer.sh | sh
//           echo "$HOME/.cargo/bin" >> $GITHUB_PATH
//       - name: Install StrictDoc
//         run: pip install strictdoc
//       - name: Validate StrictDoc document tree
//         run: strictdoc export --formats=html .
//       - name: Enforce zero-warning spec coverage & traceability
//         run: tracey query validate --deny warnings
