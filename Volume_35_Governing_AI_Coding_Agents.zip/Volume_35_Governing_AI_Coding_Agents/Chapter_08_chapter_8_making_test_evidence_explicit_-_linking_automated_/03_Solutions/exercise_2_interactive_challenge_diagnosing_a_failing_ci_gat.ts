/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_interactive_challenge_diagnosing_a_failing_ci_gat.ts
Description: Solutions and Explanations
==========================================
*/

// scripts/incident-diagnosis.ts
//
// Drives the Tracey MCP server over stdio using raw JSON-RPC framing.
// The point of this script is pedagogical: it shows that MCP is just
// newline-delimited JSON-RPC 2.0, and that every tool call is a
// `tools/call` invocation with a `name` and an `arguments` object.
//
// This is the same wire format the IDE's AI assistant uses behind the
// scenes; writing it by hand once is how a team earns the right to
// build custom dashboards against Tracey (see Exercise 4).

import { spawn, ChildProcessWithoutNullStreams } from "node:child_process";
import { writeFileSync, mkdirSync } from "node:fs";

interface JsonRpcRequest {
  jsonrpc: "2.0";
  id: number;
  method: string;
  params?: Record<string, unknown>;
}

interface JsonRpcResponse<T = unknown> {
  jsonrpc: "2.0";
  id: number;
  result?: T;
  error?: { code: number; message: string; data?: unknown };
}

interface McpContentBlock {
  type: "text";
  text: string;
}

interface McpCallResult {
  content: McpContentBlock[];
  isError?: boolean;
}

class TraceyMcp {
  private proc: ChildProcessWithoutNullStreams;
  private nextId = 1;
  private buffer = "";
  private pending = new Map<number, (resp: JsonRpcResponse) => void>();

  constructor(repoRoot: string) {
    // stdio transport: the daemon is auto-started by the bridge.
    this.proc = spawn("tracey", ["mcp", repoRoot], { stdio: ["pipe", "pipe", "pipe"] });
    this.proc.stdout.on("data", (chunk: Buffer) => this.onData(chunk.toString("utf8")));
    this.proc.on("error", (err) => {
      // Child failed to spawn — usually Tracey not on PATH.
      for (const cb of this.pending.values()) cb({ jsonrpc: "2.0", id: -1, error: { code: -32000, message: String(err) } });
      this.pending.clear();
    });
  }

  private onData(text: string): void {
    // JSON-RPC over stdio is newline-delimited. Buffer partial lines.
    this.buffer += text;
    let idx: number;
    while ((idx = this.buffer.indexOf("\n")) >= 0) {
      const line = this.buffer.slice(0, idx).trim();
      this.buffer = this.buffer.slice(idx + 1);
      if (!line) continue;
      let resp: JsonRpcResponse;
      try {
        resp = JSON.parse(line) as JsonRpcResponse;
      } catch {
        continue; // Not a JSON-RPC frame; maybe a daemon log line.
      }
      const cb = this.pending.get(resp.id);
      if (cb) {
        this.pending.delete(resp.id);
        cb(resp);
      }
    }
  }

  private send(req: Omit<JsonRpcRequest, "jsonrpc" | "id">): Promise<JsonRpcResponse> {
    const full: JsonRpcRequest = { jsonrpc: "2.0", id: this.nextId++, ...req };
    return new Promise((resolve) => {
      this.pending.set(full.id, resolve);
      this.proc.stdin.write(JSON.stringify(full) + "\n");
    });
  }

  async initialize(): Promise<void> {
    // MCP handshake: protocol version + client capabilities + clientInfo.
    const resp = await this.send({
      method: "initialize",
      params: {
        protocolVersion: "2024-11-05",
        capabilities: {},
        clientInfo: { name: "tracey-incident-diagnosis", version: "0.1.0" },
      },
    });
    if (resp.error) throw new Error(`initialize failed: ${resp.error.message}`);
    // Send `notifications/initialized` (no id) to complete the handshake.
    this.proc.stdin.write(JSON.stringify({ jsonrpc: "2.0", method: "notifications/initialized" }) + "\n");
  }

  async callTool(name: string, args: Record<string, unknown>): Promise<string> {
    const resp = await this.send({ method: "tools/call", params: { name, arguments: args } });
    if (resp.error) throw new Error(`tools/call ${name} failed: ${resp.error.message}`);
    const result = resp.result as McpCallResult;
    if (result.isError) throw new Error(`tool ${name} returned isError=true`);
    return result.content.map((b) => b.text).join("\n");
  }

  // Also, capture raw request/response pair for the report's transcript
  // section, since the exercise demands a demonstration of the wire format.
  async callToolRaw(name: string, args: Record<string, unknown>): Promise<{ request: string; response: string; text: string }> {
    const full: JsonRpcRequest = { jsonrpc: "2.0", id: this.nextId++, method: "tools/call", params: { name, arguments: args } };
    const requestLine = JSON.stringify(full);
    const response = await new Promise<JsonRpcResponse>((resolve) => {
      this.pending.set(full.id, resolve);
      this.proc.stdin.write(requestLine + "\n");
    });
    const result = response.result as McpCallResult;
    return { request: requestLine, response: JSON.stringify(response), text: result.content.map((b) => b.text).join("\n") };
  }

  close(): void {
    this.proc.stdin.end();
    this.proc.kill();
  }
}

// ---------------------------------------------------------------------------
// The diagnosis chain. Each step's output feeds the next step's decision.
// ---------------------------------------------------------------------------

interface StatusParse {
  specImpls: Array<{ spec: string; impl: string; implPct: number; verifyPct: number }>;
}

function parseStatus(text: string): StatusParse {
  // Tracey MCP responses are human-readable, with a summary header.
  // We extract "<spec>/<impl>  impl: NN%  verify: NN%" style lines.
  const rows: StatusParse["specImpls"] = [];
  const re = /(\S+)\/(\S+)\s+impl[:\s]*(\d+)%\s+verify[:\s]*(\d+)%/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    rows.push({ spec: m[1], impl: m[2], implPct: Number(m[3]), verifyPct: Number(m[4]) });
  }
  return { specImpls: rows };
}

function parseUidList(text: string): string[] {
  return text
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => /^[a-z][a-z0-9]*(\.[a-z0-9_-]+)+$/i.test(l));
}

async function main(): Promise<void> {
  const mcp = new TraceyMcp(process.cwd());
  await mcp.initialize();

  const transcript: Array<{ step: string; rawRequest?: string; rawResponse?: string; text: string }> = [];

  // STEP 1: cold-start with status. Establishes which spec_impl pairs exist
  // and what their current coverage percentages are. Any pair whose verify
  // percentage dropped is a suspect; static gaps are non-diagnostic.
  const statusText = await mcp.callTool("tracey_status", {});
  const status = parseStatus(statusText);
  transcript.push({ step: "tracey_status", text: statusText });

  // Choose the most likely culprit: for this scenario it is payments/typescript.
  const target = status.specImpls.find((s) => s.spec === "payments" && s.impl === "typescript")
    ?? status.specImpls[0];

  // STEP 2: enumerate the worklist unfiltered, then filtered to the prefix
  // the feature branch touched. The DELTA between unfiltered and filtered
  // is the regression set — the requirements that used to be covered.
  const uncoveredAll = parseUidList(await mcp.callTool("tracey_uncovered", {}));
  const untestedAll = parseUidList(await mcp.callTool("tracey_untested", {}));
  const uncoveredRefund = parseUidList(await mcp.callTool("tracey_uncovered", { prefix: "payments.refund." }));
  const untestedRefund = parseUidList(await mcp.callTool("tracey_untested", { prefix: "payments.refund." }));

  // A regression is: present in the filtered set AND absent from what we
  // would have expected given yesterday's baseline. In practice we detect
  // it as "appears in untested now" for a requirement that has a `+N+1`
  // mismatch in code (see step 3).
  const suspects = untestedRefund;

  // STEP 3: for each suspect, read the rule to see its current version and
  // every reference. If any reference's version is < spec version, it is
  // stale, and stale references are NOT counted as covered.
  const ruleReports: Array<{ uid: string; text: string }> = [];
  for (const uid of suspects) {
    const text = await mcp.callTool("tracey_rule", { uid });
    ruleReports.push({ uid, text });
  }

  // STEP 4: explicit stale set for the refund slice. This is the grist of
  // the incident report — file, line, annotated version, current version.
  const staleText = await mcp.callTool("tracey_stale", { spec_impl: `${target.spec}/${target.impl}`, prefix: "payments.refund." });
  transcript.push({ step: "tracey_stale", text: staleText });

  // STEP 5: source tree coverage to find silently-added files. A file
  // added by the feature branch with 0% coverage is a smoking gun.
  const unmappedText = await mcp.callTool("tracey_unmapped", { path: "src/payments/refunds/" });
  transcript.push({ step: "tracey_unmapped", text: unmappedText });

  // STEP 6: final validator run, categorized into the six buckets.
  const validateText = await mcp.callTool("tracey_validate", { spec_impl: `${target.spec}/${target.impl}` });
  transcript.push({ step: "tracey_validate", text: validateText });

  // Capture one raw JSON-RPC pair for the report's wire-format section.
  const rawPair = await mcp.callToolRaw("tracey_rule", { uid: suspects[0] ?? "payments.refund.reversal" });

  // STEP 7: write the incident report.
  mkdirSync("docs/incidents", { recursive: true });
  const report = `# Incident Report — 2026-05-14 Spec Drift

## Timeline

- 2026-05-13 22:00 UTC — \`feature/refund-flow-v2\` merged into \`main\`.
- 2026-05-14 03:14 UTC — \`spec-assurance.yml\` failed on \`main\` with
  \`tracey query validate --deny warnings exited with code 1\`.

## Detected Issues

\`\`\`
${validateText}
\`\`\`

### Classification

| # | Reference | Bucket | Remediation |
| - | --------- | ------ | ----------- |
| 1 | \`payments.refund.reversal\` in \`src/payments/refunds/reversal.ts:42\` | stale reference | Update code to match new 48h window, then bump annotation to \`+3\`. |
| 2 | \`payments.refund.reversal\` in \`tests/payments/refunds/reversal.test.ts:18\` | stale reference | Update assertion, then bump annotation to \`+3\`. |
| 3 | \`payments.refund.sweeper\` in \`src/payments/jobs/refund-sweeper.ts:11\` | stale reference | Same review-order discipline as above. |

> A **broken** reference (points at a UID that does not exist) is fixed by
> correcting the UID or restoring the requirement. A **stale** reference is
> a legitimate annotation against an older version; it is fixed by reviewing
> the code against the new spec text and only then bumping the annotation.

## Root Cause

The refund-window constant was changed from 72h to 48h inside
\`feature/refund-flow-v2\`, but the spec text was updated *without* the version
suffix being bumped from \`+2\` to \`+3\` in the same commit. Tracey's
versioning model treats every reference written as \`+2\` (i.e. no suffix,
or an explicit \`+2\`) as pointing at version 2 of the rule. Because the
spec now declares version 3, those references were silently reclassified as
stale, and stale references are *not* counted as covered. The commit that
introduced the drift is the one touching \`docs/spec/payments.md\` on the
feature branch.

## Fix

1. On the feature branch, correct the reference versions:
   - \`src/payments/refunds/reversal.ts\` — bump \`+2\` → \`+3\`.
   - \`src/payments/jobs/refund-sweeper.ts\` — bump \`+2\` → \`+3\`.
   - \`tests/payments/refunds/reversal.test.ts\` — bump \`+2\` → \`+3\`.
   - \`tests/payments/jobs/refund-sweeper.test.ts\` — bump \`+2\` → \`+3\`.
2. Confirm \`tracey query stale --prefix payments.refund.\` returns empty.
3. Confirm \`tracey query validate --deny warnings\` exits 0.
4. Commit on the feature branch; the CI gate goes green on the next push.

## Prevention

1. **Pre-commit hook** installing \`tracey pre-commit\` on every developer
   machine. This refuses to let a spec text change land without a version
   bump, which is exactly the omission that caused this incident.
2. **CI validation step** that runs \`tracey query validate --deny warnings\`
   *before* the merge queue accepts the commit, so no drift can reach
   \`main\` in the first place.

## Raw JSON-RPC Transcript

\`\`\`
> ${rawPair.request}
< ${rawPair.response}
\`\`\`

The request demonstrates the MCP wire format: \`jsonrpc\` version, a numeric
\`id\`, the \`method\` (\`tools/call\`), and a \`params\` object carrying the
tool \`name\` and its \`arguments\`. The response echoes the \`id\` and carries
a \`result.content\` array of typed text blocks.
`;
  writeFileSync("docs/incidents/2026-05-14-spec-drift.md", report);

  mcp.close();
}

void main();
