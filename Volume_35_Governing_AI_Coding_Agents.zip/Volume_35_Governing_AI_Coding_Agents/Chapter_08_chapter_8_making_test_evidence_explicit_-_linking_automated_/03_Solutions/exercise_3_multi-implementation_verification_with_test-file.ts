/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_multi-implementation_verification_with_test-file.ts
Description: Solutions and Explanations
==========================================
*/

// .config/tracey/config.styx — single spec, two implementations.
//
// Note that the `include` globs are disjoint from the `test_include` globs
// by construction: sources live under `src/` and tests live under `tests/`.
// This sibling-directory layout is deliberate and is the recommended
// pattern, because Tracey must otherwise decide, per file, whether the
// verify-only gate applies — and a file matched by both globs is a
// configuration smell even if Tracey resolves it.
export const MUX_CONFIG_STYX = `
@schema {id crate:tracey-config@1, cli tracey}

specs (
  {
    name mux
    source_url https://github.com/example/mux
    include (docs/spec/mux.sdoc)
    impls (
      {
        name typescript
        include (packages/mux-ts/src/**/*.ts)
        exclude (node_modules/** dist/** coverage/**)
        test_include (packages/mux-ts/tests/**/*.test.ts)
      }
      {
        name rust
        include (crates/mux-rs/src/**/*.rs)
        exclude (target/**)
        test_include (crates/mux-rs/tests/**/*.rs)
      }
    )
  }
)
`;

// ---------------------------------------------------------------------------
// scripts/mux_parity.ts — the parity gate.
// Invoked from CI. Two responsibilities:
//   (1) fail if impl or verify coverage differs by more than 5pp.
//   (2) fail if any requirement has an impl reference in one implementation
//       but not the other — cross-implementation drift.
// ---------------------------------------------------------------------------

import { execFileSync } from "node:child_process";

interface ImplStatus {
  implPct: number;
  verifyPct: number;
}

interface Coverage {
  ts: ImplStatus;
  rs: ImplStatus;
  tsImplSet: Set<string>;
  rsImplSet: Set<string>;
  allUids: Set<string>;
}

function tracey(args: string[]): string {
  return execFileSync("tracey", args, { encoding: "utf8" }).trim();
}

function parseStatus(text: string, implName: string): ImplStatus {
  // Example line from `tracey query status --spec_impl mux/typescript`:
  //   mux/typescript   impl 87%   verify 72%
  const re = new RegExp(`mux/${implName}\\s+impl[:\\s]*(\\d+)%\\s+verify[:\\s]*(\\d+)%`);
  const m = text.match(re);
  if (!m) throw new Error(`Could not parse status for impl=${implName}. Raw:\n${text}`);
  return { implPct: Number(m[1]), verifyPct: Number(m[2]) };
}

function parseUidSet(text: string): Set<string> {
  // `tracey query uncovered --spec_impl mux/rust` returns a list of UIDs
  // (one per line) grouped under spec sections. Extract the bare UIDs.
  const uidRe = /^[A-Z][A-Z0-9-]*(\.[A-Z0-9_-]+)*\d+$/i;
  return new Set(
    text
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => uidRe.test(l)),
  );
}

function collectAllUids(): Set<string> {
  // The complete set of UIDs is the union of the spec's declared requirements.
  // Tracey does not have a single "list every UID" tool; we derive the set
  // from the two `uncovered` queries plus the two `untested` queries plus
  // the currently-covered set implied by coverage percentages. In practice
  // the most robust way is to grep the spec file directly for UID markers,
  // because the spec is a text file in version control.
  const raw = execFileSync("grep", ["-oE", "UID:\\s*[A-Z0-9-]+", "docs/spec/mux.sdoc"], { encoding: "utf8" });
  const uids = raw.split("\n").map((l) => l.replace(/^UID:\s*/, "").trim()).filter(Boolean);
  return new Set(uids);
}

function deriveUncoveredSet(specImpl: string): Set<string> {
  return parseUidSet(tracey(["query", "uncovered", "--spec_impl", specImpl]));
}

function computeCoverage(): Coverage {
  const tsStatus = parseStatus(tracey(["query", "status", "--spec_impl", "mux/typescript"]), "typescript");
  const rsStatus = parseStatus(tracey(["query", "status", "--spec_impl", "mux/rust"]), "rust");

  const allUids = collectAllUids();
  const tsUncovered = deriveUncoveredSet("mux/typescript");
  const rsUncovered = deriveUncoveredSet("mux/rust");

  // Impl coverage for an implementation = UIDs NOT in that impl's uncovered set.
  const tsImplSet = new Set([...allUids].filter((u) => !tsUncovered.has(u)));
  const rsImplSet = new Set([...allUids].filter((u) => !rsUncovered.has(u)));

  return { ts: tsStatus, rs: rsStatus, tsImplSet, rsImplSet, allUids };
}

function main(): number {
  const cov = computeCoverage();

  let failed = false;

  // Check 1: percentage parity within 5pp.
  const implDelta = Math.abs(cov.ts.implPct - cov.rs.implPct);
  const verifyDelta = Math.abs(cov.ts.verifyPct - cov.rs.verifyPct);

  if (implDelta > 5) {
    console.error(`PARITY FAIL: impl coverage differs by ${implDelta}pp (ts=${cov.ts.implPct}%, rs=${cov.rs.implPct}%)`);
    failed = true;
  }
  if (verifyDelta > 5) {
    console.error(`PARITY FAIL: verify coverage differs by ${verifyDelta}pp (ts=${cov.ts.verifyPct}%, rs=${cov.rs.verifyPct}%)`);
    failed = true;
  }

  // Check 2: cross-implementation drift. Every requirement must be impl'd
  // in both implementations or in neither. A requirement impl'd in TS but
  // not Rust means the two implementations disagree about the spec.
  const onlyTs = [...cov.allUids].filter((u) => cov.tsImplSet.has(u) && !cov.rsImplSet.has(u));
  const onlyRs = [...cov.allUids].filter((u) => cov.rsImplSet.has(u) && !cov.tsImplSet.has(u));

  if (onlyTs.length > 0 || onlyRs.length > 0) {
    console.error("CROSS-IMPLEMENTATION DRIFT DETECTED:");
    for (const u of onlyTs) console.error(`  - ${u}  [impl in typescript only]`);
    for (const u of onlyRs) console.error(`  - ${u}  [impl in rust only]`);
    failed = true;
  }

  if (!failed) {
    console.log(`PARITY OK: impl Δ=${implDelta}pp, verify Δ=${verifyDelta}pp, no drift.`);
    return 0;
  }
  return 1;
}

process.exit(main());

// ---------------------------------------------------------------------------
// tests/mux-ts/tests/channel.test.ts — one annotation per it(), on its own line.
// ---------------------------------------------------------------------------
//
// import { describe, it, expect } from "vitest";
// import { allocateChannelId } from "../src/channel";
//
// describe("mux.channel", () => {
//   // r[verify MUX-CHANNEL-001]
//   it("allocates channel IDs sequentially from zero", () => {
//     const a = allocateChannelId(0);
//     const b = allocateChannelId(1);
//     expect(a).toBe(0);
//     expect(b).toBe(1);
//   });
//
//   // r[verify MUX-CHANNEL-002]
//   it("assigns odd IDs to client-initiated channels", () => {
//     expect(allocateChannelId(0, "client")).toBe(1);
//   });
// });
//
// ---------------------------------------------------------------------------
// crates/mux-rs/tests/channel.rs — same discipline, Rust side.
// ---------------------------------------------------------------------------
//
// use mux_rs::channel::allocate_channel_id;
//
// // r[verify MUX-CHANNEL-001]
// #[test]
// fn channel_ids_are_sequential_from_zero() {
//     assert_eq!(allocate_channel_id(0), 0);
//     assert_eq!(allocate_channel_id(1), 1);
// }
//
// // r[verify MUX-CHANNEL-002]
// #[test]
// fn client_channels_are_odd() {
//     assert_eq!(allocate_channel_id(0, Side::Client), 1);
// }
