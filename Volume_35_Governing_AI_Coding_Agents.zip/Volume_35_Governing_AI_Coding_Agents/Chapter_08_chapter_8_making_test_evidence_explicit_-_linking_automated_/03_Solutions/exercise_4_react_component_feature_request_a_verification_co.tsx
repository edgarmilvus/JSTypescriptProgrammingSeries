/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_react_component_feature_request_a_verification_co.tsx
Description: Solutions and Explanations
==========================================
*/

// apps/dx-console/src/features/release-readiness/VerificationCoveragePanel/types.ts
export type CoverageState = "covered" | "partially-covered" | "uncovered";

export interface StatusKPI {
  spec: string;
  impl: string;
  implPct: number;
  verifyPct: number;
}

export interface UntestedRequirement {
  uid: string;
  state: Extract<CoverageState, "partially-covered" | "uncovered">;
}

export interface StaleReference {
  uid: string;
  annotatedVersion: number;
  currentVersion: number;
  file: string;
  line: number;
}

export interface CoveragePayload {
  status: StatusKPI;
  untested: UntestedRequirement[];
  stale: StaleReference[];
}

// ---------------------------------------------------------------------------
// apps/dx-console/src/features/release-readiness/VerificationCoveragePanel/mcpClient.ts
// ---------------------------------------------------------------------------
import { spawn, ChildProcessWithoutNullStreams } from "node:child_process";

interface JsonRpcResponse {
  jsonrpc: "2.0";
  id: number;
  result?: { content: Array<{ type: "text"; text: string }>; isError?: boolean };
  error?: { code: number; message: string };
}

export class TraceyMcpClient {
  private proc: ChildProcessWithoutNullStreams | null = null;
  private nextId = 1;
  private buffer = "";
  private pending = new Map<number, (r: JsonRpcResponse) => void>();

  private ensureSpawned(repoRoot: string): void {
    if (this.proc) return;
    try {
      this.proc = spawn("tracey", ["mcp", repoRoot], { stdio: ["pipe", "pipe", "pipe"] });
    } catch (err) {
      // Distinguish "not installed" from other failures so the UI can
      // surface the right remediation (install Tracey vs. fix PATH).
      throw new Error(`TRACEY_NOT_INSTALLED: ${(err as Error).message}`);
    }
    this.proc.stdout.on("data", (c: Buffer) => this.onData(c.toString("utf8")));
    this.proc.on("exit", (code) => {
      if (code !== 0) {
        for (const cb of this.pending.values()) cb({ jsonrpc: "2.0", id: -1, error: { code: -32000, message: `Tracey exited ${code}` } });
        this.pending.clear();
        this.proc = null;
      }
    });
  }

  private onData(text: string): void {
    this.buffer += text;
    let i: number;
    while ((i = this.buffer.indexOf("\n")) >= 0) {
      const line = this.buffer.slice(0, i).trim();
      this.buffer = this.buffer.slice(i + 1);
      if (!line) continue;
      try {
        const resp = JSON.parse(line) as JsonRpcResponse;
        const cb = this.pending.get(resp.id);
        if (cb) { this.pending.delete(resp.id); cb(resp); }
      } catch { /* daemon log line */ }
    }
  }

  private call(repoRoot: string, method: string, params: Record<string, unknown>): Promise<JsonRpcResponse> {
    this.ensureSpawned(repoRoot);
    const id = this.nextId++;
    return new Promise((resolve) => {
      this.pending.set(id, resolve);
      this.proc!.stdin.write(JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n");
    });
  }

  private async toolCall(repoRoot: string, name: string, args: Record<string, unknown>): Promise<string> {
    const resp = await this.call(repoRoot, "tools/call", { name, arguments: args });
    if (resp.error) throw new Error(resp.error.message);
    if (resp.result?.isError) throw new Error(`tracey tool ${name} reported an error`);
    return (resp.result?.content ?? []).map((b) => b.text).join("\n");
  }

  async getStatus(repoRoot: string, specImpl: string): Promise<StatusKPI> {
    const text = await this.toolCall(repoRoot, "tracey_status", { spec_impl: specImpl });
    const m = text.match(/(\S+)\/(\S+)\s+impl[:\s]*(\d+)%\s+verify[:\s]*(\d+)%/);
    if (!m) throw new Error(`Unparseable status response for spec_impl=${specImpl}`);
    return { spec: m[1], impl: m[2], implPct: Number(m[3]), verifyPct: Number(m[4]) };
  }

  async getUntested(repoRoot: string, specImpl: string, prefix?: string): Promise<UntestedRequirement[]> {
    const args: Record<string, unknown> = { spec_impl: specImpl };
    if (prefix) args.prefix = prefix;
    const text = await this.toolCall(repoRoot, "tracey_untested", args);
    return text
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => /^[a-z][a-z0-9]*(\.[a-z0-9_-]+)+$/i.test(l))
      .map((uid) => ({ uid, state: "partially-covered" as const }));
  }

  async getStale(repoRoot: string, specImpl: string, prefix?: string): Promise<StaleReference[]> {
    const args: Record<string, unknown> = { spec_impl: specImpl };
    if (prefix) args.prefix = prefix;
    const text = await this.toolCall(repoRoot, "tracey_stale", args);
    // Tracey prints "uid  file:line  annotated +N  current +M" lines.
    const out: StaleReference[] = [];
    const re = /^([a-z][a-z0-9]*(?:\.[a-z0-9_-]+)+)\s+(\S+):(\d+)\s+annotated\s+\+(\d+)\s+current\s+\+(\d+)/i;
    for (const line of text.split("\n")) {
      const m = line.trim().match(re);
      if (m) out.push({
        uid: m[1], file: m[2], line: Number(m[3]),
        annotatedVersion: Number(m[4]), currentVersion: Number(m[5]),
      });
    }
    return out;
  }

  dispose(): void {
    this.proc?.kill();
    this.proc = null;
  }
}

// ---------------------------------------------------------------------------
// apps/dx-console/src/features/release-readiness/VerificationCoveragePanel/useTraceyCoverage.ts
// ---------------------------------------------------------------------------
import { useCallback, useEffect, useRef, useState } from "react";

const REFRESH_INTERVAL_MS = 60_000; // one minute: fast enough for on-call,
                                    // slow enough that polling does not
                                    // dominate the Tracey daemon's rebuild budget.
const DEBOUNCE_MS = 500;

export function useTraceyCoverage(
  client: TraceyMcpClient,
  repoRoot: string,
  specImpl: string,
  prefix?: string,
) {
  const [status, setStatus] = useState<StatusKPI | null>(null);
  const [untested, setUntested] = useState<UntestedRequirement[]>([]);
  const [stale, setStale] = useState<StaleReference[]>([]);
  const [isLoading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  // Monotonic request id: a late response with an id less than the newest
  // is discarded, preventing a stale refresh from overwriting fresh data.
  const requestIdRef = useRef(0);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refreshInternal = useCallback(async () => {
    const myId = ++requestIdRef.current;
    setLoading(true);
    setError(null);
    try {
      const [s, u, st] = await Promise.all([
        client.getStatus(repoRoot, specImpl),
        client.getUntested(repoRoot, specImpl, prefix),
        client.getStale(repoRoot, specImpl, prefix),
      ]);
      if (myId !== requestIdRef.current) return; // superseded
      setStatus(s);
      setUntested(u);
      setStale(st);
    } catch (e) {
      if (myId !== requestIdRef.current) return;
      setError(e as Error);
    } finally {
      if (myId === requestIdRef.current) setLoading(false);
    }
  }, [client, repoRoot, specImpl, prefix]);

  const refresh = useCallback(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => void refreshInternal(), DEBOUNCE_MS);
  }, [refreshInternal]);

  useEffect(() => {
    void refreshInternal();
    const id = setInterval(() => void refreshInternal(), REFRESH_INTERVAL_MS);
    return () => clearInterval(id);
  }, [refreshInternal]);

  return { status, untested, stale, isLoading, error, refresh };
}

// ---------------------------------------------------------------------------
// apps/dx-console/src/features/release-readiness/VerificationCoveragePanel/VerificationCoveragePanel.tsx
// ---------------------------------------------------------------------------
import React from "react";

const STALE_TOOLTIP =
  "Implementation must be changed to match updated rule text — and ONLY ONCE THAT'S DONE must the code annotation be bumped.";

function tileColor(pct: number): string {
  if (pct >= 90) return "green";
  if (pct >= 70) return "amber";
  return "red";
}

// r[impl dx-console.readiness.verification-coverage-1]
export function VerificationCoveragePanel(props: {
  client: TraceyMcpClient;
  repoRoot: string;
  specImpl: string;
  prefix?: string;
}) {
  const { status, untested, stale, isLoading, error, refresh } = useTraceyCoverage(
    props.client, props.repoRoot, props.specImpl, props.prefix,
  );

  // Three-state derivation: `untested` includes both partially-covered and
  // uncovered requirements. We disambiguate by intersecting with the
  // `uncovered` list, which we fetch lazily per-requirement if the panel
  // is expanded. For KPI purposes we treat everything in `untested` as
  // "not fully verified", which is the release-readiness signal we want.
  const partiallyCovered = untested.filter((u) => u.state === "partially-covered");
  const uncovered = untested.filter((u) => u.state === "uncovered");

  if (error) {
    const isConfigError = /TRACEY_NOT_INSTALLED|exited/.test(error.message);
    return (
      <div role="alert">
        {isConfigError
          ? `Tracey configuration error: ${error.message}. Check that \`tracey\` is on PATH.`
          : `Failed to load coverage for ${props.specImpl}: ${error.message}`}
      </div>
    );
  }

  if (isLoading && !status) return <div>Loading coverage…</div>;

  if (status && untested.length === 0 && stale.length === 0) {
    return <div role="status">All requirements verified. 🎉</div>;
  }

  return (
    <section aria-label="Verification coverage">
      <header>
        <h2>{props.repoRoot} — {props.specImpl}</h2>
        <button onClick={refresh} disabled={isLoading}>Refresh</button>
      </header>

      {status && (
        <div className="kpi-row">
          <div data-testid="kpi-impl" style={{ background: tileColor(status.implPct) }}>
            Implementation: {status.implPct}%
          </div>
          <div data-testid="kpi-verify" style={{ background: tileColor(status.verifyPct) }}>
            Verification: {status.verifyPct}%
          </div>
          <div data-testid="kpi-stale" style={{ background: stale.length > 0 ? "red" : "green" }}>
            Stale references: {stale.length}
          </div>
        </div>
      )}

      <ul data-testid="untested-list">
        {[...partiallyCovered, ...uncovered].map((u) => (
          <li key={u.uid}>
            <code>{u.uid}</code>
            <span data-testid="state-badge">{u.state}</span>
            <button onClick={() => void navigator.clipboard.writeText(u.uid)}>Copy UID</button>
          </li>
        ))}
      </ul>

      {stale.length > 0 && (
        <details open>
          <summary>Stale references ({stale.length})</summary>
          <ul data-testid="stale-list">
            {stale.map((s) => (
              <li key={`${s.uid}:${s.file}:${s.line}`}>
                <code>{s.uid}</code>{" "}
                <span title={STALE_TOOLTIP} data-testid="stale-badge">
                  +{s.annotatedVersion} → +{s.currentVersion}
                </span>
                <span> ({s.file}:{s.line})</span>
              </li>
            ))}
          </ul>
        </details>
      )}
    </section>
  );
}

// ---------------------------------------------------------------------------
// apps/dx-console/src/features/release-readiness/VerificationCoveragePanel/VerificationCoveragePanel.test.tsx
// ---------------------------------------------------------------------------
//
// import { describe, it, expect, vi, beforeEach } from "vitest";
// import { render, screen, waitFor, fireEvent } from "@testing-library/react";
// import { VerificationCoveragePanel } from "./VerificationCoveragePanel";
// import type { TraceyMcpClient } from "./mcpClient";
//
// function makeFakeClient(overrides: Partial<TraceyMcpClient> = {}): TraceyMcpClient {
//   return {
//     getStatus: vi.fn().mockResolvedValue({ spec: "dx-console", impl: "ts", implPct: 95, verifyPct: 82 }),
//     getUntested: vi.fn().mockResolvedValue([
//       { uid: "dx-console.readiness.foo", state: "partially-covered" },
//       { uid: "dx-console.readiness.bar", state: "uncovered" },
//     ]),
//     getStale: vi.fn().mockResolvedValue([
//       { uid: "dx-console.readiness.baz", annotatedVersion: 2, currentVersion: 3, file: "src/x.ts", line: 4 },
//     ]),
//     dispose: vi.fn(),
//     ...overrides,
//   } as unknown as TraceyMcpClient;
// }
//
// describe("VerificationCoveragePanel", () => {
//   beforeEach(() => {
//     // jsdom lacks clipboard by default.
//     Object.assign(navigator, { clipboard: { writeText: vi.fn().mockResolvedValue(undefined) } });
//   });
//
//   // r[verify dx-console.readiness.verification-coverage-1]
//   it("renders the three KPI tiles with the values from the MCP status call", async () => {
//     render(<VerificationCoveragePanel client={makeFakeClient()} repoRoot="/r" specImpl="dx-console/ts" />);
//     expect(await screen.findByTestId("kpi-impl")).toHaveTextContent("95%");
//     expect(screen.getByTestId("kpi-verify")).toHaveTextContent("82%");
//     expect(screen.getByTestId("kpi-stale")).toHaveTextContent("1");
//   });
//
//   // r[verify dx-console.readiness.verification-coverage-2]
//   it("lists every untested requirement returned by the MCP tool", async () => {
//     render(<VerificationCoveragePanel client={makeFakeClient()} repoRoot="/r" specImpl="dx-console/ts" />);
//     expect(await screen.findByTestId("untested-list")).toBeInTheDocument();
//     expect(screen.getAllByTestId("state-badge")).toHaveLength(2);
//   });
//
//   // r[verify dx-console.readiness.verification-coverage-3]
//   it("surfaces stale references with annotated → current versions", async () => {
//     render(<VerificationCoveragePanel client={makeFakeClient()} repoRoot="/r" specImpl="dx-console/ts" />);
//     const badge = await screen.findByTestId("stale-badge");
//     expect(badge).toHaveTextContent("+2 → +3");
//     expect(badge).toHaveAttribute("title", /ONLY ONCE THAT'S DONE/);
//   });
//
//   // r[verify dx-console.readiness.verification-coverage-2]
//   it("copies the requirement UID to the clipboard when the copy button is clicked", async () => {
//     render(<VerificationCoveragePanel client={makeFakeClient()} repoRoot="/r" specImpl="dx-console/ts" />);
//     await screen.findByTestId("untested-list");
//     fireEvent.click(screen.getAllByText("Copy UID")[0]);
//     expect(navigator.clipboard.writeText).toHaveBeenCalledWith("dx-console.readiness.foo");
//   });
//
//   // r[verify dx-console.readiness.verification-coverage-1]
//   it("renders a configuration-error message when Tracey is not installed", async () => {
//     const failing = makeFakeClient({ getStatus: vi.fn().mockRejectedValue(new Error("TRACEY_NOT_INSTALLED")) });
//     render(<VerificationCoveragePanel client={failing} repoRoot="/r" specImpl="dx-console/ts" />);
//     await waitFor(() => expect(screen.getByRole("alert")).toHaveTextContent(/PATH/));
//   });
// });
