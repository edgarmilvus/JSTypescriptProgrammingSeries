/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_detecting_and_resolving_stale_verification_refere.ts
Description: Solutions and Explanations
==========================================
*/

// scripts/spec-bump-workflow.ts
//
// Drives the entire version-bump workflow end to end and captures every
// command's output into the two required baseline documents. The script
// is deliberately a sequence of small named functions rather than a single
// main() so that each step can be re-run in isolation during the demo.

import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from "node:fs";

function sh(cmd: string, args: string[]): string {
  try {
    return execFileSync(cmd, args, { encoding: "utf8" }).trim();
  } catch (err) {
    // Some commands (like `tracey pre-commit` on failure, or a test runner)
    // exit non-zero as a signal; we want their stderr in the transcript.
    const e = err as { stdout?: Buffer | string; stderr?: Buffer | string; status?: number };
    const out = (e.stdout?.toString() ?? "") + (e.stderr?.toString() ?? "");
    return `${out}\n[exit code: ${e.status ?? "unknown"}]`;
  }
}

function writeBaselineEmpty(): void {
  // Step 1: before any change, capture that nothing is stale.
  const stale = sh("tracey", ["query", "stale", "--prefix", "payments.refund."]);
  const content = `# Payments Refund — Stale Baseline (Before Bump)

## \`tracey query stale --prefix payments.refund.\`

\`\`\`
${stale}
\`\`\`

_Expected: empty. No references are stale before the version bump because
no reference's annotated version differs from the spec's declared version._
`;
  writeFileSync("docs/spec/payments-refund-stale-baseline.md", content);
}

function performSpecEdit(): void {
  // Step 2: change the text from 72h to 48h and bump +2 -> +3.
  // In a real workflow this is done in an editor; here we show the exact
  // textual delta the editor must produce, and apply it idempotently.
  const path = "docs/spec/payments.md";
  const original = readFileSync(path, "utf8");
  const updated = original.replace(
    /r\[payments\.refund\.reversal(?:\+2)?\]\n([^\n]*?seventy-two[^\n]*|[\s\S]*?within 72 hours[\s\S]*?)\n/,
    "r[payments.refund.reversal+3]\nRefunds MUST be reversed within 48 hours of the original transaction.\n",
  );
  if (updated === original) {
    throw new Error("Spec edit did not match the expected 72h text. Refusing to proceed.");
  }
  writeFileSync(path, updated);
}

function stageAndPreCommit(): string {
  // Step 3: stage the spec, then run tracey pre-commit. This should PASS
  // because we bumped the version in the same edit.
  sh("git", ["add", "docs/spec/payments.md"]);
  return sh("tracey", ["pre-commit"]);
}

function demonstrateWrongOrder(): string {
  // Step 4: artificially bump ONE annotation in code to +3 *without*
  // updating the code. Tracey's validator will be happy — it only sees
  // a correctly-versioned reference. The lie is invisible to the tool,
  // and this is the point of the exercise.
  const path = "src/payments/refunds/reversal.ts";
  const original = readFileSync(path, "utf8");
  const patched = original.replace(
    /\/\/ r\[impl payments\.refund\.reversal(?:\+\d+)?\]/,
    "// r[impl payments.refund.reversal+3]",
  );
  writeFileSync(path, patched);
  const out = sh("tracey", ["query", "validate"]);
  // Restore the file so the workflow is idempotent.
  writeFileSync(path, original);
  return out;
}

function updateCodeAndTests(): string {
  // Step 5: update the implementation constants and test assertions.
  // The constants live in one place; the tests assert against the constant.
  // We do not re-write the assertions by hand — we change the constant and
  // let the assertions compare to it, so the tests still pass without
  // turning into tautologies.
  const reversal = "src/payments/refunds/reversal.ts";
  const sweeper = "src/payments/jobs/refund-sweeper.ts";
  for (const path of [reversal, sweeper]) {
    const original = readFileSync(path, "utf8");
    const bumped = original
      .replace(/72\s*\*\s*60\s*\*\s*60/g, "48 * 60 * 60")
      .replace(/REVERSAL_WINDOW_HOURS\s*=\s*72/g, "REVERSAL_WINDOW_HOURS = 48")
      .replace(/\/\/ r\[impl payments\.refund\.reversal(?:\+\d+)?\]/,
               "// r[impl payments.refund.reversal+3]"); // bump only AFTER code change
    writeFileSync(path, bumped);
  }
  const tests = [
    "tests/payments/refunds/reversal.test.ts",
    "tests/payments/jobs/refund-sweeper.test.ts",
  ];
  for (const path of tests) {
    const original = readFileSync(path, "utf8");
    const bumped = original.replace(
      /\/\/ r\[verify payments\.refund\.reversal(?:\+\d+)?\]/,
      "// r[verify payments.refund.reversal+3]",
    );
    writeFileSync(path, bumped);
  }
  // Run the tests to prove the code change is real before we trust the
  // annotation bump we just applied.
  return sh("pnpm", ["vitest", "run", "tests/payments"]);
}

function demonstrateTraceyBump(): string {
  // Step 6: revert the manual spec edit, then let tracey bump do it.
  // This proves the tool and the manual workflow converge.
  sh("git", ["checkout", "--", "docs/spec/payments.md"]);
  // Re-apply the text change WITHOUT the version bump, so `tracey bump`
  // has something to detect.
  const path = "docs/spec/payments.md";
  const original = readFileSync(path, "utf8");
  writeFileSync(
    path,
    original.replace(/within 72 hours/, "within 48 hours"),
  );
  sh("git", ["add", "docs/spec/payments.md"]);
  return sh("tracey", ["bump"]);
}

function installPreCommitHook(): void {
  // Step 9: raw git hook. Not `.pre-commit-config.yaml` — the exercise
  // explicitly wants the mechanism visible on disk.
  mkdirSync(".git/hooks", { recursive: true });
  const hook = `#!/bin/sh
# Refuse to commit a spec text change without a matching version bump.
# Without this guard, the traceability graph silently drifts the moment
# a requirement's text is edited but its "+N" suffix is not incremented.
set -e
tracey pre-commit
`;
  writeFileSync(".git/hooks/pre-commit", hook);
  chmodSync(".git/hooks/pre-commit", 0o755);
}

function writePostBumpRecord(): void {
  // Step 8: final validation and empty stale list.
  const validate = sh("tracey", ["query", "validate", "--deny", "warnings"]);
  const stale = sh("tracey", ["query", "stale", "--prefix", "payments.refund."]);
  const content = `# Payments Refund — Post Bump

## \`tracey query validate --deny warnings\`

\`\`\`
${validate}
\`\`\`

## \`tracey query stale --prefix payments.refund.\`

\`\`\`
${stale || "(empty)"}
\`\`\`

_Expected: validator exits 0; stale list is empty; every reference for
\`payments.refund.reversal\` is now annotated \`+3\`._
`;
  writeFileSync("docs/spec/payments-refund-post-bump.md", content);
}

function writeRunbook(): void {
  const runbook = `# Runbook: Spec Version Bump

Changing a requirement's *text* is not a text edit — it is a contract change
that invalidates every code annotation written against the previous version.
Follow these steps in exactly this order.

1. **Edit spec text.** Change the statement, rationale, or title as needed.
   Do not touch the version suffix yet.
2. **Bump the version.** Either manually change \`+2\` to \`+3\`, or run
   \`tracey bump\` which increments every staged requirement whose text
   changed and re-stages the file.
3. **Stage the spec.** \`git add docs/spec/payments.md\`.
4. **Run \`tracey pre-commit\`.** This refuses to proceed if any staged
   requirement changed text without a version bump. It must exit zero
   before you continue.
5. **Update code and tests.** Change the implementation to match the new
   requirement text. Change the tests to assert the new behavior.
6. **Run your test suite.** If a test fails, the code is not yet ready and
   the annotation must not be bumped.
7. **Bump code annotations.** Only now change \`r[impl payments.refund.reversal+2]\`
   to \`+3\` in the implementation and \`r[verify ...+2]\` to \`+3\` in the tests.
   The annotation is a claim that you have reviewed the code against the new
   requirement — it is not a claim about the code's behavior.
8. **Run \`tracey pre-commit\` again.** With annotations staged, this confirms
   the whole changeset is internally consistent.
9. **Run \`tracey query validate --deny warnings\`.** It must exit zero. Any
   warning here means a reference is still stale or broken.
10. **Commit.** The pre-commit hook installed in \`.git/hooks/pre-commit\`
    will run \`tracey pre-commit\` once more as a final guard.

## Why the order matters

Tracey's versioning system can detect that an annotation points at an older
version of a rule. It cannot detect that the author bumped the annotation
without reading the new text and updating the code. The version suffix is
therefore a claim about the author's *review*, not about the code's runtime
behavior. Bumping the annotation before updating the code is a lie that the
tool cannot catch, and it defeats the entire purpose of the version system.

## Cosmetic edits

Changing only a requirement's title still counts as a text change for
versioning purposes — Tracey tracks versions per requirement, not per field.
Bundle cosmetic edits with substantive ones where possible, so that teams do
not spend review budget on a version bump for a typo.
`;
  mkdirSync("docs/runbooks", { recursive: true });
  writeFileSync("docs/runbooks/spec-version-bump.md", runbook);
}

function main(): void {
  writeBaselineEmpty();
  performSpecEdit();
  const preCommitPass = stageAndPreCommit();
  writeFileSync(
    "docs/spec/payments-refund-stale-baseline.md",
    readFileSync("docs/spec/payments-refund-stale-baseline.md", "utf8") +
      `\n\n## After Spec Edit, Before Code Review\n\n\`\`\`\n${preCommitPass}\n\`\`\`\n`,
  );

  const lie = demonstrateWrongOrder();
  writeFileSync(
    "docs/spec/payments-refund-stale-baseline.md",
    readFileSync("docs/spec/payments-refund-stale-baseline.md", "utf8") +
      `\n\n## Wrong-Order Demonstration\n\nBumped \`reversal.ts\` to \`+3\` without updating the code.\n` +
      `Tracey's validator tolerated it, because the tool cannot see the lie.\n\n\`\`\`\n${lie}\n\`\`\`\n`,
  );

  updateCodeAndTests();
  const bumpOut = demonstrateTraceyBump();
  writeFileSync(
    "docs/spec/payments-refund-stale-baseline.md",
    readFileSync("docs/spec/payments-refund-stale-baseline.md", "utf8") +
      `\n\n## \`tracey bump\` Output\n\n\`\`\`\n${bumpOut}\n\`\`\`\n`,
  );

  installPreCommitHook();
  writePostBumpRecord();
  writeRunbook();
}

main();
