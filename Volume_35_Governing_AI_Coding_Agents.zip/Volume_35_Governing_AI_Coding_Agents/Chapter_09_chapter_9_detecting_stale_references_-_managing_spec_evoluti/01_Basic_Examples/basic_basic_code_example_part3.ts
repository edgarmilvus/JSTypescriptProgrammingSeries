/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

// src/intent/livingIntentGraph.ts

/**
 * @file livingIntentGraph.ts
 *
 * Detects stale Tracey annotations after a requirement version bump, and
 * computes an impact report over the Living Intent Graph.
 *
 * "Stale" is defined narrowly: a source annotation references version N of a
 * requirement whose live version in the spec is greater than N.
 */

import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/* ------------------------------------------------------------------ *
 * 1. Public types
 * ------------------------------------------------------------------ */

/**
 * A single requirement version extracted from a spec document.
 * `stem` has no `+N` suffix; `version` is always >= 1.
 */
export interface RequirementVersion {
  readonly stem: string;
  readonly version: number;
  readonly uid: string; // e.g. "billing.invoice.finalize+3"
  readonly statement: string;
  readonly status: 'Approved' | 'Superseded' | 'Draft';
}

/**
 * A single annotation extracted from a source file.
 */
export interface Annotation {
  readonly file: string;
  readonly line: number;
  readonly verb: 'impl' | 'verify' | 'depends' | 'related';
  readonly stem: string;
  readonly version: number;
  readonly raw: string; // the literal comment text, for diagnostics
}

/**
 * A stale annotation and the version it should be pointing at.
 */
export interface StaleReference {
  readonly annotation: Annotation;
  readonly liveVersion: number;
  readonly reason: string;
}

/**
 * One file that is semantically adjacent to the changed requirement.
 */
export interface ImpactedFile {
  readonly file: string;
  readonly similarity: number; // 0..1, cosine similarity
  readonly hasExplicitAnnotation: boolean;
  readonly snippet: string;
}

/**
 * The final report handed to a human reviewer or an AI agent.
 */
export interface ImpactReport {
  readonly requirement: RequirementVersion;
  readonly stale: readonly StaleReference[];
  readonly impacted: readonly ImpactedFile[];
}

/* ------------------------------------------------------------------ *
 * 2. Pure parsing helpers
 * ------------------------------------------------------------------ */

/**
 * Splits a Tracey / StrictDoc UID into its stem and implicit version.
 *
 * - "billing.invoice.finalize"      -> { stem: "billing.invoice.finalize", version: 1 }
 * - "billing.invoice.finalize+3"    -> { stem: "billing.invoice.finalize", version: 3 }
 *
 * Throws on malformed suffixes so that garbage never reaches the graph.
 */
export function parseVersionedUid(uid: string): { stem: string; version: number } {
  const match = /^(?<stem>[^+]+?)(?:\+(?<n>\d+))?$/.exec(uid);
  if (!match?.groups?.stem) {
    throw new Error(`Unparseable requirement UID: ${JSON.stringify(uid)}`);
  }
  const n = match.groups.n;
  const version = n ? Number.parseInt(n, 10) : 1;
  if (!Number.isInteger(version) || version < 1) {
    throw new Error(`Version suffix must be a positive integer in UID ${uid}`);
  }
  return { stem: match.groups.stem, version };
}

/**
 * Extracts every `r[verb uid]` annotation from a single source file.
 * The regex is deliberately greedy on the tail so trailing prose is ignored.
 *
 * Line numbers are 1-based, matching how editors and Tracey report them.
 */
export function extractAnnotations(file: string, source: string): Annotation[] {
  const out: Annotation[] = [];
  const lines = source.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i] ?? '';
    const re = /\br\[(?:(impl|verify|depends|related)\s+)?([A-Za-z0-9_.\-]+(?:\+\d+)?)\]/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(line)) !== null) {
      const verb = (m[1] ?? 'impl') as Annotation['verb'];
      const uid = m[2]!;
      const { stem, version } = parseVersionedUid(uid);
      out.push({ file, line: i + 1, verb, stem, version, raw: m[0] });
    }
  }
  return out;
}

/**
 * Given a flat list of requirement versions, returns the live version
 * (highest version with status === 'Approved') per stem.
 */
export function liveVersions(
  requirements: readonly RequirementVersion[]
): Map<string, RequirementVersion> {
  const live = new Map<string, RequirementVersion>();
  for (const r of requirements) {
    if (r.status !== 'Approved') continue;
    const current = live.get(r.stem);
    if (!current || r.version > current.version) {
      live.set(r.stem, r);
    }
  }
  return live;
}

/* ------------------------------------------------------------------ *
 * 3. The detector — pure, synchronous, fully testable
 * ------------------------------------------------------------------ */

/**
 * Returns every annotation whose version is strictly less than the live
 * version of its stem. An annotation referencing an unknown stem is ignored
 * here; that is a *broken reference*, a different diagnostic.
 */
export function detectStaleReferences(
  annotations: readonly Annotation[],
  requirements: readonly RequirementVersion[]
): StaleReference[] {
  const live = liveVersions(requirements);
  const result: StaleReference[] = [];
  for (const a of annotations) {
    const liveReq = live.get(a.stem);
    if (!liveReq) continue;
    if (a.version < liveReq.version) {
      result.push({
        annotation: a,
        liveVersion: liveReq.version,
        reason:
          `Annotation references +${a.version}, but spec ` +
          `"${liveReq.uid}" is the live version. ` +
          `Update the implementation, then bump the annotation to ` +
          `+${liveReq.version}.`,
      });
    }
  }
  return result;
}

/* ------------------------------------------------------------------ *
 * 4. The impact analyzer — the only part that touches Supabase
 * ------------------------------------------------------------------ */

export interface LivingIntentGraphConfig {
  readonly supabaseUrl: string;
  readonly supabaseAnonKey: string;
  readonly embeddingModel?: string; // default: text-embedding-3-small
}

/**
 * Thin Supabase wrapper. All storage lives in two tables:
 *
 *   requirement_versions(uid PK, stem, version, status, statement, embedding vector(1536))
 *   code_snippets(id PK, file, snippet, embedding vector(1536), requirement_stem)
 *
 * The vector column is indexed with HNSW for fast cosine search.
 */
export class LivingIntentGraph {
  private readonly client: SupabaseClient;

  constructor(private readonly cfg: LivingIntentGraphConfig) {
    this.client = createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {
      auth: { persistSession: false },
    });
  }

  /**
   * Persists a requirement version. Called once per version bump.
   * The RPC `match_code_snippets` is assumed to exist server-side and to
   * perform `<=>` cosine distance search against the HNSW index.
   */
  async upsertRequirement(req: RequirementVersion, embedding: number[]): Promise<void> {
    const { error } = await this.client
      .from('requirement_versions')
      .upsert(
        {
          uid: req.uid,
          stem: req.stem,
          version: req.version,
          status: req.status,
          statement: req.statement,
          embedding,
        },
        { onConflict: 'uid' }
      );
    if (error) throw new Error(`upsertRequirement failed: ${error.message}`);
  }

  /**
   * Returns the top-k most similar code snippets to a requirement's
   * embedding, excluding snippets that already carry a live annotation.
   */
  async findSemanticallyAdjacentCode(
    requirementEmbedding: number[],
    k = 10
  ): Promise<Array<{ file: string; snippet: string; similarity: number }>> {
    const { data, error } = await this.client.rpc('match_code_snippets', {
      query_embedding: requirementEmbedding,
      match_count: k,
    });
    if (error) throw new Error(`match_code_snippets failed: ${error.message}`);
    return (data ?? []).map((row: any) => ({
      file: row.file,
      snippet: row.snippet,
      similarity: 1 - row.distance, // `<=>` returns cosine distance
    }));
  }

  /**
   * Full pipeline: given a requirement that just bumped, produce an
   * ImpactReport combining stale references and semantic neighbours.
   *
   * `annotations` is passed in (rather than read from disk) so the caller
   * can feed in git-staged content, a virtual filesystem overlay, or the
   * output of `git show HEAD:src/...`.
   */
  async analyzeImpact(
    liveRequirement: RequirementVersion,
    embedding: number[],
    annotations: readonly Annotation[],
    allRequirements: readonly RequirementVersion[]
  ): Promise<ImpactReport> {
    const stale = detectStaleReferences(annotations, allRequirements);

    const neighbours = await this.findSemanticallyAdjacentCode(embedding);

    // A snippet is "already annotated" if any live annotation in its file
    // references the requirement stem.
    const annotatedFiles = new Set(
      annotations
        .filter((a) => a.stem === liveRequirement.stem && a.version === liveRequirement.version)
        .map((a) => a.file)
    );

    const impacted: ImpactedFile[] = neighbours.map((n) => ({
      file: n.file,
      similarity: n.similarity,
      hasExplicitAnnotation: annotatedFiles.has(n.file),
      snippet: n.snippet,
    }));

    return { requirement: liveRequirement, stale, impacted };
  }
}
