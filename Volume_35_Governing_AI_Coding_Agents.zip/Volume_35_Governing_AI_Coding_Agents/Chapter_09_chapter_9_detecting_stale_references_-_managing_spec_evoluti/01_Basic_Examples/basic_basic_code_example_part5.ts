/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

// src/intent/livingIntentGraph.test.ts

import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  parseVersionedUid,
  extractAnnotations,
  liveVersions,
  detectStaleReferences,
  type RequirementVersion,
  type Annotation,
} from './livingIntentGraph';

/* ------------------------------------------------------------------ *
 * Fixtures
 * ------------------------------------------------------------------ */

const spec: RequirementVersion[] = [
  {
    stem: 'billing.invoice.finalize',
    version: 1,
    uid: 'billing.invoice.finalize',
    statement: 'MAY finalize without guarantees.',
    status: 'Superseded',
  },
  {
    stem: 'billing.invoice.finalize',
    version: 2,
    uid: 'billing.invoice.finalize+2',
    statement: 'MUST finalize idempotently.',
    status: 'Superseded',
  },
  {
    stem: 'billing.invoice.finalize',
    version: 3,
    uid: 'billing.invoice.finalize+3',
    statement: 'MUST finalize idempotently with async settlement.',
    status: 'Approved',
  },
];

/* ------------------------------------------------------------------ *
 * parseVersionedUid
 * ------------------------------------------------------------------ */

describe('parseVersionedUid', () => {
  it('defaults an unsuffixed UID to version 1', () => {
    expect(parseVersionedUid('billing.invoice.finalize')).toEqual({
      stem: 'billing.invoice.finalize',
      version: 1,
    });
  });

  it('extracts an explicit +N suffix', () => {
    expect(parseVersionedUid('billing.invoice.finalize+3')).toEqual({
      stem: 'billing.invoice.finalize',
      version: 3,
    });
  });

  it('rejects a zero or negative suffix', () => {
    expect(() => parseVersionedUid('billing.invoice.finalize+0')).toThrow();
  });

  it('rejects a malformed UID rather than silently dropping it', () => {
    expect(() => parseVersionedUid('billing invoice finalize')).toThrow();
  });
});

/* ------------------------------------------------------------------ *
 * extractAnnotations
 * ------------------------------------------------------------------ */

describe('extractAnnotations', () => {
  it('extracts one annotation per line, 1-based line numbers', () => {
    const src = [
      '// r[impl billing.invoice.finalize+1]',
      'export function finalize() {}',
      '// r[verify billing.invoice.finalize+3]',
    ].join('\n');

    const anns = extractAnnotations('src/invoiceFinalizer.ts', src);

    expect(anns).toHaveLength(2);
    expect(anns[0]).toMatchObject({
      file: 'src/invoiceFinalizer.ts',
      line: 1,
      verb: 'impl',
      stem: 'billing.invoice.finalize',
      version: 1,
    });
    expect(anns[1]).toMatchObject({
      line: 3,
      verb: 'verify',
      version: 3,
    });
  });

  it('defaults a verb-less annotation to impl', () => {
    const anns = extractAnnotations('f.ts', '// r[billing.invoice.finalize+3]');
    expect(anns[0]?.verb).toBe('impl');
  });

  it('resets lastIndex between lines so multiple matches per file are found', () => {
    const src = [
      '// r[impl a.b+1]',
      '// r[impl c.d+1]',
      '// r[impl e.f+1]',
    ].join('\n');
    const anns = extractAnnotations('f.ts', src);
    expect(anns.map((a) => a.stem)).toEqual(['a.b', 'c.d', 'e.f']);
  });
});

/* ------------------------------------------------------------------ *
 * liveVersions
 * ------------------------------------------------------------------ */

describe('liveVersions', () => {
  it('picks the highest Approved version per stem', () => {
    const live = liveVersions(spec);
    expect(live.get('billing.invoice.finalize')?.uid).toBe(
      'billing.invoice.finalize+3'
    );
  });

  it('ignores Superseded and Draft when computing the live version', () => {
    const live = liveVersions([
      ...spec,
      {
        stem: 'billing.invoice.finalize',
        version: 4,
        uid: 'billing.invoice.finalize+4',
        statement: 'Draft rewrite.',
        status: 'Draft',
      },
    ]);
    expect(live.get('billing.invoice.finalize')?.version).toBe(3);
  });
});

/* ------------------------------------------------------------------ *
 * detectStaleReferences
 * ------------------------------------------------------------------ */

describe('detectStaleReferences', () => {
  it('flags a +1 annotation when the live spec is +3', () => {
    const anns: Annotation[] = extractAnnotations(
      'src/legacyInvoiceFinalizer.ts',
      '// r[impl billing.invoice.finalize+1]\nexport function finalize() {}'
    );
    const stale = detectStaleReferences(anns, spec);
    expect(stale).toHaveLength(1);
    expect(stale[0]?.liveVersion).toBe(3);
    expect(stale[0]?.reason).toMatch(/bump the annotation to \+3/);
  });

  it('does not flag an annotation already on the live version', () => {
    const anns = extractAnnotations(
      'src/invoiceFinalizer.ts',
      '// r[impl billing.invoice.finalize+3]'
    );
    expect(detectStaleReferences(anns, spec)).toHaveLength(0);
  });

  it('ignores annotations referencing unknown stems (broken, not stale)', () => {
    const anns = extractAnnotations('f.ts', '// r[impl billing.invoice.unknown+1]');
    expect(detectStaleReferences(anns, spec)).toHaveLength(0);
  });
});

/* ------------------------------------------------------------------ *
 * LivingIntentGraph.analyzeImpact — with a mocked Supabase client
 * ------------------------------------------------------------------ */

const rpcMock = vi.fn();

vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({
    from: () => ({ upsert: vi.fn().mockResolvedValue({ error: null }) }),
    rpc: rpcMock,
  }),
}));

import { LivingIntentGraph } from './livingIntentGraph';

describe('LivingIntentGraph.analyzeImpact', () => {
  beforeEach(() => {
    rpcMock.mockReset();
  });

  it('merges stale references with semantic neighbours', async () => {
    rpcMock.mockResolvedValueOnce({
      data: [
        { file: 'src/invoiceFinalizer.ts', snippet: 'async finalize(...)', distance: 0.1 },
        { file: 'src/report/InvoiceReport.ts', snippet: 'invoice.total', distance: 0.4 },
      ],
      error: null,
    });

    const graph = new LivingIntentGraph({
      supabaseUrl: 'http://stub',
      supabaseAnonKey: 'stub',
    });

    const anns = extractAnnotations(
      'src/legacyInvoiceFinalizer.ts',
      '// r[impl billing.invoice.finalize+1]'
    );

    const report = await graph.analyzeImpact(
      spec.find((r) => r.status === 'Approved')!,
      new Array(1536).fill(0.01),
      anns,
      spec
    );

    expect(report.stale).toHaveLength(1);
    expect(report.stale[0]?.annotation.file).toBe('src/legacyInvoiceFinalizer.ts');

    expect(report.impacted).toHaveLength(2);
    const invoiceFinalizer = report.impacted.find(
      (f) => f.file === 'src/invoiceFinalizer.ts'
    );
    const reportFile = report.impacted.find(
      (f) => f.file === 'src/report/InvoiceReport.ts'
    );

    // No live annotation in invoiceFinalizer.ts in this fixture — but
    // if one existed, hasExplicitAnnotation would be true.
    expect(invoiceFinalizer?.hasExplicitAnnotation).toBe(false);
    expect(invoiceFinalizer?.similarity).toBeCloseTo(0.9, 5);
    expect(reportFile?.similarity).toBeCloseTo(0.6, 5);
  });
});
