/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part3.ts
Description: Advanced Application Implementation
==========================================
*/

// app/actions/embedding-quota.ts
"use server";

import { createClient } from "@/lib/supabase/server";
import { RateLimiter } from "@/lib/rate-limiter";
import { z } from "zod";

/**
 * Hard cap on persisted embeddings for a free-tier account.
 *
 * @remarks
 * This constant is the single source of truth for the free-tier cap.
 * It is annotated at version `+2` of `quota.embeddings.free`, matching
 * the spec text that lowered the cap from 500 to 250.
 *
 * When the spec text changes again, `tracey query stale` will flag this
 * annotation and demand a re-review before CI passes.
 *
 * @see r[impl quota.embeddings.free+2]
 */
const FREE_TIER_EMBEDDING_CAP = 250;

/**
 * Rolling window for embedding-write rate limiting, in milliseconds.
 *
 * @see r[impl quota.embeddings.write.ratelimit]
 */
const EMBEDDING_WRITE_WINDOW_MS = 60_000;

/**
 * Maximum embedding-write invocations per {@link EMBEDDING_WRITE_WINDOW_MS}.
 *
 * @see r[impl quota.embeddings.write.ratelimit]
 */
const EMBEDDING_WRITE_MAX = 30;

/**
 * Input schema for the embedding-write Server Action.
 *
 * The `accountId` is validated here rather than trusted from the client,
 * because Server Actions are reachable over the network and must treat
 * all inputs as untrusted.
 */
const EmbeddingWriteInput = z.object({
  accountId: z.string().uuid(),
  contentId: z.string().uuid(),
  vector: z.array(z.number()).length(1536),
});

export type EmbeddingWriteResult =
  | { ok: true; embeddingId: string }
  | { ok: false; error: "quota_exceeded" }
  | { ok: false; error: "rate_limited"; retryAfterMs: number }
  | { ok: false; error: "invalid_input" };

/**
 * Persists a single embedding for an account, enforcing both the
 * free-tier storage cap and the per-account rolling write rate limit.
 *
 * @remarks
 * This Server Action is the *only* mutation path permitted into the
 * pgvector-backed store from the recommendation UI. See
 * `stream.action.mutation` — direct SDK writes are forbidden.
 *
 * The two quota checks are ordered deliberately: the cheap in-memory
 * rate-limit check runs before the more expensive Postgres count, so a
 * misbehaving client cannot use the Server Action as a CPU amplifier
 * against the database.
 *
 * @see r[impl stream.action.mutation]
 * @see r[impl quota.embeddings.free+2]
 * @see r[impl quota.embeddings.write.ratelimit]
 */
export async function writeEmbedding(
  rawInput: unknown,
): Promise<EmbeddingWriteResult> {
  // 1. Validate input shape. Server Actions are network-reachable.
  const parsed = EmbeddingWriteInput.safeParse(rawInput);
  if (!parsed.success) {
    return { ok: false, error: "invalid_input" };
  }
  const { accountId, contentId, vector } = parsed.data;

  // 2. Take a slot from the rolling-window rate limiter. If the account
  //    has exhausted its budget, return a structured retry hint rather
  //    than throwing, so the calling React component can render the
  //    Suspense fallback with an actionable message.
  const slot = await RateLimiter.tryConsume({
    key: `embedding-write:${accountId}`,
    windowMs: EMBEDDING_WRITE_WINDOW_MS,
    max: EMBEDDING_WRITE_MAX,
  });
  if (!slot.ok) {
    return { ok: false, error: "rate_limited", retryAfterMs: slot.retryAfterMs };
  }

  // 3. Enforce the free-tier storage cap inside a single transaction so
  //    that the count-check and the insert cannot be interleaved by a
  //    concurrent writer. The spec demands atomicity: a request that
  //    would exceed the cap must not partially commit.
  const supabase = await createClient();
  const result = await supabase.rpc("write_embedding_with_cap", {
    p_account_id: accountId,
    p_content_id: contentId,
    p_vector: vector,
    p_cap: FREE_TIER_EMBEDDING_CAP,
  });

  // 4. Map the Postgres-level outcome onto the structured contract the
  //    spec defines. The database function raises a `quota_exceeded`
  //    error which we translate here for the client.
  if (result.error) {
    if (result.error.message.includes("quota_exceeded")) {
      return { ok: false, error: "quota_exceeded" };
    }
    throw new Error(`embedding write failed: ${result.error.message}`);
  }

  return { ok: true, embeddingId: result.data.id };
}
