/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part4.ts
Description: Advanced Application Implementation
==========================================
*/

// lib/audit/retention.ts
import { cron } from "@/lib/scheduler";

/**
 * Retention window for LLM prompt records, in days.
 *
 * @remarks
 * This constant and the sweeper cadence below are *both* governed by
 * `audit.retention.llm`. When the requirement's text changes, both
 * annotations must be re-reviewed and bumped together — a partial bump
 * that updates only the constant would leave the cadence assertion
 * stale and CI would remain red.
 *
 * @see r[impl audit.retention.llm+2]
 */
export const LLM_PROMPT_RETENTION_DAYS = 30;

/**
 * Registers the hourly retention sweep.
 *
 * The spec requires a cadence of "at least hourly", so this expression
 * is deliberately written as an explicit hour boundary rather than a
 * fuzzy interval, which keeps the intent legible to reviewers.
 *
 * @see r[impl audit.retention.llm+2]
 */
export function registerRetentionSweep(): void {
  // Runs at minute 0 of every hour. Wired to the platform scheduler
  // which is backed by a durable queue so that a missed tick is
  // replayed on recovery.
  cron("0 * * * *", async () => {
    const cutoff = new Date(
      Date.now() - LLM_PROMPT_RETENTION_DAYS * 24 * 60 * 60 * 1000,
    );
    await purgePromptRecordsBefore(cutoff);
  });
}

async function purgePromptRecordsBefore(cutoff: Date): Promise<void> {
  // Deletion is performed in bounded batches to avoid holding long
  // locks on the prompt_records table during business hours.
  const BATCH = 5_000;
  for (;;) {
    const { count } = await deletePromptRecordsBefore(cutoff, BATCH);
    if (count < BATCH) break;
  }
}
