/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part5.tsx
Description: Advanced Application Implementation
==========================================
*/

// app/recommendations/streaming-recommendation.tsx
import { Suspense } from "react";
import { streamRecommendation } from "@/lib/ai/streamer";
import { RecommendationSkeleton } from "./recommendation-skeleton";

/**
 * Client-visible streaming container for recommendations.
 *
 * @remarks
 * The Suspense Boundary declared here is the exact one referenced by
 * `stream.suspense.fallback`. The 80ms minimum-dwell behavior is
 * enforced inside {@link RecommendationSkeleton} through a small
 * mount-time timer, not here — this component only declares the
 * boundary and thereby the fallback contract.
 *
 * @see r[impl stream.suspense.fallback]
 */
export function StreamingRecommendation({
  accountId,
}: {
  accountId: string;
}): JSX.Element {
  return (
    <Suspense fallback={<RecommendationSkeleton minimumDwellMs={80} />}>
      <RecommendationStream accountId={accountId} />
    </Suspense>
  );
}

async function RecommendationStream({
  accountId,
}: {
  accountId: string;
}): Promise<JSX.Element> {
  // This Server Component awaits the streamed recommendation payload.
  // The Suspense Boundary above will keep the skeleton visible until
  // the first chunk arrives.
  const stream = await streamRecommendation({ accountId });
  return <RecommendationList stream={stream} />;
}

function RecommendationList({ stream }: { stream: AsyncIterable<string> }) {
  // In the real implementation this is a client component that reads
  // the AsyncIterable and progressively hydrates list items.
  return <></>;
}
