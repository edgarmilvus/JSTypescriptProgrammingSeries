/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/quota.embeddings.free.test.ts
import { describe, it, expect, vi, beforeEach } from "vitest";
import { writeEmbedding } from "@/app/actions/embedding-quota";
import { mockSupabaseRpc } from "./_helpers/mock-supabase";

/**
 * Vitest suite for the free-tier embedding cap.
 *
 * These tests are annotated at `+2`, matching the current spec text.
 * If the spec bumps to `+3`, all three tests below will be reported as
 * stale by `tracey query stale` and CI will fail until the reviewer
 * either updates the tests or explicitly bumps the annotations.
 *
 * @see r[verify quota.embeddings.free+2]
 */
describe("free-tier embedding cap", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  // r[verify quota.embeddings.free+2]
  it("accepts a write that leaves the account below the cap", async () => {
    mockSupabaseRpc.mockResolvedValueOnce({
      data: { id: "emb-1" },
      error: null,
    });

    const result = await writeEmbedding({
      accountId: "00000000-0000-0000-0000-000000000001",
      contentId: "11111111-1111-1111-1111-111111111111",
      vector: new Array(1536).fill(0),
    });

    expect(result).toEqual({ ok: true, embeddingId: "emb-1" });
  });

  // r[verify quota.embeddings.free+2]
  it("rejects a write that would exceed the cap with quota_exceeded", async () => {
    mockSupabaseRpc.mockResolvedValueOnce({
      data: null,
      error: { message: "quota_exceeded: cap=250 current=250" },
    });

    const result = await writeEmbedding({
      accountId: "00000000-0000-0000-0000-000000000001",
      contentId: "22222222-2222-2222-2222-222222222222",
      vector: new Array(1536).fill(0),
    });

    expect(result).toEqual({ ok: false, error: "quota_exceeded" });
  });

  // r[verify quota.embeddings.free+2]
  it("never writes a partial row when the cap is exceeded", async () => {
    // The database function is responsible for atomicity. From the
    // Server Action's perspective, the observable contract is that a
    // quota error is returned and no embedding id is surfaced; the
    // transactional guarantee lives in the RPC.
    const rpc = mockSupabaseRpc.mockResolvedValueOnce({
      data: null,
      error: { message: "quota_exceeded" },
    });

    await writeEmbedding({
      accountId: "00000000-0000-0000-0000-000000000001",
      contentId: "33333333-3333-3333-3333-333333333333",
      vector: new Array(1536).fill(0),
    });

    // The RPC must be called exactly once — no retry-with-partial-state.
    expect(rpc).toHaveBeenCalledOnce();
  });
});
