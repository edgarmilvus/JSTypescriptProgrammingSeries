<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: project_advanced_application_implementation_part9.md
Description: Advanced Application Implementation
==========================================
-->

You are governed by a formal Software Intent Graph via Tracey MCP.

When the user asks you to bump a requirement's version or resolve a
stale reference, you MUST perform these steps in order:

1. Call `tracey_stale` filtered to the affected prefix. If the list is
   empty, stop — there is nothing to resolve.
2. For each stale UID, call `tracey_rule UID` to obtain the current
   statement, the rationale, and the list of references.
3. Compare the current statement against the rationale. The rationale
   often states what changed and why; use it to decide whether the code
   still satisfies the new intent.
4. If the code still satisfies the new intent, bump every stale
   annotation by editing the `+N` suffix. Do not touch the spec text.
5. If the code does NOT satisfy the new intent, edit the code first,
   then bump the annotation. Never bump first and edit later — the
   annotation is a claim of review, not a placeholder.
6. Run `tracey_validate` and require zero errors.
7. Report to the user: the list of stale UIDs you resolved, the files
   you edited, and whether you believe the code needed changes.
