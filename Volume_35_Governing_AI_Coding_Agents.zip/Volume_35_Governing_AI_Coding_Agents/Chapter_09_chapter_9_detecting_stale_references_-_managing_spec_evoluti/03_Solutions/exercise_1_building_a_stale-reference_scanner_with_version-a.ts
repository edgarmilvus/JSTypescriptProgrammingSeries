/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_building_a_stale-reference_scanner_with_version-a.ts
Description: Solutions and Explanations
==========================================
*/

// ─── src/scanner/types.ts ────────────────────────────────────────────────
export type Verb = "impl" | "verify" | "depends" | "related";

export interface Requirement {
  id: string;          // exact, case-preserved: "CH-001" ≠ "ch-001"
  version: number;     // implicit 1 when no +N suffix is authored
  statement: string;
  file: string;
  line: number;
  prefix: string;      // inferred prefix from the spec
}

export interface Reference {
  file: string;
  line: number;
  column: number;
  prefix: string;
  verb: Verb;
  requirementId: string;
  version: number;
  versionSuffix: boolean;
  raw: string;
}

export type Classification =
  | { kind: "fresh";   ref: Reference; current: number }
  | { kind: "stale";   ref: Reference; current: number; delta: number }
  | { kind: "future";  ref: Reference; current: number; delta: number }
  | { kind: "orphan";  ref: Reference };

export interface ScanReport {
  fresh: Classification[];
  stale: Classification[];
  orphans: Classification[];
  future: Classification[];
  errors: string[]; // unbalanced-ignore, impl-in-test, etc.
  summary: {
    files: number; references: number;
    fresh: number; stale: number; orphans: number; future: number;
  };
}

// ─── src/scanner/spec-parser.ts ──────────────────────────────────────────
import { readFile } from "node:fs/promises";
import { glob } from "glob";
import type { Requirement } from "./types.js";

// Column-0 or blockquote `>` prefix. Prefix is [a-z][a-z0-9]*.
const MD_REQ_RE = /^(?:>\s*)?([a-z][a-z0-9]*)\[([A-Za-z0-9][A-Za-z0-9._-]*)(\+\d+)?\]\s*$/;

const versionOf = (suffix?: string): number =>
  suffix ? parseInt(suffix.slice(1), 10) : 1;

export async function ingestSpecs(specRoot: string): Promise<Requirement[]> {
  const files = await glob(`${specRoot}/**/*.{md,sdoc}`, { nodir: true });
  const out: Requirement[] = [];
  for (const file of files) {
    const text = await readFile(file, "utf8");
    out.push(...(file.endsWith(".sdoc")
      ? parseStrictDoc(file, text)
      : parseMarkdown(file, text)));
  }
  return out;
}

function parseMarkdown(file: string, text: string): Requirement[] {
  const reqs: Requirement[] = [];
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const m = MD_REQ_RE.exec(lines[i]);
    if (!m) continue;
    const [, prefix, id, suffix] = m;

    // Requirement body: until blank line, heading, or next marker.
    const body: string[] = [];
    for (let j = i + 1; j < lines.length; j++) {
      const next = lines[j];
      if (next.trim() === "") break;
      if (/^#{1,6}\s/.test(next)) break;
      if (MD_REQ_RE.test(next)) break;
      body.push(next.startsWith(">") ? next.replace(/^>\s?/, "") : next);
    }

    reqs.push({
      id,
      version: versionOf(suffix),
      statement: body.join("\n").trim(),
      file, line: i + 1, prefix,
    });
  }
  return reqs;
}

function parseStrictDoc(file: string, text: string): Requirement[] {
  const reqs: Requirement[] = [];
  const lines = text.split(/\r?\n/);
  let inReq = false, uid: string | null = null;
  let stmtLines: string[] = [], heredoc = false, startLine = 0;

  const flush = () => {
    if (uid !== null) {
      reqs.push({
        id: uid, version: 1,
        statement: stmtLines.join("\n").trim(),
        file, line: startLine + 1, prefix: "r",
      });
    }
    uid = null; stmtLines = []; heredoc = false;
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (/^\[[A-Z_]+\]\s*$/.test(line)) {
      flush();
      inReq = line.startsWith("[REQUIREMENT]");
      if (inReq) startLine = i;
      continue;
    }
    if (!inReq) continue;
    if (heredoc) { if (line.trim() === "<<<") heredoc = false; else stmtLines.push(line); continue; }
    const u = /^UID:\s*(.+)$/.exec(line);
    if (u) { uid = u[1].trim(); continue; }
    const s = /^STATEMENT:\s*(.*)$/.exec(line);
    if (s) {
      if (s[1].trim() === ">>>") heredoc = true;
      else stmtLines.push(s[1].trim());
    }
  }
  flush();
  return reqs;
}

// ─── src/scanner/source-parser.ts ────────────────────────────────────────
//
// Reference grammar:  PREFIX[ (VERB WS)? REQ (+N)? ]
// The verb is optional and defaults to `impl`.
const REFERENCE_RE =
  /\b([a-z][a-z0-9]*)\[\s*(?:(impl|verify|depends|related)\s+)?([A-Za-z0-9][A-Za-z0-9._-]*)(\+\d+)?\s*\]/g;

function extractComments(text: string, ext: string): { line: number; text: string }[] {
  const out: { line: number; text: string }[] = [];
  const lines = text.split(/\r?\n/);
  const lineMarker = ext === ".py" ? "#" : "//";
  let inBlock = false, blockLine = 0, blockBuf: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (inBlock) {
      const end = line.indexOf("*/");
      if (end >= 0) {
        blockBuf.push(line.slice(0, end));
        out.push({ line: blockLine + 1, text: blockBuf.join("\n") });
        inBlock = false; blockBuf = [];
      } else blockBuf.push(line);
      continue;
    }
    const open = line.indexOf("/*");
    if (open >= 0) {
      const close = line.indexOf("*/", open + 2);
      if (close >= 0) out.push({ line: i + 1, text: line.slice(open + 2, close) });
      else { inBlock = true; blockLine = i; blockBuf = [line.slice(open + 2)]; }
      continue;
    }
    const lm = line.indexOf(lineMarker);
    if (lm >= 0) out.push({ line: i + 1, text: line.slice(lm + lineMarker.length) });
  }
  return out;
}

export interface SourceParseResult { references: Reference[]; errors: string[]; }

export async function ingestSources(
  sourceRoot: string, extensions: string[],
  exclude: string[] = [], testInclude: string[] = [],
): Promise<SourceParseResult> {
  const files = await glob(`${sourceRoot}/**/*{${extensions.join(",")}}`,
                           { nodir: true, ignore: exclude });
  const testFiles = new Set(testInclude.length
    ? await glob(testInclude, { nodir: true }) : []);
  const references: Reference[] = [];
  const errors: string[] = [];

  for (const file of files) {
    const text = await readFile(file, "utf8");
    const comments = extractComments(text, file.slice(file.lastIndexOf(".")));
    const isTest = testFiles.has(file);

    let ignoreBlock = false, ignoreStart = -1, ignoreNext = false;
    for (const { line, text: raw } of comments) {
      const t = raw.trim();
      if (t === "@tracey:ignore-start") {
        if (ignoreBlock) errors.push(`${file}:${line} — nested @tracey:ignore-start`);
        ignoreBlock = true; ignoreStart = line; continue;
      }
      if (t === "@tracey:ignore-end") {
        if (!ignoreBlock) errors.push(`${file}:${line} — @tracey:ignore-end without start`);
        ignoreBlock = false; ignoreStart = -1; continue;
      }
      if (ignoreBlock) continue;
      if (t === "@tracey:ignore-next-line") { ignoreNext = true; continue; }
      if (ignoreNext) { ignoreNext = false; continue; }

      // Blank out backtick spans so `r[...]` inside prose doesn't count.
      const sanitized = raw.replace(/`[^`]*`/g, m => " ".repeat(m.length));

      REFERENCE_RE.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = REFERENCE_RE.exec(sanitized)) !== null) {
        const [rawRef, prefix, verbRaw, id, suffix] = m;
        const verb = (verbRaw as Verb) ?? "impl";
        if (isTest && verb !== "verify") {
          errors.push(`${file}:${line} — '${verb}' in test file (only 'verify' allowed)`);
        }
        references.push({
          file, line, column: m.index, prefix, verb,
          requirementId: id,
          version: suffix ? parseInt(suffix.slice(1), 10) : 1,
          versionSuffix: suffix !== undefined,
          raw: rawRef,
        });
      }
    }
    if (ignoreBlock) errors.push(`${file}:${ignoreStart} — unbalanced @tracey:ignore-start`);
  }
  return { references, errors };
}

// ─── src/scanner/styx-config.ts ──────────────────────────────────────────
import { existsSync } from "node:fs";

type StyxValue = string | StyxValue[] | { [k: string]: StyxValue };

export interface ImplConfig { name: string; include: string[]; exclude: string[]; testInclude: string[]; }
export interface SpecConfig { name: string; include: string[]; impls: ImplConfig[]; }
export interface TraceyConfig { specs: SpecConfig[]; }

function tokenize(text: string): string[] {
  const out: string[] = [];
  for (let i = 0; i < text.length; ) {
    const c = text[i];
    if (/\s/.test(c)) { i++; continue; }
    if (c === "/" && text[i + 1] === "/") { while (i < text.length && text[i] !== "\n") i++; continue; }
    if ("{}()".includes(c)) { out.push(c); i++; continue; }
    let j = i;
    while (j < text.length && !/[\s{}()]/.test(text[j])) j++;
    out.push(text.slice(i, j)); i = j;
  }
  return out;
}

function value(tokens: string[], p: { i: number }): StyxValue {
  if (tokens[p.i] === "{") {
    p.i++;
    const obj: Record<string, StyxValue> = {};
    while (tokens[p.i] !== "}") { const k = tokens[p.i++]; obj[k] = value(tokens, p); }
    p.i++; return obj;
  }
  if (tokens[p.i] === "(") {
    p.i++;
    const arr: StyxValue[] = [];
    while (tokens[p.i] !== ")") arr.push(value(tokens, p));
    p.i++; return arr;
  }
  return tokens[p.i++];
}

export async function loadConfig(path: string): Promise<TraceyConfig | null> {
  if (!existsSync(path)) return null;
  const tokens = tokenize(await readFile(path, "utf8"));
  const p = { i: 0 };
  const top: Record<string, StyxValue> = {};
  while (p.i < tokens.length) { const k = tokens[p.i++]; top[k] = value(tokens, p); }

  const specsRaw = (top["specs"] as StyxValue[] | undefined) ?? [];
  const specs: SpecConfig[] = specsRaw.map((s) => {
    const o = s as Record<string, StyxValue>;
    const implsRaw = (o["impls"] as StyxValue[] | undefined) ?? [];
    return {
      name: String(o["name"] ?? ""),
      include: (o["include"] as string[]) ?? [],
      impls: implsRaw.map((ii) => {
        const io = ii as Record<string, StyxValue>;
        return {
          name: String(io["name"] ?? ""),
          include: (io["include"] as string[]) ?? [],
          exclude: (io["exclude"] as string[]) ?? [],
          testInclude: (io["test_include"] as string[]) ?? [],
        };
      }),
    };
  });
  return { specs };
}

// ─── src/scanner/reconcile.ts ────────────────────────────────────────────
import type { Classification, Reference, Requirement, ScanReport } from "./types.js";

export function reconcile(requirements: Requirement[], references: Reference[]): ScanReport {
  // Case-sensitive lookup — CH-001 and ch-001 are distinct IDs.
  const index = new Map(requirements.map(r => [r.id, r] as const));
  const report: ScanReport = {
    fresh: [], stale: [], orphans: [], future: [], errors: [],
    summary: { files: 0, references: references.length, fresh: 0, stale: 0, orphans: 0, future: 0 },
  };
  const files = new Set<string>();

  for (const ref of references) {
    files.add(ref.file);
    const spec = index.get(ref.requirementId);
    if (!spec) { report.orphans.push({ kind: "orphan", ref }); continue; }

    if (ref.version === spec.version) {
      report.fresh.push({ kind: "fresh", ref, current: spec.version });
    } else if (ref.version < spec.version) {
      report.stale.push({
        kind: "stale", ref, current: spec.version,
        delta: spec.version - ref.version,
      });
    } else {
      report.future.push({
        kind: "future", ref, current: spec.version,
        delta: ref.version - spec.version,
      });
    }
  }
  report.summary.files = files.size;
  report.summary.fresh = report.fresh.length;
  report.summary.stale = report.stale.length;
  report.summary.orphans = report.orphans.length;
  report.summary.future = report.future.length;
  return report;
}

// ─── src/scanner/cli.ts ──────────────────────────────────────────────────
import { Command } from "commander";

const program = new Command();
program
  .option("--root <dir>", "project root", ".")
  .option("--spec-root <dir>", "spec root", "docs/spec")
  .option("--source-root <dir>", "source root", "src")
  .option("--extensions <list>", "comma list", ".ts,.tsx,.rs,.py")
  .option("--json", "machine-readable output")
  .option("--deny-warnings", "future references also fail validate");

const dirOf = (g: string): string => {
  const i = g.indexOf("**");
  return i >= 0 ? g.slice(0, i).replace(/\/+$/, "") : g;
};

async function runAll(): Promise<ScanReport> {
  const o = program.opts();
  const extensions = String(o.extensions).split(",").map((e: string) => e.trim());
  const cfg = await loadConfig(`${o.root}/.config/tracey/config.styx`);

  const specRoots = cfg ? cfg.specs.flatMap(s => s.include) : [o.specRoot];
  const excludes: string[] = [], testIncludes: string[] = [];
  if (cfg) for (const s of cfg.specs) for (const i of s.impls) {
    excludes.push(...i.exclude); testIncludes.push(...i.testInclude);
  }

  const requirements = (await Promise.all(
    specRoots.map(p => ingestSpecs(dirOf(p))),
  )).flat();

  const src = await ingestSources(o.sourceRoot, extensions, excludes, testIncludes);
  const report = reconcile(requirements, src.references);
  report.errors.push(...src.errors);
  return report;
}

program.command("scan").action(async () => {
  const r = await runAll();
  if (program.opts().json) { process.stdout.write(JSON.stringify(r, null, 2)); return; }
  for (const s of r.stale) {
    process.stdout.write(
      `${s.ref.file}:${s.ref.line} — stale reference to ${s.ref.requirementId}\n` +
      `  reference version: +${s.ref.version}\n` +
      `  current version:   +${s.current}\n` +
      `  "Implementation must be changed to match updated rule text — and ONLY ONCE THAT'S DONE must the code annotation be bumped"\n\n`,
    );
  }
  for (const o of r.orphans) process.stdout.write(`${o.ref.file}:${o.ref.line} — unknown requirement '${o.ref.requirementId}'\n`);
  for (const f of r.future) process.stdout.write(`${f.ref.file}:${f.ref.line} — future reference to ${f.ref.requirementId} (+${f.ref.version} vs +${f.current})\n`);
  process.stdout.write(`\n${JSON.stringify(r.summary, null, 2)}\n`);
  for (const e of r.errors) process.stderr.write(`error: ${e}\n`);
});

program.command("validate").action(async () => {
  const r = await runAll();
  const hard = r.errors.length + r.stale.length + r.orphans.length +
               (program.opts().denyWarnings ? r.future.length : 0);
  process.exit(hard > 0 ? 1 : 0);
});

program.parseAsync(process.argv);
