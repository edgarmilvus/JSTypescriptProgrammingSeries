/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_building_a_stale-reference_scanner_with_version-a_part2.ts
Description: Solutions and Explanations
==========================================
*/

// ─── test/scanner.test.ts ────────────────────────────────────────────────
import { describe, it, expect, beforeEach } from "vitest";
import { mkdtempSync, writeFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { ingestSpecs } from "../src/scanner/spec-parser.js";
import { ingestSources } from "../src/scanner/source-parser.js";
import { reconcile } from "../src/scanner/reconcile.js";

function fixture(spec: string, files: Record<string, string>) {
  const root = mkdtempSync(join(tmpdir(), "scan-"));
  mkdirSync(join(root, "docs", "spec"), { recursive: true });
  writeFileSync(join(root, "docs", "spec", "auth.md"), spec);
  for (const [p, c] of Object.entries(files)) {
    mkdirSync(join(root, p, ".."), { recursive: true });
    writeFileSync(join(root, p), c);
  }
  return root;
}

describe("stale-reference scanner", () => {
  it("classifies +1 reference against +2 spec as stale", async () => {
    const root = fixture(
      "r[auth.session-timeout+2]\nNew text.\n",
      { "src/a.ts": "// r[impl auth.session-timeout+1]\n" },
    );
    const reqs = await ingestSpecs(join(root, "docs/spec"));
    const { references } = await ingestSources(
      join(root, "src"), [".ts"], [], [],
    );
    const r = reconcile(reqs, references);
    expect(r.stale).toHaveLength(1);
    expect(r.stale[0].delta).toBe(1);
  });

  it("classifies implicit-version reference to implicit-version spec as fresh", async () => {
    const root = fixture(
      "r[auth.login]\nText.\n",
      { "src/a.ts": "// r[auth.login]\n" },
    );
    const r = reconcile(
      await ingestSpecs(join(root, "docs/spec")),
      (await ingestSources(join(root, "src"), [".ts"])).references,
    );
    expect(r.fresh).toHaveLength(1);
  });

  it("classifies typo'd id as orphan", async () => {
    const root = fixture(
      "r[auth.login]\nText.\n",
      { "src/a.ts": "// r[impl auth.logyn]\n" },
    );
    const r = reconcile(
      await ingestSpecs(join(root, "docs/spec")),
      (await ingestSources(join(root, "src"), [".ts"])).references,
    );
    expect(r.orphans).toHaveLength(1);
  });

  it("classifies +4 reference to +2 spec as future", async () => {
    const root = fixture(
      "r[auth.login+2]\nText.\n",
      { "src/a.ts": "// r[verify auth.login+4]\n" },
    );
    const r = reconcile(
      await ingestSpecs(join(root, "docs/spec")),
      (await ingestSources(join(root, "src"), [".ts"])).references,
    );
    expect(r.future).toHaveLength(1);
    expect(r.future[0].delta).toBe(2);
  });

  it("rejects impl in a test_include-matched file", async () => {
    const root = fixture(
      "r[auth.login]\nText.\n",
      { "tests/x.test.ts": "// r[impl auth.login]\n" },
    );
    const { errors } = await ingestSources(
      join(root, "tests"), [".ts"], [], [`${root}/tests/**/*.test.ts`],
    );
    expect(errors.some(e => /only 'verify' allowed/.test(e))).toBe(true);
  });

  it("hides a stale reference inside a balanced ignore block", async () => {
    const root = fixture(
      "r[auth.login+2]\nNew text.\n",
      { "src/a.ts":
        "// @tracey:ignore-start\n// r[impl auth.login+1]\n// @tracey:ignore-end\n" },
    );
    const { references, errors } = await ingestSources(join(root, "src"), [".ts"]);
    expect(errors).toHaveLength(0);
    expect(references).toHaveLength(0);
  });

  it("reports an unbalanced ignore-start as an error", async () => {
    const root = fixture("r[auth.login]\nText.\n",
      { "src/a.ts": "// @tracey:ignore-start\n// r[impl auth.login]\n" });
    const { errors } = await ingestSources(join(root, "src"), [".ts"]);
    expect(errors.some(e => /unbalanced/.test(e))).toBe(true);
  });
});
