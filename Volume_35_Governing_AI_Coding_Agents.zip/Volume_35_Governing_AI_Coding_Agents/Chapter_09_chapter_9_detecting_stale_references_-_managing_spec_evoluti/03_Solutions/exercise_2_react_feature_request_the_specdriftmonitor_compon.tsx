/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_react_feature_request_the_specdriftmonitor_compon.tsx
Description: Solutions and Explanations
==========================================
*/

// ─── src/monitor/types.ts ────────────────────────────────────────────────
import type { Reference, Verb } from "../scanner/types.js";

/** A stale reference as emitted by Exercise 1's scanner. */
export interface StaleReference {
  readonly id: string;              // stable key: `${file}:${line}:${requirementId}`
  readonly file: string;
  readonly line: number;
  readonly verb: Verb;
  readonly requirementId: string;
  readonly declaredVersion: number;
  readonly currentVersion: number;
  readonly delta: number;           // current - declared, always >= 1
}

/** Full rule metadata, as would be produced by `tracey_rule`. */
export interface RuleDetail {
  readonly id: string;
  readonly title: string;
  readonly statement: string;       // full current statement text
  readonly rationale?: string;
  readonly currentVersion: number;
  readonly specFile: string;        // file that defines the requirement
  readonly specLine: number;
  readonly sourceUrl?: string;
}

export interface SpecDriftMonitorProps {
  readonly staleReferences: ReadonlyArray<StaleReference>;
  readonly rules: Readonly<Record<string, RuleDetail>>;
  readonly onAcknowledge?: (ref: StaleReference) => Promise<void>;
  readonly onJumpToSource?: (ref: StaleReference) => void;
  readonly pollIntervalMs?: number;  // provided only in MCP-bridge hosts
}

// ─── State machine ───────────────────────────────────────────────────────
//
// Invariant: the ONLY way to reach `filtered` is through `loaded`.
// `filtered` always carries the same `references` array as `loaded`;
// it differs only by the non-empty filter criteria that produced it.

export type FilterCriteria =
  | { readonly kind: "none" }
  | { readonly kind: "text"; readonly query: string }
  | { readonly kind: "verbs"; readonly verbs: ReadonlySet<Verb> }
  | { readonly kind: "text+verbs"; readonly query: string; readonly verbs: ReadonlySet<Verb> };

export type MonitorState =
  | { readonly kind: "idle" }
  | { readonly kind: "scanning" }
  | { readonly kind: "loaded";
      readonly references: ReadonlyArray<StaleReference>;
      readonly criteria: { readonly kind: "none" }; }
  | { readonly kind: "filtered";
      readonly references: ReadonlyArray<StaleReference>;
      readonly criteria: Exclude<FilterCriteria, { kind: "none" }>; }
  | { readonly kind: "error"; readonly message: string; readonly cause?: unknown };

// Transitions:
//  mount without polling + non-empty data  →  idle    → loaded
//  mount with polling (pollIntervalMs set) →  idle    → scanning → loaded
//  filter change (query or verbs non-empty)         →  loaded  → filtered
//  filter cleared                                   →  filtered → loaded
//  new data arrives (poll tick or props change)     →  any     → scanning → loaded
//  Promise from poll or context fetch rejects       →  scanning → error
//  ACK_OPTIMISTIC then ACK_ROLLBACK                 →  loaded | filtered → same bucket

// ─── Reducer ─────────────────────────────────────────────────────────────
// The reducer is the ONLY place where references are mutated. Optimistic
// acknowledgements are represented as actions so both the forward and the
// rollback paths are trivially testable.

export type MonitorAction =
  | { type: "SCAN_START" }
  | { type: "SCAN_OK"; references: ReadonlyArray<StaleReference> }
  | { type: "SCAN_FAIL"; message: string; cause?: unknown }
  | { type: "SET_FILTER"; criteria: FilterCriteria }
  | { type: "ACK_OPTIMISTIC"; id: string }
  | { type: "ACK_ROLLBACK"; id: string };

export interface MonitorRuntimeState {
  readonly state: MonitorState;
  /** Ids hidden between ACK_OPTIMISTIC and a settled promise. */
  readonly pendingAck: ReadonlySet<string>;
}

export function monitorReducer(
  s: MonitorRuntimeState,
  a: MonitorAction,
): MonitorRuntimeState {
  switch (a.type) {
    case "SCAN_START":
      return { ...s, state: { kind: "scanning" } };
    case "SCAN_OK": {
      // Preserve filter when new data arrives — do not silently drop
      // a user's filter on a poll tick.
      const crit = currentCriteria(s.state);
      const next: MonitorState = crit.kind === "none"
        ? { kind: "loaded", references: a.references, criteria: { kind: "none" } }
        : { kind: "filtered", references: a.references, criteria: crit };
      return { state: next, pendingAck: s.pendingAck };
    }
    case "SCAN_FAIL":
      return { ...s, state: { kind: "error", message: a.message, cause: a.cause } };
    case "SET_FILTER": {
      const base = s.state;
      if (base.kind !== "loaded" && base.kind !== "filtered") return s;
      const next: MonitorState = a.criteria.kind === "none"
        ? { kind: "loaded", references: base.references, criteria: { kind: "none" } }
        : { kind: "filtered", references: base.references, criteria: a.criteria };
      return { ...s, state: next };
    }
    case "ACK_OPTIMISTIC": {
      const pending = new Set(s.pendingAck); pending.add(a.id);
      return { ...s, pendingAck: pending };
    }
    case "ACK_ROLLBACK": {
      const pending = new Set(s.pendingAck); pending.delete(a.id);
      return { ...s, pendingAck: pending };
    }
  }
}

function currentCriteria(s: MonitorState): FilterCriteria {
  if (s.kind === "loaded") return { kind: "none" };
  if (s.kind === "filtered") return s.criteria;
  return { kind: "none" };
}

// ─── Component outline (skeleton; behavior asserted by tests below) ──────
import React, { useEffect, useMemo, useReducer, useRef } from "react";

export function SpecDriftMonitor(props: SpecDriftMonitorProps): React.ReactElement {
  const [rt, dispatch] = useReducer(monitorReducer, {
    state: { kind: "idle" },
    pendingAck: new Set<string>(),
  });

  // Mount + polling lifecycle → SCAN_START / SCAN_OK / SCAN_FAIL.
  useEffect(() => {
    let cancelled = false;
    const tick = () => {
      dispatch({ type: "SCAN_START" });
      Promise.resolve(props.staleReferences)
        .then(rs => { if (!cancelled) dispatch({ type: "SCAN_OK", references: rs }); })
        .catch((e: unknown) => { if (!cancelled) dispatch({
          type: "SCAN_FAIL",
          message: e instanceof Error ? e.message : String(e),
          cause: e,
        }); });
    };
    tick();
    if (props.pollIntervalMs && props.pollIntervalMs > 0) {
      const h = setInterval(tick, props.pollIntervalMs);
      return () => { cancelled = true; clearInterval(h); };
    }
    return () => { cancelled = true; };
  }, [props.staleReferences, props.pollIntervalMs]);

  const visible = useMemo(() => {
    if (rt.state.kind !== "loaded" && rt.state.kind !== "filtered") return [];
    // ACK_OPTIMISTIC removes rows from the visible set without deleting
    // them from the source array — pure filtering, never mutation.
    return rt.state.references.filter(r => !rt.pendingAck.has(r.id));
  }, [rt]);

  const worstDelta = useMemo(
    () => visible.reduce((m, r) => Math.max(m, r.delta), 0),
    [visible],
  );
  const orphans = useMemo(
    () => visible.filter(r => !props.rules[r.requirementId]).length,
    [visible, props.rules],
  );

  // Row keyboard navigation: j/k move, Enter expands, Escape collapses.
  // `useKeyboardNav` must early-return when the active element is inside an
  // <input>, <textarea>, or [contenteditable=true].
  const nav = useKeyboardNavigation(visible.length);
  const containerRef = useRef<HTMLDivElement>(null);

  if (rt.state.kind === "idle" || rt.state.kind === "scanning") {
    return <Spinner aria-label="Scanning…" />;
  }
  if (rt.state.kind === "error") {
    return <ErrorBanner message={rt.state.message} />;
  }
  if (visible.length === 0) {
    // Distinct visual treatment from the loading state — see rendering
    // contract in the exercise. The empty state is a confirmation, not a
    // placeholder; loading is a spinner, empty is a checkmark.
    return <EmptyState reason={rt.state.kind === "filtered" ? "filter" : "clean"} />;
  }

  return (
    <section ref={containerRef} aria-label="Spec drift monitor">
      <DriftHeader
        totalStale={visible.length}
        totalOrphans={orphans}
        worstDelta={worstDelta}
      />
      <FilterBar
        onTextChange={q => dispatch({
          type: "SET_FILTER",
          criteria: q.trim() === "" ? { kind: "none" } : { kind: "text", query: q },
        })}
        onVerbChange={verbs => dispatch({
          type: "SET_FILTER",
          criteria: verbs.size === 0 ? { kind: "none" } : { kind: "verbs", verbs },
        })}
      />
      <ol role="listbox">
        {visible.map((r, i) => (
          <DriftRow
            key={r.id}
            ref={r}
            rule={props.rules[r.requirementId]}
            focused={nav.focusedIndex === i}
            onExpand={nav.setExpanded}
            onJumpToSource={props.onJumpToSource}
            onAcknowledge={async () => {
              dispatch({ type: "ACK_OPTIMISTIC", id: r.id });
              try {
                await props.onAcknowledge?.(r);
              } catch {
                dispatch({ type: "ACK_ROLLBACK", id: r.id });
              }
            }}
          />
        ))}
      </ol>
    </section>
  );
}

// Stubs — implemented separately; signature is the contract.
declare function Spinner(p: { "aria-label": string }): React.ReactElement;
declare function ErrorBanner(p: { message: string }): React.ReactElement;
declare function EmptyState(p: { reason: "filter" | "clean" }): React.ReactElement;
declare function DriftHeader(p: {
  totalStale: number; totalOrphans: number; worstDelta: number;
}): React.ReactElement;
declare function FilterBar(p: {
  onTextChange: (q: string) => void;
  onVerbChange: (v: ReadonlySet<Verb>) => void;
}): React.ReactElement;
declare function DriftRow(p: {
  ref: StaleReference;
  rule: RuleDetail | undefined;
  focused: boolean;
  onExpand: (i: number | null) => void;
  onJumpToSource?: (r: StaleReference) => void;
  onAcknowledge: () => Promise<void>;
}): React.ReactElement;
declare function useKeyboardNavigation(length: number): {
  focusedIndex: number | null;
  setExpanded: (i: number | null) => void;
};

// ─── Vitest component-test OUTLINE (not implemented) ─────────────────────
//
// describe("<SpecDriftMonitor />")
//
//  1. renders distinct empty state when staleReferences is [] and never
//     shows the scanning spinner
//  2. renders exactly one row for a single stale reference, with the
//     `path:line — verb — id (+declared → +current)` line visible
//  3. flags multi-version drift by marking the header's `worst drift`
//     indicator with the maximum delta, keeping older deltas in-row
//  4. keeps the empty state when the filter matches nothing, and renders
//     the "0 of N" counter in the header
//  5. renders every row when the filter matches everything, i.e. the
//     filtered set is identical to the loaded set
//  6. removes a row from the visible list on ACK_OPTIMISTIC and does not
//     restore it when the onAcknowledge promise resolves
//  7. restores the row on ACK_ROLLBACK when onAcknowledge rejects, and
//     re-renders it at its original index within the sorted list
//  8. navigating with `j` reaches the last row without wrapping, and
//     pressing `j` again is a no-op; `k` symmetric; Enter expands the
//     focused row; Escape collapses it
//
// Each of (6) and (7) is asserted by dispatching the raw reducer action
// against a synthetic state and asserting the pendingAck set — the reducer
// is the unit under test for the acknowledgement contract, because the
// promise is the only source of nondeterminism and should be isolated in
// a `waitFor` block of the integration test.
