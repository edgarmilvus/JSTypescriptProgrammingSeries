/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_impact_analysis_over_the_living_intent_graph.ts
Description: Solutions and Explanations
==========================================
*/

// ─── src/impact/types.ts ─────────────────────────────────────────────────
import type { Reference, Requirement, Verb } from "../scanner/types.js";

export type NodeKind = "Spec" | "Requirement" | "SourceFile" | "Annotation";
export type EdgeKind =
  | "Defines" | "Annotates" | "SameUnit"
  | "Verb:impl" | "Verb:verify" | "Verb:depends" | "Verb:related";

export interface GraphNode {
  readonly id: string;
  readonly kind: NodeKind;
  // SourceFile has `path`; Requirement has `requirement`; Annotation has `ref`.
  readonly path?: string;
  readonly requirement?: Requirement;
  readonly ref?: Reference;
  readonly unit?: string; // enclosing function/class for annotations
}

export interface GraphEdge {
  readonly from: string;
  readonly to: string;
  readonly kind: EdgeKind;
}

export interface IntentGraph {
  readonly nodes: ReadonlyMap<string, GraphNode>;
  readonly edges: ReadonlyArray<GraphEdge>;
  readonly annotationsByRequirement: ReadonlyMap<string, ReadonlyArray<string>>;
  readonly annotationsByUnit: ReadonlyMap<string, ReadonlyArray<string>>;
}

export interface SpecChange {
  readonly requirementId: string;
  readonly fromVersion: number;
  readonly toVersion: number;
  readonly summary: string;
}

export interface ImpactEntry {
  readonly ref: Reference;
  readonly verb: Verb;
  readonly requirementId: string;
  readonly versionBefore: number | null; // null = new requirement
  readonly versionAfter: number;
  readonly distance: number;             // 1 = direct, 2+ = transitive
  readonly via: "requirement-change" | "same-unit-depends";
}

export interface ImpactReport {
  readonly changed: ReadonlyArray<SpecChange>;
  readonly directlyAffected: ReadonlyArray<ImpactEntry>;
  readonly transitivelyAffected: ReadonlyArray<ImpactEntry>;
  readonly unverifiedAfterChange: ReadonlyArray<string>;
  readonly unimplementedAfterChange: ReadonlyArray<string>;
  readonly summaryCounts: {
    readonly files: number;
    readonly annotations: number;
    readonly tests: number;
  };
}

// ─── src/impact/graph.ts ─────────────────────────────────────────────────
import { createHash } from "node:crypto";

const reqId = (rid: string) => `req:${rid}`;
const fileId = (path: string) => `file:${path}`;
const annId = (ref: Reference) =>
  `ann:${createHash("sha1")
    .update(`${ref.file}:${ref.line}:${ref.prefix}:${ref.verb}:${ref.requirementId}`)
    .digest("hex").slice(0, 12)}`;
const unitId = (path: string, unit: string | undefined) =>
  unit ? `unit:${path}#${unit}` : `unit:${path}#`;

export function buildIntentGraph(
  requirements: ReadonlyArray<Requirement>,
  references: ReadonlyArray<Reference>,
  unitResolver: (ref: Reference) => string | undefined,
): IntentGraph {
  const nodes = new Map<string, GraphNode>();
  const edges: GraphEdge[] = [];
  const annByReq = new Map<string, string[]>();
  const annByUnit = new Map<string, string[]>();

  for (const r of requirements) {
    nodes.set(reqId(r.id), { id: reqId(r.id), kind: "Requirement", requirement: r });
  }

  for (const ref of references) {
    const id = annId(ref);
    const unit = unitResolver(ref);
    nodes.set(id, { id, kind: "Annotation", ref, unit });
    edges.push({ from: id, to: reqId(ref.requirementId), kind: `Verb:${ref.verb}` });

    if (!nodes.has(fileId(ref.file))) {
      nodes.set(fileId(ref.file), { id: fileId(ref.file), kind: "SourceFile", path: ref.file });
    }
    edges.push({ from: id, to: fileId(ref.file), kind: "Annotates" });

    const u = unitId(ref.file, unit);
    if (!nodes.has(u)) {
      nodes.set(u, { id: u, kind: "SourceFile", path: ref.file, unit });
    }
    edges.push({ from: id, to: u, kind: "SameUnit" });

    (annByReq.get(ref.requirementId) ?? annByReq.set(ref.requirementId, []).get(ref.requirementId)!)
      .push(id);
    (annByUnit.get(u) ?? annByUnit.set(u, []).get(u)!).push(id);
  }

  return {
    nodes, edges,
    annotationsByRequirement: annByReq,
    annotationsByUnit: annByUnit,
  };
}

// ─── src/impact/normalize.ts ─────────────────────────────────────────────
// A normalized statement form used to detect text changes. Whitespace
// reflow must not count as a semantic change.
export function normalizeStatement(text: string): string {
  return text
    .split(/\r?\n/)
    .map(l => l.trim())
    .join(" ")
    .replace(/\s+/g, " ")
    .replace(/[.?!]+$/, "")
    .toLowerCase();
}

// ─── src/impact/impact.ts ────────────────────────────────────────────────
const VERB_ORDER: Record<Verb, number> = { depends: 0, impl: 1, verify: 2, related: 3 };

export function computeImpact(
  graph: IntentGraph,
  changes: ReadonlyArray<SpecChange>,
): ImpactReport {
  const changedById = new Map(changes.map(c => [c.requirementId, c] as const));
  const direct: ImpactEntry[] = [];
  const transitive: ImpactEntry[] = [];
  const seen = new Set<string>(); // annotation ids already placed

  // --- Direct pass ---
  // `depends` annotations that cite a changed requirement are directly
  // affected and — critically — establish a one-hop `depends` traversal
  // budget for the same code unit.
  const dependsUnitsToExpand = new Set<string>();

  for (const change of changes) {
    const annIds = graph.annotationsByRequirement.get(change.requirementId) ?? [];
    for (const aid of annIds) {
      const node = graph.nodes.get(aid);
      if (!node || !node.ref) continue;
      seen.add(aid);
      const verb = node.ref.verb;

      // `related` is transitive-only, by design.
      if (verb === "related") {
        transitive.push(entry(node.ref, change, 2, "requirement-change"));
        continue;
      }
      direct.push(entry(node.ref, change, 1, "requirement-change"));
      if (verb === "depends" && node.unit !== undefined) {
        dependsUnitsToExpand.add(unitId(node.ref.file, node.unit));
      }
    }
  }

  // --- Transitive pass: same-unit fan-out through one `depends` hop ---
  // Design decision: propagate through exactly one depends edge, then stop.
  // This caps blast-radius reports at a size a reviewer can actually read.
  for (const unit of dependsUnitsToExpand) {
    const anns = graph.annotationsByUnit.get(unit) ?? [];
    for (const aid of anns) {
      if (seen.has(aid)) continue;
      const node = graph.nodes.get(aid);
      if (!node || !node.ref) continue;
      seen.add(aid);
      transitive.push(entry(node.ref, /* change is contextual */ {
        requirementId: node.ref.requirementId,
        fromVersion: 0,
        toVersion: Math.max(0, node.ref.version - 1),
        summary: "(unchanged; pulled in by same-unit depends)",
      }, 2, "same-unit-depends"));
    }
  }

  const sortDirect = (a: ImpactEntry, b: ImpactEntry) =>
    (VERB_ORDER[a.verb] - VERB_ORDER[b.verb])
    || a.ref.file.localeCompare(b.ref.file)
    || a.ref.line - b.ref.line;
  const sortTransitive = (a: ImpactEntry, b: ImpactEntry) =>
    (a.distance - b.distance)
    || (VERB_ORDER[a.verb] - VERB_ORDER[b.verb])
    || a.ref.file.localeCompare(b.ref.file)
    || a.ref.line - b.ref.line;

  direct.sort(sortDirect);
  transitive.sort(sortTransitive);

  // --- Coverage regression ---
  const { unverified, unimplemented } = computeCoverageRegression(graph, changes);

  const files = new Set([...direct, ...transitive].map(e => e.ref.file));
  const tests = [...direct, ...transitive].filter(e =>
    e.ref.verb === "verify" ||
    /(?:^|\/)(?:tests?|__tests__)\//.test(e.ref.file) ||
    /\.(?:test|spec)\./.test(e.ref.file),
  ).length;

  return {
    changed: changes,
    directlyAffected: direct,
    transitivelyAffected: transitive,
    unverifiedAfterChange: unverified,
    unimplementedAfterChange: unimplemented,
    summaryCounts: {
      files: files.size,
      annotations: direct.length + transitive.length,
      tests,
    },
  };
}

function entry(
  ref: Reference,
  change: SpecChange,
  distance: number,
  via: ImpactEntry["via"],
): ImpactEntry {
  return {
    ref,
    verb: ref.verb,
    requirementId: ref.requirementId,
    versionBefore: change.fromVersion === 0 ? null : change.fromVersion,
    versionAfter: change.toVersion,
    distance,
    via,
  };
}

/**
 * Coverage regression: which requirements had at least one FRESH impl /
 * verify annotation BEFORE this change-set, and have none AFTER it?
 * Requirements that are themselves new in this change-set are excluded —
 * a regression must be a loss, not an absence.
 */
function computeCoverageRegression(
  graph: IntentGraph,
  changes: ReadonlyArray<SpecChange>,
): { unverified: string[]; unimplemented: string[] } {
  const newInThisChange = new Set(changes.filter(c => c.fromVersion === 0).map(c => c.requirementId));
  const futureVersion = new Map(changes.map(c => [c.requirementId, c.toVersion] as const));

  const unverified: string[] = [];
  const unimplemented: string[] = [];

  for (const [rid, node] of graph.nodes) {
    if (node.kind !== "Requirement" || !node.requirement) continue;
    if (newInThisChange.has(rid)) continue;

    const annIds = graph.annotationsByRequirement.get(rid) ?? [];
    let hadFreshVerify = false, hadFreshImpl = false;
    let willHaveVerify = false, willHaveImpl = false;

    const afterVersion = futureVersion.get(rid) ?? node.requirement.version;

    for (const aid of annIds) {
      const a = graph.nodes.get(aid);
      if (!a || !a.ref) continue;
      if (a.ref.verb === "verify" && a.ref.version === node.requirement.version) hadFreshVerify = true;
      if (a.ref.verb === "impl"   && a.ref.version === node.requirement.version) hadFreshImpl = true;
      if (a.ref.verb === "verify" && a.ref.version === afterVersion) willHaveVerify = true;
      if (a.ref.verb === "impl"   && a.ref.version === afterVersion) willHaveImpl = true;
    }
    if (hadFreshVerify && !willHaveVerify) unverified.push(rid);
    if (hadFreshImpl   && !willHaveImpl)   unimplemented.push(rid);
  }
  unverified.sort(); unimplemented.sort();
  return { unverified, unimplemented };
}

// ─── src/impact/format.ts ────────────────────────────────────────────────
const ACTION: Record<Verb, string> = {
  impl: "re-review",
  verify: "re-verify",
  depends: "re-review (hard obligation)",
  related: "spot-check",
};

export function toMarkdown(r: ImpactReport): string {
  const lines: string[] = [];
  lines.push(`## Impact report — ${r.changed.length} requirement(s) changed`);
  lines.push("");
  lines.push("| Location | Action | Verb | Requirement | Version | Dist |");
  lines.push("|---|---|---|---|---|---|");
  for (const e of [...r.directlyAffected, ...r.transitivelyAffected]) {
    lines.push(
      `| \`${e.ref.file}:${e.ref.line}\` | ${ACTION[e.verb]} | ${e.verb} ` +
      `| ${e.requirementId} | +${e.versionBefore ?? "–"} → +${e.versionAfter} | ${e.distance} |`,
    );
  }
  if (r.unverifiedAfterChange.length) {
    lines.push(""); lines.push("### Requirements left unverified");
    for (const u of r.unverifiedAfterChange) lines.push(`- ${u}`);
  }
  if (r.unimplementedAfterChange.length) {
    lines.push(""); lines.push("### Requirements left unimplemented");
    for (const u of r.unimplementedAfterChange) lines.push(`- ${u}`);
  }
  return lines.join("\n");
}
