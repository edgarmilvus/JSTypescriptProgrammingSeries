/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_impact_analysis_over_the_living_intent_graph_part2.ts
Description: Solutions and Explanations
==========================================
*/

// ─── test/impact.test.ts (fixture + expectations) ────────────────────────
//
// Fixture: 8 source files, 3 spec files, ~24 annotations.
//
// describe("computeImpact")
//   1. single changed requirement → { direct, transitive } split
//   2. three changed requirements → merged report, sorting stable
//   3. depends chain: policy.ts depends on expiry; the impl on creation
//      in the same unit appears at distance 2 via `same-unit-depends`
//   4. `related` reference to a changed requirement appears ONLY in
//      transitivelyAffected, never direct
//   5. unverifiedAfterChange matches hand-computed expected set
//   6. ordering stable under shuffling the annotations array before
//      building the graph (sort keys: verb, path, line)
//   7. new requirement in change-set is excluded from coverage-regression
//      lists even when it has no verify annotation
//   8. --format=md output round-trips: a Markdown parse of the emitted
//      table yields the same (file, line, action) triples
