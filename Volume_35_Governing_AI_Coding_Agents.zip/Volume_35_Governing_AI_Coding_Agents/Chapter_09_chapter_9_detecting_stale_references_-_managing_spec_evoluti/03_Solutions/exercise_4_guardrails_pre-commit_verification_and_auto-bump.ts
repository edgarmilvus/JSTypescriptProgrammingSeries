/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_guardrails_pre-commit_verification_and_auto-bump.ts
Description: Solutions and Explanations
==========================================
*/

// ─── src/guardrail/git.ts ────────────────────────────────────────────────
import { execFileSync } from "node:child_process";

export function git(args: string[], cwd: string): string {
  return execFileSync("git", args, { cwd, encoding: "utf8" });
}

export function gitQuiet(args: string[], cwd: string): string | null {
  try { return git(args, cwd); } catch { return null; }
}

export function stagedFiles(cwd: string): string[] {
  const out = git(["diff", "--cached", "--name-only", "--diff-filter=ACM"], cwd);
  return out.split("\n").map(l => l.trim()).filter(Boolean);
}

/** Content of a path in a revision. `HEAD` for the base, `:0:` for index. */
export function show(revision: string, path: string, cwd: string): string | null {
  return gitQuiet(["show", `${revision}:${path}`], cwd);
}

export function workingTreeDirtyFor(path: string, cwd: string): boolean {
  const out = git(["diff", "--name-only", "--", path], cwd);
  return out.trim().length > 0;
}

export function stage(paths: string[], cwd: string): void {
  if (paths.length) git(["add", "--", ...paths], cwd);
}

// ─── src/guardrail/normalize.ts ──────────────────────────────────────────
/**
 * Requirement statements are frequently reflowed without semantic change.
 * A line-based diff produces false positives on every reflow. We therefore
 * compare a *normalized* form: per-line trim, whitespace collapse, and
 * trailing-punctuation stripping — lowercased for good measure.
 */
export function normalizeStatement(text: string): string {
  return text
    .split(/\r?\n/)
    .map(l => l.trim())
    .join(" ")
    .replace(/\s+/g, " ")
    .replace(/[.?!]+$/, "")
    .toLowerCase();
}

// ─── src/guardrail/spec-edit.ts ──────────────────────────────────────────
import { createHash } from "node:crypto";

export interface RequirementSnapshot {
  readonly id: string;
  readonly version: number;
  readonly statement: string;
  readonly statementHash: string;
  /** [startLine, endLine] in the source file, inclusive. */
  readonly lineRange: readonly [number, number];
  /** The raw marker line (which we rewrite on bump). */
  readonly markerLine: number;
}

const MD_REQ_RE = /^(?:>\s*)?([a-z][a-z0-9]*)\[([A-Za-z0-9][A-Za-z0-9._-]*)(\+\d+)?\]\s*$/;

export function snapshotMarkdown(text: string): RequirementSnapshot[] {
  const lines = text.split(/\r?\n/);
  const snaps: RequirementSnapshot[] = [];
  for (let i = 0; i < lines.length; i++) {
    const m = MD_REQ_RE.exec(lines[i]);
    if (!m) continue;
    const [, , id, suffix] = m;
    const body: string[] = [];
    let j = i + 1;
    for (; j < lines.length; j++) {
      const n = lines[j];
      if (n.trim() === "") break;
      if (/^#{1,6}\s/.test(n)) break;
      if (MD_REQ_RE.test(n)) break;
      body.push(n.startsWith(">") ? n.replace(/^>\s?/, "") : n);
    }
    const stmt = body.join("\n").trim();
    snaps.push({
      id,
      version: suffix ? parseInt(suffix.slice(1), 10) : 1,
      statement: stmt,
      statementHash: createHash("sha1").update(normalizeStatement(stmt)).digest("hex"),
      lineRange: [i, j - 1],
      markerLine: i,
    });
    i = j - 1;
  }
  return snaps;
}

/** Rewrite one requirement's marker line to carry an explicit `+N`. */
export function setVersion(
  text: string, snap: RequirementSnapshot, newVersion: number,
): string {
  const lines = text.split(/\r?\n/);
  const old = lines[snap.markerLine];
  const m = MD_REQ_RE.exec(old)!;
  const [, prefix, id, suffix] = m;
  const bang = old.startsWith("> ") ? "> " : old.startsWith(">") ? ">" : "";
  const rest = old.slice(bang.length).trimEnd();
  // Preserve any trailing comment after the closing bracket.
  const trail = rest.slice(rest.indexOf("]") + 1);
  lines[snap.markerLine] =
    `${bang}${prefix}[${id}+${newVersion}]${trail}`;
  return lines.join("\n");
}

// ─── src/guardrail/orchestrator.ts ───────────────────────────────────────
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { loadConfig } from "../scanner/styx-config.js";
import { ingestSpecs } from "../scanner/spec-parser.js";
import { ingestSources } from "../scanner/source-parser.js";
import { reconcile } from "../scanner/reconcile.js";
import { buildIntentGraph } from "../impact/graph.js";
import { computeImpact } from "../impact/impact.js";
import type { SpecChange } from "../impact/types.js";

export interface Violation {
  readonly file: string;
  readonly requirementId: string;
  readonly headVersion: number;
  readonly indexVersion: number;
  readonly requiredMin: number;
  readonly diffPreview: string;
}

export interface BumpSummary {
  readonly file: string;
  readonly requirementId: string;
  readonly fromVersion: number;
  readonly toVersion: number;
  readonly staleAfterBump: ReadonlyArray<{ verb: string; file: string; line: number }>;
}

/***********************************************************************
 *  Mode 1: pre-commit
 *  Fails with a non-zero exit when a requirement's statement text
 *  changed in the index but the version suffix did not increase.
 ***********************************************************************/
export function preCommit(cwd: string, specGlobs: string[]): { violations: Violation[]; ok: boolean } {
  const violations: Violation[] = [];
  const files = stagedFiles(cwd).filter(f => matchesAny(f, specGlobs));
  for (const file of files) {
    const head = show("HEAD", file, cwd) ?? "";
    const index = show(":0", file, cwd);
    if (index === null) continue;

    const headSnaps = new Map(snapshotMarkdown(head).map(s => [s.id, s] as const));
    const indexSnaps = snapshotMarkdown(index);

    for (const cur of indexSnaps) {
      const prev = headSnaps.get(cur.id);
      if (!prev) continue; // new requirement — no bump obligation
      if (prev.statementHash === cur.statementHash) continue; // text unchanged

      // Text changed. Version must be strictly greater.
      if (cur.version > prev.version) continue;
      violations.push({
        file,
        requirementId: cur.id,
        headVersion: prev.version,
        indexVersion: cur.version,
        requiredMin: prev.version + 1,
        diffPreview: previewDelta(prev.statement, cur.statement).slice(0, 80),
      });
    }
  }
  return { violations, ok: violations.length === 0 };
}

/***********************************************************************
 *  Mode 2: bump
 *  Rewrites the index in place to increment each changed requirement's
 *  version by one, re-stages the file, and returns an advisory of the
 *  source annotations that will become stale.
 ***********************************************************************/
export function bump(
  cwd: string,
  specGlobs: string[],
  sourceRoot: string,
  extensions: string[],
): { summaries: BumpSummary[]; refused: string[] } {
  const files = stagedFiles(cwd).filter(f => matchesAny(f, specGlobs));
  const summaries: BumpSummary[] = [];
  const refused: string[] = [];

  for (const file of files) {
    // Fail-safe: refuse to bump a file whose working tree is dirty.
    if (workingTreeDirtyFor(file, cwd)) { refused.push(file); continue; }

    const head = show("HEAD", file, cwd) ?? "";
    const index = show(":0", file, cwd) ?? "";
    const headSnaps = new Map(snapshotMarkdown(head).map(s => [s.id, s] as const));
    let rewritten = index;
    const bumpsForFile: BumpSummary[] = [];

    // Rewrite from the bottom up so earlier snapshots' line indices stay valid.
    const snapshots = snapshotMarkdown(index).sort((a, b) => b.markerLine - a.markerLine);
    for (const cur of snapshots) {
      const prev = headSnaps.get(cur.id);
      if (!prev || prev.statementHash === cur.statementHash) continue;
      if (cur.version > prev.version) continue; // already bumped by the author

      const next = cur.version + 1;
      rewritten = setVersion(rewritten, cur, next);
      bumpsForFile.push({
        file, requirementId: cur.id,
        fromVersion: cur.version, toVersion: next,
        staleAfterBump: [],
      });
    }

    if (bumpsForFile.length === 0) continue;
    writeFileSync(join(cwd, file), rewritten);
    stage([file], cwd);
    summaries.push(...bumpsForFile);
  }

  // Advisory: build a synthetic impact report to list annotations that
  // will become stale as a result of the bumps we just performed.
  const changes: SpecChange[] = summaries.map(s => ({
    requirementId: s.requirementId,
    fromVersion: s.fromVersion,
    toVersion: s.toVersion,
    summary: "auto-bump",
  }));

  if (changes.length) {
    void (async () => {
      const requirements = await ingestSpecs(sourceRoot);
      const src = await ingestSources(sourceRoot, extensions);
      // NB: in a real implementation this is awaited at the top level; the
      // synchronous signature is a simplification for readability here.
      const graph = buildIntentGraph(requirements, src.references, () => undefined);
      const impact = computeImpact(graph, changes);
      for (const s of summaries) {
        const hits = impact.directlyAffected
          .filter(e => e.requirementId === s.requirementId)
          .map(e => ({ verb: e.verb, file: e.ref.file, line: e.ref.line }));
        (s as { staleAfterBump: typeof hits }).staleAfterBump = hits;
      }
    })();
  }

  return { summaries, refused };
}

// ─── src/guardrail/report.ts ─────────────────────────────────────────────
export function renderBumpSummary(summaries: BumpSummary[]): string {
  const out: string[] = [];
  out.push(`Bumped ${summaries.length} requirement${summaries.length === 1 ? "" : "s"}:`);
  for (const s of summaries) {
    out.push(`  ${s.requirementId}  ${s.fromVersion} → ${s.toVersion}`);
    out.push(`    Because its statement text changed.`);
    const byVerb = new Map<string, { file: string; line: number }[]>();
    for (const a of s.staleAfterBump) {
      (byVerb.get(a.verb) ?? byVerb.set(a.verb, []).get(a.verb)!)
        .push({ file: a.file, line: a.line });
    }
    if (byVerb.size) {
      out.push(`    After this bump, ${s.staleAfterBump.length} annotations will become stale:`);
      for (const [verb, list] of byVerb) {
        for (const { file, line } of list) out.push(`      ${verb}  (${file}:${line})`);
      }
    }
    out.push(`    Run \`tracey query stale\` after committing to review them.`);
  }
  return out.join("\n");
}

function previewDelta(a: string, b: string): string {
  const words = (s: string) => new Set(s.toLowerCase().split(/\W+/).filter(Boolean));
  const wa = words(a), wb = words(b);
  const added = [...wb].filter(w => !wa.has(w));
  const removed = [...wa].filter(w => !wb.has(w));
  return `+[${added.join(" ")}] -[${removed.join(" ")}]`;
}

function matchesAny(path: string, globs: string[]): boolean {
  return globs.some(g => {
    // Minimal glob translator for `docs/spec/**/*.md` style patterns.
    const rx = new RegExp("^" + g
      .replace(/[.+^${}()|[\]\\]/g, "\\$&")
      .replace(/\*\*\//g, "(?:.*/)?")
      .replace(/\*\*/g, ".*")
      .replace(/\*/g, "[^/]*") + "$");
    return rx.test(path);
  });
}

// ─── bin/tracey-guard.ts ─────────────────────────────────────────────────
import { Command } from "commander";
const p = new Command();
p.option("--root <dir>", "project root", ".")
 .option("--config <path>", "config path")
 .option("--json", "machine-readable output");

p.command("pre-commit").action(async () => {
  const o = p.opts();
  const cfg = await loadConfig(o.config ?? `${o.root}/.config/tracey/config.styx`);
  const globs = cfg?.specs.flatMap(s => s.include) ?? ["docs/spec/**/*.md"];
  const { violations, ok } = preCommit(o.root, globs);
  for (const v of violations) {
    process.stderr.write(
      `${v.file}: ${v.requirementId}\n` +
      `  HEAD version:  ${v.headVersion}\n` +
      `  Index version: ${v.indexVersion}  ← must be at least ${v.requiredMin}\n` +
      `  Text change: ${v.diffPreview}\n\n`,
    );
  }
  process.exit(ok ? 0 : 1);
});

p.command("bump").action(async () => {
  const o = p.opts();
  const cfg = await loadConfig(o.config ?? `${o.root}/.config/tracey/config.styx`);
  const globs = cfg?.specs.flatMap(s => s.include) ?? ["docs/spec/**/*.md"];
  const inc = cfg?.specs.flatMap(s => s.impls).flatMap(i => i.include) ?? ["src/**/*.ts"];
  const { summaries, refused } = bump(o.root, globs, inc[0] ?? "src", [".ts"]);
  if (refused.length) {
    process.stderr.write(
      `refusing to bump: working tree has unstaged changes for the following specs:\n` +
      refused.map(f => `  ${f}`).join("\n") + "\n",
    );
    process.exit(2);
  }
  process.stdout.write(renderBumpSummary(summaries) + "\n");
});

p.parseAsync(process.argv);
