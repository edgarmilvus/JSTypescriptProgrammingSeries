/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_guardrails_pre-commit_verification_and_auto-bump_part4.ts
Description: Solutions and Explanations
==========================================
*/

// ─── test/guardrail.test.ts ──────────────────────────────────────────────
import { describe, it, expect, beforeEach } from "vitest";
import { mkdtempSync, writeFileSync, mkdirSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { preCommit, bump, renderBumpSummary } from "../src/guardrail/orchestrator.js";

function gitInit(): string {
  const root = mkdtempSync(join(tmpdir(), "guard-"));
  execFileSync("git", ["init", "-q", "-b", "main"], { cwd: root });
  execFileSync("git", ["config", "user.email", "t@t"], { cwd: root });
  execFileSync("git", ["config", "user.name", "t"], { cwd: root });
  mkdirSync(join(root, "docs/spec"), { recursive: true });
  mkdirSync(join(root, "src"), { recursive: true });
  return root;
}

const SPEC = "r[auth.session-timeout+1]\nSessions expire after 30 minutes.\n";

describe("guardrail", () => {
  let root: string;
  beforeEach(() => {
    root = gitInit();
    writeFileSync(join(root, "docs/spec/auth.md"), SPEC);
    writeFileSync(join(root, "src/a.ts"), "// r[impl auth.session-timeout+1]\n");
    execFileSync("git", ["add", "."], { cwd: root });
    execFileSync("git", ["commit", "-q", "-m", "init"], { cwd: root });
  });

  it("pre-commit fails when statement text changed without a bump", () => {
    writeFileSync(join(root, "docs/spec/auth.md"),
      "r[auth.session-timeout+1]\nSessions expire after 15 minutes.\n");
    execFileSync("git", ["add", "docs/spec/auth.md"], { cwd: root });
    const { ok, violations } = preCommit(root, ["docs/spec/**/*.md"]);
    expect(ok).toBe(false);
    expect(violations[0].requirementId).toBe("auth.session-timeout");
    expect(violations[0].requiredMin).toBe(2);
  });

  it("pre-commit succeeds when version was bumped", () => {
    writeFileSync(join(root, "docs/spec/auth.md"),
      "r[auth.session-timeout+2]\nSessions expire after 15 minutes.\n");
    execFileSync("git", ["add", "docs/spec/auth.md"], { cwd: root });
    const { ok } = preCommit(root, ["docs/spec/**/*.md"]);
    expect(ok).toBe(true);
  });

  it("bump increments versions and re-stages the file", () => {
    writeFileSync(join(root, "docs/spec/auth.md"),
      "r[auth.session-timeout+1]\nSessions expire after 15 minutes.\n");
    execFileSync("git", ["add", "docs/spec/auth.md"], { cwd: root });
    const { summaries, refused } = bump(root, ["docs/spec/**/*.md"], "src", [".ts"]);
    expect(refused).toHaveLength(0);
    expect(summaries[0].toVersion).toBe(2);
    const staged = execFileSync("git",
      ["diff", "--cached", "--name-only"], { cwd: root, encoding: "utf8" });
    expect(staged).toContain("docs/spec/auth.md");
  });

  it("bump refuses when the working tree has unstaged changes to a spec file", () => {
    writeFileSync(join(root, "docs/spec/auth.md"),
      "r[auth.session-timeout+1]\nSessions expire after 15 minutes.\n");
    execFileSync("git", ["add", "docs/spec/auth.md"], { cwd: root });
    writeFileSync(join(root, "docs/spec/auth.md"),
      "r[auth.session-timeout+1]\nSessions expire after 12 minutes.\n");
    const { refused } = bump(root, ["docs/spec/**/*.md"], "src", [".ts"]);
    expect(refused).toContain("docs/spec/auth.md");
  });

  it("advisory lists the expected number of stale annotations", () => {
    writeFileSync(join(root, "docs/spec/auth.md"),
      "r[auth.session-timeout+1]\nSessions expire after 15 minutes.\n");
    execFileSync("git", ["add", "docs/spec/auth.md"], { cwd: root });
    const { summaries } = bump(root, ["docs/spec/**/*.md"], "src", [".ts"]);
    const msg = renderBumpSummary(summaries);
    expect(msg).toContain("auth.session-timeout");
    expect(msg).toContain("2 → 3");
    expect(msg).toMatch(/annotations? will become stale/);
  });
});
