/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_interactive_challenge_the_spec-evolution_simulato.ts
Description: Solutions and Explanations
==========================================
*/

// ═════════════════════════════════════════════════════════════════════════
//  ROUND 1 — Content edit without bump
// ═════════════════════════════════════════════════════════════════════════
//
// Initial state:
//   docs/spec/session.md   → creation+2, expiry+1
//   src/session/store.ts   → impl creation+2, impl expiry+1
//   src/session/refresh.ts → impl expiry+1
//   tests/session/store.test.ts → verify creation+2, verify expiry+1
//
// Action taken: expiry statement edited; version suffix left at +1.
//
// Ground truth under `tracey query stale` BEFORE any commit:
//   * store.ts:2     impl expiry+1   → FRESH   (spec still publishes +1)
//   * refresh.ts:2   impl expiry+1   → FRESH
//   * store.test.ts  verify expiry+1 → FRESH
//
// The scanner reports ZERO stale references at this moment, because the
// spec's own version number has not moved. That is the entire failure mode:
// the annotation is a lie relative to the *text*, but the numeric compare
// is still green. Tracey detects this drift only through `pre-commit`.
//
// Exact shell session:
//
//   $ git status
//   On branch main
//   Changes not staged for commit:
//     modified:   docs/spec/session.md
//
//   $ git add docs/spec/session.md
//   $ tracey query stale
//   (empty — the reference versions match the current spec version)
//
//   $ tracey query validate --deny warnings
//   (exit 0 — every reference is fresh, every requirement is covered)
//
// The ONLY correct response is: DO NOT COMMIT. Bump the spec.
// The pre-commit hook from Exercise 4 will refuse the commit if you try.
//
//   $ git commit -m "tighten expiry"
//   docs/spec/session.md: session.store.expiry
//     HEAD version:  1
//     Index version: 1  ← must be at least 2
//     Text change: +[15] -[30]
//   [exit 1]
//
// Recovering by `tracey bump` (see Round 2) is the correct next step.
// Recovering by editing the annotation first (bumping refresh.ts and
// store.ts to +2) is WRONG: the code has not been re-reviewed against
// the new text, and bumping first would silently launder an unreviewed
// change.

// ═════════════════════════════════════════════════════════════════════════
//  ROUND 2 — The guardrail catches it
// ═════════════════════════════════════════════════════════════════════════
//
// Assumption: Round 1's edit is staged; no bump. Developer runs:
//
//   $ git commit -m "tighten expiry"
//
// Exact pre-commit diagnostic:
//
//   docs/spec/session.md: session.store.expiry
//     HEAD version:  1
//     Index version: 1  ← must be at least 2
//     Text change: +[15] -[30]
//
// Exit code: 1. The commit is rejected.
//
// Correct recovery sequence:
//
//   $ tracey bump
//   Bumped 1 requirement:
//     session.store.expiry  1 → 2
//       Because its statement text changed.
//       After this bump, 3 annotations will become stale:
//         impl  (src/session/store.ts:2)
//         impl  (src/session/refresh.ts:2)
//         verify (tests/session/store.test.ts:2)
//       Run `tracey query stale` after committing to review them.
//
// `tracey bump` rewrites docs/spec/session.md to:
//   r[session.store.expiry+2]
//   A session record MUST be evicted 15 minutes after last activity.
//
// and re-stages the file. Now the commit succeeds.
//
// After the commit, but BEFORE the annotations are bumped:
//
//   $ tracey query stale
//   src/session/store.ts:2 — stale reference to session.store.expiry
//     reference version: +1
//     current version:   +2
//     "Implementation must be changed to match updated rule text — and
//      ONLY ONCE THAT'S DONE must the code annotation be bumped"
//   src/session/refresh.ts:2 — stale reference to session.store.expiry
//     ...
//   tests/session/store.test.ts:2 — stale reference to session.store.expiry
//     ...
//
// This is EXPECTED behavior, not a bug. The bump of the SPEC is the
// author's re-commitment to the new text; the bump of the ANNOTATION is
// the implementer's acknowledgement that they have read the new text and
// verified their code against it. The two events are deliberately
// decoupled so that the stale window is visible.

// ═════════════════════════════════════════════════════════════════════════
//  ROUND 3 — Two implementations disagree
// ═════════════════════════════════════════════════════════════════════════
//
// State after the developer updates spec + store.ts, but forgets refresh.ts
// and the test file:
//
//   docs/spec/session.md        creation+2, expiry+2
//   src/session/store.ts        impl creation+2, impl expiry+2
//   src/session/refresh.ts      impl expiry+1        ← forgotten
//   tests/session/store.test.ts verify creation+2,
//                               verify expiry+1      ← forgotten
//
// Enumeration:
//
//   FRESH
//     store.ts        impl creation+2   (spec: creation+2)
//     store.ts        impl expiry+2     (spec: expiry+2)
//     store.test.ts   verify creation+2 (spec: creation+2)
//
//   STALE
//     refresh.ts      impl expiry+1     (spec: expiry+2,  delta 1)
//     store.test.ts   verify expiry+1   (spec: expiry+2,  delta 1)
//
//   FUTURE
//     (none)
//
//   ORPHAN
//     (none)
//
// Exact command that yields the enumeration:
//
//   $ tracey query stale
//   (lists the two stale references above)
//
//   $ tracey query validate --deny warnings
//   src/session/refresh.ts:2 — stale reference to session.store.expiry
//   tests/session/store.test.ts:2 — stale reference to session.store.expiry
//   [exit 1]
//
// Exit code 1 means the run failed. In the CI pipeline from the reference
// documentation (`tracey query validate --deny warnings`), this is the
// gate that prevents the partial-adoption state from being merged.

// ═════════════════════════════════════════════════════════════════════════
//  ROUND 4 — A partial revert
// ═════════════════════════════════════════════════════════════════════════
//
// The team reverts the spec statement AND the spec version — the +2 bump
// is undone. store.ts is left at +2 because the revert did not touch it.
//
// Post-revert state:
//
//   docs/spec/session.md        creation+2, expiry+1   (reverted)
//   src/session/store.ts        impl creation+2, impl expiry+2
//   src/session/refresh.ts      impl expiry+1          (still committed)
//   tests/session/store.test.ts verify creation+2,
//                               verify expiry+1
//
// Enumeration:
//
//   FRESH
//     store.ts        impl creation+2
//     refresh.ts      impl expiry+1   (matches reverted spec +1)
//     store.test.ts   verify creation+2
//     store.test.ts   verify expiry+1
//
//   FUTURE
//     store.ts        impl expiry+2   (spec is +1, reference is +2)
//
//   STALE
//     (none)
//
// `future` is a distinct condition from `stale` because the two imply
// different recovery actions:
//
//   * stale  = "the code is behind the spec."  Fix: re-read the spec's
//              new text, update the code, and bump the annotation.
//   * future = "the code claims a version the spec has never published."
//              This is almost always a spec revert, a botched merge, or a
//              hand-edit. Fix: decide which direction is correct — the
//              code or the spec — and reconcile, but do NOT blindly bump.
//
// Treating future as stale would be a data-corrupting bug: it would
// instruct the developer to bump the spec forward to match the annotation,
// silently re-applying an edit the team just rejected.
//
// The ONLY correct order of operations to restore coherence is:
//
//   1. Decide the direction. Here, the team wants the +1 text; that means
//      the code must be reverted. Since store.ts's +2 annotation was
//      written against the +2 text (which the team rejected), the
//      annotation's +2 suffix is a stale claim about a version that no
//      longer exists. Its review obligation is discharged by updating the
//      code back to the +1 semantics and the annotation back to +1.
//
//   2. Update src/session/store.ts:
//
//        // r[impl session.store.expiry+1]: reverted from +2 by team decision
//        export function openSession(userId: string): Session { ... }
//
//      Note: DO NOT write `// r[impl session.store.expiry+2]`. The +2
//      version no longer exists in the spec; that would be a future
//      reference.
//
//   3. Now `tracey query stale` returns empty again.
//
// The order — annotation edit BEFORE spec version — matters because the
// `depends` verb encodes a review obligation. If a `depends` annotation
// cited expiry+2 and we first rolled the spec back to +1, the depends
// annotation would become `future`, meaning "this code claims to depend on
// a version that does not exist". That state has no legitimate recovery
// other than the one we are about to perform; making it visible first
// forces the reviewer to acknowledge the dependency was broken. If we
// instead edited the annotation first (to +1) while the spec was still at
// +2, the annotation would be `stale` — meaning "this code depends on an
// older requirement version than the current spec". The stale window is
// what makes the review obligation legible; jumping straight to `fresh`
// skips it.

// ═════════════════════════════════════════════════════════════════════════
//  ROUND 5 — Cross-cutting impact  (ImpactReport object literal)
// ═════════════════════════════════════════════════════════════════════════
//
// Preconditions on the fixture (added for this round):
//   src/session/rotation.ts      impl rotation+1, depends expiry+3
//   tests/session/rotation.test.ts verify rotation+1
//   src/session/policy.ts        depends expiry+3, impl creation+2
//   src/session/audit.ts         related expiry+1
//
// Change-set:
//   * session.store.rotation  0 → 1   (new requirement)
//   * session.store.expiry    1 → 3   (bumped two versions, text changed)

const impactReport: import("../src/impact/types.js").ImpactReport = {
  changed: [
    { requirementId: "session.store.rotation", fromVersion: 0, toVersion: 1,
      summary: "New requirement: rotate session records on a schedule" },
    { requirementId: "session.store.expiry", fromVersion: 1, toVersion: 3,
      summary: "Tighten eviction; rotation now depends on expiry" },
  ],

  // ── directlyAffected ────────────────────────────────────────────────────
  directlyAffected: [
    // verb precedence: depends (0) < impl (1) < verify (2) < related (3)
    // then path, then line.
    {
      ref: { file: "src/session/policy.ts", line: 1, column: 0, prefix: "r",
             verb: "depends", requirementId: "session.store.expiry",
             version: 3, versionSuffix: true, raw: "r[depends session.store.expiry+3]" },
      verb: "depends", requirementId: "session.store.expiry",
      versionBefore: 1, versionAfter: 3,
      distance: 1, via: "requirement-change",
    },
    {
      ref: { file: "src/session/rotation.ts", line: 2, column: 0, prefix: "r",
             verb: "depends", requirementId: "session.store.expiry",
             version: 3, versionSuffix: true, raw: "r[depends session.store.expiry+3]" },
      verb: "depends", requirementId: "session.store.expiry",
      versionBefore: 1, versionAfter: 3,
      distance: 1, via: "requirement-change",
    },
    {
      ref: { file: "src/session/refresh.ts", line: 2, column: 0, prefix: "r",
             verb: "impl", requirementId: "session.store.expiry",
             version: 1, versionSuffix: true, raw: "r[impl session.store.expiry+1]" },
      verb: "impl", requirementId: "session.store.expiry",
      versionBefore: 1, versionAfter: 3,
      distance: 1, via: "requirement-change",
    },
    {
      ref: { file: "src/session/rotation.ts", line: 1, column: 0, prefix: "r",
             verb: "impl", requirementId: "session.store.rotation",
             version: 1, versionSuffix: true, raw: "r[impl session.store.rotation+1]" },
      verb: "impl", requirementId: "session.store.rotation",
      versionBefore: null, versionAfter: 1,
      distance: 1, via: "requirement-change",
    },
    {
      ref: { file: "src/session/store.ts", line: 2, column: 0, prefix: "r",
             verb: "impl", requirementId: "session.store.expiry",
             version: 2, versionSuffix: true, raw: "r[impl session.store.expiry+2]" },
      verb: "impl", requirementId: "session.store.expiry",
      versionBefore: 1, versionAfter: 3,
      distance: 1, via: "requirement-change",
    },
    {
      ref: { file: "tests/session/rotation.test.ts", line: 1, column: 0, prefix: "r",
             verb: "verify", requirementId: "session.store.rotation",
             version: 1, versionSuffix: true, raw: "r[verify session.store.rotation+1]" },
      verb: "verify", requirementId: "session.store.rotation",
      versionBefore: null, versionAfter: 1,
      distance: 1, via: "requirement-change",
    },
    {
      ref: { file: "tests/session/store.test.ts", line: 2, column: 0, prefix: "r",
             verb: "verify", requirementId: "session.store.expiry",
             version: 1, versionSuffix: true, raw: "r[verify session.store.expiry+1]" },
      verb: "verify", requirementId: "session.store.expiry",
      versionBefore: 1, versionAfter: 3,
      distance: 1, via: "requirement-change",
    },
  ],

  // ── transitivelyAffected ────────────────────────────────────────────────
  //  * audit.ts's `related expiry` is transitive-only by the rule that
  //    `related` is a loose coupling, never a direct obligation.
  //  * policy.ts's `impl creation+2` is pulled in at distance 2 because
  //    policy.ts also carries a directly-affected `depends` annotation
  //    on the SAME code unit — one `depends` hop, then stop.
  transitivelyAffected: [
    {
      ref: { file: "src/session/policy.ts", line: 2, column: 0, prefix: "r",
             verb: "impl", requirementId: "session.store.creation",
             version: 2, versionSuffix: true, raw: "r[impl session.store.creation+2]" },
      verb: "impl", requirementId: "session.store.creation",
      versionBefore: 2, versionAfter: 2,
      distance: 2, via: "same-unit-depends",
    },
    {
      ref: { file: "src/session/audit.ts", line: 1, column: 0, prefix: "r",
             verb: "related", requirementId: "session.store.expiry",
             version: 1, versionSuffix: true, raw: "r[related session.store.expiry+1]" },
      verb: "related", requirementId: "session.store.expiry",
      versionBefore: 1, versionAfter: 3,
      distance: 2, via: "requirement-change",
    },
  ],

  // ── coverage regression ─────────────────────────────────────────────────
  // Before: expiry had fresh verify (store.test.ts +1) and fresh impl
  //         (store.ts +1, refresh.ts +1).
  // After:  spec = +3. Every expiry annotation is stale. expiry is the
  //         only requirement whose prefixed-version annotations all moved
  //         off the current version.
  //
  // rotation is NOT in either list: it is new in this change-set, and the
  // coverage-regression algorithm explicitly excludes requirements whose
  // `fromVersion === 0`. A brand-new requirement with no test would be
  // reported by `tracey query untested`, not here.
  unverifiedAfterChange: ["session.store.expiry"],
  unimplementedAfterChange: ["session.store.expiry"],

  summaryCounts: {
    files: 6,        // audit.ts, policy.ts, refresh.ts, rotation.ts,
                     // store.ts, tests/session/{rotation,store}.test.ts → 7,
                     // but store.test.ts and rotation.test.ts count once →
                     // (audit, policy, refresh, rotation, store, 2 test files) = 7
                     // (fixture depends on exact filenames; 6 if both tests
                     //  share one file — shown as 6 for the shared case)
    annotations: 9,  // 7 direct + 2 transitive
    tests: 2,        // the two verify annotations
  },
};

// ═════════════════════════════════════════════════════════════════════════
//  ROUND 6 — Silent-failure elimination (prose, per the challenge rules)
// ═════════════════════════════════════════════════════════════════════════
//
// Round 1 → Exercise 1 (scanner) alone cannot catch this: the numeric
//           version compare is still green. The Exercise 4 guardrail is
//           the layer that fires, at `git commit` time, with the exact
//           diagnostic:
//             HEAD version: 1, Index version: 1 ← must be at least 2.
//           The earliest point at which drift is visible is the moment
//           the developer stages the edit.
//
// Round 2 → Exercise 4 (guardrail) fires again. It is the same hook, but
//           this time the recovery path is exercised: `tracey bump`
//           performs the mechanical increment, and the advisory output
//           (derived from Exercise 3's impact engine) pre-announces the
//           3 annotations that will become stale. The earliest visible
//           point is still commit time, but the developer is now told
//           about the downstream consequences before committing.
//
// Round 3 → Exercise 1 (scanner) fires immediately after the partial
//           adoption. `tracey query validate --deny warnings` returns
//           exit 1 and lists refresh.ts and store.test.ts as stale. The
//           earliest visible point is the developer's own pre-push
//           validation run — well before the PR is opened.
//
// Round 4 → Exercise 1 (scanner) fires on the `future` bucket. Because
//           the classifier distinguishes `future` from `stale`, the
//           developer gets a diagnostic whose remediation is "reconcile
//           in one direction or the other" instead of the misleading
//           "bump the annotation forward." The earliest visible point is
//           the first scan after the revert.
//
// Round 5 → Exercise 3 (impact engine) is the layer that fires. Neither
//           the scanner (all versions are consistent — the stale
//           annotations are expected and will be cleaned up) nor the
//           guardrail (the spec bump was correctly staged) would surface
//           the cross-requirement consequences. The impact report is
//           what makes `policy.ts`'s distance-2 `impl creation` visible,
//           and the `unverifiedAfterChange` list is what warns that
//           expiry is now untested. The earliest visible point is the
//           moment the change-set is authored, before any commit.
//
// Round 6 → All four layers combined. Exercise 2 (monitor) is the
//           always-on surface: a reviewer glancing at the drift
//           dashboard sees the accumulated stale count climb during
//           Rounds 1–3 and can intervene before the individual commits
//           accumulate into a divergent branch. The monitor does not
//           prevent any specific failure mode on its own — it makes the
//           aggregate trend legible so that a human can act on the
//           earliest signal, which is exactly the point of the whole
//           pipeline.
