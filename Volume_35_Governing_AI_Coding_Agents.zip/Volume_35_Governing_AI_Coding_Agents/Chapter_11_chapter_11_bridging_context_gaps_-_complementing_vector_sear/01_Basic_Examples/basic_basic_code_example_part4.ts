/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// src/billing/trial-manager.ts

/**
 * Transition a tenant from TRIALING to RESTRICTED when the trial has
 * fully elapsed without a payment method having been attached.
 *
 * @param subscription - The subscription record read from the database.
 * @returns The mutated subscription after the state transition.
 */
// r[impl BILLING-TRIAL-EXPIRY]
export function expireTrialIfDue(subscription: Subscription): Subscription {
  if (subscription.state !== SubscriptionState.Trialing) {
    return subscription;
  }

  const elapsedMs = Date.now() - subscription.trialStartedAt.getTime();
  const trialMs = 14 * 24 * 60 * 60 * 1000;
  const hasPaymentMethod = subscription.paymentMethodId !== null;

  if (elapsedMs >= trialMs && !hasPaymentMethod) {
    subscription.state = SubscriptionState.Restricted;
    // Cancellation handled elsewhere; see convertTrial below for the
    // complementary transition.
  }

  return subscription;
}

/**
 * Convert an in-trial subscription to ACTIVE when a payment method lands.
 * Cancels the pending expiry job so that the trial cannot later flip the
 * subscription into RESTRICTED.
 */
// r[impl BILLING-TRIAL-CONVERT]
export function convertTrial(
  subscription: Subscription,
  tokenizedPaymentMethod: string,
  scheduler: JobScheduler,
): Subscription {
  if (subscription.state !== SubscriptionState.Trialing) {
    throw new Error("convertTrial called on non-TRIALING subscription");
  }
  subscription.paymentMethodId = tokenizedPaymentMethod;
  subscription.state = SubscriptionState.Active;
  scheduler.cancel(`trial.expiry.${subscription.id}`);
  return subscription;
}
