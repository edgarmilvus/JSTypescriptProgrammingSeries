/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part7.ts
Description: Basic Code Example
==========================================
*/

// src/bridge/intent-graph-bridge.ts

/**
 * A chunk of source code returned by the vector search layer, together
 * with its similarity score and its file path. Chunks are opaque to the
 * vector layer — they carry no understanding of requirements.
 */
export interface VectorChunk {
  filePath: string;
  content: string;
  score: number;
}

/**
 * A minimal, deterministic view of a requirement, as returned by the
 * Tracey MCP `tracey_rule` tool. Every field here is normative.
 */
export interface ResolvedRequirement {
  uid: string;
  title: string;
  statement: string;
  implRefs: string[];
  verifyRefs: string[];
}

/**
 * The output of the bridge: a vector chunk that has been *validated*
 * against the intent graph. `governedBy` is non-empty for every grounded
 * chunk — that is the invariant that makes this deterministic.
 */
export interface GroundedChunk {
  chunk: VectorChunk;
  governedBy: ResolvedRequirement[];
}

/**
 * The dependency surface the bridge needs. Both the vector store and the
 * MCP client are behind interfaces so tests can substitute fakes without
 * network I/O.
 */
export interface BridgeDeps {
  /** Return the top-K chunks for a query. */
  vectorSearch: (query: string, topK: number) => Promise<VectorChunk[]>;
  /** Resolve a requirement UID through Tracey MCP. Returns null on failure. */
  resolveRequirement: (uid: string) => Promise<ResolvedRequirement | null>;
}

/**
 * The regex that matches a Tracey marker in a source comment. It accepts
 * both the compact form `r[impl UID]` and the StrictDoc-native form
 * `@relation(UID, scope=...)`. Capture group 2 is the UID; group 1 is the
 * optional verb (defaults to `impl`).
 */
const TRACEY_MARKER_REGEX =
  /(?:\/\/|#|\/\*)\s*(?:r\[(impl|verify|depends|related)?\s*([A-Za-z0-9._-]+)\]|@relation\(\s*([A-Za-z0-9._-]+))/g;

/**
 * Extract every Tracey-marked requirement UID that appears in the chunk.
 * Deduplicates so that a chunk annotated twice for the same UID emits the
 * UID once. The verb is intentionally ignored here because grounding only
 * cares about *whether* a chunk is governed, not *how*.
 */
export function extractRequirementUids(content: string): string[] {
  const uids = new Set<string>();
  for (const match of content.matchAll(TRACEY_MARKER_REGEX)) {
    const uid = match[2] ?? match[3];
    if (uid) uids.add(uid);
  }
  return Array.from(uids);
}

/**
 * Turn vector candidates into grounded candidates by resolving every
 * Tracey marker through the intent graph. Chunks with zero resolvable
 * markers are dropped — this is the deterministic filter.
 */
export async function groundChunks(
  candidates: VectorChunk[],
  deps: BridgeDeps,
): Promise<GroundedChunk[]> {
  const grounded: GroundedChunk[] = [];

  for (const chunk of candidates) {
    const uids = extractRequirementUids(chunk.content);
    if (uids.length === 0) continue;

    const resolved: ResolvedRequirement[] = [];
    for (const uid of uids) {
      const requirement = await deps.resolveRequirement(uid);
      if (requirement) resolved.push(requirement);
    }

    if (resolved.length > 0) {
      grounded.push({ chunk, governedBy: resolved });
    }
  }

  return grounded;
}

/**
 * The end-to-end "hybrid retrieval" entry point: vector for discovery,
 * intent graph for validation. Returns a payload the agent can trust.
 */
export async function retrieveWithIntentGraph(
  query: string,
  deps: BridgeDeps,
  topK = 8,
): Promise<GroundedChunk[]> {
  const candidates = await deps.vectorSearch(query, topK);
  return groundChunks(candidates, deps);
}

/**
 * Render the grounded result into a Markdown block suitable for injection
 * into an agent's context window. Requirements are attached to each chunk
 * so the model can cite them verbatim.
 */
export function renderGroundedContext(grounded: GroundedChunk[]): string {
  const sections = grounded.map(({ chunk, governedBy }) => {
    const reqBlock = governedBy
      .map(
        (r) =>
          `- **${r.uid}** — ${r.title}\n  > ${r.statement.replace(/\n/g, " ")}`,
      )
      .join("\n");
    return `### ${chunk.filePath}\n\n\`\`\`\n${chunk.content}\n\`\`\`\n\nGoverning requirements:\n${reqBlock}`;
  });
  return sections.join("\n\n---\n\n");
}
