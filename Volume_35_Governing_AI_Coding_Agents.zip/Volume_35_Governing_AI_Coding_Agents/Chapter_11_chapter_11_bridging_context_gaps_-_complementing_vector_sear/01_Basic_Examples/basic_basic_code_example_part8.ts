/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part8.ts
Description: Basic Code Example
==========================================
*/

// src/bridge/intent-graph-bridge.test.ts
import { describe, it, expect, vi } from "vitest";
import {
  extractRequirementUids,
  groundChunks,
  retrieveWithIntentGraph,
  type BridgeDeps,
  type VectorChunk,
} from "./intent-graph-bridge";

const reqExpiry = {
  uid: "BILLING-TRIAL-EXPIRY",
  title: "Trial Expiry Enforcement",
  statement:
    "While a tenant is in TRIALING state, BillingHub shall transition to RESTRICTED after 14 days.",
  implRefs: ["src/billing/trial-manager.ts:14"],
  verifyRefs: [],
};

const reqUnrelated = {
  uid: "REDIS-SESSION-TTL",
  title: "Redis Session TTL",
  statement: "Sessions shall expire after 30 minutes of inactivity.",
  implRefs: ["src/session/redis.ts:8"],
  verifyRefs: [],
};

describe("extractRequirementUids", () => {
  it("extracts the compact r[impl UID] form", () => {
    const uids = extractRequirementUids(`
      // r[impl BILLING-TRIAL-EXPIRY]
      function foo() {}
    `);
    expect(uids).toEqual(["BILLING-TRIAL-EXPIRY"]);
  });

  it("extracts the StrictDoc @relation form", () => {
    const uids = extractRequirementUids(`
      /* @relation(BILLING-TRIAL-CONVERT, scope=function) */
    `);
    expect(uids).toEqual(["BILLING-TRIAL-CONVERT"]);
  });

  it("deduplicates repeated markers in the same chunk", () => {
    const uids = extractRequirementUids(`
      // r[impl BILLING-TRIAL-EXPIRY]
      // r[verify BILLING-TRIAL-EXPIRY]
    `);
    expect(uids).toEqual(["BILLING-TRIAL-EXPIRY"]);
  });
});

describe("groundChunks", () => {
  it("drops chunks that have no Tracey markers", async () => {
    const candidates: VectorChunk[] = [
      { filePath: "src/session/redis.ts", content: "const ttl = 30 * 60;", score: 0.92 },
    ];
    const deps: BridgeDeps = {
      vectorSearch: vi.fn(),
      resolveRequirement: vi.fn(async () => reqExpiry),
    };
    const grounded = await groundChunks(candidates, deps);
    expect(grounded).toHaveLength(0);
  });

  it("keeps chunks whose markers resolve and attaches requirement text", async () => {
    const candidates: VectorChunk[] = [
      {
        filePath: "src/billing/trial-manager.ts",
        content: "// r[impl BILLING-TRIAL-EXPIRY]\nexport function expireTrialIfDue() {}",
        score: 0.81,
      },
    ];
    const deps: BridgeDeps = {
      vectorSearch: vi.fn(),
      resolveRequirement: vi.fn(async (uid) =>
        uid === "BILLING-TRIAL-EXPIRY" ? reqExpiry : null,
      ),
    };
    const grounded = await groundChunks(candidates, deps);
    expect(grounded).toHaveLength(1);
    expect(grounded[0].governedBy[0].statement).toContain("RESTRICTED");
  });

  it("rejects chunks whose markers are unknown to the intent graph", async () => {
    const candidates: VectorChunk[] = [
      {
        filePath: "src/legacy/old.ts",
        content: "// r[impl BILLING-TRIAL-EXPIRED]\nfunction old() {}",
        score: 0.88,
      },
    ];
    const deps: BridgeDeps = {
      vectorSearch: vi.fn(),
      resolveRequirement: vi.fn(async () => null),
    };
    const grounded = await groundChunks(candidates, deps);
    expect(grounded).toHaveLength(0);
  });
});

describe("retrieveWithIntentGraph (end-to-end)", () => {
  it("only surfaces the spec-relevant chunk when both are semantically similar", async () => {
    const deps: BridgeDeps = {
      vectorSearch: vi.fn(async () => [
        { filePath: "src/session/redis.ts", content: "const ttl = 30 * 60; // expiration", score: 0.94 },
        {
          filePath: "src/billing/trial-manager.ts",
          content: "// r[impl BILLING-TRIAL-EXPIRY]\nexport function expireTrialIfDue() {}",
          score: 0.79,
        },
      ]),
      resolveRequirement: vi.fn(async (uid) => {
        if (uid === "BILLING-TRIAL-EXPIRY") return reqExpiry;
        if (uid === "REDIS-SESSION-TTL") return reqUnrelated;
        return null;
      }),
    };

    const grounded = await retrieveWithIntentGraph("trial expiry logic", deps);
    expect(grounded).toHaveLength(1);
    expect(grounded[0].chunk.filePath).toBe("src/billing/trial-manager.ts");
  });
});
