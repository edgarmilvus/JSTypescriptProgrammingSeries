/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

// src/graph/traverse.test.ts
import { describe, it, expect } from 'vitest';
import { packGraphIntoSharedBuffer } from './sab-layout.js';
import { traverse } from './traverse.js';
import { asEdgeId, asNodeId, type IntentEdge, type IntentNode } from '../types/intent-graph.js';

describe('SAB-parallel traversal', () => {
  // r[verify CB-TRV-002]
  it('rejects maxDepth outside [1,8]', () => {
    const { layout, nodeById } = smallFixture();
    expect(() =>
      traverse(layout, nodeById, [0], 'REQUIREMENT', {
        maxDepth: 0,
        maxFrontier: 16,
        followEdges: [1, 2],
      }),
    ).toThrow(RangeError);
    expect(() =>
      traverse(layout, nodeById, [0], 'REQUIREMENT', {
        maxDepth: 9,
        maxFrontier: 16,
        followEdges: [1, 2],
      }),
    ).toThrow(RangeError);
  });

  // r[verify CB-TRV-002]
  it('rejects maxFrontier outside [1,1024]', () => {
    const { layout, nodeById } = smallFixture();
    expect(() =>
      traverse(layout, nodeById, [0], 'REQUIREMENT', {
        maxDepth: 3,
        maxFrontier: 0,
        followEdges: [1, 2],
      }),
    ).toThrow(RangeError);
  });

  // r[verify CB-TRV-001]
  it('shares its visited bitvector with concurrent traversals', () => {
    const { layout, nodeById } = smallFixture();
    const result1 = traverse(layout, nodeById, [0], 'REQUIREMENT', {
      maxDepth: 3,
      maxFrontier: 16,
      followEdges: [1, 2],
    });
    const result2 = traverse(layout, nodeById, [0], 'REQUIREMENT', {
      maxDepth: 3,
      maxFrontier: 16,
      followEdges: [1, 2],
    });
    // The second traversal, starting after the first has claimed every
    // reachable node, must not visit anything new.
    expect(result2.visitedCount).toBe(result1.visitedCount);
  });

  // r[verify CB-TRV-003]
  it('does not require modification to collect a new node kind', () => {
    const { layout, nodeById } = smallFixtureWith('TEST');
    // The type parameter is inferred from the literal, and the traversal
    // body does not know that 'TEST' exists.
    const result = traverse(layout, nodeById, [0], 'TEST', {
      maxDepth: 3,
      maxFrontier: 16,
      followEdges: [3], // VERIFIES
    });
    expect(result.nodes.every((n) => n.kind === 'TEST')).toBe(true);
  });

  // r[verify CB-TRV-002]
  it('reports truncation rather than silently dropping nodes', () => {
    const { layout, nodeById } = smallFixtureDense();
    const result = traverse(layout, nodeById, [0], 'REQUIREMENT', {
      maxDepth: 5,
      maxFrontier: 2,
      followEdges: [1, 2],
    });
    expect(result.truncated).toBe(true);
  });
});

interface Fixture {
  readonly layout: ReturnType<typeof packGraphIntoSharedBuffer>;
  readonly nodeById: ReadonlyMap<string, IntentNode>;
}

function smallFixture(): Fixture {
  return buildFixture([
    node('root', 'REQUIREMENT'),
    node('req-a', 'REQUIREMENT'),
    node('req-b', 'REQUIREMENT'),
  ], [
    edge('e1', 'req-a', 'root', 'PARENT'),
    edge('e2', 'req-b', 'req-a', 'PARENT'),
  ]);
}

function smallFixtureWith(kind: 'TEST'): Fixture {
  return buildFixture([
    node('root', 'REQUIREMENT'),
    node('req-a', 'REQUIREMENT'),
    node('test-a', kind),
  ], [
    edge('e1', 'req-a', 'root', 'PARENT'),
    edge('e2', 'test-a', 'req-a', 'VERIFIES'),
  ]);
}

function smallFixtureDense(): Fixture {
  const nodes = [node('root', 'REQUIREMENT')];
  const edges: IntentEdge[] = [];
  for (let i = 0; i < 10; i++) {
    nodes.push(node(`req-${i}`, 'REQUIREMENT'));
    edges.push(edge(`e-${i}`, `req-${i}`, 'root', 'PARENT'));
  }
  return buildFixture(nodes, edges);
}

function buildFixture(nodes: IntentNode[], edges: IntentEdge[]): Fixture {
  const layout = packGraphIntoSharedBuffer(nodes, edges);
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  return { layout, nodeById };
}

function node(id: string, kind: IntentNode['kind']): IntentNode {
  return {
    id,
    kind,
    payload: payloadFor(kind),
    outgoing: [],
    incoming: [],
  } as IntentNode;
}

function edge(id: string, from: string, to: string, kind: IntentEdge['kind']): IntentEdge {
  return {
    id: asEdgeId(id),
    kind,
    from: asNodeId(from),
    to: asNodeId(to),
    mintedBy: { file: 'test.ts', line: 1, rawAnnotation: `r[${kind.toLowerCase()} fixture]` },
  };
}

function payloadFor(kind: IntentNode['kind']): IntentNode['payload'] {
  switch (kind) {
    case 'REQUIREMENT':
      return {
        uid: 'CB-TEST-000',
        mid: 'deadbeef',
        statement: 'Test fixture.',
        ears: 'UBIQUITOUS',
      };
    case 'TEST':
      return { suite: 'traverse', framework: 'vitest', verifies: ['CB-TEST-000'] };
    case 'DECISION':
      return { adrNumber: 1, title: 'Fixture', status: 'ACCEPTED' };
    case 'CODE_BOUNDARY':
      return { filePath: 'test.ts', span: { startLine: 1, endLine: 10 }, language: 'typescript' };
    case 'INCIDENT':
      return { incidentId: 'INC-1', detectedAt: '2025-01-01', severity: 'SEV3' };
  }
}
