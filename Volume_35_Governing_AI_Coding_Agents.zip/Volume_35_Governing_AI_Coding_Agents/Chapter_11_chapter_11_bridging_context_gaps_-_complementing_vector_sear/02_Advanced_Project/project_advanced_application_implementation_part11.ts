/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part11.ts
Description: Advanced Application Implementation
==========================================
*/

// src/bridge/context-bridge.test.ts
import { describe, it, expect, vi } from 'vitest';
import { retrieve } from './context-bridge.js';
import type { SupervisorLLM } from '../supervisor/supervisor-node.js';

describe('ContextBridge.retrieve', () => {
  // r[verify CB-RET-002]
  it('never returns an unauthorized vector candidate', async () => {
    const llm = scriptedLLM([
      { kind: 'DISCOVER', reasoning: 'first pass', topK: 8 },
      { kind: 'FINALIZE', reasoning: 'no requirements reachable' },
    ]);
    const envelope = await retrieve(deps({ llm, authorizedFixture: [] }), 'retry policy');
    expect(envelope.authorized).toEqual([]);
    expect(envelope.rejected.length).toBeGreaterThan(0);
    expect(envelope.rejected.every((r) => r.reason === 'NO_OVERLAPPING_NODE')).toBe(true);
  });

  // r[verify CB-RET-004]
  it('produces byte-identical envelopes for repeated identical queries', async () => {
    const llm = scriptedLLM([
      { kind: 'DISCOVER', reasoning: 'p1', topK: 8 },
      { kind: 'VALIDATE', reasoning: 'p2', candidateIds: ['c1'] },
      { kind: 'FINALIZE', reasoning: 'p3' },
    ]);
    const d = deps({ llm });
    const first = JSON.stringify(await retrieve(d, 'same query'));
    const second = JSON.stringify(await retrieve(d, 'same query'));
    expect(second).toBe(first);
  });

  // r[verify CB-SUP-002]
  it('rejects a supervisor decision with an illegal discriminant', async () => {
    const llm = scriptedLLM([{ kind: 'TRAVERSE_EVERYTHING', reasoning: 'nope' }]);
    await expect(retrieve(deps({ llm }), 'query')).rejects.toThrow(/CB-SUP-002/);
  });

  // r[verify CB-SUP-003]
  it('resolves vector/graph disagreement in favour of the graph', async () => {
    // The fixture presents one candidate that the vector index scores 0.99
    // but that has no reachable requirement. The bridge must reject it.
    const llm = scriptedLLM([
      { kind: 'DISCOVER', reasoning: 'p1', topK: 8 },
      { kind: 'VALIDATE', reasoning: 'p2', candidateIds: ['c-unreachable'] },
      { kind: 'FINALIZE', reasoning: 'done' },
    ]);
    const envelope = await retrieve(deps({ llm, highScoreUnreachable: true }), 'q');
    expect(envelope.authorized).toEqual([]);
  });
});

function scriptedLLM(responses: readonly unknown[]): SupervisorLLM {
  let i = 0;
  return {
    async complete() {
      const r = responses[Math.min(i++, responses.length - 1)];
      return JSON.stringify(r);
    },
  };
}

function deps(arg: {
  llm: SupervisorLLM;
  authorizedFixture?: readonly unknown[];
  highScoreUnreachable?: boolean;
}) {
  // Fixture construction elided for brevity. The fixture is documented in
  // src/__fixtures__/intent-graph.ts and is the canonical set used by all
  // bridge tests.
  void arg;
  return undefined as never;
}
