/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part3.ts
Description: Advanced Application Implementation
==========================================
*/

// src/types/intent-graph.ts
/**
 * The complete vocabulary of node kinds understood by the ContextBridge.
 *
 * Adding a new kind here is the *only* change required to make the graph
 * traversal, validation, and envelope construction work with it — provided
 * the new kind's field shape is declared in {@link NodePayloadMap}.
 */
export type NodeKind =
  | 'REQUIREMENT'
  | 'DECISION'
  | 'TEST'
  | 'CODE_BOUNDARY'
  | 'INCIDENT';

/**
 * The edge kinds permitted between intent nodes. Each edge is directed and
 * carries the identity of the annotation that minted it (`mintedBy`), so that
 * a retrieval envelope can cite the exact Tracey annotation that authorized
 * a candidate chunk.
 */
export type EdgeKind = 'PARENT' | 'IMPLEMENTS' | 'VERIFIES' | 'DEPENDS' | 'RELATED';

/**
 * Payload shape per node kind. This is the map that gives the generic
 * {@link IntentNode} its type-safety: an `IntentNode<'REQUIREMENT'>` is
 * statically known to have a payload of type `RequirementPayload`.
 */
export interface NodePayloadMap {
  REQUIREMENT: {
    uid: string;
    mid: string;
    statement: string;
    rationale?: string;
    ears: 'UBIQUITOUS' | 'EVENT' | 'STATE' | 'UNWANTED' | 'OPTIONAL';
  };
  DECISION: {
    adrNumber: number;
    title: string;
    status: 'PROPOSED' | 'ACCEPTED' | 'SUPERSEDED';
  };
  TEST: {
    suite: string;
    framework: 'vitest' | 'cargo-test' | 'pytest';
    verifies: readonly string[]; // UIDs verified
  };
  CODE_BOUNDARY: {
    filePath: string;
    span: { startLine: number; endLine: number };
    language: 'typescript' | 'rust' | 'python';
  };
  INCIDENT: {
    incidentId: string;
    detectedAt: string;
    severity: 'SEV1' | 'SEV2' | 'SEV3';
  };
}

/**
 * A node in the deterministic intent graph.
 *
 * @typeParam K - The node kind. Constrained to {@link NodeKind}, which makes
 *                the payload field (`node.payload`) statically known.
 */
export interface IntentNode<K extends NodeKind = NodeKind> {
  readonly id: string;
  readonly kind: K;
  readonly payload: NodePayloadMap[K];
  readonly outgoing: readonly EdgeId[];
  readonly incoming: readonly EdgeId[];
}

/**
 * An edge in the intent graph. Always directed (from → to).
 *
 * The `mintedBy` field is the audit trail: it records the exact source
 * annotation (`r[verify CB-RET-002]` in `src/retrieval/vector-search.test.ts`,
 * line 47) that caused Tracey to mint this edge. Without it, the retrieval
 * envelope would be able to cite *that* an edge exists but not *why*.
 */
export interface IntentEdge {
  readonly id: EdgeId;
  readonly kind: EdgeKind;
  readonly from: string;
  readonly to: string;
  readonly mintedBy: {
    readonly file: string;
    readonly line: number;
    readonly rawAnnotation: string;
  };
}

/** Branded identifier types. These prevent accidentally passing a node ID
 *  where an edge ID is expected — a class of bug that has burned every
 *  graph-based system ever written in a structurally-typed language. */
export type NodeId = string & { readonly __brand: 'NodeId' };
export type EdgeId = string & { readonly __brand: 'EdgeId' };

export const asNodeId = (s: string): NodeId => s as NodeId;
export const asEdgeId = (s: string): EdgeId => s as EdgeId;
