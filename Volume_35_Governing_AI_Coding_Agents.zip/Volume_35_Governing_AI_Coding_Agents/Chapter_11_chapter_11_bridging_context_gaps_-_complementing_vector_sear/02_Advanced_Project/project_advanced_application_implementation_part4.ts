/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part4.ts
Description: Advanced Application Implementation
==========================================
*/

// src/graph/sab-layout.ts
/**
 * The on-buffer layout of a graph snapshot.
 *
 * Layout (all little-endian, all 32-bit signed except where noted):
 *
 *   [0]                   magic ('CBG1' as u32)
 *   [1]                   nodeCount
 *   [2]                   edgeCount
 *   [3]                   reserved
 *   [4 .. 4+3*edgeCount]  edge triplets: (fromIndex, toIndex, kindCode)
 *   [4+3*edgeCount .. +nodeCount] node kind codes
 *   [..]                  visited bitvector (ceil(nodeCount / 32) u32s)
 *
 * The visited bitvector is at a fixed offset *after* the immutable region, so
 * that concurrent workers can perform Atomic Or on the same 32-bit word
 * without risk of false sharing on adjacent edges.
 */
export const SAB_HEADER_WORDS = 4;
export const SAB_MAGIC = 0x43424731; // 'CBG1'

export interface SabLayout {
  readonly sab: SharedArrayBuffer;
  readonly header: Int32Array;
  readonly edges: Int32Array;   // length = 3 * edgeCount
  readonly nodeKinds: Int32Array;
  readonly visited: Int32Array; // bitvector, one bit per node
  readonly nodeCount: number;
  readonly edgeCount: number;
}

/**
 * Serialize a parsed intent graph into a shared buffer suitable for
 * multi-threaded traversal.
 *
 * This is the *only* function that allocates a SharedArrayBuffer. Every
 * traversal worker receives the returned {@link SabLayout} by reference and
 * never allocates its own.
 */
export function packGraphIntoSharedBuffer(
  nodes: readonly IntentNode[],
  edges: readonly IntentEdge[],
): SabLayout {
  const nodeIndex = new Map<string, number>();
  nodes.forEach((n, i) => nodeIndex.set(n.id, i));

  const headerWords = SAB_HEADER_WORDS;
  const edgeWords = edges.length * 3;
  const kindWords = nodes.length;
  const visitedWords = Math.ceil(nodes.length / 32);

  const totalWords = headerWords + edgeWords + kindWords + visitedWords;
  const sab = new SharedArrayBuffer(totalWords * 4);

  const header = new Int32Array(sab, 0, headerWords);
  header[0] = SAB_MAGIC;
  header[1] = nodes.length;
  header[2] = edges.length;

  const edgeView = new Int32Array(sab, headerWords * 4, edgeWords);
  edges.forEach((e, i) => {
    const from = nodeIndex.get(e.from);
    const to = nodeIndex.get(e.to);
    if (from === undefined || to === undefined) {
      throw new Error(`Edge ${e.id} references unknown node`);
    }
    edgeView[i * 3 + 0] = from;
    edgeView[i * 3 + 1] = to;
    edgeView[i * 3 + 2] = EDGE_KIND_CODES[e.kind];
  });

  const kindView = new Int32Array(sab, (headerWords + edgeWords) * 4, kindWords);
  nodes.forEach((n, i) => {
    kindView[i] = NODE_KIND_CODES[n.kind];
  });

  const visited = new Int32Array(
    sab,
    (headerWords + edgeWords + kindWords) * 4,
    visitedWords,
  );

  return {
    sab,
    header,
    edges: edgeView,
    nodeKinds: kindView,
    visited,
    nodeCount: nodes.length,
    edgeCount: edges.length,
  };
}

const EDGE_KIND_CODES: Record<EdgeKind, number> = {
  PARENT: 1,
  IMPLEMENTS: 2,
  VERIFIES: 3,
  DEPENDS: 4,
  RELATED: 5,
};

const NODE_KIND_CODES: Record<NodeKind, number> = {
  REQUIREMENT: 1,
  DECISION: 2,
  TEST: 3,
  CODE_BOUNDARY: 4,
  INCIDENT: 5,
};
