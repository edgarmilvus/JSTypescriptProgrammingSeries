/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part5.ts
Description: Advanced Application Implementation
==========================================
*/

// src/graph/traverse.ts
import {
  type IntentNode,
  type NodeKind,
  type NodePayloadMap,
  type SabLayout,
} from '../types/intent-graph.js';

/**
 * The result of a single traversal. The {@link T} parameter is the kind of
 * node that was targeted, so consumers statically know which payload fields
 * are available.
 */
export interface TraversalResult<T extends NodeKind> {
  readonly nodes: readonly IntentNode<T>[];
  readonly truncated: boolean;
  readonly depthReached: number;
  readonly visitedCount: number;
}

export interface TraversalOptions {
  readonly maxDepth: number;      // 1..8 per CB-TRV-002
  readonly maxFrontier: number; // 1..1024 per CB-TRV-002
  readonly followEdges: readonly EdgeKindCode[];
}

/**
 * Breadth-first traversal over the intent graph snapshot.
 *
 * @remarks
 * The traversal shares its visited bitvector with every concurrent caller
 * through {@link SabLayout.visited}. Each visited bit is claimed with an
 * `Atomics.or` on the containing 32-bit word; the succeeding thread sees the
 * bit already set and skips the node. This is the standard "test-and-set on a
 * bitvector" pattern and it is what makes CB-TRV-001 enforceable: there is no
 * per-thread copy.
 *
 * @typeParam T - The node kind we are collecting. Because the caller declares
 *                `T` at the call site (`traverse<'REQUIREMENT'>(...)`), the
 *                returned array is `readonly IntentNode<'REQUIREMENT'>[]` and
 *                downstream code gets full autocomplete on `payload.ears`
 *                without any casts.
 *
 * @param layout   - The shared graph snapshot.
 * @param nodeById - A caller-owned index from node ID to node record. This is
 *                   read-only during traversal; it lives outside the SAB
 *                   because the node payloads contain strings that cannot be
 *                   meaningfully stored in a fixed-width buffer.
 * @param roots    - Starting node indices.
 * @param wanted   - The kind we collect.
 * @param options  - Bounds and edge filter.
 */
export function traverse<T extends NodeKind>(
  layout: SabLayout,
  nodeById: ReadonlyMap<string, IntentNode>,
  roots: readonly number[],
  wanted: T,
  options: TraversalOptions,
): TraversalResult<T> {
  const { maxDepth, maxFrontier, followEdges } = options;
  if (maxDepth < 1 || maxDepth > 8) {
    throw new RangeError(`maxDepth ${maxDepth} outside [1,8] (CB-TRV-002)`);
  }
  if (maxFrontier < 1 || maxFrontier > 1024) {
    throw new RangeError(`maxFrontier ${maxFrontier} outside [1,1024] (CB-TRV-002)`);
  }

  const followSet = new Set(followEdges);
  const out: IntentNode<T>[] = [];
  let frontier: number[] = [...roots];
  let depth = 0;
  let truncated = false;

  // Claim each root in the shared visited bitvector before expanding.
  for (const root of frontier) {
    claimBit(layout.visited, root);
  }

  while (frontier.length > 0 && depth < maxDepth) {
    const next: number[] = [];
    for (const from of frontier) {
      // Iterate over the edge list linearly. This is O(E) per level, which is
      // dominated by the graph's low average degree and is what permits us to
      // avoid a CSR construction step. For graphs above ~1M edges, swap this
      // for a CSR built once and memoized alongside the SAB.
      for (let e = 0; e < layout.edgeCount; e++) {
        const fromIdx = layout.edges[e * 3 + 0];
        if (fromIdx !== from) continue;
        const kindCode = layout.edges[e * 3 + 2];
        if (!followSet.has(kindCode)) continue;

        const toIdx = layout.edges[e * 3 + 1];
        if (!claimBit(layout.visited, toIdx)) continue;

        if (next.length >= maxFrontier) {
          truncated = true;
          break;
        }
        next.push(toIdx);

        const nodeId = nodeIdFromIndex(layout, nodeById, toIdx);
        const node = nodeById.get(nodeId);
        if (node && node.kind === wanted) {
          out.push(node as IntentNode<T>);
        }
      }
      if (truncated) break;
    }
    if (truncated) break;
    frontier = next;
    depth++;
  }

  return {
    nodes: out,
    truncated,
    depthReached: depth,
    visitedCount: countBits(layout.visited),
  };
}

/** Test-and-set on a bit in a 32-bit word. Returns true iff we won the race. */
function claimBit(visited: Int32Array, index: number): boolean {
  const word = index >>> 5;
  const mask = 1 << (index & 31);
  const prior = Atomics.or(visited, word, mask);
  return (prior & mask) === 0;
}

/** Population count across the visited bitvector. */
function countBits(visited: Int32Array): number {
  let total = 0;
  for (let i = 0; i < visited.length; i++) {
    let x = visited[i];
    // Kernighan's algorithm.
    while (x) {
      x &= x - 1;
      total++;
    }
  }
  return total;
}

function nodeIdFromIndex(
  layout: SabLayout,
  nodeById: ReadonlyMap<string, IntentNode>,
  index: number,
): string {
  // The map is keyed by node ID, so we invert once at construction time. The
  // helper here is intentionally linear; it exists only to make the
  // main traversal loop above readable.
  let i = 0;
  for (const [id] of nodeById) {
    if (i++ === index) return id;
  }
  throw new RangeError(`Index ${index} out of range`);
}

export type EdgeKindCode = 1 | 2 | 3 | 4 | 5;
