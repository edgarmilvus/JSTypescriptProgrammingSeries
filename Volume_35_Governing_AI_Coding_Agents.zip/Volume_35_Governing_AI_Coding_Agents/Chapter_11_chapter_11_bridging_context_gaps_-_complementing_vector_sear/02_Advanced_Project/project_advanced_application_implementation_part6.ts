/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

// src/retrieval/vector-search.ts
/**
 * A candidate chunk returned by the vector index. Note the absence of the
 * word "result" in the type name — the bridge deliberately calls these
 * "candidates" everywhere, because CB-RET-002 forbids treating them as
 * anything more than that before graph validation.
 */
export interface VectorCandidate {
  readonly chunkId: string;
  readonly filePath: string;
  readonly span: { readonly startLine: number; readonly endLine: number };
  readonly text: string;
  readonly score: number; // cosine similarity in [-1, 1]
}

export interface VectorQuery {
  readonly text: string;
  readonly topK: number;   // bounded by CB-RET-001
  readonly minScore?: number;
}

/**
 * Executes a vector query against the in-process HNSW index.
 *
 * @remarks
 * The index itself is loaded once at process start from a Tantivy snapshot;
 * this function is the read-only query path. It is intentionally synchronous
 * so that the caller (the Supervisor Node) can reason about it as a pure
 * function from `VectorQuery` to `VectorCandidate[]`.
 *
 * @throws RangeError if `topK` is outside [1, 64] per CB-RET-001.
 */
export function searchVectors(index: VectorIndex, query: VectorQuery): VectorCandidate[] {
  if (query.topK < 1 || query.topK > 64) {
    throw new RangeError(`topK ${query.topK} outside [1,64] (CB-RET-001)`);
  }
  const scored = index.query(query.text, query.topK * 4);
  const minScore = query.minScore ?? 0.35;
  return scored
    .filter((c) => c.score >= minScore)
    .slice(0, query.topK);
}

/**
 * The minimal interface a vector index must satisfy to be usable by the
 * bridge. Implementations may wrap Tantivy, HNSW, or an external service.
 */
export interface VectorIndex {
  query(text: string, k: number): readonly VectorCandidate[];
}
