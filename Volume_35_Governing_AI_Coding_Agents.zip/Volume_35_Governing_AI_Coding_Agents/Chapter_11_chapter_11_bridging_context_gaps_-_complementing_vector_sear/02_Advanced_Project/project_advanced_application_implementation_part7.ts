/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

// src/bridge/envelope.ts
import type { IntentNode, IntentEdge, NodeKind } from '../types/intent-graph.js';

/**
 * The wire format returned to the MCP client. Every field is derived from the
 * intent graph; the `candidates` that survived validation are only present
 * insomuch as they match a `CODE_BOUNDARY` node in the graph.
 */
export interface DeterministicEnvelope {
  readonly query: string;
  readonly graphVersion: string; // hash of the SAB snapshot at time of query
  readonly authorized: readonly AuthorizedChunk[];
  readonly rejected: readonly RejectedCandidate[];
  readonly truncation: { readonly truncated: boolean; readonly depth: number };
}

export interface AuthorizedChunk {
  readonly filePath: string;
  readonly span: { readonly startLine: number; readonly endLine: number };
  readonly text: string;
  /** The rule that authorizes this chunk. */
  readonly authority: {
    readonly uid: string;
    readonly mid: string;
    readonly statement: string;
    readonly rationale?: string;
  };
  /** The exact trace edges, in traversal order, that connect the chunk to the
   *  authority. This is what turns a retrieval into an explanation. */
  readonly trace: readonly TraceStep[];
}

export interface TraceStep {
  readonly kind: IntentEdge['kind'];
  readonly from: string;
  readonly to: string;
  readonly mintedBy: IntentEdge['mintedBy'];
}

export interface RejectedCandidate {
  readonly chunkId: string;
  readonly reason:
    | 'NO_OVERLAPPING_NODE'
    | 'NOT_REACHABLE_FROM_ROOT'
    | 'BELOW_SCORE_THRESHOLD';
}

/**
 * Build the deterministic envelope.
 *
 * @remarks
 * The function is pure over (candidates, graph, traversal). Two invocations
 * with identical inputs and an unchanged graph version produce byte-identical
 * output. This is the operational meaning of CB-RET-004.
 */
export function buildEnvelope(
  query: string,
  graphVersion: string,
  candidates: readonly VectorCandidate[],
  authorized: readonly AuthorizedChunk[],
  rejected: readonly RejectedCandidate[],
  truncation: DeterministicEnvelope['truncation'],
): DeterministicEnvelope {
  return { query, graphVersion, authorized, rejected, truncation };
}
