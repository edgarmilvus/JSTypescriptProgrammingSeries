/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.ts
Description: Advanced Application Implementation
==========================================
*/

// src/supervisor/supervisor-node.ts
import type { DeterministicEnvelope, AuthorizedChunk } from '../bridge/envelope.js';

/**
 * A routing decision. The discriminant is the only thing the bridge acts on;
 * `reasoning` is retained for audit and is never parsed by the bridge itself.
 */
export type RoutingDecision =
  | { kind: 'DISCOVER'; reasoning: string; topK: number }
  | { kind: 'VALIDATE'; reasoning: string; candidateIds: readonly string[] }
  | { kind: 'EXPLAIN'; reasoning: string; uids: readonly string[] }
  | { kind: 'FINALIZE'; reasoning: string };

/**
 * The Graph State visible to the Supervisor. It is intentionally small: the
 * supervisor must not be given substrate data, because CB-SUP-001 forbids it
 * from traversing.
 */
export interface GraphState {
  readonly candidateCount: number;
  readonly authorizedCount: number;
  readonly rejectedCount: number;
  readonly citedUids: readonly string[];
  readonly truncated: boolean;
}

/**
 * The Supervisor Node. Delegates routing to an LLM prompt but validates the
 * response against the closed discriminant set (CB-SUP-002).
 *
 * @param llm      - A minimal client shaped like Anthropic's or OpenAI's
 *                   completions API.
 * @param query    - The original MCP query.
 * @param state    - The summarized Graph State.
 * @returns        - A routing decision, guaranteed to have a valid discriminant.
 * @throws Error   - If the LLM emits an unrecognized discriminant. CB-SUP-002
 *                   requires that this be a *rejection*, not a silent fallback.
 */
export async function route(
  llm: SupervisorLLM,
  query: string,
  state: GraphState,
): Promise<RoutingDecision> {
  const raw = await llm.complete({
    system: SUPERVISOR_SYSTEM_PROMPT,
    user: renderGraphState(query, state),
    temperature: 0,
    maxTokens: 256,
  });

  const parsed = parseDecisionOrThrow(raw);
  return parsed;
}

const SUPERVISOR_SYSTEM_PROMPT = `
You are the Supervisor Node of a deterministic intent-graph context bridge.
You do NOT traverse the graph, embed text, or read files.

Given a query and a Graph State, emit exactly one routing decision as JSON.

Discriminated decisions (kind is required, no other kinds are permitted):
  {"kind":"DISCOVER","reasoning":"...","topK":<1..64>}
  {"kind":"VALIDATE","reasoning":"...","candidateIds":[...]}
  {"kind":"EXPLAIN","reasoning":"...","uids":[...]}
  {"kind":"FINALIZE","reasoning":"..."}

Routing heuristics:
  - If candidateCount == 0, emit DISCOVER with topK=16.
  - If candidateCount > 0 and authorizedCount == 0, emit VALIDATE with the
    candidate ids.
  - If authorizedCount > 0 and citedUids.length == 0, emit EXPLAIN.
  - Otherwise, emit FINALIZE.

Output only the JSON object. No prose. No markdown fences.
`.trim();

interface SupervisorLLM {
  complete(args: {
    system: string;
    user: string;
    temperature: number;
    maxTokens: number;
  }): Promise<string>;
}

function renderGraphState(query: string, state: GraphState): string {
  return JSON.stringify({ query, state }, null, 2);
}

function parseDecisionOrThrow(raw: string): RoutingDecision {
  const trimmed = raw.trim();
  let parsed: unknown;
  try {
    parsed = JSON.parse(trimmed);
  } catch {
    throw new Error('Supervisor emitted non-JSON (CB-SUP-002 violation)');
  }
  if (typeof parsed !== 'object' || parsed === null) {
    throw new Error('Supervisor emitted non-object (CB-SUP-002 violation)');
  }
  const kind = (parsed as { kind?: unknown }).kind;
  switch (kind) {
    case 'DISCOVER': {
      const topK = (parsed as { topK?: unknown }).topK;
      if (typeof topK !== 'number' || topK < 1 || topK > 64) {
        throw new Error('DISCOVER.topK outside [1,64] (CB-RET-001)');
      }
      return { kind, reasoning: readReasoning(parsed), topK };
    }
    case 'VALIDATE': {
      const ids = (parsed as { candidateIds?: unknown }).candidateIds;
      if (!Array.isArray(ids) || !ids.every((x) => typeof x === 'string')) {
        throw new Error('VALIDATE.candidateIds must be string[]');
      }
      return { kind, reasoning: readReasoning(parsed), candidateIds: ids };
    }
    case 'EXPLAIN': {
      const uids = (parsed as { uids?: unknown }).uids;
      if (!Array.isArray(uids) || !uids.every((x) => typeof x === 'string')) {
        throw new Error('EXPLAIN.uids must be string[]');
      }
      return { kind, reasoning: readReasoning(parsed), uids };
    }
    case 'FINALIZE':
      return { kind, reasoning: readReasoning(parsed) };
    default:
      throw new Error(`Supervisor emitted illegal discriminant: ${String(kind)} (CB-SUP-002)`);
  }
}

function readReasoning(parsed: unknown): string {
  const r = (parsed as { reasoning?: unknown }).reasoning;
  return typeof r === 'string' ? r : '';
}
