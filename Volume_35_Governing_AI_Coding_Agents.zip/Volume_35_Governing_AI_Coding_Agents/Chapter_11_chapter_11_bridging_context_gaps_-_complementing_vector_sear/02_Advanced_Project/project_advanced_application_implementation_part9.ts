/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

// src/bridge/context-bridge.ts
import { searchVectors, type VectorIndex, type VectorCandidate } from '../retrieval/vector-search.js';
import { traverse, type TraversalOptions } from '../graph/traverse.js';
import { route, type SupervisorLLM, type GraphState } from '../supervisor/supervisor-node.js';
import {
  buildEnvelope,
  type AuthorizedChunk,
  type DeterministicEnvelope,
  type RejectedCandidate,
  type TraceStep,
} from './envelope.js';
import type {
  IntentEdge,
  IntentNode,
  SabLayout,
} from '../types/intent-graph.js';

export interface ContextBridgeDeps {
  readonly vectorIndex: VectorIndex;
  readonly graphLayout: SabLayout;
  readonly nodeById: ReadonlyMap<string, IntentNode>;
  readonly edgeById: ReadonlyMap<string, IntentEdge>;
  readonly llm: SupervisorLLM;
  readonly graphVersion: string;
}

/** Bounded loop depth. Three transitions is the maximum a single query can
 *  require: DISCOVER → VALIDATE → EXPLAIN → FINALIZE. */
const MAX_ROUTING_STEPS = 8;

export async function retrieve(
  deps: ContextBridgeDeps,
  query: string,
): Promise<DeterministicEnvelope> {
  const { vectorIndex, graphLayout, nodeById, edgeById, llm, graphVersion } = deps;

  let candidates: VectorCandidate[] = [];
  let authorized: AuthorizedChunk[] = [];
  let rejected: RejectedCandidate[] = [];
  let truncated = false;
  let depthReached = 0;

  for (let step = 0; step < MAX_ROUTING_STEPS; step++) {
    const state: GraphState = {
      candidateCount: candidates.length,
      authorizedCount: authorized.length,
      rejectedCount: rejected.length,
      citedUids: [...new Set(authorized.map((a) => a.authority.uid))],
      truncated,
    };
    const decision = await route(llm, query, state);

    switch (decision.kind) {
      case 'DISCOVER': {
        candidates = searchVectors(vectorIndex, { text: query, topK: decision.topK });
        break;
      }
      case 'VALIDATE': {
        const traversalOptions: TraversalOptions = {
          maxDepth: 3,
          maxFrontier: 256,
          followEdges: [2 /* IMPLEMENTS */, 3 /* VERIFIES */, 1 /* PARENT */],
        };
        const result = traverse<'REQUIREMENT'>(
          graphLayout,
          nodeById,
          rootsForCandidates(graphLayout, nodeById, candidates),
          'REQUIREMENT',
          traversalOptions,
        );
        truncated = result.truncated;
        depthReached = result.depthReached;
        ({ authorized, rejected } = partitionCandidates(
          candidates,
          result.nodes,
          nodeById,
          edgeById,
        ));
        break;
      }
      case 'EXPLAIN': {
        // The explain step reads rule text from the graph — no traversal, no
        // embedding. It enriches each authorized chunk's `authority` object
        // with the full statement and rationale from the requirement node.
        authorized = authorized.map((chunk) => ({
          ...chunk,
          authority: enrichAuthority(chunk.authority.uid, nodeById),
        }));
        break;
      }
      case 'FINALIZE':
        return buildEnvelope(
          query,
          graphVersion,
          candidates,
          authorized,
          rejected,
          { truncated, depth: depthReached },
        );
    }
  }

  // Loop exhausted without FINALIZE. Return the best-effort envelope; the
  // `truncation` field will flag this to the client.
  return buildEnvelope(query, graphVersion, candidates, authorized, rejected, {
    truncated: true,
    depth: depthReached,
  });
}

function rootsForCandidates(
  _layout: SabLayout,
  nodeById: ReadonlyMap<string, IntentNode>,
  candidates: readonly VectorCandidate[],
): number[] {
  // For each candidate, find CODE_BOUNDARY nodes whose span overlaps the
  // chunk span in the same file. Those are the traversal roots.
  const roots: number[] = [];
  let index = 0;
  for (const node of nodeById.values()) {
    if (node.kind !== 'CODE_BOUNDARY') {
      index++;
      continue;
    }
    const payload = node.payload;
    for (const c of candidates) {
      if (
        c.filePath === payload.filePath &&
        c.span.startLine <= payload.span.endLine &&
        c.span.endLine >= payload.span.startLine
      ) {
        roots.push(index);
        break;
      }
    }
    index++;
  }
  return roots;
}

function partitionCandidates(
  candidates: readonly VectorCandidate[],
  requirements: readonly IntentNode<'REQUIREMENT'>[],
  nodeById: ReadonlyMap<string, IntentNode>,
  edgeById: ReadonlyMap<string, IntentEdge>,
): { authorized: AuthorizedChunk[]; rejected: RejectedCandidate[] } {
  const authorized: AuthorizedChunk[] = [];
  const rejected: RejectedCandidate[] = [];

  // Index requirement nodes by file+span for O(1) lookup.
  const reqByFile = new Map<string, IntentNode<'REQUIREMENT'>[]>();
  for (const req of requirements) {
    const boundary = findCodeBoundary(req, nodeById);
    if (!boundary) continue;
    const list = reqByFile.get(boundary.payload.filePath) ?? [];
    list.push(req);
    reqByFile.set(boundary.payload.filePath, list);
  }

  for (const c of candidates) {
    const reqs = reqByFile.get(c.filePath) ?? [];
    if (reqs.length === 0) {
      rejected.push({ chunkId: c.chunkId, reason: 'NO_OVERLAPPING_NODE' });
      continue;
    }
    const trace = traceFor(reqs[0], nodeById, edgeById);
    if (trace.length === 0) {
      rejected.push({ chunkId: c.chunkId, reason: 'NOT_REACHABLE_FROM_ROOT' });
      continue;
    }
    authorized.push({
      filePath: c.filePath,
      span: c.span,
      text: c.text,
      authority: {
        uid: reqs[0].payload.uid,
        mid: reqs[0].payload.mid,
        statement: reqs[0].payload.statement,
        rationale: reqs[0].payload.rationale,
      },
      trace,
    });
  }
  return { authorized, rejected };
}

function findCodeBoundary(
  node: IntentNode,
  nodeById: ReadonlyMap<string, IntentNode>,
): IntentNode<'CODE_BOUNDARY'> | undefined {
  for (const edgeId of node.incoming) {
    // (Implementation elided — the full source walks incoming edges and
    // resolves any CODE_BOUNDARY target.)
    void edgeId;
  }
  void nodeById;
  return undefined;
}

function traceFor(
  req: IntentNode<'REQUIREMENT'>,
  nodeById: ReadonlyMap<string, IntentNode>,
  edgeById: ReadonlyMap<string, IntentEdge>,
): TraceStep[] {
  // Walk incoming Parent/Implements edges from the requirement back to the
  // spec root. The specific edge is included in each step so that the
  // envelope can cite the annotation that minted it.
  void req;
  void nodeById;
  void edgeById;
  return [];
}

function enrichAuthority(
  uid: string,
  nodeById: ReadonlyMap<string, IntentNode>,
): AuthorizedChunk['authority'] {
  for (const node of nodeById.values()) {
    if (node.kind === 'REQUIREMENT' && node.payload.uid === uid) {
      return {
        uid: node.payload.uid,
        mid: node.payload.mid,
        statement: node.payload.statement,
        rationale: node.payload.rationale,
      };
    }
  }
  throw new Error(`Unknown authority UID ${uid}`);
}
