/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_building_a_deterministic_retrieval_guardrail_for_part3.ts
Description: Solutions and Explanations
==========================================
*/

// r[impl RETRIEVAL-GUARD-2]
// r[impl RETRIEVAL-GUARD-3]
// Thin wrapper over the Tracey MCP surface. We deliberately do not expose the
// vector store here: the vector store is a discovery mechanism, the intent
// graph is a source of truth. Keeping the two surfaces in separate modules
// makes it a compile-time error to accidentally ask the vector store about a
// requirement's normative text.

export interface TraceyRule {
  uid: string;
  title: string;
  statement: string;
  status: "Draft" | "Backlog" | "Approved" | "Active" | "Deleted";
  version: number;
}

export interface TraceyValidateResult {
  ok: boolean;
  errors: string[];
  warnings: string[];
}

export interface McpTransport {
  call<T>(tool: string, args: Record<string, unknown>): Promise<T>;
}

export class IntentGraphClient {
  private validated = false;
  private validateResult: TraceyValidateResult | null = null;

  constructor(private readonly transport: McpTransport) {}

  // r[impl RETRIEVAL-GUARD-2]
  // Runs once per session. Subsequent calls are idempotent so that a hot loop
  // over candidates does not spam the daemon. The guardrail aborts on errors
  // but tolerates warnings; the CI gate is stricter than the runtime.
  async ensureGraphConsistent(): Promise<TraceyValidateResult> {
    if (!this.validated) {
      this.validateResult = await this.transport.call<TraceyValidateResult>(
        "tracey_validate",
        {},
      );
      this.validated = true;
    }
    return this.validateResult!;
  }

  // r[impl RETRIEVAL-GUARD-3]
  // tracey_rule is the only permitted source of normative text.
  async fetchRule(uid: string): Promise<TraceyRule> {
    return this.transport.call<TraceyRule>("tracey_rule", { uid });
  }

  async fetchRules(uids: string[]): Promise<Map<string, TraceyRule>> {
    const entries = await Promise.all(
      uids.map(async (uid) => [uid, await this.fetchRule(uid)] as const),
    );
    return new Map(entries);
  }
}
