/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_building_a_deterministic_retrieval_guardrail_for_part4.ts
Description: Solutions and Explanations
==========================================
*/

// r[impl RETRIEVAL-GUARD-1]
// r[impl RETRIEVAL-GUARD-4]
// Retrieval guardrail. Vector search proposes; the intent graph disposes.

import { IntentGraphClient, TraceyRule } from "./IntentGraphClient";

export interface VectorCandidate {
  chunkId: string;
  filePath: string;
  excerpt: string;
  score: number;
  /** Requirement UIDs recovered by scanning the chunk's leading comments. */
  annotatedUids: string[];
}

export interface VectorSearch {
  search(instruction: string, topK: number): Promise<VectorCandidate[]>;
}

export type Disposition = "survived" | "pruned";

export interface GuardedResult {
  candidate: VectorCandidate;
  disposition: Disposition;
  reason: string;
  resolvedRules: TraceyRule[];
}

export interface GuardrailOptions {
  vectorStore: VectorSearch;
  intentGraph: IntentGraphClient;
  /** Optional override of the tokenizer, primarily for tests. */
  tokenize?: (text: string) => string[];
}

// Extracted so tests can assert the boundary in isolation.
// We do NOT use embeddings here. Vector similarity is probabilistic; the
// anchor test is deterministic. The two must not be conflated.
function defaultTokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9_\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2);
}

const STOPWORDS = new Set([
  "the", "and", "for", "with", "that", "this", "from", "into", "shall",
  "must", "should", "may", "when", "where", "while", "if", "then",
]);

function lexicalAnchors(text: string, tokenize: (t: string) => string[]): Set<string> {
  return new Set(tokenize(text).filter((t) => !STOPWORDS.has(t)));
}

function intersects(a: Set<string>, b: Set<string>): string | null {
  for (const t of a) {
    if (b.has(t)) return t;
  }
  return null;
}

export async function guardRetrieval(
  instruction: string,
  topK: number,
  options: GuardrailOptions,
): Promise<GuardedResult[]> {
  const tokenize = options.tokenize ?? defaultTokenize;

  // Phase 0: refuse to guard against an inconsistent graph.
  const validation = await options.intentGraph.ensureGraphConsistent();
  if (!validation.ok) {
    throw new Error(
      `Refusing to guard retrieval: intent graph is inconsistent. ` +
        `Errors: ${validation.errors.join("; ")}`,
    );
  }

  const candidates = await options.vectorStore.search(instruction, topK);
  const instructionAnchors = lexicalAnchors(instruction, tokenize);

  // Collect every UID mentioned by any candidate so we can batch the tracey_rule
  // lookups. One RPC round-trip per unique UID, not per candidate.
  const allUids = new Set<string>();
  for (const c of candidates) {
    for (const uid of c.annotatedUids) allUids.add(uid);
  }
  const rulesByUid = await options.intentGraph.fetchRules([...allUids]);

  const results: GuardedResult[] = [];
  for (const candidate of candidates) {
    // Branch point between discovery and validation:
    //  - If a candidate has no annotations at all, we prune. The vector store
    //    has no signal from the intent graph, so it cannot be trusted to
    //    shape the agent's subsequent edits. RATIONALE: a chunk with no
    //    trace link is by construction unreachable from any spec, and the
    //    agent would be reasoning about code that no requirement justifies.
    if (candidate.annotatedUids.length === 0) {
      results.push({
        candidate,
        disposition: "pruned",
        reason: "no requirement annotations recovered from chunk",
        resolvedRules: [],
      });
      continue;
    }

    const resolved: TraceyRule[] = [];
    let matchedAnchor: string | null = null;

    for (const uid of candidate.annotatedUids) {
      const rule = rulesByUid.get(uid);
      if (!rule) {
        // Should not happen because tracey_validate ran, but defensive.
        continue;
      }
      resolved.push(rule);
      if (matchedAnchor) continue;
      const ruleAnchors = lexicalAnchors(
        `${rule.title} ${rule.statement}`,
        tokenize,
      );
      matchedAnchor = intersects(instructionAnchors, ruleAnchors);
    }

    if (resolved.length === 0) {
      results.push({
        candidate,
        disposition: "pruned",
        reason: "annotated UIDs failed to resolve in the intent graph",
        resolvedRules: [],
      });
      continue;
    }

    if (matchedAnchor === null) {
      results.push({
        candidate,
        disposition: "pruned",
        reason:
          `no lexical anchor between instruction and any of ` +
          `[${resolved.map((r) => r.uid).join(", ")}]`,
        resolvedRules: resolved,
      });
      continue;
    }

    results.push({
      candidate,
      disposition: "survived",
      reason: `anchored on "${matchedAnchor}" via ${resolved
        .map((r) => r.uid)
        .join(", ")}`,
      resolvedRules: resolved,
    });
  }

  return results;
}

export function survivors(results: GuardedResult[]): GuardedResult[] {
  return results.filter((r) => r.disposition === "survived");
}
