/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_building_a_deterministic_retrieval_guardrail_for_part5.ts
Description: Solutions and Explanations
==========================================
*/

// r[verify RETRIEVAL-GUARD-1]
// r[verify RETRIEVAL-GUARD-2]
// r[verify RETRIEVAL-GUARD-4]
import { describe, it, expect, vi } from "vitest";
import {
  guardRetrieval,
  survivors,
  VectorCandidate,
} from "../../src/agent/RetrievalGuardrail";
import { IntentGraphClient } from "../../src/agent/IntentGraphClient";

function makeClient(
  ruleFor: Record<string, { title: string; statement: string }>,
): IntentGraphClient {
  const transport = {
    call: vi.fn(async (tool: string, args: any) => {
      if (tool === "tracey_validate") {
        return { ok: true, errors: [], warnings: [] };
      }
      if (tool === "tracey_rule") {
        const uid = args.uid as string;
        if (!ruleFor[uid]) throw new Error(`no rule ${uid}`);
        return {
          uid,
          title: ruleFor[uid].title,
          statement: ruleFor[uid].statement,
          status: "Approved",
          version: 1,
        };
      }
      throw new Error(`unknown tool ${tool}`);
    }),
  };
  return new IntentGraphClient(transport as any);
}

describe("guardRetrieval", () => {
  it("prunes a commentary candidate that shares surface vocabulary but points at no requirement", async () => {
    // r[verify RETRIEVAL-GUARD-1]
    // The vector store's top hit is a docs snippet that says "rate limit"; it
    // has NO annotations. The second hit is the real login() implementation,
    // annotated with RETRIEVAL-GUARD-3 whose statement talks about "throttling".
    const commentCandidate: VectorCandidate = {
      chunkId: "c1",
      filePath: "docs/commentary/rate-limiting.md",
      excerpt: "Rate limiting is a best practice for login endpoints.",
      score: 0.94,
      annotatedUids: [],
    };
    const implCandidate: VectorCandidate = {
      chunkId: "c2",
      filePath: "src/agent/login.ts",
      excerpt: "export function login(creds) { /* credential throttling */ }",
      score: 0.61,
      annotatedUids: ["RETRIEVAL-GUARD-3"],
    };
    const vectorStore = {
      search: vi.fn(async () => [commentCandidate, implCandidate]),
    };
    const intentGraph = makeClient({
      "RETRIEVAL-GUARD-3": {
        title: "Resolve normative text via Tracey MCP",
        statement: "The retrieval layer shall resolve every candidate's requirement UIDs via tracey_rule.",
      },
    });

    const results = await guardRetrieval("Add rate-limiting to the login endpoint", 5, {
      vectorStore,
      intentGraph,
    });

    expect(results).toHaveLength(2);
    expect(results[0].disposition).toBe("pruned");
    expect(results[0].reason).toMatch(/no requirement annotations/);
    expect(survivors(results).map((r) => r.candidate.chunkId)).toEqual(["c2"]);
  });

  it("aborts when tracey_validate reports errors", async () => {
    // r[verify RETRIEVAL-GUARD-2]
    const intentGraph = new IntentGraphClient({
      call: vi.fn(async () => ({ ok: false, errors: ["broken UID"], warnings: [] })),
    } as any);
    const vectorStore = { search: vi.fn(async () => []) };
    await expect(
      guardRetrieval("x", 1, { vectorStore, intentGraph }),
    ).rejects.toThrow(/intent graph is inconsistent/);
  });
});
