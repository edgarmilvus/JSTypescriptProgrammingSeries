/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_living_intent_nodes_versioning_and_drift_detectio_part11.ts
Description: Solutions and Explanations
==========================================
*/

// r[verify SBX-execute+2]
// r[verify SBX-read]
// This file exists to assert the POST-DRIFT-RESOLUTION state. It intentionally
// does NOT test the pre-drift behavior (unconditional execution), because that
// behavior is now non-conforming.
import { describe, it, expect } from "vitest";
import { executeRetrieved } from "../../src/sandbox/execute";

describe("executeRetrieved — post-drift, requirement SBX-execute+2", () => {
  it("refuses to execute unverified content", () => {
    expect(() => executeRetrieved("globalThis.__x = 1;", false)).toThrow(
      /Refusing to execute unverified/,
    );
  });

  it("executes content that the intent graph has verified", () => {
    executeRetrieved("globalThis.__y = 2;", true);
    expect((globalThis as any).__y).toBe(2);
  });
});
