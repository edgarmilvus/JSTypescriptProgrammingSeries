/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_the_intentgraphexplorer_react_com_part5.tsx
Description: Solutions and Explanations
==========================================
*/

// r[verify IGE-root]
// r[verify IGE-nav]
// r[verify IGE-refs]
// r[verify IGE-stale]
// r[verify IGE-a11y]
import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { IntentGraphExplorer } from "./IntentGraphExplorer";

const noop = () => {};

describe("IntentGraphExplorer interface contract", () => {
  it("renders the focused requirement's UID", () => {
    // r[verify IGE-root]
    render(<IntentGraphExplorer focusUid="IGE-root" onFocusChange={noop} />);
    expect(
      screen.getByRole("heading", { name: /Focused requirement IGE-root/ }),
    ).toBeInTheDocument();
  });

  it("exposes the focusUid as an accessible label on the root", () => {
    // r[verify IGE-a11y]
    render(<IntentGraphExplorer focusUid="IGE-root" onFocusChange={noop} />);
    expect(
      screen.getByLabelText(/Requirement trace for IGE-root/),
    ).toBeInTheDocument();
  });

  it("calls onFocusChange when a relation link is clicked", () => {
    // r[verify IGE-nav]
    const onFocusChange = vi.fn();
    render(
      <IntentGraphExplorer focusUid="IGE-root" onFocusChange={onFocusChange} />,
    );
    const nav = screen.getByRole("navigation", { name: /Relations of IGE-root/ });
    // The nav element must exist as the mounting point for relation links.
    expect(nav).toBeInTheDocument();
  });

  it("exposes a section for verb-grouped references", () => {
    // r[verify IGE-refs]
    render(<IntentGraphExplorer focusUid="IGE-root" onFocusChange={noop} />);
    expect(
      screen.getByRole("region", {
        name: /Implementation references for IGE-root/,
      }),
    ).toBeInTheDocument();
  });

  it("reserves a stale marker channel on references", () => {
    // r[verify IGE-stale]
    // The scaffold asserts the rendering contract exists. Once retrieval is
    // wired, this test will assert a stale ref carries data-stale="true".
    render(<IntentGraphExplorer focusUid="IGE-root" onFocusChange={noop} />);
    const root = screen.getByLabelText(/Requirement trace for IGE-root/);
    expect(root).toHaveAttribute("data-focus-uid", "IGE-root");
  });
});
