/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_schema-constrained_retrieval_plans_with_a_json_sc_part3.ts
Description: Solutions and Explanations
==========================================
*/

// r[impl AGENT-PLAN-SCHEMA]
export const RETRIEVAL_PROMPT = `You produce a RetrievalPlan as a single JSON object.

Rules:
  - The JSON MUST validate against the RetrievalPlan schema provided below.
  - Every UID you name in "relevantUids" MUST be one of the UIDs provided in
    the "availableUids" context. Do not invent UIDs.
  - For every UID in "relevantUids", provide exactly one sentence in
    "rationaleByUid" keyed by that UID.
  - "confidence" MUST be a number between 0 and 1 inclusive.

Emit JSON only. No prose, no code fences.`;
