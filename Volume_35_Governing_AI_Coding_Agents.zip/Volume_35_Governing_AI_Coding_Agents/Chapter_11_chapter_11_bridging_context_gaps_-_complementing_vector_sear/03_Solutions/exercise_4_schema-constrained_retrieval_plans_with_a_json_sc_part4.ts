/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_schema-constrained_retrieval_plans_with_a_json_sc_part4.ts
Description: Solutions and Explanations
==========================================
*/

// r[impl AGENT-PLAN-SCHEMA]
// r[impl AGENT-PLAN-ALLOWLIST]
// r[impl AGENT-PLAN-STATUS]
import Ajv, { ValidateFunction } from "ajv";
import schema from "./RetrievalPlan.schema.json";
import { IntentGraphClient } from "./IntentGraphClient";

export interface RetrievalPlan {
  instruction: string;
  relevantUids: string[];
  rationaleByUid: Record<string, string>;
  targetFiles: string[];
  confidence: number;
}

export type PlanValidationResult =
  | { ok: true; plan: RetrievalPlan }
  | { ok: false; errors: string[] };

const ajv = new Ajv({ allErrors: true, strict: true });
const validateSchema: ValidateFunction<RetrievalPlan> = ajv.compile(schema);

export async function validatePlan(
  raw: unknown,
  availableUids: Set<string>,
  intentGraph: IntentGraphClient,
): Promise<PlanValidationResult> {
  const errors: string[] = [];

  // Phase 1: structural conformance.
  if (!validateSchema(raw)) {
    for (const e of validateSchema.errors ?? []) {
      errors.push(`${e.instancePath || "/"} ${e.message ?? "invalid"}`);
    }
    // A structurally invalid plan cannot be trusted to have the fields we
    // need for later phases, so return now.
    return { ok: false, errors };
  }
  const plan = raw as RetrievalPlan;

  // Phase 2: allow-list.
  const unknown = plan.relevantUids.filter((uid) => !availableUids.has(uid));
  if (unknown.length > 0) {
    errors.push(
      `plan names UIDs outside availableUids: ${unknown.join(", ")}`,
    );
  }

  // Phase 3: rationale key parity.
  const rationaleKeys = Object.keys(plan.rationaleByUid).sort();
  const expectedKeys = [...plan.relevantUids].sort();
  const keysMatch =
    rationaleKeys.length === expectedKeys.length &&
    rationaleKeys.every((k, i) => k === expectedKeys[i]);
  if (!keysMatch) {
    errors.push(
      `rationaleByUid keys (${rationaleKeys.join(",")}) do not match ` +
        `relevantUids (${expectedKeys.join(",")})`,
    );
  }

  if (errors.length > 0) return { ok: false, errors };

  // Phase 4: status gate via the intent graph. This is the boundary at which
  // the plan transitions from "probabilistically generated" to
  // "deterministically verified". Everything upstream of this point is a
  // machine proposal; everything downstream is a checked assertion.
  const rules = await Promise.all(
    plan.relevantUids.map((uid) => intentGraph.fetchRule(uid)),
  );
  for (const rule of rules) {
    if (rule.status === "Backlog" || rule.status === "Draft") {
      errors.push(
        `requirement ${rule.uid} is STATUS: ${rule.status} and may not guide the agent`,
      );
    }
  }
  if (errors.length > 0) return { ok: false, errors };

  return { ok: true, plan };
}
