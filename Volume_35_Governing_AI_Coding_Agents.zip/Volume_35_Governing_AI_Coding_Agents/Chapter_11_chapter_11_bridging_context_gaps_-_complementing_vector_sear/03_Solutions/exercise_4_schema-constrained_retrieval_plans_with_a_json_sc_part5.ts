/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_schema-constrained_retrieval_plans_with_a_json_sc_part5.ts
Description: Solutions and Explanations
==========================================
*/

// r[verify AGENT-PLAN-SCHEMA]
// r[verify AGENT-PLAN-ALLOWLIST]
// r[verify AGENT-PLAN-STATUS]
import { describe, it, expect, vi } from "vitest";
import { validatePlan } from "./validatePlan";
import { IntentGraphClient } from "./IntentGraphClient";

const AVAILABLE = new Set(["SPEC-A", "SPEC-B", "SPEC-C"]);

function client(statuses: Record<string, "Active" | "Approved" | "Backlog" | "Draft">) {
  return new IntentGraphClient({
    call: vi.fn(async (_tool: string, args: any) => ({
      uid: args.uid,
      title: args.uid,
      statement: "s",
      status: statuses[args.uid] ?? "Active",
      version: 1,
    })),
  } as any);
}

const goodPlan = {
  instruction: "do x",
  relevantUids: ["SPEC-A"],
  rationaleByUid: { "SPEC-A": "because" },
  targetFiles: ["src/a.ts"],
  confidence: 0.7,
};

describe("validatePlan", () => {
  it("accepts a well-formed plan naming Active requirements", async () => {
    // r[verify AGENT-PLAN-SCHEMA]
    const r = await validatePlan(goodPlan, AVAILABLE, client({ "SPEC-A": "Active" }));
    expect(r.ok).toBe(true);
  });

  it("rejects a plan missing a required property", async () => {
    // r[verify AGENT-PLAN-SCHEMA]
    const { targetFiles, ...rest } = goodPlan;
    const r = await validatePlan(rest, AVAILABLE, client({ "SPEC-A": "Active" }));
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors.join(" ")).toMatch(/required/);
  });

  it("rejects a plan naming an unknown UID", async () => {
    // r[verify AGENT-PLAN-ALLOWLIST]
    const r = await validatePlan(
      { ...goodPlan, relevantUids: ["SPEC-Z"], rationaleByUid: { "SPEC-Z": "x" } },
      AVAILABLE,
      client({ "SPEC-Z": "Active" }),
    );
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors.join(" ")).toMatch(/SPEC-Z/);
  });

  it("rejects a plan whose rationale keys miss a UID", async () => {
    // r[verify AGENT-PLAN-SCHEMA]
    const r = await validatePlan(
      { ...goodPlan, relevantUids: ["SPEC-A", "SPEC-B"], rationaleByUid: { "SPEC-A": "x" } },
      AVAILABLE,
      client({ "SPEC-A": "Active", "SPEC-B": "Active" }),
    );
    expect(r.ok).toBe(false);
  });

  it("rejects confidence outside [0,1]", async () => {
    // r[verify AGENT-PLAN-SCHEMA]
    const r = await validatePlan({ ...goodPlan, confidence: 1.5 }, AVAILABLE, client({ "SPEC-A": "Active" }));
    expect(r.ok).toBe(false);
  });

  it("rejects a structurally valid plan whose requirement is Backlog", async () => {
    // r[verify AGENT-PLAN-STATUS]
    // This is the intent-graph gate. A plan can pass every structural check
    // and still be refused because the target requirement is not committed.
    const r = await validatePlan(goodPlan, AVAILABLE, client({ "SPEC-A": "Backlog" }));
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors.join(" ")).toMatch(/Backlog/);
  });
});
