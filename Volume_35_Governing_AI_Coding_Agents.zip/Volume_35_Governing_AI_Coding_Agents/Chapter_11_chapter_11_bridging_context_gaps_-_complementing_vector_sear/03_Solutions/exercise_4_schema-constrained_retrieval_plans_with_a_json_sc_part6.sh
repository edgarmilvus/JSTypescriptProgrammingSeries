# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: exercise_4_schema-constrained_retrieval_plans_with_a_json_sc_part6.sh
# Description: Solutions and Explanations
# ==========================================

# (a) Reproduce the failure.
tracey query validate --deny warnings
# Output: four errors as described.

# (b) Confirm the diagnosis incrementally.
tracey query status               # observe the 71% impl coverage
tracey query rule authn.session.ttl   # confirm the UID does not resolve
tracey query uncovered --prefix authn. # confirm the namespace is empty

# (c) Confirm the fix, in the same order the diagnostics were fixed.
tracey query validate
tracey query validate --deny warnings  # now exit code 0
tracey query status                    # coverage returns to 78%
tracey query uncovered --prefix auth.  # only genuinely-uncovered UIDs, if any
tracey query untested --prefix auth.   # same for tests
