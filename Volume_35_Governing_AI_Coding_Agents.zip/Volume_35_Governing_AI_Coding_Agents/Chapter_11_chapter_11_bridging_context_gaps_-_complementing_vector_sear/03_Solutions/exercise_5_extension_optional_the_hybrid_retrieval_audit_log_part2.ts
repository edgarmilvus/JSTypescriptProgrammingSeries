/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_extension_optional_the_hybrid_retrieval_audit_log_part2.ts
Description: Solutions and Explanations
==========================================
*/

// r[impl AUDIT-RECORD]
// r[impl AUDIT-VERSION-PIN]

export interface PinnedRule {
  /** Requirement UID as it appeared in the intent graph. */
  uid: string;
  /** Version suffix reported by tracey_rule at decision time. */
  version: number;
  /** STATUS reported at decision time. */
  status: string;
}

export interface CandidateConsidered {
  chunkId: string;
  filePath: string;
  score: number;
  annotatedUids: string[];
}

export interface SurvivedDisposition {
  kind: "survived";
  candidate: CandidateConsidered;
  /** The lexical anchor that justified survival. */
  anchor: string;
  pinnedRules: PinnedRule[];
}

export interface PrunedDisposition {
  kind: "pruned";
  candidate: CandidateConsidered;
  /** Machine-readable prune category, e.g. "no_annotations", "no_anchor". */
  category: "no_annotations" | "unresolved_uid" | "no_anchor" | "status_gate";
  /** Human-readable reason, safe to replay without the graph. */
  reason: string;
  pinnedRules: PinnedRule[];
}

export type Disposition = SurvivedDisposition | PrunedDisposition;

export interface AuditRecord {
  /** Schema version of the audit record itself, not of any requirement. */
  schemaVersion: 1;
  /** Wall-clock ISO-8601 timestamp of the decision. */
  decidedAt: string;
  /** Verbatim instruction the retrieval was performed for. */
  instruction: string;
  /** SHA-256 of the vector store's snapshot identifier, if the store exposes one. */
  vectorSnapshotHash: string | null;
  /** Every candidate the vector store returned, in returned order. */
  candidates: Disposition[];
}
