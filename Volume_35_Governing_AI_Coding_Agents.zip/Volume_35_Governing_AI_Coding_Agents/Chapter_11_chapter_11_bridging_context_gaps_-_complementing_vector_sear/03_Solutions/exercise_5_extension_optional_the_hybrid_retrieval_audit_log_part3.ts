/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_extension_optional_the_hybrid_retrieval_audit_log_part3.ts
Description: Solutions and Explanations
==========================================
*/

// r[impl AUDIT-RECORD]
// r[impl AUDIT-VERSION-PIN]
import { appendFile } from "node:fs/promises";
import { AuditRecord } from "./AuditRecord";

const AUDIT_PATH = "var/audit/retrievals.ndjson";

export async function appendAuditRecord(record: AuditRecord): Promise<void> {
  // NDJSON: exactly one JSON value per line, newline-terminated. This is what
  // makes the log both streamable and greppable. It also means a partial write
  // corrupts at most one record, not the whole file.
  const line = JSON.stringify(record) + "\n";
  await appendFile(AUDIT_PATH, line, { encoding: "utf8", flag: "a" });
}
