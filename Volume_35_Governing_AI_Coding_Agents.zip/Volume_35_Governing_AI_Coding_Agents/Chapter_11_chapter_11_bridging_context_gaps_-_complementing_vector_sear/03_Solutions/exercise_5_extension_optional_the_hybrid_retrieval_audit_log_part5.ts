/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_extension_optional_the_hybrid_retrieval_audit_log_part5.ts
Description: Solutions and Explanations
==========================================
*/

// r[verify AUDIT-RECORD]
// r[verify AUDIT-VERSION-PIN]
// Replays a FROZEN fixture rather than the live graph. The intent graph evolves
// as requirements gain versions; the fixture is the historical record of what
// the graph looked like at decision time, and the test asserts the record is
// internally consistent against that frozen state.
import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { replayAudit } from "./replayAudit";

describe("audit log replay", () => {
  it("replays records with pinned versions intact", () => {
    const fixture = readFileSync(
      "tests/fixtures/audit/retrievals.frozen.ndjson",
      "utf8",
    );
    const records = replayAudit(fixture);

    expect(records.length).toBeGreaterThan(0);
    for (const rec of records) {
      expect(rec.schemaVersion).toBe(1);
      for (const d of rec.candidates) {
        for (const rule of d.pinnedRules) {
          expect(rule.uid).toMatch(/^[A-Z0-9-]+/);
          expect(rule.version).toBeGreaterThanOrEqual(1);
        }
      }
      // Every survived disposition must name an anchor; every pruned one must
      // name a category. This is the internal-consistency invariant the
      // regulator cares about.
      for (const d of rec.candidates) {
        if (d.kind === "survived") expect(d.anchor.length).toBeGreaterThan(0);
        else expect(d.category.length).toBeGreaterThan(0);
      }
    }
  });
});
