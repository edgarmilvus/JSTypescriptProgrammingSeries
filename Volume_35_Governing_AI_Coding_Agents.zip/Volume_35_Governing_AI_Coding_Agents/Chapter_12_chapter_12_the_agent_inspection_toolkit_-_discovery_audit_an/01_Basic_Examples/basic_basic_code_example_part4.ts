/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// src/agent/tracey-inspector.ts
// ---------------------------------------------------------------------------
// TraceyInspector — the Agent Inspection Toolkit facade.
//
// This class is the ONLY surface a Supervisor agent uses to learn about the
// workspace. Worker agents never touch the filesystem directly; they consume
// the GovernanceReport produced by inspect(). This keeps every worker's
// policy-envelope byte-identical and observable in the audit log.
// ---------------------------------------------------------------------------

import type { Client } from "@modelcontextprotocol/sdk/client/index.js";

/**
 * The immutable facts a Supervisor publishes to its Worker Agent Pool.
 * Everything downstream is a pure function of this object.
 */
export interface GovernanceReport {
  readonly workspaceRoot: string;
  readonly specs: ReadonlyArray<{ name: string; prefix: string }>;
  readonly impls: ReadonlyArray<{ name: string; spec: string }>;
  readonly coverage: {
    readonly total: number;
    readonly implemented: number;
    readonly verified: number;
    readonly percentImpl: number;
  };
  readonly uncovered: ReadonlyArray<string>;
  readonly untested: ReadonlyArray<string>;
  readonly stale: ReadonlyArray<string>;
  readonly validationErrors: ReadonlyArray<string>;
  /** Worker agents must refuse any edit that would push percentImpl below this. */
  readonly coverageFloor: number;
}

/**
 * A tiny structural wrapper around the MCP client. We narrow the type so the
 * rest of the code never has to think about JSON-RPC framing, content blocks,
 * or the difference between a tool result and a tool error.
 */
type McpToolResult = {
  content: Array<{ type: "text"; text: string }>;
  isError?: boolean;
};

/** Parse the first text content block of an MCP tool result as JSON. */
function parseToolText(result: McpToolResult): unknown {
  const first = result.content.find((c) => c.type === "text");
  if (!first || first.type !== "text") {
    throw new Error("Tracey MCP returned a non-text content block");
  }
  return JSON.parse(first.text);
}

/**
 * The inspector. Constructed with an already-connected MCP client scoped to
 * the `tracey` server. Static, dependency-free, and trivially stubbable.
 */
export class TraceyInspector {
  public constructor(
    private readonly client: Client,
    /** The floor below which the Supervisor will not let workers fall. */
    private readonly configuredFloor = 0.85,
  ) {}

  /** Call a Tracey MCP tool and return its parsed text payload. */
  private async call<T>(name: string, args: Record<string, unknown> = {}): Promise<T> {
    const result = (await this.client.callTool({
      name,
      arguments: args,
    })) as McpToolResult;
    if (result.isError) {
      throw new Error(`Tracey tool ${name} failed: ${JSON.stringify(result.content)}`);
    }
    return parseToolText(result) as T;
  }

  /** Discover workspace root, spec names, inferred prefixes, impls. */
  public async discoverWorkspace(): Promise<{
    root: string;
    specs: Array<{ name: string; prefix: string }>;
    impls: Array<{ name: string; spec: string }>;
  }> {
    // tracey_config returns the active configuration parsed from
    // .config/tracey/config.styx.
    const cfg = await this.call<{
      root: string;
      specs: Array<{ name: string; prefix: string }>;
      impls: Array<{ name: string; spec: string }>;
    }>("tracey_config");
    return cfg;
  }

  /** Pull coverage statistics for the primary spec/impl pair. */
  public async auditCoverage(): Promise<{
    total: number;
    implemented: number;
    verified: number;
    percentImpl: number;
    uncovered: string[];
    untested: string[];
  }> {
    // tracey_status returns global coverage; uncovered/untested give UIDs.
    const status = await this.call<{
      coverage: { total: number; implemented: number; verified: number; percentImpl: number };
    }>("tracey_status");
    const uncovered = await this.call<{ uids: string[] }>("tracey_uncovered");
    const untested = await this.call<{ uids: string[] }>("tracey_untested");
    return {
      ...status.coverage,
      uncovered: uncovered.uids,
      untested: untested.uids,
    };
  }

  /** Pull stale references — code annotated against an older rule version. */
  public async auditDrift(): Promise<string[]> {
    const stale = await this.call<{ uids: string[] }>("tracey_stale");
    return stale.uids;
  }

  /** Run the semantic linter and return any error-level findings. */
  public async validate(): Promise<string[]> {
    // tracey_validate fails on cycles/orphans; we surface them as strings.
    const report = await this.call<{ errors: string[]; warnings: string[] }>(
      "tracey_validate",
    );
    return [...report.errors, ...report.warnings];
  }

  /**
   * The single public entry point. Runs all four audits in a deterministic
   * order, then packages them into an immutable GovernanceReport.
   */
  public async inspect(): Promise<GovernanceReport> {
    const workspace = await this.discoverWorkspace();
    const coverage = await this.auditCoverage();
    const stale = await this.auditDrift();
    const errors = await this.validate();

    // Structural freeze: nothing downstream may mutate the envelope.
    const report: GovernanceReport = {
      workspaceRoot: workspace.root,
      specs: Object.freeze([...workspace.specs]),
      impls: Object.freeze([...workspace.impls]),
      coverage: Object.freeze({
        total: coverage.total,
        implemented: coverage.implemented,
        verified: coverage.verified,
        percentImpl: coverage.percentImpl,
      }),
      uncovered: Object.freeze([...coverage.uncovered]),
      untested: Object.freeze([...coverage.untested]),
      stale: Object.freeze([...stale]),
      validationErrors: Object.freeze([...errors]),
      coverageFloor: this.configuredFloor,
    };
    return Object.freeze(report);
  }
}
