/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

// src/agent/tracey-inspector.test.ts
import { describe, expect, it, vi } from "vitest";
import { TraceyInspector, type GovernanceReport } from "./tracey-inspector";

/**
 * Build a stub MCP client whose `callTool` returns canned text blocks.
 * This is the canonical way to test MCP-consuming code in CI: no sockets,
 * no daemon, no flakiness.
 */
function makeStubClient(
  responses: Record<string, unknown>,
): { callTool: (req: { name: string }) => Promise<unknown> } {
  return {
    callTool: vi.fn(async ({ name }: { name: string }) => {
      if (!(name in responses)) {
        throw new Error(`Unexpected tool call: ${name}`);
      }
      return {
        content: [{ type: "text", text: JSON.stringify(responses[name]) }],
      };
    }),
  };
}

describe("TraceyInspector", () => {
  it("produces a frozen GovernanceReport from MCP tool responses", async () => {
    const client = makeStubClient({
      tracey_config: {
        root: "/repo/nimbus-auth",
        specs: [{ name: "nimbus-auth", prefix: "r" }],
        impls: [{ name: "edge-workers", spec: "nimbus-auth" }],
      },
      tracey_status: {
        coverage: { total: 3, implemented: 2, verified: 1, percentImpl: 66.7 },
      },
      tracey_uncovered: { uids: ["AUTH-TENANT-001"] },
      tracey_untested: { uids: ["AUTH-SESSION-002", "AUTH-TENANT-001"] },
      tracey_stale: { uids: ["AUTH-SESSION-001"] },
      tracey_validate: { errors: [], warnings: ["Prefix 'h2' unknown in src/edge/foo.ts"] },
    });

    const inspector = new TraceyInspector(client as never, 0.9);
    const report: GovernanceReport = await inspector.inspect();

    expect(report.workspaceRoot).toBe("/repo/nimbus-auth");
    expect(report.specs).toHaveLength(1);
    expect(report.coverage.percentImpl).toBeCloseTo(66.7);
    expect(report.uncovered).toEqual(["AUTH-TENANT-001"]);
    expect(report.stale).toEqual(["AUTH-SESSION-001"]);
    expect(report.coverageFloor).toBe(0.9);

    // The envelope must be immutable so worker agents can't drift it.
    expect(Object.isFrozen(report)).toBe(true);
    expect(Object.isFrozen(report.coverage)).toBe(true);
    expect(() => {
      (report as unknown as { workspaceRoot: string }).workspaceRoot = "/tmp";
    }).toThrow();
  });

  it("propagates Tracey tool errors instead of silently returning partial data", async () => {
    const client = {
      callTool: vi.fn(async () => ({
        content: [{ type: "text", text: "boom" }],
        isError: true,
      })),
    };
    const inspector = new TraceyInspector(client as never);
    await expect(inspector.inspect()).rejects.toThrow(/tracey_config failed/);
  });
});
