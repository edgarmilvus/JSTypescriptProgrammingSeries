/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

import { createHash } from "node:crypto";
import { randomUUID } from "node:crypto";

/**
 * ReceiptLedger
 *
 * Persists {@link GovernanceReceipt}s and computes their deterministic hash.
 * The hash is the load-bearing primitive: an auditor must be able to
 * recompute it from the logged payload on any machine, at any time.
 *
 * @relation(SENTINEL-RECEIPT-001, scope=class)
 * @relation(SENTINEL-RECEIPT-002, scope=class)
 */
export class ReceiptLedger {
  private sequence = 0;
  private readonly receipts = new Map<string, GovernanceReceipt>();

  constructor(private readonly store: ReceiptStore) {}

  /**
   * Issue a new receipt, computing its hash over a canonicalised payload.
   * @relation(SENTINEL-RECEIPT-002, scope=function)
   */
  public async issue(
    draft: Omit<GovernanceReceipt, "receiptId" | "preflightSequence" | "issuedAt" | "receiptHash">,
  ): Promise<GovernanceReceipt> {
    // Step 1: Assign identity and monotonic ordering. Sequence is per-gateway,
    // not per-tenant — tenants can be added without invalidating the log.
    const receiptId = randomUUID();
    const preflightSequence = ++this.sequence;
    const issuedAt = new Date().toISOString();

    const withoutHash = { ...draft, receiptId, preflightSequence, issuedAt };

    // Step 2: Canonicalise. Sorted keys, UTF-8, no floats allowed.
    const canonical = canonicalise(withoutHash);

    // Step 3: blake3 is preferred for its speed and wide availability in
    // Node's ecosystem; the CLI uses blake3 too, so hashing is consistent.
    const receiptHash = createHash("blake3").update(canonical, "utf8").digest("hex");

    const receipt: GovernanceReceipt = { ...withoutHash, receiptHash };

    // Step 4: Persist before returning. If the store is down, the caller
    // never sees a receipt and therefore never sees a lease.
    await this.store.append(receipt);
    this.receipts.set(receiptId, receipt);
    return receipt;
  }

  public async get(receiptId: string): Promise<GovernanceReceipt | undefined> {
    return this.receipts.get(receiptId) ?? (await this.store.read(receiptId));
  }
}

/**
 * Canonical serialisation: sorted keys, no floating-point numbers allowed.
 * @relation(SENTINEL-RECEIPT-002, scope=function)
 */
export function canonicalise(value: unknown): string {
  if (typeof value === "number" && !Number.isInteger(value)) {
    throw new Error("Receipts forbid floating-point numbers (non-deterministic)");
  }
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalise).join(",")}]`;
  const entries = Object.entries(value as Record<string, unknown>).sort(([a], [b]) => (a < b ? -1 : 1));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalise(v)}`).join(",")}}`;
}

export interface ReceiptStore {
  append(receipt: GovernanceReceipt): Promise<void>;
  read(receiptId: string): Promise<GovernanceReceipt | undefined>;
}
