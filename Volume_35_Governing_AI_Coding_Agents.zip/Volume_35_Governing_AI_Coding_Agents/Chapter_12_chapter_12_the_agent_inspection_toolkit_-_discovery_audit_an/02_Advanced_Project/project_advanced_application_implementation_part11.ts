/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part11.ts
Description: Advanced Application Implementation
==========================================
*/

import { Router, Request, Response } from "express";

/**
 * POST /v1/workspaces/:workspaceId/inspect
 *
 * The single entry point for agent-facing preflight. Responsibilities:
 *   1. Authenticate the bearer token → (tenantId, agentPrincipal).
 *   2. Verify tenant ownership of the workspace (SENTINEL-SESSION-002).
 *   3. Delegate to the workspace's PreflightOrchestrator.
 *   4. Return the receipt; HTTP status mirrors `verdict.decision`.
 *
 * @relation(SENTINEL-SESSION-002, scope=function)
 */
export function inspectionRoutes(deps: RouteDeps): Router {
  const router = Router();

  router.post("/v1/workspaces/:workspaceId/inspect", async (req: Request, res: Response) => {
    // Step 1: Identify the caller.
    const auth = deps.auth.fromBearer(req.header("authorization"));
    if (!auth) return res.status(401).json({ error: "unauthenticated" });

    // Step 2: Authorise — the workspace must belong to this tenant.
    const owned = await deps.workspaces.isOwnedBy(req.params.workspaceId, auth.tenantId);
    if (!owned) {
      return res.status(403).json({ error: "workspace_not_owned_by_tenant" });
    }

    // Step 3: Extract the agent's declared scope of work. Agents must tell us
    // up-front which requirement UIDs they intend to touch, otherwise we can
    // only classify global hazards (still useful, but weaker).
    const { declaredScopeUids = [], declaredScopePath } = req.body ?? {};

    // Step 4: Delegate to the orchestrator held by the per-workspace
    // connection pool.
    const orchestrator = await deps.orchestrators.forWorkspace(req.params.workspaceId);

    try {
      const receipt = await orchestrator.run({
        tenantId: auth.tenantId,
        workspaceId: req.params.workspaceId,
        agentPrincipal: auth.principal,
        declaredScopeUids,
        declaredScopePath,
      });

      // Step 5: HTTP status mirrors the verdict. A `deny` is not an error
      // in the transport sense — it is the correct, expected result of
      // running the inspect protocol against an unhealthy graph.
      const status = receipt.verdict.decision === "allow" ? 200 : 409;
      return res.status(status).json(receipt);
    } catch (err) {
      deps.logger.error({ err, workspaceId: req.params.workspaceId }, "preflight failed");
      // Infrastructure failure is 500, distinct from a governance denial.
      return res.status(500).json({ error: "preflight_infrastructure_failure" });
    }
  });

  return router;
}

interface RouteDeps {
  auth: { fromBearer(header: string | undefined): { tenantId: string; principal: string } | null };
  workspaces: { isOwnedBy(workspaceId: string, tenantId: string): Promise<boolean> };
  orchestrators: { forWorkspace(workspaceId: string): Promise<PreflightOrchestrator> };
  logger: { error(ctx: unknown, msg: string): void };
}
