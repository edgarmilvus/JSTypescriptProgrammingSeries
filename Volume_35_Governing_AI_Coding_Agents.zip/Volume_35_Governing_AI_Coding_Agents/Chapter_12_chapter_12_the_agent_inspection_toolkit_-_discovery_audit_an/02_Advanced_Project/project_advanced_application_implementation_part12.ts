/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/hazard-classifier.spec.ts
import { describe, it, expect } from "vitest";
import { HazardClassifier } from "../src/inspection/HazardClassifier";

// @relation(SENTINEL-AUDIT-001, role=Verifies)
describe("HazardClassifier.classify — uncovered in scope", () => {
  const classifier = new HazardClassifier();

  it("raises an error when an uncovered UID is inside the declared scope", () => {
    const hazards = classifier.classify({
      ctx: {
        tenantId: "t1",
        workspaceId: "w1",
        agentPrincipal: "cursor@acme",
        declaredScopeUids: ["AUTH-001"],
      },
      uncovered: ["AUTH-001", "AUTH-002"],
      untested: [],
      stale: [],
      validationOutput: "No errors found.",
    });

    const inScope = hazards.find((h) => h.code === "UNCOVERED_IN_SCOPE");
    expect(inScope).toBeDefined();
    expect(inScope!.severity).toBe("error");
    // AUTH-002 is uncovered but out of scope — it must NOT appear here.
    expect(inScope!.requirementUids).toEqual(["AUTH-001"]);
  });

  it("does not raise UNCOVERED_IN_SCOPE when all uncovered UIDs are out of scope", () => {
    const hazards = classifier.classify({
      ctx: {
        tenantId: "t1",
        workspaceId: "w1",
        agentPrincipal: "cursor@acme",
        declaredScopeUids: ["AUTH-001"],
      },
      uncovered: ["AUTH-002"],
      untested: [],
      stale: [],
      validationOutput: "No errors found.",
    });
    expect(hazards.find((h) => h.code === "UNCOVERED_IN_SCOPE")).toBeUndefined();
  });
});

// @relation(SENTINEL-AUDIT-002, role=Verifies)
describe("HazardClassifier.classify — missing verification", () => {
  const classifier = new HazardClassifier();

  it("escalates MISSING_VERIFICATION to error when UID is in scope", () => {
    const hazards = classifier.classify({
      ctx: { tenantId: "t1", workspaceId: "w1", agentPrincipal: "claude@acme", declaredScopeUids: ["X-1"] },
      uncovered: [],
      untested: ["X-1"],
      stale: [],
      validationOutput: "No errors found.",
    });
    const h = hazards.find((x) => x.code === "MISSING_VERIFICATION");
    expect(h!.severity).toBe("error");
  });

  it("keeps MISSING_VERIFICATION as a warning when UID is out of scope", () => {
    const hazards = classifier.classify({
      ctx: { tenantId: "t1", workspaceId: "w1", agentPrincipal: "claude@acme", declaredScopeUids: [] },
      uncovered: [],
      untested: ["X-1"],
      stale: [],
      validationOutput: "No errors found.",
    });
    const h = hazards.find((x) => x.code === "MISSING_VERIFICATION");
    expect(h!.severity).toBe("warning");
  });
});

// @relation(SENTINEL-AUDIT-003, role=Verifies)
describe("HazardClassifier.classify — stale references", () => {
  it("always raises a blocking STALE_REFERENCE hazard", () => {
    const classifier = new HazardClassifier();
    const hazards = classifier.classify({
      ctx: { tenantId: "t1", workspaceId: "w1", agentPrincipal: "codex@acme", declaredScopeUids: [] },
      uncovered: [],
      untested: [],
      stale: ["CH-001"],
      validationOutput: "No errors found.",
    });
    expect(hazards.find((h) => h.code === "STALE_REFERENCE")!.severity).toBe("error");
  });
});

// @relation(SENTINEL-AUDIT-005, role=Verifies)
describe("HazardClassifier.classify — validation gate", () => {
  it("raises VALIDATION_FAILED when tracey_validate reports errors", () => {
    const classifier = new HazardClassifier();
    const hazards = classifier.classify({
      ctx: { tenantId: "t1", workspaceId: "w1", agentPrincipal: "codex@acme", declaredScopeUids: [] },
      uncovered: [],
      untested: [],
      stale: [],
      validationOutput: "Error: broken reference in src/auth.rs:88",
    });
    expect(hazards.find((h) => h.code === "VALIDATION_FAILED")!.severity).toBe("error");
  });
});
