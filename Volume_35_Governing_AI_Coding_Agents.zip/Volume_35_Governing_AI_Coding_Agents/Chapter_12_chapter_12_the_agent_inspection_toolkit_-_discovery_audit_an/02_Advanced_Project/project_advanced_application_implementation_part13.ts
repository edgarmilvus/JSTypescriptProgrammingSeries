/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part13.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/receipt-ledger.spec.ts
import { describe, it, expect } from "vitest";
import { ReceiptLedger, canonicalise, ReceiptStore } from "../src/receipts/ReceiptLedger";

// @relation(SENTINEL-RECEIPT-002, role=Verifies)
describe("canonicalise", () => {
  it("sorts object keys lexicographically", () => {
    expect(canonicalise({ b: 1, a: 2 })).toBe('{"a":2,"b":1}');
  });

  it("rejects floating-point numbers", () => {
    expect(() => canonicalise({ x: 1.5 })).toThrow(/floating-point/);
  });

  it("produces identical output for nested objects regardless of insertion order", () => {
    const a = { x: { q: 1, p: 2 }, y: [1, 2] };
    const b = { y: [1, 2], x: { p: 2, q: 1 } };
    expect(canonicalise(a)).toBe(canonicalise(b));
  });
});

// @relation(SENTINEL-RECEIPT-002, role=Verifies)
describe("ReceiptLedger — deterministic hashing", () => {
  it("yields identical hashes for byte-identical payloads", async () => {
    const store = makeInMemoryStore();
    const ledgerA = new ReceiptLedger(store);
    const ledgerB = new ReceiptLedger(store);

    const draft = {
      tenantId: "t1", workspaceId: "w1", agentPrincipal: "cursor@acme",
      workspaceSnapshotDigest: "abc",
      configuration: { specs: [], rawOutput: "" },
      baseline: { perSpecImpl: [], totalRequirements: 0, coveredRequirements: 0 },
      uncovered: [], untested: [], stale: [], hydratedRules: [],
      verdict: { decision: "allow" as const, hazards: [] },
    };

    const rA = await ledgerA.issue({ ...draft });
    const rB = await ledgerB.issue({ ...draft });

    // The hash excludes identity metadata so that identical graph states
    // certify identically.
    const stripped = (r: any) => {
      const { receiptId, preflightSequence, issuedAt, receiptHash, ...rest } = r;
      return rest;
    };
    expect(canonicalise(stripped(rA))).toBe(canonicalise(stripped(rB)));
  });
});

function makeInMemoryStore(): ReceiptStore {
  const rows: any[] = [];
  return {
    async append(r) { rows.push(r); },
    async read(id) { return rows.find((r) => r.receiptId === id); },
  };
}
