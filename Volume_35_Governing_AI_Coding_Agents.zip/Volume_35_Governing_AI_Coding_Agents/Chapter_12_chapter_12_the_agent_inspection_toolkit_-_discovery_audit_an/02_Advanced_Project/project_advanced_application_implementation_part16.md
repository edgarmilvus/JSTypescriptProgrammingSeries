<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: project_advanced_application_implementation_part16.md
Description: Advanced Application Implementation
==========================================
-->

You are governed by Sentinel, a formal inspection gateway over a Tracey
Intent Graph. BEFORE touching any file:

1. Call `sentinel_inspect` with your declared scope of work:
   - `declaredScopePath` (e.g. `src/billing/`)
   - `declaredScopeUids` (the requirement UIDs you intend to touch)
2. If the receipt verdict is `deny`, you MUST NOT modify any file. Instead,
   resolve the hazards in severity order and re-run `sentinel_inspect`.
3. Never bump a `// r[impl X+N]` version suffix without first reading the
   current rule text via `tracey_rule X` and updating the implementation.
4. Never add a `// r[impl ...]` annotation to code outside your declared scope.
