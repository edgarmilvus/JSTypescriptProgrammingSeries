/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * TraceyMcpClient
 *
 * A minimal, typed JSON-RPC 2.0 client for the Tracey MCP stdio transport.
 * Sentinel does not speak MCP over HTTP directly to agents — it hosts one
 * long-lived stdio session per workspace and multiplexes agent requests
 * across it. This keeps daemon startup cost amortised across tenants.
 *
 * @remarks
 * Tracey's MCP server auto-starts the daemon if it is not already running.
 * The client therefore treats "daemon not running" as a normal cold-start
 * path rather than an error.
 */

import { spawn, ChildProcessWithoutNullStreams } from "node:child_process";
import { createInterface, Interface } from "node:readline";
import { EventEmitter } from "node:events";

/** JSON-RPC request envelope. */
interface JsonRpcRequest {
  jsonrpc: "2.0";
  id: number;
  method: string;
  params?: Record<string, unknown>;
}

/** JSON-RPC success response. */
interface JsonRpcResponse<T> {
  jsonrpc: "2.0";
  id: number;
  result: T;
}

/** Result payload returned by every Tracey MCP tool call. */
export interface TraceyToolResult {
  /** Human-readable text body, per Tracey's documented response format. */
  content: Array<{ type: "text"; text: string }>;
  /** Optional structured envelope when Tracey upgrades the protocol. */
  structuredContent?: Record<string, unknown>;
  /** MCP-level error flag. */
  isError?: boolean;
}

/**
 * A single workspace's Tracey MCP session.
 *
 * @relation(SENTINEL-SESSION-001, scope=file)
 */
export class TraceyMcpClient extends EventEmitter {
  private proc: ChildProcessWithoutNullStreams | null = null;
  private rl: Interface | null = null;
  private nextId = 1;
  private readonly pending = new Map<number, {
    resolve: (value: TraceyToolResult) => void;
    reject: (err: Error) => void;
    timer: NodeJS.Timeout;
  }>();

  private static readonly DEFAULT_TIMEOUT_MS = 20_000;

  constructor(
    private readonly workspaceRoot: string,
    private readonly workspaceId: string,
  ) {
    super({ captureRejections: true });
  }

  /**
   * @relation(SENTINEL-SESSION-002, scope=function)
   */
  public async connect(): Promise<void> {
    if (this.proc) return;

    // Step 1: Spawn the Tracey MCP bridge as a child process. Tracey will
    // auto-start the daemon if it is not already running for this workspace.
    this.proc = spawn("tracey", ["mcp"], {
      cwd: this.workspaceRoot,
      stdio: ["pipe", "pipe", "pipe"],
    });

    // Step 2: Frame inbound messages one line at a time. The MCP stdio
    // transport is line-delimited JSON, not length-prefixed.
    this.rl = createInterface({ input: this.proc.stdout });
    this.rl.on("line", (line) => this.onLine(line));

    // Step 3: Forward stderr to the event bus so ops can trace daemon logs.
    this.proc.stderr.on("data", (chunk: Buffer) => {
      this.emit("stderr", chunk.toString("utf8"));
    });

    // Step 4: Detect transport death so we can reject in-flight requests
    // rather than hanging forever.
    this.proc.on("exit", (code) => {
      this.emit("exit", code);
      for (const [id, entry] of this.pending) {
        clearTimeout(entry.timer);
        entry.reject(new Error(`Tracey MCP exited during request ${id}`));
      }
      this.pending.clear();
      this.proc = null;
    });

    // Step 5: Perform the MCP initialize handshake. Sentinel always
    // advertises its workspace ID as part of the clientInfo so tracey logs
    // can correlate sessions to tenants.
    await this.call("initialize", {
      protocolVersion: "2025-06-18",
      clientInfo: { name: "sentinel-gateway", version: "1.4.0" },
    });
  }

  /**
   * Invoke a Tracey MCP tool by name.
   *
   * @param tool - One of Tracey's documented tool names, e.g. `tracey_status`.
   * @param args - Optional tool arguments.
   */
  public async tool<T = TraceyToolResult>(
    tool: string,
    args: Record<string, unknown> = {},
  ): Promise<T> {
    return this.call<T>(`tools/call`, { name: tool, arguments: args });
  }

  /**
   * @relation(SENTINEL-SESSION-002, scope=function)
   */
  public async disconnect(): Promise<void> {
    if (!this.proc) return;
    this.proc.stdin.end();
    await new Promise<void>((resolve) => {
      this.proc!.once("exit", () => resolve());
      this.proc!.kill("SIGTERM");
    });
    this.proc = null;
    this.rl?.close();
    this.rl = null;
  }

  // ---------------------------------------------------------------------
  // Internal JSON-RPC machinery
  // ---------------------------------------------------------------------

  private async call<T>(
    method: string,
    params?: Record<string, unknown>,
  ): Promise<T> {
    if (!this.proc) {
      throw new Error(`TraceyMcpClient not connected for workspace ${this.workspaceId}`);
    }
    const id = this.nextId++;
    const payload: JsonRpcRequest = { jsonrpc: "2.0", id, method, params };

    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Tracey MCP timeout after ${TraceyMcpClient.DEFAULT_TIMEOUT_MS}ms (${method})`));
      }, TraceyMcpClient.DEFAULT_TIMEOUT_MS);

      this.pending.set(id, {
        resolve: resolve as (value: TraceyToolResult) => void,
        reject,
        timer,
      });
      this.proc!.stdin.write(JSON.stringify(payload) + "\n");
    });
  }

  private onLine(line: string): void {
    if (!line.trim()) return;
    let parsed: JsonRpcResponse<unknown> | { error: { message: string }; id: number };
    try {
      parsed = JSON.parse(line);
    } catch {
      this.emit("protocol_error", line);
      return;
    }
    const id = (parsed as { id: number }).id;
    const entry = this.pending.get(id);
    if (!entry) return;
    clearTimeout(entry.timer);
    this.pending.delete(id);

    if ("error" in parsed) {
      entry.reject(new Error((parsed as { error: { message: string } }).error.message));
    } else {
      entry.resolve((parsed as JsonRpcResponse<TraceyToolResult>).result);
    }
  }
}
