/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * Shared type surface for the preflight protocol.
 * These types are deliberately serialisable — the receipt ledger stores them
 * verbatim after canonicalisation.
 */

/** A hazard raised by the classifier. */
export interface Hazard {
  /** Machine-readable identifier, e.g. `UNCOVERED_IN_SCOPE`. */
  code: HazardCode;
  /** Human text meant for the agent, not for the end-user UI. */
  message: string;
  /** `info` | `warning` | `error`. `error` blocks the mutation lease. */
  severity: "info" | "warning" | "error";
  /** Requirement UIDs this hazard pertains to, if any. */
  requirementUids?: string[];
}

export type HazardCode =
  | "CONFIG_EMPTY"
  | "UNCOVERED_IN_SCOPE"
  | "MISSING_VERIFICATION"
  | "STALE_REFERENCE"
  | "VALIDATION_FAILED"
  | "TENANT_MISMATCH";

/** Envelope describing a workspace's Tracey configuration. */
export interface ConfigurationEnvelope {
  specs: Array<{ name: string; prefixes: string[]; implNames: string[] }>;
  rawOutput: string;
}

/** Coverage baseline captured at Discovery time. */
export interface BaselineMetrics {
  perSpecImpl: Array<{ specImpl: string; covered: number; total: number; percent: number }>;
  totalRequirements: number;
  coveredRequirements: number;
}

/** The final verdict returned to the agent. */
export interface PreflightVerdict {
  decision: "allow" | "deny";
  hazards: Hazard[];
}

/** The complete receipt persisted for the tenant's audit ledger. */
export interface GovernanceReceipt {
  receiptId: string;
  preflightSequence: number;
  workspaceId: string;
  tenantId: string;
  agentPrincipal: string;
  workspaceSnapshotDigest: string;
  configuration: ConfigurationEnvelope;
  baseline: BaselineMetrics;
  uncovered: string[];
  untested: string[];
  stale: string[];
  hydratedRules: Array<{ uid: string; title: string; statement: string }>;
  verdict: PreflightVerdict;
  issuedAt: string;
  /** blake3 hex of canonicalised receipt without this field. */
  receiptHash: string;
}
