/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * PreflightOrchestrator
 *
 * The Supervisor layer of Sentinel's Hierarchical Agentic Workflow. It runs
 * the six-phase inspection protocol defined in the StrictDoc spec tree and
 * returns either a mutation lease or a structured denial.
 *
 * The orchestrator is intentionally *sequential*. Every phase's parameters
 * depend on the phase before it (a `tracey_unmapped` path scope is
 * meaningless until `tracey_config` has told us which globs are active), and
 * parallel execution would let a slow config query race a stale-status query.
 *
 * @relation(SENTINEL-DISC-001, scope=class)
 * @relation(SENTINEL-DISC-002, scope=class)
 * @relation(SENTINEL-DISC-003, scope=class)
 */
export class PreflightOrchestrator {
  constructor(
    private readonly client: TraceyMcpClient,
    private readonly classifier: HazardClassifier,
    private readonly ledger: ReceiptLedger,
    private readonly snapshots: WorkspaceSnapshotStore,
  ) {}

  /**
   * Run the complete inspection protocol.
   *
   * @param ctx - Session context (tenant, agent, declared scope of work).
   * @returns The persisted receipt, whose `verdict.decision` is authoritative.
   *
   * @relation(SENTINEL-AUDIT-005, scope=function)
   */
  public async run(ctx: PreflightContext): Promise<GovernanceReceipt> {
    // ---- Phase 0: Snapshot the workspace ------------------------------------
    // The snapshot pins every subsequent phase to a specific content hash.
    // If another agent mutates the config mid-flight, we detect it here.
    const snapshot = await this.snapshots.capture(ctx.workspaceId);

    // ---- Phase 1: Discovery — tracey_config ---------------------------------
    // @relation(SENTINEL-DISC-001, scope=function)
    const configRaw = await this.client.tool("tracey_config");
    const configuration = this.parseConfiguration(configRaw);

    if (configuration.specs.length === 0) {
      // Short-circuit — no configuration means every downstream tool will
      // also return empty, and that emptiness would be misleading.
      return this.finalise(ctx, snapshot, configuration, emptyBaseline(), {
        decision: "deny",
        hazards: [this.classifier.emptyConfig()],
      }, [], [], [], []);
    }

    // ---- Phase 2: Discovery — tracey_status ---------------------------------
    // @relation(SENTINEL-DISC-002, scope=function)
    const statusRaw = await this.client.tool("tracey_status");
    const baseline = this.parseBaseline(statusRaw);

    // ---- Phase 3: Discovery — tracey_unmapped -------------------------------
    // @relation(SENTINEL-DISC-003, scope=function)
    const unmappedRaw = await this.client.tool("tracey_unmapped", {
      path: ctx.declaredScopePath ?? ".",
    });
    void unmappedRaw; // persisted on the snapshot store for later leases

    // ---- Phase 4: Audit — parallel-safe reads -------------------------------
    // These three tools are read-only and commute, so we fan them out. This
    // is the Consensus Mechanism pattern: three independent inspections whose
    // outputs are synthesised by the classifier, not merged.
    const [uncoveredRaw, untestedRaw, staleRaw] = await Promise.all([
      this.client.tool("tracey_uncovered"),
      this.client.tool("tracey_untested"),
      this.client.tool("tracey_stale"),
    ]);

    const uncovered = parseUidList(uncoveredRaw);
    const untested = parseUidList(untestedRaw);
    const stale = parseUidList(staleRaw);

    // ---- Phase 5: Audit — tracey_rule per in-scope UID ----------------------
    // @relation(SENTINEL-AUDIT-004, scope=function)
    const hydratedRules = await Promise.all(
      ctx.declaredScopeUids.map(async (uid) => {
        const raw = await this.client.tool("tracey_rule", { ruleId: uid });
        return this.parseRule(uid, raw);
      }),
    );

    // ---- Phase 6: Final gate — tracey_validate ------------------------------
    // @relation(SENTINEL-AUDIT-005, scope=function)
    const validateRaw = await this.client.tool("tracey_validate");

    // ---- Classify -----------------------------------------------------------
    const hazards = this.classifier.classify({
      ctx,
      uncovered,
      untested,
      stale,
      validationOutput: extractText(validateRaw),
    });

    const decision = hazards.some((h) => h.severity === "error") ? "deny" : "allow";

    // ---- Issue receipt ------------------------------------------------------
    return this.finalise(
      ctx,
      snapshot,
      configuration,
      baseline,
      { decision, hazards },
      uncovered,
      untested,
      stale,
      hydratedRules,
    );
  }

  // -------------------------------------------------------------------------
  // Parsers (kept private — they are brittle string handling around a
  // text-first MCP response format, and encapsulating them shrinks the blast
  // radius of a Tracey response-format upgrade).
  // -------------------------------------------------------------------------

  private parseConfiguration(raw: TraceyToolResult): ConfigurationEnvelope {
    const text = extractText(raw);
    // Tracey's MCP responses are human-readable text. We parse the two stable
    // signals — the spec name lines and the prefix table — and keep the raw
    // text as the authoritative fallback for agents that read output directly.
    const specLines = text.split("\n").filter((l) => l.includes("Spec:") || l.includes("Impl:"));
    const specs = specLines
      .filter((l) => l.includes("Spec:"))
      .map((l) => ({
        name: l.split("Spec:")[1].trim(),
        prefixes: [] as string[],
        implNames: [] as string[],
      }));
    return { specs, rawOutput: text };
  }

  private parseBaseline(raw: TraceyToolResult): BaselineMetrics {
    const text = extractText(raw);
    const perSpecImpl: BaselineMetrics["perSpecImpl"] = [];
    // Simplified parse — production code should use a robust tokenizer.
    const re = /([\w-]+\/[\w-]+)\s+(\d+)%\s+\((\d+)\/(\d+)\)/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      perSpecImpl.push({
        specImpl: m[1],
        percent: Number(m[2]),
        covered: Number(m[3]),
        total: Number(m[4]),
      });
    }
    const covered = perSpecImpl.reduce((acc, row) => acc + row.covered, 0);
    const total = perSpecImpl.reduce((acc, row) => acc + row.total, 0);
    return { perSpecImpl, coveredRequirements: covered, totalRequirements: total };
  }

  private parseRule(uid: string, raw: TraceyToolResult): { uid: string; title: string; statement: string } {
    const text = extractText(raw);
    const [, title = uid] = text.match(/^###\s+(.+)$/m) ?? [];
    return { uid, title, statement: text };
  }

  private async finalise(
    ctx: PreflightContext,
    snapshot: WorkspaceSnapshot,
    configuration: ConfigurationEnvelope,
    baseline: BaselineMetrics,
    verdict: PreflightVerdict,
    uncovered: string[],
    untested: string[],
    stale: string[],
    hydratedRules: Array<{ uid: string; title: string; statement: string }>,
  ): Promise<GovernanceReceipt> {
    return this.ledger.issue({
      tenantId: ctx.tenantId,
      workspaceId: ctx.workspaceId,
      agentPrincipal: ctx.agentPrincipal,
      workspaceSnapshotDigest: snapshot.digest,
      configuration,
      baseline,
      uncovered,
      untested,
      stale,
      hydratedRules,
      verdict,
    });
  }
}
