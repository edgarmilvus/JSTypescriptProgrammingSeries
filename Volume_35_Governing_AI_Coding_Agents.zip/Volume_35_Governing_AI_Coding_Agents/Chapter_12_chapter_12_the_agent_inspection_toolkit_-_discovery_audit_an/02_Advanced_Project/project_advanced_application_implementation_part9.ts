/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * HazardClassifier
 *
 * Pure, deterministic function of preflight inputs to hazards. No I/O.
 * Every path is exercised by Vitest — the classifier is the single most
 * security-sensitive component in Sentinel because its output determines
 * whether an agent gets to write to a customer's repository.
 */
export class HazardClassifier {
  /** @relation(SENTINEL-DISC-001, scope=function) */
  public emptyConfig(): Hazard {
    return {
      code: "CONFIG_EMPTY",
      severity: "error",
      message:
        "Workspace returned zero specs from tracey_config. Decline the lease " +
        "and instruct the operator to create .config/tracey/config.styx.",
    };
  }

  /**
   * @relation(SENTINEL-AUDIT-001, scope=function)
   * @relation(SENTINEL-AUDIT-002, scope=function)
   * @relation(SENTINEL-AUDIT-003, scope=function)
   */
  public classify(input: ClassificationInput): Hazard[] {
    const hazards: Hazard[] = [];
    const scopeUids = new Set(input.ctx.declaredScopeUids);

    // 1) Uncovered requirements that overlap with the agent's declared scope
    //    are hard errors — the agent is touching code that claims to
    //    implement something, yet nothing references it.
    const uncoveredInScope = input.uncovered.filter((uid) => scopeUids.has(uid));
    if (uncoveredInScope.length > 0) {
      hazards.push({
        code: "UNCOVERED_IN_SCOPE",
        severity: "error",
        requirementUids: uncoveredInScope,
        message:
          "The following requirements are implemented by nothing, yet fall inside " +
          "your declared scope. Add an `impl` annotation or narrow your scope: " +
          uncoveredInScope.join(", "),
      });
    }

    // 2) Untested requirements are warnings globally, errors if in scope.
    for (const uid of input.untested) {
      const inScope = scopeUids.has(uid);
      hazards.push({
        code: "MISSING_VERIFICATION",
        severity: inScope ? "error" : "warning",
        requirementUids: [uid],
        message:
          `${uid} has no \`verify\` annotation. ` +
          (inScope
            ? "Because you are editing its implementation, add a test annotation."
            : "Consider adding coverage in a future change."),
      });
    }

    // 3) Stale references are always errors. The spec text changed, the
    //    annotation did not — the correct sequence is update-then-bump.
    if (input.stale.length > 0) {
      hazards.push({
        code: "STALE_REFERENCE",
        severity: "error",
        requirementUids: input.stale,
        message:
          "Stale annotations detected. Update each implementation to match the " +
          "new requirement text BEFORE bumping the annotation version: " +
          input.stale.join(", "),
      });
    }

    // 4) Validator failure is a fatal, whole-workspace hazard.
    if (/error/i.test(input.validationOutput)) {
      hazards.push({
        code: "VALIDATION_FAILED",
        severity: "error",
        message: `tracey_validate reported errors:\n${input.validationOutput}`,
      });
    }

    return hazards;
  }
}

interface ClassificationInput {
  ctx: PreflightContext;
  uncovered: string[];
  untested: string[];
  stale: string[];
  validationOutput: string;
}
