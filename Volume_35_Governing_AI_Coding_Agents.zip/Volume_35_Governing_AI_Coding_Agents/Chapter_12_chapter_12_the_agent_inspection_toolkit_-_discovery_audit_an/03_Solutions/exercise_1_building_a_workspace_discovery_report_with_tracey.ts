/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_building_a_workspace_discovery_report_with_tracey.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * discovery.ts
 *
 * The discovery report MUST be derived from live MCP tool output rather than
 * by reading `.config/tracey/config.styx` on disk. The reason is that Tracey
 * supports runtime scope overrides via `tracey_config_include` /
 * `tracey_config_exclude` (see Exercise 4). Those tools "dynamically append an
 * include/exclude glob pattern to an implementation" and only take effect
 * after `tracey_reload`. An agent may therefore be operating against an
 * in-memory config that has diverged from the on-disk file. `tracey_config`
 * is documented as "the active configuration parsed from
 * `.config/tracey/config.styx`" and reflects any runtime mutations; the
 * on-disk file does not. Because the supervisor node must route work that is
 * consistent with what inspection tools will *actually* return, the report
 * must be built from `tracey_config`/`tracey_status`/`tracey_unmapped`, never
 * from filesystem inspection.
 */

// ---------------------------------------------------------------------------
// Typed shapes
// ---------------------------------------------------------------------------

export interface SpecImplConfig {
  specName: string;
  implName: string;
  include: string[];
  exclude: string[];
  testInclude: string[];
}

export interface ParsedTraceyConfig {
  specs: Array<{
    name: string;
    prefixes: string[];
    sourceUrl?: string;
    impls: Array<{
      name: string;
      include: string[];
      exclude: string[];
      testInclude: string[];
    }>;
  }>;
}

export interface StatusEntry {
  specImpl: string;          // e.g. "myapp/rust"
  implCoveragePercent: number;
  verifyCoveragePercent: number;
}

export interface UnmappedUnit {
  specImpl: string;
  filePath: string;
  symbolName: string;
  symbolKind: string;
  startLine: number;
}

export interface SpecSummary {
  name: string;
  prefixes: string[];
  implementationNames: string[];
  implCoveragePercent: number;
  verifyCoveragePercent: number;
}

export interface DiscoveryReport {
  generatedAt: string;               // ISO timestamp
  specs: SpecSummary[];              // sorted by name
  unmappedCodeUnits: UnmappedUnit[]; // sorted by specImpl, filePath, startLine
  scopeWarnings: string[];
}

// ---------------------------------------------------------------------------
// TraceyClient: thin typed wrapper around McpClient
// ---------------------------------------------------------------------------

export interface McpClient {
  callTool(name: string, args: Record<string, unknown>): Promise<{ content: { type: string; text: string }[] }>;
}

export interface TraceyClient {
  status(): Promise<StatusEntry[]>;
  config(): Promise<ParsedTraceyConfig>;
  unmapped(path?: string): Promise<UnmappedUnit[]>;
}

// ---------------------------------------------------------------------------
// Adapters: turn human-readable MCP text into typed shapes
// ---------------------------------------------------------------------------

function textOf(res: { content: { type: string; text: string }[] }): string {
  return res.content.map((c) => c.text).join("\n");
}

export function parseStatusText(text: string): StatusEntry[] {
  // Expected shape (per Tracey docs):
  //   myapp/rust        impl 78%  verify 42%
  //   myapp/typescript  impl 61%  verify 12%
  const out: StatusEntry[] = [];
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*([\w.-]+\/[\w.-]+)\s+.*?(\d+)%.*?(\d+)%/);
    if (!m) continue;
    out.push({
      specImpl: m[1],
      implCoveragePercent: Number(m[2]),
      verifyCoveragePercent: Number(m[3]),
    });
  }
  return out;
}

export function parseConfigText(text: string): ParsedTraceyConfig {
  // Expected shape (modelled on `tracey query config` / `tracey_config`):
  //   spec myapp  prefixes=[r]
  //     impl rust  include=[src/**/*.rs]  exclude=[target/**]
  //     impl typescript  include=[frontend/src/**/*.ts]
  //   spec http2  prefixes=[h2]
  //     impl rust  include=[src/http2/**/*.rs]
  const specs: ParsedTraceyConfig["specs"] = [];
  let current: ParsedTraceyConfig["specs"][number] | null = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trimEnd();
    const specMatch = line.match(/^\s*spec\s+(\S+)\s+prefixes=\[([^\]]*)\]/);
    if (specMatch) {
      current = {
        name: specMatch[1],
        prefixes: specMatch[2].split(",").map((s) => s.trim()).filter(Boolean),
        impls: [],
      };
      specs.push(current);
      continue;
    }
    const implMatch = line.match(/^\s*impl\s+(\S+)(.*)/);
    if (implMatch && current) {
      const rest = implMatch[2];
      const get = (key: string): string[] => {
        const m = rest.match(new RegExp(`${key}=\\[([^\\]]*)\\]`));
        return m ? m[1].split(/[\s,]+/).filter(Boolean) : [];
      };
      current.impls.push({
        name: implMatch[1],
        include: get("include"),
        exclude: get("exclude"),
        testInclude: get("test_include"),
      });
    }
  }
  return { specs };
}

export function parseUnmappedText(text: string, specImpl: string): UnmappedUnit[] {
  // Expected shape: one line per unmapped code unit, e.g.
  //   src/auth.rs:42  fn login  (unmapped)
  // Grouped under a tree header that names the specImpl.
  const out: UnmappedUnit[] = [];
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*(\S+):(\d+)\s+(\w+)\s+(\S+)/);
    if (!m) continue;
    out.push({
      specImpl,
      filePath: m[1],
      startLine: Number(m[2]),
      symbolKind: m[3],
      symbolName: m[4],
    });
  }
  return out;
}

export function wrapMcpClient(raw: McpClient): TraceyClient {
  return {
    async status() {
      return parseStatusText(textOf(await raw.callTool("tracey_status", {})));
    },
    async config() {
      return parseConfigText(textOf(await raw.callTool("tracey_config", {})));
    },
    async unmapped(path?: string) {
      const args = path ? { path } : {};
      const text = textOf(await raw.callTool("tracey_unmapped", args));
      // Callers typically pass no path; report the tree under a synthetic key.
      return parseUnmappedText(text, "(all)");
    },
  };
}

// ---------------------------------------------------------------------------
// Scope-warning derivation
// ---------------------------------------------------------------------------

function globToRegExp(glob: string): RegExp {
  const escaped = glob.replace(/[.+^${}()|[\]\\]/g, "\\$&")
    .replace(/\*\*/g, "§§")
    .replace(/\*/g, "[^/]*")
    .replace(/§§/g, ".*");
  return new RegExp(`^${escaped}$`);
}

function anyGlobMatches(globs: string[], path: string): boolean {
  return globs.some((g) => globToRegExp(g).test(path));
}

export function deriveScopeWarnings(
  config: ParsedTraceyConfig,
  units: UnmappedUnit[],
): string[] {
  const warnings: string[] = [];
  for (const unit of units) {
    for (const spec of config.specs) {
      for (const impl of spec.impls) {
        const specImpl = `${spec.name}/${impl.name}`;
        if (unit.specImpl !== specImpl && unit.specImpl !== "(all)") continue;
        const matchedInclude = anyGlobMatches(impl.include, unit.filePath);
        const matchedExclude = anyGlobMatches(impl.exclude, unit.filePath);
        if (matchedExclude) {
          warnings.push(
            `[${specImpl}] ${unit.filePath} is matched by an exclude pattern yet appears in tracey_unmapped.`,
          );
        } else if (!matchedInclude && impl.include.length > 0) {
          warnings.push(
            `[${specImpl}] ${unit.filePath} appears in tracey_unmapped but is matched by no include pattern.`,
          );
        }
      }
    }
  }
  return warnings;
}

// ---------------------------------------------------------------------------
// Report builder
// ---------------------------------------------------------------------------

export async function buildWorkspaceDiscoveryReport(
  client: TraceyClient,
): Promise<DiscoveryReport> {
  const config = await client.config();
  const status = await client.status();
  const units = await client.unmapped();

  // Build a lookup so spec summaries can be assembled without hard-coded names.
  const statusBySpecImpl = new Map(status.map((s) => [s.specImpl, s]));

  const specs: SpecSummary[] = config.specs.map((spec) => {
    const implNames = spec.impls.map((i) => i.name).sort();
    // Aggregate coverage across this spec's impls (average, rounded).
    let implSum = 0;
    let verifySum = 0;
    let counted = 0;
    for (const impl of spec.impls) {
      const key = `${spec.name}/${impl.name}`;
      const s = statusBySpecImpl.get(key);
      if (!s) continue;
      implSum += s.implCoveragePercent;
      verifySum += s.verifyCoveragePercent;
      counted += 1;
    }
    return {
      name: spec.name,
      prefixes: [...spec.prefixes].sort(),
      implementationNames: implNames,
      implCoveragePercent: counted ? Math.round(implSum / counted) : 0,
      verifyCoveragePercent: counted ? Math.round(verifySum / counted) : 0,
    };
  });

  specs.sort((a, b) => a.name.localeCompare(b.name));

  const unmappedCodeUnits = [...units].sort((a, b) => {
    if (a.specImpl !== b.specImpl) return a.specImpl.localeCompare(b.specImpl);
    if (a.filePath !== b.filePath) return a.filePath.localeCompare(b.filePath);
    return a.startLine - b.startLine;
  });

  return {
    generatedAt: new Date().toISOString(),
    specs,
    unmappedCodeUnits,
    scopeWarnings: deriveScopeWarnings(config, units),
  };
}
