/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_building_a_workspace_discovery_report_with_tracey_part2.ts
Description: Solutions and Explanations
==========================================
*/

// discovery.test.ts
import { describe, it, expect, vi } from "vitest";
import {
  buildWorkspaceDiscoveryReport,
  wrapMcpClient,
  type McpClient,
} from "./discovery";

function fakeRaw(responses: Record<string, string>): McpClient {
  return {
    async callTool(name) {
      return { content: [{ type: "text", text: responses[name] ?? "" }] };
    },
  };
}

const FAKE_CONFIG = `
spec myapp  prefixes=[r]
  impl rust  include=[src/**/*.rs]  exclude=[target/**]
  impl typescript  include=[frontend/src/**/*.ts]  exclude=[]
spec http2  prefixes=[h2]
  impl rust  include=[src/http2/**/*.rs]  exclude=[vendor/**]
`.trim();

const FAKE_STATUS = `
myapp/rust        impl 78%  verify 42%
myapp/typescript  impl 61%  verify 12%
http2/rust        impl 40%  verify 10%
`.trim();

const FAKE_UNMAPPED = `
src/auth.rs:42  fn login
src/orders.rs:7  fn place_order
vendor/dep/src/lib.rs:11  fn vendored_helper
`.trim();

describe("buildWorkspaceDiscoveryReport", () => {
  it("sorts specs by name and impl names alphabetically", async () => {
    const client = wrapMcpClient(
      fakeRaw({
        tracey_config: FAKE_CONFIG,
        tracey_status: FAKE_STATUS,
        tracey_unmapped: FAKE_UNMAPPED,
      }),
    );
    const r = await buildWorkspaceDiscoveryReport(client);
    expect(r.specs.map((s) => s.name)).toEqual(["http2", "myapp"]);
    const myapp = r.specs.find((s) => s.name === "myapp")!;
    expect(myapp.implementationNames).toEqual(["rust", "typescript"]);
  });

  it("sorts unmapped units by specImpl, filePath, startLine", async () => {
    const client = wrapMcpClient(
      fakeRaw({
        tracey_config: FAKE_CONFIG,
        tracey_status: FAKE_STATUS,
        tracey_unmapped: FAKE_UNMAPPED,
      }),
    );
    const r = await buildWorkspaceDiscoveryReport(client);
    const keys = r.unmappedCodeUnits.map(
      (u) => `${u.specImpl}|${u.filePath}|${u.startLine}`,
    );
    const sorted = [...keys].sort();
    expect(keys).toEqual(sorted);
  });

  it("emits a scope warning when a path is excluded but still surfaced", async () => {
    const client = wrapMcpClient(
      fakeRaw({
        tracey_config: FAKE_CONFIG,
        tracey_status: FAKE_STATUS,
        tracey_unmapped: "vendor/dep/src/lib.rs:11  fn vendored_helper",
      }),
    );
    const r = await buildWorkspaceDiscoveryReport(client);
    expect(r.scopeWarnings.some((w) => w.includes("excluded"))).toBe(true);
  });

  it("is idempotent for specs and unmappedCodeUnits", async () => {
    const client = wrapMcpClient(
      fakeRaw({
        tracey_config: FAKE_CONFIG,
        tracey_status: FAKE_STATUS,
        tracey_unmapped: FAKE_UNMAPPED,
      }),
    );
    const a = await buildWorkspaceDiscoveryReport(client);
    const b = await buildWorkspaceDiscoveryReport(client);
    expect(a.specs).toEqual(b.specs);
    expect(a.unmappedCodeUnits).toEqual(b.unmappedCodeUnits);
    expect(a.scopeWarnings).toEqual(b.scopeWarnings);
  });
});
