/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_drift-dashboard_react_component.tsx
Description: Solutions and Explanations
==========================================
*/

/**
 * DriftDashboard.tsx
 *
 * The component MUST NOT compute staleness itself. Tracey's definition of
 * "stale" is precise: a stale reference means "code references an older
 * version of a requirement" — i.e. the annotation's `+N` suffix does not
 * match the spec's current `+M`. That fact is established by the
 * `tracey_stale` tool, which walks the traceability graph and compares
 * annotation versions to spec versions using the same machinery that
 * `tracey_validate --deny warnings` uses. Any UI that recomputed staleness
 * from neighboring files, git history, or spec text would be guessing at
 * something the toolchain already knows, and would risk disagreeing with
 * the CI gate. The component is therefore a *pure view over MCP output*.
 */

import React, { useEffect, useState } from "react";
import { useTraceyInspection } from "./useTraceyInspection";
import type { DriftReport, DriftEntry } from "./driftClient";

export interface DriftDashboardProps {
  data: DriftReport;
  refreshKey?: number;
}

function verbLabel(verb: DriftEntry["verb"]): string {
  return verb === "impl" ? "impl" : verb === "verify" ? "verify" : verb;
}

export function DriftDashboard({ data, refreshKey }: DriftDashboardProps) {
  const { report, offline, hydrated } = useTraceyInspection({ data, refreshKey });

  if (report.kind === "loading") return <div data-testid="loading">Loading drift report…</div>;
  if (report.kind === "error")
    return (
      <div data-testid="error">
        {report.message}
        {hydrated && (
          <div data-testid="offline">
            Tracey daemon unreachable — showing last known good data
          </div>
        )}
      </div>
    );
  if (report.kind === "empty") return <div data-testid="empty">No stale references.</div>;

  const { entries, validationPasses } = report;

  return (
    <div data-testid="drift-dashboard">
      <header>
        <span data-testid="count-stale">{entries.length}</span> stale ·{" "}
        <span data-testid="count-specs">{new Set(entries.map((e) => e.specImpl.split("/")[0])).size}</span> specs ·{" "}
        <span data-testid="count-impls">{new Set(entries.map((e) => e.specImpl)).size}</span> impls
      </header>

      {offline && (
        <div data-testid="offline">
          Tracey daemon unreachable — showing last known good data
        </div>
      )}

      <table>
        <thead>
          <tr>
            <th>Requirement</th>
            <th>Spec/Impl</th>
            <th>Annotated</th>
            <th>Current</th>
            <th>Verb</th>
            <th>Source</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((e) => (
            <DriftRow key={`${e.requirementUid}|${e.specImpl}|${e.sourceFile}:${e.sourceLine}`} entry={e} />
          ))}
        </tbody>
      </table>

      <footer data-testid="validation-footer">
        {validationPasses
          ? "Validation passes."
          : "Validation fails with stale references — the annotation bump has not yet been performed."}
      </footer>
    </div>
  );
}

function DriftRow({ entry }: { entry: DriftEntry }) {
  const [expanded, setExpanded] = useState(false);
  const [ruleText, setRuleText] = useState<string | null>(null);

  useEffect(() => {
    if (!expanded || ruleText !== null) return;
    // Call tracey_rule exactly once per row on first expansion.
    import("./driftClient").then(({ fetchCurrentRule }) =>
      fetchCurrentRule(entry.requirementUid).then(setRuleText),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expanded]);

  return (
    <>
      <tr onClick={() => setExpanded((v) => !v)} data-testid={`row-${entry.requirementUid}`}>
        <td>{entry.requirementUid}</td>
        <td>{entry.specImpl}</td>
        <td>{entry.annotatedVersion}</td>
        <td>{entry.currentVersion}</td>
        <td>{verbLabel(entry.verb)}</td>
        <td>
          <a href={`editor://${entry.sourceFile}:${entry.sourceLine}`}>
            {entry.sourceFile}:{entry.sourceLine}
          </a>
        </td>
      </tr>
      {expanded && (
        <tr data-testid={`expanded-${entry.requirementUid}`}>
          <td colSpan={6}>
            <div className="hint">Bump only after code update</div>
            <pre>{ruleText ?? "Loading rule…"}</pre>
          </td>
        </tr>
      )}
    </>
  );
}
