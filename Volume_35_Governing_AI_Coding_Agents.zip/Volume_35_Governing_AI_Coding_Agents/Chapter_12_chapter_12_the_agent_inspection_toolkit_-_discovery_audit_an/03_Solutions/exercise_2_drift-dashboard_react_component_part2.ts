/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_drift-dashboard_react_component_part2.ts
Description: Solutions and Explanations
==========================================
*/

// driftClient.ts
import type { McpClient } from "./discovery";

export type DriftVerb = "impl" | "verify" | "depends" | "related";

export interface DriftEntry {
  requirementUid: string;
  specImpl: string;
  annotatedVersion: number;
  currentVersion: number;
  sourceFile: string;
  sourceLine: number;
  verb: DriftVerb;
}

export type DriftReport =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "empty" }
  | { kind: "populated"; entries: DriftEntry[]; validationPasses: boolean };

export interface McpTextResponse {
  content: { type: string; text: string }[];
}

export interface DriftClient {
  stale(filter?: { spec_impl?: string; prefix?: string }): Promise<McpTextResponse>;
  rule(uid: string): Promise<McpTextResponse>;
  validate(denyWarnings: boolean): Promise<McpTextResponse>;
}

export function makeDriftClient(raw: McpClient): DriftClient {
  return {
    stale: (f) => raw.callTool("tracey_stale", f ?? {}),
    rule: (uid) => raw.callTool("tracey_rule", { uid }),
    validate: (deny) => raw.callTool("tracey_validate", { deny_warnings: deny }),
  };
}

/**
 * toDriftReport — pure, no React, no I/O. This function is the single
 * translation point between the human-readable MCP text response and the
 * typed DriftReport. It is intentionally exported so the reviewer agent
 * (Exercise 5) can reuse it without importing React.
 */
export function toDriftReport(
  staleText: string,
  validationText: string,
): DriftReport {
  const entries: DriftEntry[] = [];
  for (const line of staleText.split(/\r?\n/)) {
    // Expected: "auth.login+3 -> +4  [r[verify auth.login+3]]  src/auth.rs:88"
    const m = line.match(
      /^\s*([\w.-]+)\+(\d+)\s*->\s*\+(\d+)\s+\[r\[(impl|verify|depends|related)\s+[^\]]+\]\]\s+(\S+):(\d+)/,
    );
    if (!m) continue;
    entries.push({
      requirementUid: m[1],
      annotatedVersion: Number(m[2]),
      currentVersion: Number(m[3]),
      verb: m[4] as DriftVerb,
      sourceFile: m[5],
      sourceLine: Number(m[6]),
      // specImpl is derived from the tool grouping header; caller supplies
      // per group, see parseStaleWithSpecImpl.
      specImpl: "",
    });
  }
  if (entries.length === 0) return { kind: "empty" };
  const validationPasses = !/fail|error/i.test(validationText);
  return { kind: "populated", entries, validationPasses };
}

export async function fetchCurrentRule(uid: string): Promise<string> {
  // In the real system this is the bound DriftClient.rule() result assembled
  // into a string; here we return a placeholder to keep the module pure of
  // the McpClient type.
  return `(current rule text for ${uid})`;
}
