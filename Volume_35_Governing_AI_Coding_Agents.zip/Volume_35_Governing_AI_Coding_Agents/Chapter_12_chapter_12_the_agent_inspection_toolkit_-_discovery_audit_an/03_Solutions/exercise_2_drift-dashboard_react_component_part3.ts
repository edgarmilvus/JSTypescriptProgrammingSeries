/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_drift-dashboard_react_component_part3.ts
Description: Solutions and Explanations
==========================================
*/

// useTraceyInspection.ts
import { useEffect, useRef, useState } from "react";
import type { DriftReport } from "./driftClient";

export function useTraceyInspection(args: {
  data: DriftReport;
  refreshKey?: number;
}) {
  const [report, setReport] = useState<DriftReport>(args.data);
  const [offline, setOffline] = useState(false);
  const lastGood = useRef<DriftReport | null>(
    args.data.kind === "populated" ? args.data : null,
  );

  useEffect(() => {
    setReport(args.data);
    if (args.data.kind === "populated") lastGood.current = args.data;
    if (args.data.kind === "error" && lastGood.current) setOffline(true);
    else setOffline(false);
  }, [args.data, args.refreshKey]);

  return { report, offline, hydrated: lastGood.current !== null };
}
