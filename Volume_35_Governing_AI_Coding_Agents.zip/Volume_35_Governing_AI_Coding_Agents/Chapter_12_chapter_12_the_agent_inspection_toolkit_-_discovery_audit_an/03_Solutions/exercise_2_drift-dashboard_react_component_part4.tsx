/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_drift-dashboard_react_component_part4.tsx
Description: Solutions and Explanations
==========================================
*/

// DriftDashboard.test.tsx (Vitest + RTL)
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { DriftDashboard } from "./DriftDashboard";

const populated = {
  kind: "populated" as const,
  validationPasses: false,
  entries: [
    {
      requirementUid: "auth.login",
      specImpl: "myapp/rust",
      annotatedVersion: 3,
      currentVersion: 4,
      sourceFile: "src/auth.rs",
      sourceLine: 88,
      verb: "impl" as const,
    },
  ],
};

describe("DriftDashboard", () => {
  it("renders the loading state", () => {
    render(<DriftDashboard data={{ kind: "loading" }} />);
    expect(screen.getByTestId("loading")).toBeTruthy();
  });

  it("renders the empty state", () => {
    render(<DriftDashboard data={{ kind: "empty" }} />);
    expect(screen.getByTestId("empty")).toBeTruthy();
  });

  it("renders the error state with an offline indicator", () => {
    render(<DriftDashboard data={{ kind: "error", message: "transport" }} />);
    expect(screen.getByTestId("error")).toBeTruthy();
  });

  it("flips the footer text based on validation outcome", () => {
    const { rerender } = render(<DriftDashboard data={populated} />);
    expect(screen.getByTestId("validation-footer").textContent).toMatch(/fails/);
    rerender(
      <DriftDashboard data={{ ...populated, validationPasses: true }} />,
    );
    expect(screen.getByTestId("validation-footer").textContent).toMatch(/passes/);
  });

  it("calls tracey_rule once per row on first expansion only", async () => {
    const spy = vi.spyOn(await import("./driftClient"), "fetchCurrentRule");
    render(<DriftDashboard data={populated} />);
    const row = screen.getByTestId("row-auth.login");
    fireEvent.click(row);
    fireEvent.click(row);
    fireEvent.click(row);
    await waitFor(() => expect(spy).toHaveBeenCalledTimes(1));
  });
});
