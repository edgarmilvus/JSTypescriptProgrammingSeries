/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_supervisor_node_function-calling_schema_for_the_a.ts
Description: Solutions and Explanations
==========================================
*/

// schema.ts
export const TRACEY_INSPECTION_SCHEMA = {
  type: "object",
  properties: {
    tracey_status: {
      type: "object",
      description:
        "Returns coverage overview across every spec/impl pair, including the prefixes Tracey currently recognises. Prefer this as the first call to prove the daemon is up and to learn which spec_impl strings are valid filters for the other tools.",
      properties: {},
      additionalProperties: false,
    },
    tracey_config: {
      type: "object",
      description:
        "Returns the active parsed `.config/tracey/config.styx` including runtime-appended include/exclude globs. Authoritative for scope. Prefer over reading the file on disk because tracey_config_include/exclude may have mutated the in-memory config.",
      properties: {},
      additionalProperties: false,
    },
    tracey_uncovered: {
      type: "object",
      description:
        "Returns requirements that have no impl reference. Prefer over tracey_untested when the goal is to discover unimplemented requirements. Prefer over tracey_stale when the goal is to find work that has never been implemented.",
      properties: {
        spec_impl: { type: "string", description: "Filter to a specific spec/impl pair, e.g. 'myapp/rust'." },
        prefix: { type: "string", description: "Filter by requirement ID prefix, e.g. 'auth.'." },
      },
      additionalProperties: false,
    },
    tracey_untested: {
      type: "object",
      description:
        "Returns requirements that have an impl reference but no verify reference. Prefer over tracey_uncovered when the implementation exists but tests are missing.",
      properties: {
        spec_impl: { type: "string" },
        prefix: { type: "string" },
      },
      additionalProperties: false,
    },
    tracey_stale: {
      type: "object",
      description:
        "Returns references whose annotation version is behind the spec's current version. Prefer over tracey_untested and tracey_uncovered when annotations exist but the underlying requirement text has been bumped.",
      properties: {
        spec_impl: { type: "string" },
        prefix: { type: "string" },
      },
      additionalProperties: false,
    },
    tracey_unmapped: {
      type: "object",
      description:
        "Returns the source tree with coverage percentages. Pass `path` to zoom into a specific directory or file. Prefer this over loading the entire tree when you already know which subdirectory is likely unmapped.",
      properties: {
        path: { type: "string", description: "Relative path to a directory or file to zoom into." },
      },
      additionalProperties: false,
    },
    tracey_rule: {
      type: "object",
      description:
        "Returns the exact title, statement, rationale, and references for a single requirement UID. Use this when you need the normative text of a requirement before deciding whether work is possible.",
      properties: {
        uid: { type: "string", description: "The requirement UID, e.g. 'auth.login'." },
      },
      required: ["uid"],
      additionalProperties: false,
    },
    tracey_validate: {
      type: "object",
      description:
        "Runs the semantic linter. Set deny_warnings=true to mirror the CLI's --deny warnings behaviour, which is the gate used by CI. Prefer calling this first when you suspect a broken intent graph; if it fails, halt rather than dispatch work.",
      properties: {
        deny_warnings: { type: "boolean" },
      },
      additionalProperties: false,
    },
    tracey_config_include: {
      type: "object",
      description:
        "Append an include glob pattern to an implementation. Precondition: the effect is only visible after a subsequent tracey_reload call. Scope-only mutation — does not modify source or spec content.",
      properties: {
        spec_impl: { type: "string" },
        pattern: { type: "string" },
      },
      required: ["spec_impl", "pattern"],
      additionalProperties: false,
    },
    tracey_config_exclude: {
      type: "object",
      description:
        "Append an exclude glob pattern to an implementation. Precondition: the effect is only visible after a subsequent tracey_reload call. Scope-only mutation — does not modify source or spec content.",
      properties: {
        spec_impl: { type: "string" },
        pattern: { type: "string" },
      },
      required: ["spec_impl", "pattern"],
      additionalProperties: false,
    },
  },
  additionalProperties: false,
} as const;

export type TraceyToolName = keyof typeof TRACEY_INSPECTION_SCHEMA.properties;
