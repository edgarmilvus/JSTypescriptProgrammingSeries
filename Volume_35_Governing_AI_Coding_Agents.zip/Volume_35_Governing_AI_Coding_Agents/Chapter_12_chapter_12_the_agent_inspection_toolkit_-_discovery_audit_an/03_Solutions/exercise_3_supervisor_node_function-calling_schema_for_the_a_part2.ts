/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_supervisor_node_function-calling_schema_for_the_a_part2.ts
Description: Solutions and Explanations
==========================================
*/

// supervisor.ts
import { TRACEY_INSPECTION_SCHEMA, type TraceyToolName } from "./schema";

export interface ToolEvidence {
  tool: TraceyToolName;
  args: Record<string, unknown>;
  responseText: string;
}

export interface GraphState {
  evidence: ToolEvidence[];
  toolCallCount: number;
}

export interface WorkerTask {
  requirementUids: string[];
  specImpl: string;
  evidence: ToolEvidence[];
}

export type RoutingDecision =
  | { kind: "invoke_worker"; worker: "annotator" | "tester" | "remediator"; task: WorkerTask }
  | { kind: "halt"; reason: "validation_failed" | "budget_exhausted" | "no_work_found" };

export interface LlmModel {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  complete(conversation: any[], tools: unknown): Promise<{ toolCalls?: { name: string; args: unknown }[]; content?: string }>;
}

interface SupervisorOpts {
  perTurnBudget?: number;
  globalBudget?: number;
}

export class SupervisorNode {
  private perTurnBudget: number;
  private globalBudget: number;
  private globalUsed = 0;

  constructor(opts: SupervisorOpts = {}) {
    this.perTurnBudget = opts.perTurnBudget ?? 6;
    this.globalBudget = opts.globalBudget ?? 24;
  }

  async next(state: GraphState, model: LlmModel): Promise<RoutingDecision> {
    if (this.globalUsed >= this.globalBudget) {
      return { kind: "halt", reason: "budget_exhausted" };
    }

    let perTurn = 0;
    const local = [...state.evidence];
    const conversation: any[] = [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: serializeState({ evidence: local, toolCallCount: state.toolCallCount }) },
    ];

    while (perTurn < this.perTurnBudget && this.globalUsed < this.globalBudget) {
      const reply = await model.complete(conversation, TRACEY_INSPECTION_SCHEMA);
      const calls = reply.toolCalls ?? [];
      if (calls.length === 0) break;

      for (const call of calls) {
        // Validate the tool name against the schema.
        if (!isKnownTool(call.name)) {
          conversation.push({
            role: "tool",
            content: `Rejected: unknown tool "${call.name}". Available tools: ${Object.keys(TRACEY_INSPECTION_SCHEMA.properties).join(", ")}`,
          });
          continue;
        }
        // Validate args against the tool's subschema.
        const err = validateArgs(call.name as TraceyToolName, call.args);
        if (err) {
          conversation.push({ role: "tool", content: `Rejected: ${err}` });
          continue;
        }
        // Execute (in production this goes through the MCP client).
        const evidence = await this.execute(call.name as TraceyToolName, call.args as Record<string, unknown>);
        local.push(evidence);
        perTurn += 1;
        this.globalUsed += 1;
      }
    }

    return this.route(local);
  }

  private async execute(tool: TraceyToolName, args: Record<string, unknown>): Promise<ToolEvidence> {
    // Placeholder: real implementation calls McpClient.callTool.
    return { tool, args, responseText: "" };
  }

  private route(evidence: ToolEvidence[]): RoutingDecision {
    const validation = evidence.find((e) => e.tool === "tracey_validate");
    if (validation && /fail|error/i.test(validation.responseText)) {
      return { kind: "halt", reason: "validation_failed" };
    }
    const stale = evidence.find((e) => e.tool === "tracey_stale");
    if (stale && stale.responseText.trim().length > 0) {
      const uids = extractUids(stale.responseText);
      return {
        kind: "invoke_worker",
        worker: "remediator",
        task: { requirementUids: uids, specImpl: "(all)", evidence },
      };
    }
    const uncovered = evidence.find((e) => e.tool === "tracey_uncovered");
    if (uncovered && uncovered.responseText.trim().length > 0) {
      const uids = extractUids(uncovered.responseText);
      return {
        kind: "invoke_worker",
        worker: "annotator",
        task: {
          requirementUids: uids,
          specImpl: pickSmallestSpecScope(uids),
          evidence,
        },
      };
    }
    const untested = evidence.find((e) => e.tool === "tracey_untested");
    if (untested && untested.responseText.trim().length > 0) {
      const uids = extractUids(untested.responseText);
      return {
        kind: "invoke_worker",
        worker: "tester",
        task: { requirementUids: uids, specImpl: "(all)", evidence },
      };
    }
    return { kind: "halt", reason: "no_work_found" };
  }
}

const SYSTEM_PROMPT =
  "You are a read-only supervisor. You may only call the Tracey inspection tools listed in the schema. You must not emit tool calls that would modify source code or specs.";

function serializeState(state: GraphState): string {
  return JSON.stringify(state, null, 2);
}

function isKnownTool(name: string): name is TraceyToolName {
  return name in TRACEY_INSPECTION_SCHEMA.properties;
}

function validateArgs(tool: TraceyToolName, args: unknown): string | null {
  if (typeof args !== "object" || args === null) return "args must be an object";
  const schema = TRACEY_INSPECTION_SCHEMA.properties[tool] as { required?: readonly string[]; properties: Record<string, unknown>; additionalProperties?: boolean };
  for (const key of Object.keys(args)) {
    if (!(key in schema.properties)) return `unknown parameter "${key}" for tool "${tool}"`;
  }
  if (schema.required) {
    for (const r of schema.required) {
      if (!(r in (args as Record<string, unknown>))) return `missing required parameter "${r}"`;
    }
  }
  return null;
}

function extractUids(text: string): string[] {
  return Array.from(new Set(text.match(/[\w.-]+\.[\w.-]+/g) ?? []));
}

function pickSmallestSpecScope(uids: string[]): string {
  // In the real implementation this reads the spec_impl column from the
  // uncovered payload and returns the one with the fewest UIDs.
  return "(all)";
}
