/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_supervisor_node_function-calling_schema_for_the_a_part3.ts
Description: Solutions and Explanations
==========================================
*/

// supervisor.policy.md (quote verbatim as a file)
/*
# Supervisor Policy

The supervisor node is **read-only with respect to source code and spec text**.
It never writes `r[impl …]` annotations, never edits requirement bodies, and
never modifies `.sdoc` or `.md` files. Its only output is a `RoutingDecision`
that hands a scoped task to a worker agent.

The `tracey_config_include` and `tracey_config_exclude` tools are permitted in
the supervisor's schema even though they sound like configuration mutators.
They are permitted because they only *append* glob patterns to an
implementation's include/exclude set — they adjust the scope of the intent
graph, not its content. Appending `vendor/**` to an exclude list cannot
introduce or conceal behaviour in shipped code; it only changes which source
files Tracey attributes to a given spec. The supervisor is allowed to reason
about scope because scope is the language the inspection tools speak
(`spec_impl`, `prefix`, `path`).

Scope changes are *provisional*: their effect is invisible until
`tracey_reload` has been called, and any subsequent inspection call must have
been preceded by a reload. The supervisor tracks this in the evidence list
so that a stale report cannot be mistaken for a post-change report.
*/
