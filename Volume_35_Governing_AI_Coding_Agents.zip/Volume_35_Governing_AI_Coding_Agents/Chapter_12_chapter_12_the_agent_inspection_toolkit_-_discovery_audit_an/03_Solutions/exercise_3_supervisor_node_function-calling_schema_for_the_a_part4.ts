/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_supervisor_node_function-calling_schema_for_the_a_part4.ts
Description: Solutions and Explanations
==========================================
*/

// supervisor.test.ts
import { describe, it, expect, vi } from "vitest";
import { SupervisorNode, type LlmModel } from "./supervisor";
import type { ToolEvidence } from "./supervisor";

function scriptedLlm(scripts: Array<{ name: string; args: unknown }[]>): LlmModel {
  let i = 0;
  return {
    async complete() {
      const toolCalls = scripts[i++] ?? [];
      return { toolCalls };
    },
  };
}

describe("SupervisorNode", () => {
  it("halts with no_work_found on an empty workspace", async () => {
    const node = new SupervisorNode();
    const llm = scriptedLlm([
      [{ name: "tracey_validate", args: { deny_warnings: true } }],
      [{ name: "tracey_uncovered", args: {} }],
      [{ name: "tracey_untested", args: {} }],
      [{ name: "tracey_stale", args: {} }],
    ]);
    const r = await node.next({ evidence: [], toolCallCount: 0 }, llm);
    expect(r).toEqual({ kind: "halt", reason: "no_work_found" });
  });

  it("halts with validation_failed when validate reports errors", async () => {
    const node = new SupervisorNode();
    (node as any).execute = async (tool: string, args: Record<string, unknown>): Promise<ToolEvidence> =>
      ({ tool, args, responseText: tool === "tracey_validate" ? "FAIL: orphan references" : "" } as any);
    const llm = scriptedLlm([[{ name: "tracey_validate", args: { deny_warnings: true } }]]);
    const r = await node.next({ evidence: [], toolCallCount: 0 }, llm);
    expect(r).toEqual({ kind: "halt", reason: "validation_failed" });
  });

  it("prefers the annotator for uncovered requirements", async () => {
    const node = new SupervisorNode();
    (node as any).execute = async (tool: string, args: Record<string, unknown>): Promise<ToolEvidence> =>
      ({ tool, args, responseText: tool === "tracey_uncovered" ? "auth.login\nauth.token-expiry" : "" } as any);
    const llm = scriptedLlm([
      [{ name: "tracey_validate", args: { deny_warnings: true } }],
      [{ name: "tracey_uncovered", args: {} }],
    ]);
    const r = await node.next({ evidence: [], toolCallCount: 0 }, llm);
    expect(r.kind).toBe("invoke_worker");
    if (r.kind === "invoke_worker") {
      expect(r.worker).toBe("annotator");
      expect(r.task.requirementUids).toEqual(["auth.login", "auth.token-expiry"]);
    }
  });

  it("prefers the remediator when only stale references exist", async () => {
    const node = new SupervisorNode();
    (node as any).execute = async (tool: string, args: Record<string, unknown>): Promise<ToolEvidence> =>
      ({ tool, args, responseText: tool === "tracey_stale" ? "auth.login+3 -> +4" : "" } as any);
    const llm = scriptedLlm([
      [{ name: "tracey_validate", args: { deny_warnings: true } }],
      [{ name: "tracey_stale", args: {} }],
    ]);
    const r = await node.next({ evidence: [], toolCallCount: 0 }, llm);
    if (r.kind === "invoke_worker") expect(r.worker).toBe("remediator");
  });

  it("rejects unknown tools and respects the subsequent valid call", async () => {
    const node = new SupervisorNode();
    (node as any).execute = async (tool: string, args: Record<string, unknown>): Promise<ToolEvidence> =>
      ({ tool, args, responseText: tool === "tracey_validate" ? "ok" : "" } as any);
    const llm = scriptedLlm([
      [{ name: "tracey_mutate_source", args: {} }],
      [{ name: "tracey_validate", args: { deny_warnings: true } }],
    ]);
    const r = await node.next({ evidence: [], toolCallCount: 0 }, llm);
    // The unknown tool must not terminate the loop; the subsequent valid
    // call must be executed and route the decision.
    expect(r.kind).toBe("halt");
  });
});
