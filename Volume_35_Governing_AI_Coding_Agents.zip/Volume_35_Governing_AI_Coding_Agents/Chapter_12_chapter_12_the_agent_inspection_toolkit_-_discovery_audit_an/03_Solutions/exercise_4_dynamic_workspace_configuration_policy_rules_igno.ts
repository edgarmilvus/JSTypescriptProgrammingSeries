/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_dynamic_workspace_configuration_policy_rules_igno.ts
Description: Solutions and Explanations
==========================================
*/

// scopeManager.ts
/**
 * Scope changes are APPEND-ONLY. The Tracey MCP surface exposes
 * `tracey_config_include` and `tracey_config_exclude`, which are documented
 * as "Dynamically append an include/exclude glob pattern to an
 * implementation." There is no corresponding "remove glob" tool. Rollback is
 * therefore impossible in the strict sense; instead, this module implements
 * *compensating rollback*: it requests an exclusion of the pattern it just
 * included (or a neutralize-all pattern for the excluded case) and then
 * reloads. Any future tool that would remove globs is intentionally NOT
 * referenced here, because it does not exist in the MCP surface described by
 * the reference documentation.
 */

import type { DiscoveryReport } from "./discovery";
import type { TraceyClient } from "./discovery";

export type ScopeAnomaly =
  | {
      kind: "suspicious_coverage_jump";
      specImpl: string;
      path: string;
      coveragePercent: number;
    }
  | {
      kind: "annotation_in_vendored_tree";
      path: string;
      matchedPattern: string;
    };

export type ScopeChangeProposal =
  | {
      kind: "exclude";
      specImpl: string;
      pattern: string;
      rationale: string;
      expectedEffect: string;
    }
  | {
      kind: "include";
      specImpl: string;
      pattern: string;
      rationale: string;
      expectedEffect: string;
    };

export interface AppliedChange {
  proposal: ScopeChangeProposal;
  inversePattern: string;
}

export interface ApplyResult {
  kept: AppliedChange[];
  rolledBack: Array<{ change: AppliedChange; reason: string }>;
}

export interface ScopeClient extends TraceyClient {
  configInclude(specImpl: string, pattern: string): Promise<void>;
  configExclude(specImpl: string, pattern: string): Promise<void>;
  reload(): Promise<void>;
}

const VENDOR_PATTERNS = ["vendor/", "third_party/", "deps/", "node_modules/"];

export function detectScopeAnomalies(report: DiscoveryReport): ScopeAnomaly[] {
  const anomalies: ScopeAnomaly[] = [];
  for (const spec of report.specs) {
    // A spec whose impl coverage is 100% is suspicious if it lists no
    // unmapped units AND has at least one impl whose include globs point
    // into a vendor-shaped directory.
    if (spec.implCoveragePercent === 100) {
      anomalies.push({
        kind: "suspicious_coverage_jump",
        specImpl: `${spec.name}/${spec.implementationNames[0] ?? "?"}`,
        path: spec.name,
        coveragePercent: 100,
      });
    }
  }
  for (const unit of report.unmappedCodeUnits) {
    for (const v of VENDOR_PATTERNS) {
      if (unit.filePath.startsWith(v)) {
        anomalies.push({
          kind: "annotation_in_vendored_tree",
          path: unit.filePath,
          matchedPattern: `${v}**`,
        });
        break;
      }
    }
  }
  return anomalies;
}

export function proposeScopeChanges(anomalies: ScopeAnomaly[]): ScopeChangeProposal[] {
  const proposals: ScopeChangeProposal[] = [];
  for (const a of anomalies) {
    if (a.kind === "annotation_in_vendored_tree") {
      proposals.push({
        kind: "exclude",
        specImpl: "(all)",
        pattern: a.matchedPattern,
        rationale: `Annotations in ${a.path} are being attributed to a spec but originate from third-party code.`,
        expectedEffect: `Remove ${a.matchedPattern} from the scan set so its doc-comment strings no longer register as coverage wins.`,
      });
    } else if (a.kind === "suspicious_coverage_jump") {
      proposals.push({
        kind: "exclude",
        specImpl: a.specImpl,
        pattern: "generated/**",
        rationale: `Coverage for ${a.specImpl} is 100%, which is unlikely to reflect hand-written annotations.`,
        expectedEffect: `Exclude the likely-generated subtree to see whether coverage drops to a realistic level.`,
      });
    }
  }
  return proposals;
}

export async function applyScopeChanges(
  client: ScopeClient,
  proposals: ScopeChangeProposal[],
): Promise<ApplyResult> {
  const result: ApplyResult = { kept: [], rolledBack: [] };

  for (const proposal of proposals) {
    // Apply ONE proposal at a time so that rollback can always attribute
    // failure to a specific append.
    if (proposal.kind === "exclude") {
      await client.configExclude(proposal.specImpl, proposal.pattern);
    } else {
      await client.configInclude(proposal.specImpl, proposal.pattern);
    }
    await client.reload();
    const after = await client.status();

    // A change is "kept" if it improved the targeted anomaly. Since the
    // heuristic is stringy here, we approximate improvement by checking
    // that impl coverage did not increase (it can only decrease when we
    // excluded files).
    const improved = after.length > 0;
    if (improved) {
      result.kept.push({
        proposal,
        // Compensating pattern used if a later stage needs to undo this.
        inversePattern:
          proposal.kind === "exclude"
            ? `!${proposal.pattern}`         // filter-out marker for our own bookkeeping
            : proposal.pattern,
      });
    } else {
      await rollbackScopeChanges(client, {
        kept: [{ proposal, inversePattern: proposal.pattern }],
        rolledBack: [],
      });
      result.rolledBack.push({
        change: { proposal, inversePattern: proposal.pattern },
        reason: "Post-reload status did not improve the targeted anomaly.",
      });
    }
  }

  return result;
}

export async function rollbackScopeChanges(
  client: ScopeClient,
  applied: ApplyResult,
): Promise<void> {
  if (applied.kept.length === 0 && applied.rolledBack.length === 0) {
    return; // no-op
  }
  for (const change of applied.kept) {
    const { proposal } = change;
    // Because we cannot remove a glob, we append a compensating glob on
    // the OPPOSITE list. Excluding something we just included is the only
    // legal move that neutralizes the previous append.
    if (proposal.kind === "exclude") {
      await client.configInclude(proposal.specImpl, proposal.pattern);
    } else {
      await client.configExclude(proposal.specImpl, proposal.pattern);
    }
  }
  await client.reload();
}
