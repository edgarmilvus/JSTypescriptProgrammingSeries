<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_4_dynamic_workspace_configuration_policy_rules_igno_part2.md
Description: Solutions and Explanations
==========================================
-->

<!-- scopeManager.POLICY.md -->
# Scope-Change Policy

## Budget

A session may apply at most **4** scope-change proposals. Because each
proposal is verified individually with a reload and a status call, a larger
budget would let a runaway loop reconfigure the intent graph faster than a
reviewer could read the diff.

## Net-scope invariant

Every `include` proposal MUST be paired with an `exclude` proposal that
removes at least as many files from the scan set as the include adds. The net
scope of the intent graph is therefore monotonically non-increasing. This
guarantees that a malformed heuristic cannot slowly widen the workspace until
every file is "in scope" and coverage becomes meaningless.

## Never retarget spec files

Scope changes MUST target implementation globs only. No proposal may include
or exclude `docs/spec/**/*.md`, `docs/**/*.sdoc`, or any path under a spec's
`include` list. Scope changes alter which **source** files feed coverage;
they must not touch which specs are authored, because a scope change that
silently removed a spec from the read set would look like "coverage went up"
rather than "we stopped reading requirements."
