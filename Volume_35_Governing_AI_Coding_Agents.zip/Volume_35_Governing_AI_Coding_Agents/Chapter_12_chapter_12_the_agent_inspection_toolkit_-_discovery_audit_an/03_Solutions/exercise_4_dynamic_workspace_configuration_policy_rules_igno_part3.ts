/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_dynamic_workspace_configuration_policy_rules_igno_part3.ts
Description: Solutions and Explanations
==========================================
*/

// scopeManager.test.ts
import { describe, it, expect, vi } from "vitest";
import {
  detectScopeAnomalies,
  proposeScopeChanges,
  applyScopeChanges,
  rollbackScopeChanges,
  type ScopeClient,
} from "./scopeManager";

function fakeClient(overrides: Partial<ScopeClient> = {}): ScopeClient & {
  calls: string[];
} {
  const calls: string[] = [];
  const c: any = {
    calls,
    status: vi.fn(async () => []),
    config: vi.fn(async () => ({ specs: [] })),
    unmapped: vi.fn(async () => []),
    configInclude: vi.fn(async () => { calls.push("include"); }),
    configExclude: vi.fn(async () => { calls.push("exclude"); }),
    reload: vi.fn(async () => { calls.push("reload"); }),
    ...overrides,
  };
  return c;
}

describe("scopeManager", () => {
  const fakeReport = {
    generatedAt: new Date().toISOString(),
    specs: [{ name: "myapp", prefixes: ["r"], implementationNames: ["rust"], implCoveragePercent: 100, verifyCoveragePercent: 0 }],
    unmappedCodeUnits: [
      { specImpl: "myapp/rust", filePath: "vendor/dep/lib.rs", symbolName: "f", symbolKind: "fn", startLine: 1 },
    ],
    scopeWarnings: [],
  };

  it("detects anomalies in a report containing a vendor subtree", () => {
    const anomalies = detectScopeAnomalies(fakeReport);
    expect(anomalies.some((a) => a.kind === "annotation_in_vendored_tree")).toBe(true);
  });

  it("applies a single exclude proposal and reloads exactly once", async () => {
    const client = fakeClient({
      status: vi.fn(async () => [{ specImpl: "myapp/rust", implCoveragePercent: 40, verifyCoveragePercent: 0 }]),
    });
    const proposals = proposeScopeChanges(detectScopeAnomalies(fakeReport));
    await applyScopeChanges(client, proposals);
    expect(client.calls.filter((c) => c === "exclude").length).toBeGreaterThanOrEqual(1);
    expect(client.calls.filter((c) => c === "reload").length).toBe(proposals.length);
  });

  it("rolls back a proposal whose post-reload status does not improve", async () => {
    const client = fakeClient({
      status: vi.fn(async () => []), // improvement heuristic returns false
    });
    const proposals = proposeScopeChanges(detectScopeAnomalies(fakeReport));
    const result = await applyScopeChanges(client, proposals);
    expect(result.rolledBack.length).toBeGreaterThanOrEqual(1);
  });

  it("never calls a hypothetical remove-glob tool", async () => {
    const client: any = fakeClient();
    client.removeGlob = () => {
      throw new Error("removeGlob must never be called");
    };
    await rollbackScopeChanges(client, { kept: [], rolledBack: [] });
    // The no-op path must not touch removeGlob either.
    expect(true).toBe(true);
  });
});
