/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_consensus-driven_coverage_audit_across_multiple_i.ts
Description: Solutions and Explanations
==========================================
*/

// consensus.ts
import type { RoutingDecision, WorkerTask, ToolEvidence } from "./supervisor";

export type AgentId = "A" | "B" | "C";

export interface AgentReport {
  agentId: AgentId;
  toolCalls: Array<{ tool: string; args: Record<string, unknown> }>;
  raw: Record<string, string>;
  findings: {
    uncoveredUids: string[];
    untestedUids: string[];
    staleUids: string[];
  };
  receivedAt: number; // ms epoch
}

export interface ReconcileFinding {
  uid: string;
  specImpl: string;
  verb: "impl" | "verify" | "depends" | "related";
  supportingAgents: AgentId[];
}

export interface AgentPosition {
  present: boolean;
  toolNames: string[];
}

export interface ReconcileConflict {
  uid: string;
  positions: Record<AgentId, AgentPosition>;
  suggestedResolution: string;
}

export type ConsensusOutcome =
  | { kind: "agree"; findings: ReconcileFinding[] }
  | { kind: "disagree"; conflicts: ReconcileConflict[] }
  | { kind: "insufficient_evidence"; reason: string };

export interface ConsensusProtocol {
  reconcile(reports: AgentReport[]): Promise<ConsensusOutcome>;
}

export interface ScopeClient {
  status(): Promise<unknown>;
  config(): Promise<{ specs: Array<{ name: string; impls: Array<{ name: string }> }> }>;
  unmapped(path?: string): Promise<unknown>;
  reload?(): Promise<void>;
}

export interface TraceyEscalationClient {
  rule(uid: string): Promise<{ text: string }>;
  status(): Promise<unknown>;
  config(): Promise<{ runtimeIncludes?: string[]; runtimeExcludes?: string[] }>;
}

// ---------------------------------------------------------------------------
// StrictIntersection strategy
// ---------------------------------------------------------------------------

export class StrictIntersectionProtocol implements ConsensusProtocol {
  async reconcile(reports: AgentReport[]): Promise<ConsensusOutcome> {
    if (reports.length < 2) {
      return { kind: "insufficient_evidence", reason: "Fewer than two agents reported." };
    }
    const sets = reports.map(
      (r) => new Set([...r.findings.uncoveredUids, ...r.findings.untestedUids, ...r.findings.staleUids]),
    );
    const [first, ...rest] = sets;
    const intersection = new Set([...first].filter((uid) => rest.every((s) => s.has(uid))));
    const findings: ReconcileFinding[] = [...intersection].map((uid) => ({
      uid,
      specImpl: "unknown",
      verb: "impl",
      supportingAgents: reports.map((r) => r.agentId),
    }));
    return findings.length ? { kind: "agree", findings } : { kind: "insufficient_evidence", reason: "No intersection." };
  }
}

// ---------------------------------------------------------------------------
// WeightedUnionProtocol with conflict flagging
// ---------------------------------------------------------------------------

export class WeightedUnionProtocol implements ConsensusProtocol {
  constructor(
    private weights: Record<AgentId, number> = { A: 1, B: 1, C: 1 },
    private escalation?: TraceyEscalationClient,
  ) {}

  async reconcile(reports: AgentReport[]): Promise<ConsensusOutcome> {
    if (reports.length === 0) {
      return { kind: "insufficient_evidence", reason: "No agent reports." };
    }

    const all = new Set<string>();
    const presence = new Map<string, Map<AgentId, Set<string>>>();
    for (const r of reports) {
      const uids = [...r.findings.uncoveredUids, ...r.findings.untestedUids, ...r.findings.staleUids];
      for (const uid of uids) {
        all.add(uid);
        if (!presence.has(uid)) presence.set(uid, new Map());
        presence.get(uid)!.set(r.agentId, new Set(
          r.toolCalls.filter((t) => Object.values(t.args).includes(uid)).map((t) => t.tool),
        ));
      }
    }

    const agreed: ReconcileFinding[] = [];
    const conflicts: ReconcileConflict[] = [];
    for (const uid of all) {
      const p = presence.get(uid)!;
      const presentCount = p.size;
      if (presentCount === reports.length) {
        agreed.push({ uid, specImpl: "unknown", verb: "impl", supportingAgents: [...p.keys()] });
      } else {
        const positions: Record<AgentId, AgentPosition> = {} as Record<AgentId, AgentPosition>;
        for (const r of reports) {
          const toolNames = Array.from(p.get(r.agentId) ?? new Set<string>());
          positions[r.agentId] = { present: p.has(r.agentId), toolNames };
        }
        conflicts.push({
          uid,
          positions,
          suggestedResolution:
            "Re-inspect with tracey_rule before dispatching; agents scoped their queries differently.",
        });
      }
    }

    // Escalation: if the caller supplied an escalation client, re-check the
    // disputed UIDs via tracey_rule and once again via tracey_status. If the
    // disagreement persists, return disagree.
    if (this.escalation && conflicts.length > 0) {
      for (const c of conflicts) {
        await this.escalation.rule(c.uid);
      }
      await this.escalation.status();
    }

    if (agreed.length > 0) return { kind: "agree", findings: agreed };
    if (conflicts.length > 0) return { kind: "disagree", conflicts };
    return { kind: "insufficient_evidence", reason: "No findings from any agent." };
  }
}

// ---------------------------------------------------------------------------
// Staleness heuristic
// ---------------------------------------------------------------------------

export function isReportStale(
  report: AgentReport,
  config: { runtimeIncludes?: string[]; runtimeExcludes?: string[] },
): boolean {
  const recordedPatterns = report.toolCalls
    .filter((t) => t.tool === "tracey_config_include" || t.tool === "tracey_config_exclude")
    .map((t) => String(t.args.pattern ?? ""));
  const livePatterns = [...(config.runtimeIncludes ?? []), ...(config.runtimeExcludes ?? [])];
  for (const live of livePatterns) {
    if (!recordedPatterns.includes(live)) return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// Reconciler
// ---------------------------------------------------------------------------

export interface ReconcilerDeps {
  runAgent: (id: AgentId) => Promise<AgentReport>;
  protocol: ConsensusProtocol;
  escalation: TraceyEscalationClient;
  log: (msg: string) => void;
  wallClockMs?: number;
}

export class Reconciler {
  constructor(private deps: ReconcilerDeps) {}

  async run(agentIds: AgentId[]): Promise<RoutingDecision> {
    const capMs = this.deps.wallClockMs ?? 45_000;

    // Pre-flight: confirm the daemon is ready.
    try {
      await this.deps.escalation.config();
      await this.deps.escalation.status();
    } catch (err) {
      const which = String(err).includes("status") ? "tracey_status" : "tracey_config";
      this.deps.log(`Pre-flight failed on ${which}`);
      return { kind: "halt", reason: "validation_failed" };
    }

    const runners = agentIds.map(async (id) => {
      const timeout = new Promise<AgentReport>((_, reject) =>
        setTimeout(() => reject(new Error(`agent ${id} timed out after ${capMs}ms`)), capMs),
      );
      return Promise.race([this.deps.runAgent(id), timeout]);
    });

    const settled = await Promise.allSettled(runners);
    const reports = settled
      .filter((s): s is PromiseFulfilledResult<AgentReport> => s.status === "fulfilled")
      .map((s) => s.value);

    if (reports.length < agentIds.length) {
      return { kind: "halt", reason: "no_work_found" };
    }

    const outcome = await this.deps.protocol.reconcile(reports);

    if (outcome.kind === "insufficient_evidence") {
      this.deps.log(`Insufficient evidence: ${outcome.reason}`);
      return { kind: "halt", reason: "no_work_found" };
    }
    if (outcome.kind === "disagree") {
      this.deps.log(`Conflicts: ${outcome.conflicts.map((c) => c.uid).join(", ")}`);
      return { kind: "halt", reason: "validation_failed" };
    }

    // Agree: dispatch an annotator for the agreed UIDs.
    const task: WorkerTask = {
      requirementUids: outcome.findings.map((f) => f.uid),
      specImpl: outcome.findings[0]?.specImpl ?? "(all)",
      evidence: [],
    };
    return { kind: "invoke_worker", worker: "annotator", task };
  }
}
