<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_5_consensus-driven_coverage_audit_across_multiple_i_part2.md
Description: Solutions and Explanations
==========================================
-->

<!-- DESIGN.md -->
# Design decisions

## Why `tracey_rule` is the escalation tool

The disputed UID is a *fact about one requirement*: does its annotation
version match its spec version, is it uncovered, is it untested? The
authoritative answer comes from `tracey_rule`, which returns the exact title,
statement, and reference list for that UID. Re-running the entire inspection
(`tracey_status`, `tracey_unmapped`) would be more expensive and would not
narrow the disagreement — it would simply re-surface the same scope-dependent
summaries that caused the disagreement in the first place.

## Why conflicted UIDs never go to `annotator`

The `annotator` worker writes new `r[impl …]` / `r[verify …]` annotations.
Those annotations embed the version suffix — `r[impl auth.login+3]` — that
Tracey uses to detect staleness. If two agents disagree about whether
`auth.login` is currently covered, dispatching an annotator risks writing an
annotation at the *wrong* version, which converts a coverage conflict into a
stale-reference drift. Conflicted UIDs are therefore only ever dispatchable
to the `remediator` worker, which is expected to read the spec via
`tracey_rule` before touching code.

## Why a 45-second wall-clock cap

Forty-five seconds is long enough for three concurrent inspection passes over
a mid-sized monorepo (the reference Tracey config's real-world example scans
`crates/**/*.rs` and `../marq/**/*.rs`), and short enough that a stuck agent
does not consume the supervisor's entire budget. For a monorepo with, say,
200k Rust files, the correct value would be closer to 3 minutes — but at that
point the reconciler should also be re-examining its agent partitioning
rather than hoping a single wall-clock bump will save it. This exercise uses
45 seconds to keep the test suite fast.

## Why conflicts must be logged before dispatch

The `disagree` case is the only case where the reconciler has partial
information. If it dispatched a compensating worker silently, a reviewer
reading the audit log later would see a `remediator` invocation with no
preceding explanation of why that UID was escalated. The log line is the
"why" — it is what turns a reconciliation pass into an auditable decision.
