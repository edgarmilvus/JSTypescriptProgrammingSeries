/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_consensus-driven_coverage_audit_across_multiple_i_part3.ts
Description: Solutions and Explanations
==========================================
*/

// consensus.test.ts
import { describe, it, expect, vi } from "vitest";
import {
  Reconciler,
  WeightedUnionProtocol,
  StrictIntersectionProtocol,
  type AgentReport,
  type AgentId,
} from "./consensus";

function report(id: AgentId, uids: { uncovered?: string[]; untested?: string[]; stale?: string[] }): AgentReport {
  return {
    agentId: id,
    toolCalls: [
      { tool: "tracey_uncovered", args: {} },
      { tool: "tracey_untested", args: {} },
      { tool: "tracey_stale", args: {} },
    ],
    raw: {},
    findings: {
      uncoveredUids: uids.uncovered ?? [],
      untestedUids: uids.untested ?? [],
      staleUids: uids.stale ?? [],
    },
    receivedAt: Date.now(),
  };
}

const esc = {
  rule: vi.fn(async () => ({ text: "" })),
  status: vi.fn(async () => ({})),
  config: vi.fn(async () => ({})),
};

describe("WeightedUnionProtocol", () => {
  it("agrees when all agents report the same UID", async () => {
    const proto = new WeightedUnionProtocol();
    const out = await proto.reconcile([
      report("A", { uncovered: ["auth.login"] }),
      report("B", { uncovered: ["auth.login"] }),
      report("C", { uncovered: ["auth.login"] }),
    ]);
    expect(out.kind).toBe("agree");
  });

  it("flags partial agreements as conflicts", async () => {
    const proto = new WeightedUnionProtocol();
    const out = await proto.reconcile([
      report("A", { uncovered: ["auth.login", "auth.token"] }),
      report("B", { uncovered: ["auth.login"] }),
      report("C", { uncovered: ["auth.login"] }),
    ]);
    if (out.kind === "disagree") expect(out.conflicts.map((c) => c.uid)).toContain("auth.token");
  });

  it("escalates via tracey_rule for disputed UIDs", async () => {
    const proto = new WeightedUnionProtocol({ A: 1, B: 1, C: 1 }, esc);
    await proto.reconcile([
      report("A", { uncovered: ["auth.token"] }),
      report("B", {}),
      report("C", {}),
    ]);
    expect(esc.rule).toHaveBeenCalledWith("auth.token");
  });

  it("returns insufficient_evidence when an agent times out", async () => {
    const proto = new StrictIntersectionProtocol();
    const out = await proto.reconcile([report("A", {})]);
    expect(out.kind).toBe("insufficient_evidence");
  });

  it("detects a stale report from runtime config drift", async () => {
    const r = report("A", {});
    r.toolCalls = [];
    const stale = isReportStale(r, { runtimeIncludes: ["vendor/**"] });
    expect(stale).toBe(true);
  });
});
