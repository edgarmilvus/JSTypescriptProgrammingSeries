/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5b_wiring_the_consensus_mechanism_into_a_react_insp.tsx
Description: Solutions and Explanations
==========================================
*/

// ConsensusPanel.tsx
import React, { useMemo, useState } from "react";
import type {
  ConsensusOutcome,
  ReconcileConflict,
  AgentId,
} from "./consensus";

export interface ConsensusPanelProps {
  outcome: ConsensusOutcome;
  provenance: Array<{ agentId: AgentId; receivedAt: number }>;
  onRequestReinspection: () => Promise<ConsensusOutcome>;
}

export function ConsensusPanel({
  outcome,
  provenance,
  onRequestReinspection,
}: ConsensusPanelProps) {
  const [inFlight, setInFlight] = useState(false);
  const [sortKey, setSortKey] = useState<"resolution" | "uid">("resolution");
  const [specFilter, setSpecFilter] = useState<string>("");

  const conflicts: ReconcileConflict[] =
    outcome.kind === "disagree" ? outcome.conflicts : [];

  const visibleConflicts = useMemo(() => {
    const list = specFilter
      ? conflicts.filter((c) => Object.values(c.positions).some((p) => p.toolNames.join(",").includes(specFilter)))
      : conflicts;
    return [...list].sort((a, b) =>
      sortKey === "uid"
        ? a.uid.localeCompare(b.uid)
        : a.suggestedResolution.localeCompare(b.suggestedResolution),
    );
  }, [conflicts, sortKey, specFilter]);

  const handleReinspect = async () => {
    if (inFlight) return;
    setInFlight(true);
    try {
      await onRequestReinspection();
    } finally {
      setInFlight(false);
    }
  };

  return (
    <div data-testid="consensus-panel">
      {outcome.kind === "agree" && (
        <section data-testid="agree-section">
          <h3>Agreements</h3>
          <ul>
            {outcome.findings.map((f) => (
              <li key={f.uid} data-testid={`agree-${f.uid}`}>
                {f.uid} — supported by {f.supportingAgents.join(", ")}
              </li>
            ))}
          </ul>
        </section>
      )}

      {outcome.kind === "disagree" && (
        <section data-testid="conflict-section">
          <h3>Conflicts</h3>
          <label>
            Filter by specImpl/toolName:
            <input
              data-testid="spec-filter"
              value={specFilter}
              onChange={(e) => setSpecFilter(e.target.value)}
            />
          </label>
          <button
            data-testid="sort-resolution"
            onClick={() => setSortKey(sortKey === "resolution" ? "uid" : "resolution")}
          >
            Sort by: {sortKey}
          </button>
          <ul>
            {visibleConflicts.map((c) => (
              <li key={c.uid} data-testid={`conflict-${c.uid}`}>
                <div>{c.uid}</div>
                <div data-testid={`resolution-${c.uid}`}>{c.suggestedResolution}</div>
                <ul>
                  {(Object.keys(c.positions) as AgentId[]).map((id) => (
                    <li key={id} data-testid={`position-${c.uid}-${id}`}>
                      {id}: {c.positions[id].present ? "present" : "absent"} ({c.positions[id].toolNames.join(", ") || "no tools"})
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        </section>
      )}

      {outcome.kind === "insufficient_evidence" && (
        <section data-testid="insufficient-section">
          <h3>Insufficient evidence</h3>
          <p>{outcome.reason}</p>
        </section>
      )}

      <button
        data-testid="reinspect"
        disabled={inFlight}
        onClick={handleReinspect}
      >
        Request re-inspection
      </button>

      <footer data-testid="provenance">
        Inspection provenance:{" "}
        {provenance
          .slice()
          .sort((a, b) => a.receivedAt - b.receivedAt)
          .map((p) => `${p.agentId}@${new Date(p.receivedAt).toISOString()}`)
          .join(" · ")}
      </footer>
    </div>
  );
}
