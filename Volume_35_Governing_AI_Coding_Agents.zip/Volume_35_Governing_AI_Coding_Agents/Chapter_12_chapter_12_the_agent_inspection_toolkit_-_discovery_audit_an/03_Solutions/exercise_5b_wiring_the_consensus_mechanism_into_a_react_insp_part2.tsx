/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5b_wiring_the_consensus_mechanism_into_a_react_insp_part2.tsx
Description: Solutions and Explanations
==========================================
*/

// ConsensusPanel.test.tsx
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { ConsensusPanel } from "./ConsensusPanel";

const disagree = {
  kind: "disagree" as const,
  conflicts: [
    {
      uid: "auth.token",
      positions: {
        A: { present: true, toolNames: ["tracey_uncovered"] },
        B: { present: false, toolNames: [] },
        C: { present: false, toolNames: [] },
      },
      suggestedResolution: "Re-inspect with tracey_rule before dispatching.",
    },
  ],
};

const provenance = [
  { agentId: "B" as const, receivedAt: 200 },
  { agentId: "A" as const, receivedAt: 100 },
  { agentId: "C" as const, receivedAt: 300 },
];

describe("ConsensusPanel", () => {
  it("renders the suggested resolution and both positions for a conflict", () => {
    render(
      <ConsensusPanel
        outcome={disagree}
        provenance={provenance}
        onRequestReinspection={async () => disagree}
      />,
    );
    expect(screen.getByTestId("resolution-auth.token").textContent).toMatch(/tracey_rule/);
    expect(screen.getByTestId("position-auth.token-A").textContent).toMatch(/present/);
    expect(screen.getByTestId("position-auth.token-B").textContent).toMatch(/absent/);
  });

  it("disables the re-inspection button while the pass is in flight", async () => {
    let resolvePass: (v: typeof disagree) => void = () => {};
    const promise = new Promise<typeof disagree>((res) => (resolvePass = res));
    render(
      <ConsensusPanel
        outcome={disagree}
        provenance={provenance}
        onRequestReinspection={() => promise}
      />,
    );
    const btn = screen.getByTestId("reinspect") as HTMLButtonElement;
    fireEvent.click(btn);
    expect(btn.disabled).toBe(true);
    resolvePass(disagree);
    await waitFor(() => expect(btn.disabled).toBe(false));
  });

  it("lists provenance in received-at order, not alphabetically", () => {
    render(
      <ConsensusPanel
        outcome={disagree}
        provenance={provenance}
        onRequestReinspection={async () => disagree}
      />,
    );
    const text = screen.getByTestId("provenance").textContent ?? "";
    const order = ["A@", "B@", "C@"].map((m) => text.indexOf(m));
    expect(order).toEqual([...order].sort((a, b) => a - b));
  });

  it("does not contradict a stale-UID report from the single-agent dashboard", () => {
    // When the single-agent DriftDashboard reports `auth.token`, this panel
    // must include it in either `agree` or `disagree`, never omit it.
    const present = Object.values(disagree.conflicts[0].positions).some((p) => p.present);
    expect(present).toBe(true);
  });
});
