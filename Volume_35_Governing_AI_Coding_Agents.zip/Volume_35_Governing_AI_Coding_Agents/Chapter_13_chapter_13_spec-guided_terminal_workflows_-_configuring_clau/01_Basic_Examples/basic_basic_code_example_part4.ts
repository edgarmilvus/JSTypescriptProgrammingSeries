/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// r[impl billing.discount.apply]
// The governor below is the runtime bridge that forces every terminal
// agent action to be justified by a specific requirement in the
// living intent graph. It is annotated with the same grammar it
// enforces on the agent's output.

import { z } from "zod";

/* ----------------------------------------------------------------- *
 * 1. MCP transport — a thin JSON-RPC 2.0 client for tracey mcp      *
 * ----------------------------------------------------------------- */

/**
 * Minimal envelope for a JSON-RPC 2.0 response as returned by the
 * tracey MCP stdio bridge.
 */
interface McpJsonRpcResponse {
  jsonrpc: "2.0";
  id: string | number;
  result?: unknown;
  error?: { code: number; message: string };
}

/**
 * Invoke a tracey MCP tool by name and return its raw payload.
 *
 * In production this call goes over stdio to `tracey mcp`; here it is
 * modelled as an HTTP POST so the example is runnable from Node's
 * built-in fetch without spawning a child process.
 */
async function callTraceyTool(
  toolName: "tracey_rule" | "tracey_status" | "tracey_validate",
  args: Record<string, unknown>,
): Promise<unknown> {
  const envelope = {
    jsonrpc: "2.0" as const,
    id: crypto.randomUUID(),
    method: "tools/call",
    params: { name: toolName, arguments: args },
  };

  const response = await fetch("http://127.0.0.1:7777/mcp", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(envelope),
  });

  const json = (await response.json()) as McpJsonRpcResponse;

  if (json.error) {
    throw new Error(`tracey MCP error: ${json.error.message}`);
  }
  return json.result;
}

/* ----------------------------------------------------------------- *
 * 2. The JSON Schema we impose on the agent's reply                 *
 * ----------------------------------------------------------------- */

/**
 * The DelegationPlanSchema is the contract between the governor and
 * the LLM. Any field the model returns that is not listed here — or
 * that violates a constraint — causes Zod to throw, which fails the
 * agent run closed rather than letting a malformed plan escape into
 * the codebase.
 */
const DelegationPlanSchema = z.object({
  requirementUid: z
    .string()
    .regex(/^billing\.[a-z0-9.-]+$/, "Must reference a billing.* rule"),
  targetFile: z.string().endsWith(".ts"),
  functionName: z.string().min(1).max(64),
  summary: z.string().min(20).max(500),
  annotations: z
    .array(z.enum(["impl", "verify", "depends", "related"]))
    .min(1),
});

/** A narrowed, fully typed delegation plan. */
type DelegationPlan = z.infer<typeof DelegationPlanSchema>;

/* ----------------------------------------------------------------- *
 * 3. Type narrowing across the LLM trust boundary                   *
 * ----------------------------------------------------------------- */

/**
 * Runtime guard that narrows `unknown` into a plain object map. This
 * is the first gate the agent's payload must pass through.
 */
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

/**
 * Narrow the raw LLM output into a DelegationPlan. Every escape from
 * the `unknown` type is guarded by a runtime check so that the
 * TypeScript compiler can prove the eventual access to `.plan` and
 * the Zod parse input are safe.
 */
function extractPlan(raw: unknown): DelegationPlan {
  if (!isRecord(raw)) {
    throw new TypeError("Agent response was not a JSON object");
  }
  const candidate = raw.plan;
  if (!isRecord(candidate)) {
    throw new TypeError("Agent response is missing the top-level 'plan' key");
  }
  // Zod takes over from here: it validates the shape declared above
  // and returns a value the compiler accepts as DelegationPlan.
  return DelegationPlanSchema.parse(candidate);
}

/* ----------------------------------------------------------------- *
 * 4. The governed terminal invocation                              *
 * ----------------------------------------------------------------- */

/**
 * Result of a governed agent run: the typed plan plus the raw rule
 * text that was used as the grounding context.
 */
export interface GovernedRunResult {
  plan: DelegationPlan;
  ruleText: string;
}

/**
 * Run a terminal agent under spec governance for a single requirement.
 *
 * Order of operations:
 *   1. tracey_rule       → fetch the *exact* normative text
 *   2. terminal agent    → delegate with JSON Schema output
 *   3. extractPlan       → narrow + validate the reply
 *   4. tracey_validate   → confirm we did not break the intent graph
 */
export async function governAgentRun(
  requirementUid: string,
): Promise<GovernedRunResult> {
  // Step 1 — preflight retrieval.
  const rule = await callTraceyTool("tracey_rule", { uid: requirementUid });
  const ruleText = JSON.stringify(rule);

  // Step 2 — delegate to the terminal agent with the schema attached.
  const rawAgentOutput = await runTerminalAgent({
    prompt:
      `You are governed by a StrictDoc intent graph. ` +
      `Requirement ${requirementUid} states:\n${ruleText}\n` +
      `Respond with JSON only, matching the DelegationPlanSchema.`,
    jsonSchema: {
      type: "object",
      required: ["plan"],
      properties: {
        plan: {
          type: "object",
          required: [
            "requirementUid",
            "targetFile",
            "functionName",
            "summary",
            "annotations",
          ],
        },
      },
    },
  });

  // Step 3 — narrow the trust boundary.
  const plan = extractPlan(rawAgentOutput);

  // Step 4 — postflight validation against the live graph.
  await callTraceyTool("tracey_validate", { deny_warnings: true });

  return { plan, ruleText };
}

/* ----------------------------------------------------------------- *
 * 5. Stub for the real terminal agent                              *
 * ----------------------------------------------------------------- */

/**
 * In production this shells out to `claude` or `codex` with
 * `--output-format=json --json-schema=<path>`. For the hello-world
 * example we return a fixed, schema-valid reply so the governor is
 * unit-testable without network access.
 */
async function runTerminalAgent(params: {
  prompt: string;
  jsonSchema: object;
}): Promise<unknown> {
  void params.prompt;
  void params.jsonSchema;
  return {
    plan: {
      requirementUid: "billing.discount.apply",
      targetFile: "src/discounts.ts",
      functionName: "applyPromoCode",
      summary:
        "Validate the promo code against the ledger and discount the subtotal.",
      annotations: ["impl", "verify"],
    },
  };
}
