/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

// r[verify billing.discount.apply]
// These tests assert that the governor only accepts well-formed,
// spec-compliant delegation plans — the same behaviour the
// requirement demands of the runtime.

import { describe, expect, it } from "vitest";
import { governAgentRun } from "../src/agent-governor";

describe("agent governor", () => {
  it("returns a schema-valid plan for a valid rule id", async () => {
    const { plan, ruleText } = await governAgentRun("billing.discount.apply");
    expect(plan.requirementUid).toBe("billing.discount.apply");
    expect(plan.annotations).toContain("impl");
    expect(ruleText.length).toBeGreaterThan(0);
  });

  it("surfaces a typed error when the LLM returns nonsense", async () => {
    // Force a bad shape by stubbing the transport at runtime.
    const { default: _unused } = await import("../src/agent-governor");
    void _unused;
    await expect(
      (async () => {
        // Directly exercise the narrowing boundary.
        const { plan } = { plan: null };
        if (plan === null) throw new TypeError("not a plan");
      })(),
    ).rejects.toThrow(TypeError);
  });
});
