/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_wiring_tracey_ai_into_a_dual-agent_terminal_works_part4.ts
Description: Solutions and Explanations
==========================================
*/

import { readFile } from "node:fs/promises";
import { z } from "zod";

export const OnboardingSchema = z
  .object({
    tracey_version: z.string().min(1),
    claude_registered: z.boolean(),
    codex_registered: z.boolean(),
    skill_path_claude: z.string().min(1),
    skill_path_codex: z.string().min(1),
    timestamp_utc: z.string().datetime(),
  })
  .superRefine((value, ctx) => {
    if (!value.claude_registered) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["claude_registered"],
        message: "claude_registered must be true",
      });
    }
    if (!value.codex_registered) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["codex_registered"],
        message: "codex_registered must be true",
      });
    }
  });

export type Onboarding = z.infer<typeof OnboardingSchema>;

export type VerifyOnboardingResult =
  | { ok: true; data: Onboarding }
  | { ok: false; errors: string[] };

export async function verifyOnboarding(
  path = ".tracey/onboarding.json"
): Promise<VerifyOnboardingResult> {
  try {
    const raw = await readFile(path, "utf8");
    const json: unknown = JSON.parse(raw);
    const parsed = OnboardingSchema.safeParse(json);

    if (parsed.success) {
      return { ok: true, data: parsed.data };
    }

    return {
      ok: false,
      errors: parsed.error.issues.map(
        (issue) => `${issue.path.join(".") || "<root>"}: ${issue.message}`
      ),
    };
  } catch (error) {
    return {
      ok: false,
      errors: [error instanceof Error ? error.message : String(error)],
    };
  }
}
