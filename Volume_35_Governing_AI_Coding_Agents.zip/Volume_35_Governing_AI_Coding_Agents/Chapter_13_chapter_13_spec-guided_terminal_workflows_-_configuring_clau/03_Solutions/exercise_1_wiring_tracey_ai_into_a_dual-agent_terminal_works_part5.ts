/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_wiring_tracey_ai_into_a_dual-agent_terminal_works_part5.ts
Description: Solutions and Explanations
==========================================
*/

import { describe, expect, it, vi, beforeEach } from "vitest";
import { readFile } from "node:fs/promises";
import { verifyOnboarding } from "./verify-onboarding";

vi.mock("node:fs/promises", () => ({
  readFile: vi.fn(),
}));

const mockedReadFile = vi.mocked(readFile);

const valid = {
  tracey_version: "2.0.0-rc.0",
  claude_registered: true,
  codex_registered: true,
  skill_path_claude: "/home/u/.claude/skills/tracey",
  skill_path_codex: "/home/u/.codex/skills/tracey",
  timestamp_utc: "2026-09-16T08:11:23Z",
};

describe("verifyOnboarding", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("accepts a fully valid onboarding state", async () => {
    mockedReadFile.mockResolvedValue(JSON.stringify(valid));
    const result = await verifyOnboarding();
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.data.tracey_version).toBe("2.0.0-rc.0");
  });

  it("reports missing skill_path_codex", async () => {
    const { skill_path_codex: _, ...broken } = valid;
    mockedReadFile.mockResolvedValue(JSON.stringify(broken));
    const result = await verifyOnboarding();
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.errors.some((e) => e.includes("skill_path_codex"))).toBe(true);
    }
  });

  it("reports claude_registered false", async () => {
    mockedReadFile.mockResolvedValue(
      JSON.stringify({ ...valid, claude_registered: false })
    );
    const result = await verifyOnboarding();
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.errors.some((e) => e.includes("claude_registered"))).toBe(true);
    }
  });
});
