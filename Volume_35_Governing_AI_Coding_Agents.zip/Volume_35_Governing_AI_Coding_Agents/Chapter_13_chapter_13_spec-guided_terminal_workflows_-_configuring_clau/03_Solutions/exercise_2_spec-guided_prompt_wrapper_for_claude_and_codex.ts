/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_spec-guided_prompt_wrapper_for_claude_and_codex.ts
Description: Solutions and Explanations
==========================================
*/

#!/usr/bin/env node
/**
 * sagent — spec-guided terminal wrapper.
 *
 * Governance contract:
 *   - always sets TRACEY_AGENT_SPEC=1 before launching the child agent.
 *   - preflight aborts with exit code 7 and stderr:
 *       sagent: preflight abort reason=<reason>
 */
import { Command } from "commander";
import { execa } from "execa";

export interface CoverageStatus {
  implCoverage: number;
  verifyCoverage: number;
  uncovered: number;
  untested: number;
}

export function isCoverageStatus(value: unknown): value is CoverageStatus {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.implCoverage === "number" &&
    typeof v.verifyCoverage === "number" &&
    typeof v.uncovered === "number" &&
    typeof v.untested === "number"
  );
}

export function parseStatus(stdout: string): CoverageStatus {
  const impl = /impl[:\s]+(\d+(?:\.\d+)?)%/i.exec(stdout);
  const verify = /verify[:\s]+(\d+(?:\.\d+)?)%/i.exec(stdout);
  const uncovered = /uncovered[:\s]+(\d+)/i.exec(stdout);
  const untested = /untested[:\s]+(\d+)/i.exec(stdout);

  const status: CoverageStatus = {
    implCoverage: impl ? Number(impl[1]) : 0,
    verifyCoverage: verify ? Number(verify[1]) : 0,
    uncovered: uncovered ? Number(uncovered[1]) : 0,
    untested: untested ? Number(untested[1]) : 0,
  };

  if (!isCoverageStatus(status)) {
    throw new Error("invalid coverage status");
  }
  return status;
}

export interface UncoveredRow {
  uid: string;
  statement?: string;
}

export function buildPreamble(uncovered: UncoveredRow[]): string {
  const sorted = [...uncovered].sort((a, b) => a.uid.localeCompare(b.uid));
  const lines = sorted.map((row) => {
    const snippet = row.statement ? row.statement.slice(0, 80) : "(truncated)";
    return `- ${row.uid} (statement: ${snippet})`;
  });

  return [
    "You are operating under a Tracey-governed intent graph.",
    "The following requirement UIDs are uncovered and must be annotated with // r[impl <uid>] where implemented:",
    ...lines,
    "Do not proceed with any code change that does not carry an annotation referencing one of these UIDs.",
  ].join("\n");
}

async function tracey(args: string[]): Promise<string> {
  const { stdout } = await execa("tracey", args, { reject: false });
  return stdout;
}

async function getStatus(): Promise<CoverageStatus> {
  return parseStatus(await tracey(["query", "status"]));
}

async function getUncovered(prefix: string): Promise<UncoveredRow[]> {
  const stdout = await tracey(["query", "uncovered", "--prefix", prefix]);
  return stdout
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const m = /^([a-z0-9._-]+)\s+—\s+(.*)$/i.exec(line);
      return m ? { uid: m[1], statement: m[2] } : null;
    })
    .filter((x): x is UncoveredRow => x !== null);
}

async function getStale(prefix: string): Promise<string[]> {
  const stdout = await tracey(["query", "stale", "--prefix", prefix]);
  return stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
}

async function getUntested(prefix: string): Promise<string[]> {
  const stdout = await tracey(["query", "untested", "--prefix", prefix]);
  return stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
}

async function ruleSnippet(uid: string): Promise<string> {
  const stdout = await tracey(["query", "rule", uid]);
  const match = /STATEMENT:\s*([\s\S]*?)(?:\n[A-Z_]+:|$)/.exec(stdout);
  return match ? match[1].trim().slice(0, 80) : "(truncated)";
}

async function main() {
  const program = new Command();

  program
    .name("sagent")
    .command("run")
    .argument("<agent>", "claude | codex")
    .requiredOption("--prefix <prefix>")
    .option("--strict", "abort on uncovered requirements")
    .option("--mode <mode>", "preflight | drift | repair", "preflight")
    .allowUnknownOption(true)
    .argument("[agentArgs...]")
    .action(async (agent: string, options, agentArgs: string[]) => {
      if (!["claude", "codex"].includes(agent)) {
        console.error(`sagent: unknown agent <${agent}>`);
        process.exit(2);
      }

      const prefix = options.prefix as string;
      const mode = options.mode as string;

      if (mode === "drift") {
        console.log(await getStale(prefix));
        console.log(await getUntested(prefix));
        process.exit(0);
      }

      const validate = await execa(
        "tracey",
        ["query", "validate", "--deny", "warnings"],
        { reject: false }
      );

      if (validate.exitCode !== 0) {
        console.error("sagent: preflight abort reason=validate_failed");
        process.exit(7);
      }

      const status = await getStatus();
      const uncovered = await getUncovered(prefix);
      const stale = await getStale(prefix);

      if (options.strict && uncovered.length > 0) {
        console.error("sagent: preflight abort reason=uncovered");
        process.exit(7);
      }

      if (uncovered.length || stale.length) {
        console.error(
          `sagent: warning uncovered=${uncovered.length} stale=${stale.length} ` +
            `impl=${status.implCoverage}% verify=${status.verifyCoverage}%`
        );
      }

      const env: NodeJS.ProcessEnv = {
        ...process.env,
        TRACEY_AGENT_SPEC: "1",
      };

      if (mode === "repair") {
        const untested = await getUntested(prefix);
        const firstTen = uncovered.slice(0, 10);
        const rows = await Promise.all(
          firstTen.map(async (row) => ({
            uid: row.uid,
            statement: row.statement ?? (await ruleSnippet(row.uid)),
          }))
        );
        env.TRACEY_PREAMBLE = buildPreamble(rows);
        console.error(
          `sagent: repair untested=${untested.length} uncovered=${uncovered.length}`
        );
      }

      const child = execa(agent, agentArgs, { stdio: "inherit", env });
      await child;
      process.exit(child.exitCode ?? 0);
    });

  await program.parseAsync(process.argv);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((err) => {
    console.error(`sagent: fatal ${err instanceof Error ? err.message : String(err)}`);
    process.exit(1);
  });
}
