/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_spec-guided_prompt_wrapper_for_claude_and_codex_part2.ts
Description: Solutions and Explanations
==========================================
*/

import { describe, expect, it } from "vitest";
import { parseStatus, isCoverageStatus, buildPreamble } from "./sagent";

describe("parseStatus", () => {
  it("parses all green", () => {
    const s = parseStatus("impl: 100% verify: 100%\nUncovered: 0\nUntested: 0");
    expect(s).toEqual({
      implCoverage: 100,
      verifyCoverage: 100,
      uncovered: 0,
      untested: 0,
    });
  });

  it("parses two uncovered", () => {
    const s = parseStatus("impl: 80% verify: 50%\nUncovered: 2\nUntested: 1");
    expect(s.uncovered).toBe(2);
  });
});

describe("isCoverageStatus", () => {
  it.each([undefined, null, {}, "x"])("rejects %p", (v) => {
    expect(isCoverageStatus(v)).toBe(false);
  });
});

describe("buildPreamble", () => {
  it("falls back to (truncated)", () => {
    const text = buildPreamble([{ uid: "auth.login", statement: undefined }]);
    expect(text).toContain("(truncated)");
  });
});
