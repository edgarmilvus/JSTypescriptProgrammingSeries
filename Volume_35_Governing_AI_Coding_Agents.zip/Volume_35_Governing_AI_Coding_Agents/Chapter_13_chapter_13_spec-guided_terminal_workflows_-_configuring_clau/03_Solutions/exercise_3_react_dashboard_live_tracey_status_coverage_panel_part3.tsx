/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_react_dashboard_live_tracey_status_coverage_panel_part3.tsx
Description: Solutions and Explanations
==========================================
*/

import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach } from "vitest";
import { http, HttpResponse } from "msw";
import { setupServer } from "msw/node";
import { TraceyCoveragePanel } from "./TraceyCoveragePanel";

const server = setupServer(
  http.post("/api/tracey/tools/tracey_uncovered", () =>
    HttpResponse.json({
      result: {
        content: [
          {
            type: "text",
            text: "auth.login — must accept credentials\nauth.token — must expire",
          },
        ],
      },
    })
  ),
  http.post("/api/tracey/tools/tracey_untested", () =>
    HttpResponse.json({
      result: { content: [{ type: "text", text: "auth.login — must accept credentials" }] },
    })
  ),
  http.post("/api/tracey/tools/tracey_stale", () =>
    HttpResponse.json({
      result: { content: [{ type: "text", text: "auth.token — must expire" }] },
    })
  )
);

beforeEach(() => {
  server.listen({ onUnhandledRequest: "error" });
  Object.assign(navigator, {
    clipboard: { writeText: vi.fn() },
  });
});

describe("TraceyCoveragePanel", () => {
  it("renders counters", async () => {
    render(<TraceyCoveragePanel />);
    expect(await screen.findByText(/Uncovered: 2/)).toBeInTheDocument();
    expect(await screen.findByText(/Untested: 1/)).toBeInTheDocument();
  });

  it("copies impl annotation", async () => {
    render(<TraceyCoveragePanel />);
    const buttons = await screen.findAllByText("Copy annotation");
    fireEvent.click(buttons[0]);
    await waitFor(() => {
      expect(navigator.clipboard.writeText).toHaveBeenCalledWith(
        "// r[impl auth.login]"
      );
    });
  });

  it("renders MCP failure message", async () => {
    server.use(
      http.post("/api/tracey/tools/tracey_uncovered", () =>
        HttpResponse.json({ error: { message: "tracey daemon unavailable" } })
      )
    );
    render(<TraceyCoveragePanel />);
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "tracey daemon unavailable"
    );
  });
});
