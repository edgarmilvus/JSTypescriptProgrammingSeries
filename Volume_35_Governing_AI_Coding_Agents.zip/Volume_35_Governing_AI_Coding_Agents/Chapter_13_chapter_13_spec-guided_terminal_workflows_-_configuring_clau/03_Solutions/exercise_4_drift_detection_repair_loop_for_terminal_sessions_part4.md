<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_4_drift_detection_repair_loop_for_terminal_sessions_part4.md
Description: Solutions and Explanations
==========================================
-->

# Drift loop

The drift loop runs after an agent session and compares Tracey's stale and
unmapped output against local source files.

## Safety guards

`applyEdits` refuses two classes of edits:

1. A replacement containing a backtick example such as `` `r[ impl x] ``, because
   Tracey ignores annotations inside backticks.
2. A target line that appears to be inside a string literal, detected by a
   lightweight lexical scan for `"`, `'`, `"""`, and `'''`.

The string-literal guard is deliberately not a full AST. It is fast, language
agnostic, and conservative: false positives are preferred over corrupting
source. It does not parse heredocs, raw strings, or language-specific quoting
rules. Review refused edits manually.
