/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

/**
 * Sliding-window rate limiter for login attempts, keyed by source IP.
 *
 * Reference implementation for the living intent graph requirements
 * `auth.rate-limit` and `auth.rate-limit.window`.
 *
 * @module auth/rate-limiter
 */

/** Rolling window length in milliseconds. */
const WINDOW_MS = 60_000;

/** Maximum attempts allowed per IP inside the window. */
const MAX_ATTEMPTS = 5;

/** In-memory store: IP address → ascending list of attempt timestamps. */
const attemptsByIp = new Map<string, number[]>();

/**
 * Record a login attempt for `ip` at unix-millisecond time `now`.
 *
 * @param ip  Source IP address of the client.
 * @param now Current time in ms. Injectable so tests stay deterministic.
 * @returns `true` if the attempt is allowed, `false` if it exceeded the limit.
 */
// r[impl auth.rate-limit]
// r[impl auth.rate-limit.window]
export function recordLoginAttempt(ip: string, now: number = Date.now()): boolean {
  const history = (attemptsByIp.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  history.push(now);
  attemptsByIp.set(ip, history);
  return history.length <= MAX_ATTEMPTS;
}

/**
 * Check whether `ip` is currently blocked, without recording an attempt.
 *
 * @param ip  Source IP address of the client.
 * @param now Current time in ms.
 * @returns `true` when the IP has already reached the attempt limit.
 */
// r[impl auth.rate-limit]
export function isBlocked(ip: string, now: number = Date.now()): boolean {
  const history = attemptsByIp.get(ip) ?? [];
  return history.filter((t) => now - t < WINDOW_MS).length >= MAX_ATTEMPTS;
}
