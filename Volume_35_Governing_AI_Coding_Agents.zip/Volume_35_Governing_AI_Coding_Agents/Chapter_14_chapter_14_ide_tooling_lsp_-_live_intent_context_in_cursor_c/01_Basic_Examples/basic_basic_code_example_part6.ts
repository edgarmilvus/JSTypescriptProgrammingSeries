/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part6.ts
Description: Basic Code Example
==========================================
*/

import { describe, it, expect } from 'vitest';
import { recordLoginAttempt, isBlocked } from './rate-limiter';

describe('rate-limiter (sliding window)', () => {
  // r[verify auth.rate-limit]
  it('blocks the 6th attempt inside the same 60s window', () => {
    const ip = '10.0.0.1';
    const t0 = 1_000_000;

    for (let i = 0; i < 5; i++) {
      expect(recordLoginAttempt(ip, t0 + i)).toBe(true);
    }

    expect(recordLoginAttempt(ip, t0 + 5)).toBe(false);
    expect(isBlocked(ip, t0 + 5)).toBe(true);
  });

  // r[verify auth.rate-limit.window]
  it('expires attempts that fall outside the rolling window', () => {
    const ip = '10.0.0.2';
    const t0 = 2_000_000;

    for (let i = 0; i < 5; i++) recordLoginAttempt(ip, t0 + i);
    expect(isBlocked(ip, t0 + 10)).toBe(true);

    // 61 seconds later, every prior attempt is outside the window.
    expect(isBlocked(ip, t0 + 61_000)).toBe(false);
    expect(recordLoginAttempt(ip, t0 + 61_000)).toBe(true);
  });
});
