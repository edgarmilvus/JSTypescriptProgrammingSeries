/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

// src/tenant/provisioning.ts

import { randomUUID } from "node:crypto";
import { AuditWriter } from "./audit-writer";
import { QuotaLedger } from "./quota-ledger";
import { Telemetry } from "./telemetry";

/**
 * Represents the input to a tenant provisioning request.
 */
export interface ProvisionTenantRequest {
  /** The human-readable tenant slug, unique across the platform. */
  readonly slug: string;
  /** The seat limit contractually granted to this tenant. */
  readonly seatLimit: number;
  /** Caller-supplied idempotency key; must be stable across retries. */
  readonly idempotencyKey: string;
}

/** The materialized state of a freshly provisioned tenant. */
export interface ProvisionedTenant {
  readonly tenantId: string;
  readonly slug: string;
  readonly seatLimit: number;
  readonly auditSequence: number;
}

/**
 * Sentinel error raised when the quota invariant would be breached.
 * The HTTP layer maps this to status 422 and code `quota.exceeded`.
 */
export class QuotaExceededError extends Error {
  public readonly code = "quota.exceeded" as const;
  constructor(public readonly attempted: number, public readonly limit: number) {
    super(`Quota exceeded: attempted=${attempted} limit=${limit}`);
    this.name = "QuotaExceededError";
  }
}

/**
 * Provisions a new tenant atomically.
 *
 * The caller MUST supply a stable idempotency key. Repeated calls with the same
 * key return the same tenant and do not append additional audit entries.
 *
 * @see PROV-001 — Atomic Tenant Provisioning
 * @see PROV-010 — Immutable Audit Append
 */
// r[impl PROV-001]
// r[impl PROV-010]
export async function provisionTenant(
  request: ProvisionTenantRequest,
  deps: {
    readonly audit: AuditWriter;
    readonly quota: QuotaLedger;
    readonly telemetry: Telemetry;
  },
): Promise<ProvisionedTenant> {
  const { slug, seatLimit, idempotencyKey } = request;

  // Fast path: idempotent replay.
  const existing = await deps.quota.lookupByIdempotencyKey(idempotencyKey);
  if (existing) {
    return existing;
  }

  const tenantId = randomUUID();

  // The quota ledger stages the allocation without committing.
  const staged = await deps.quota.stage(tenantId, slug, seatLimit);

  if (staged.attempted > seatLimit) {
    // The quota invariant forbids over-allocation. Roll back the staging.
    await deps.quota.rollback(tenantId);
    deps.telemetry.emit("provisioning.rolled_back", {
      slug,
      reason: "quota.exceeded",
    });
    throw new QuotaExceededError(staged.attempted, seatLimit);
  }

  // Append the immutable audit entry. This must be the last write.
  let auditSequence: number;
  try {
    auditSequence = await deps.audit.append({
      slug,
      seatDelta: seatLimit,
      idempotencyKey,
    });
  } catch (cause) {
    // Audit append failed after staging: compensate.
    await deps.quota.rollback(tenantId);
    deps.telemetry.emit("provisioning.rolled_back", {
      slug,
      reason: "audit.append_failed",
    });
    throw cause;
  }

  // Commit the staged allocation now that durability is guaranteed.
  await deps.quota.commit(tenantId);

  return { tenantId, slug, seatLimit, auditSequence };
}
