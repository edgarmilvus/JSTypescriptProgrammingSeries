/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part13.ts
Description: Advanced Application Implementation
==========================================
*/

// src/tenant/quota-check.ts

import { QuotaLedger } from "./quota-ledger";
import { QuotaExceededError } from "./provisioning";

/**
 * Validates a proposed seat mutation against the tenant's recorded seat limit.
 *
 * The check reads the tenant's authoritative seat limit from the ledger, then
 * compares it against the proposed post-mutation total. It never mutates state;
 * the caller is responsible for staging and committing accepted mutations.
 *
 * @see PROV-002 — Per-Seat Quota Invariant
 */
// r[impl PROV-002]
export async function assertSeatMutationAllowed(
  tenantId: string,
  proposedSeats: number,
  ledger: QuotaLedger,
): Promise<void> {
  const tenant = await ledger.get(tenantId);
  if (!tenant) {
    throw new Error(`Unknown tenant: ${tenantId}`);
  }
  if (proposedSeats > tenant.seatLimit) {
    throw new QuotaExceededError(proposedSeats, tenant.seatLimit);
  }
}
