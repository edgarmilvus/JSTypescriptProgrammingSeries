/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part14.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/tenant/provisioning.test.ts

import { describe, it, expect, vi } from "vitest";
import {
  provisionTenant,
  QuotaExceededError,
  type ProvisionTenantRequest,
} from "../../src/tenant/provisioning";
import { AuditWriter } from "../../src/tenant/audit-writer";
import { QuotaLedger } from "../../src/tenant/quota-ledger";
import { Telemetry } from "../../src/tenant/telemetry";

/**
 * Builds a minimal in-memory double for the provisioning collaborators.
 */
function makeDeps() {
  const auditLog: Array<{ slug: string; seatDelta: number; key: string }> = [];
  const telemetryEvents: Array<{ name: string; payload: unknown }> = [];

  const audit = {
    append: vi.fn(async (entry) => {
      auditLog.push({
        slug: entry.slug,
        seatDelta: entry.seatDelta,
        key: entry.idempotencyKey,
      });
      return auditLog.length;
    }),
  } as unknown as AuditWriter;

  const quota = {
    lookupByIdempotencyKey: vi.fn(async () => null),
    stage: vi.fn(async (tenantId, slug, seatLimit) => ({
      tenantId,
      attempted: seatLimit,
    })),
    commit: vi.fn(async () => {}),
    rollback: vi.fn(async () => {}),
  } as unknown as QuotaLedger;

  const telemetry = {
    emit: vi.fn((name, payload) => {
      telemetryEvents.push({ name, payload });
    }),
  } as unknown as Telemetry;

  return { audit, quota, telemetry, auditLog, telemetryEvents };
}

describe("provisionTenant", () => {
  it("commits tenant, quota, and audit atomically on the happy path", async () => {
    // r[verify PROV-001]
    const { audit, quota, telemetry, auditLog } = makeDeps();
    const request: ProvisionTenantRequest = {
      slug: "acme",
      seatLimit: 25,
      idempotencyKey: "idem-acme-001",
    };

    const result = await provisionTenant(request, { audit, quota, telemetry });

    expect(result.slug).toBe("acme");
    expect(result.seatLimit).toBe(25);
    expect(auditLog).toHaveLength(1);
    expect(auditLog[0]).toEqual({
      slug: "acme",
      seatDelta: 25,
      key: "idem-acme-001",
    });
    expect(quota.commit).toHaveBeenCalledTimes(1);
    expect(quota.rollback).not.toHaveBeenCalled();
  });

  it("rolls back when the audit append fails after staging", async () => {
    // r[verify prov.tenant.provisioning-rollback]
    const { audit, quota, telemetry, telemetryEvents } = makeDeps();
    (audit.append as ReturnType<typeof vi.fn>).mockRejectedValueOnce(
      new Error("audit durable store unavailable"),
    );

    await expect(
      provisionTenant(
        { slug: "acme", seatLimit: 10, idempotencyKey: "idem-acme-002" },
        { audit, quota, telemetry },
      ),
    ).rejects.toThrow("audit durable store unavailable");

    expect(quota.rollback).toHaveBeenCalledTimes(1);
    expect(quota.commit).not.toHaveBeenCalled();
    expect(telemetryEvents).toContainEqual({
      name: "provisioning.rolled_back",
      payload: { slug: "acme", reason: "audit.append_failed" },
    });
  });

  it("rejects mutations that would breach the seat limit", async () => {
    // r[verify PROV-002]
    const { audit, quota, telemetry } = makeDeps();
    (quota.stage as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      tenantId: "t-1",
      attempted: 30,
    });

    await expect(
      provisionTenant(
        { slug: "acme", seatLimit: 20, idempotencyKey: "idem-acme-003" },
        { audit, quota, telemetry },
      ),
    ).rejects.toBeInstanceOf(QuotaExceededError);

    expect(quota.rollback).toHaveBeenCalledTimes(1);
  });
});
