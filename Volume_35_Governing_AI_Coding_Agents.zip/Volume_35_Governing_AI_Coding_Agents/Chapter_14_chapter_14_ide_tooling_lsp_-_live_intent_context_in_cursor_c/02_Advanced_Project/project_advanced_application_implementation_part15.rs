/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part15.rs
Description: Advanced Application Implementation
==========================================
*/

// crates/audit/src/writer.rs

//! Immutable audit writer for tenant provisioning events.
//!
//! The writer guarantees idempotency with respect to the caller-supplied
//! idempotency key and monotonic sequence numbers per tenant.

use std::collections::HashMap;
use std::sync::Mutex;

/// A single audit entry describing a provisioning mutation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AuditEntry {
    pub slug: String,
    pub seat_delta: i64,
    pub idempotency_key: String,
    pub sequence: u64,
}

/// In-memory audit store. The production implementation would persist to an
/// append-only ledger; the invariants proven here carry over unchanged.
#[derive(Default)]
pub struct AuditWriter {
    by_key: Mutex<HashMap<String, AuditEntry>>,
    by_slug_seq: Mutex<HashMap<String, u64>>,
}

/// The outcome of an append operation.
#[derive(Debug, PartialEq, Eq)]
pub enum AppendOutcome {
    /// The entry was appended; the returned sequence is fresh.
    Appended(AuditEntry),
    /// A prior append with the same idempotency key already exists.
    Replayed(AuditEntry),
}

impl AuditWriter {
    /// Appends one immutable audit entry.
    ///
    /// If an entry with the same idempotency key already exists, the existing
    /// entry is returned verbatim and no new sequence number is allocated.
    ///
    /// Implements PROV-010 (Immutable Audit Append).
    // r[impl PROV-010]
    pub fn append(
        &self,
        slug: &str,
        seat_delta: i64,
        idempotency_key: &str,
    ) -> AppendOutcome {
        // Fast path: idempotent replay.
        {
            let by_key = self.by_key.lock().unwrap();
            if let Some(existing) = by_key.get(idempotency_key) {
                return AppendOutcome::Replayed(existing.clone());
            }
        }

        // Allocate the next strictly increasing sequence for the tenant.
        // r[impl prov.audit.sequence-monotonic]
        let mut by_slug_seq = self.by_slug_seq.lock().unwrap();
        let next = by_slug_seq
            .entry(slug.to_string())
            .and_modify(|s| *s += 1)
            .or_insert(1);

        let entry = AuditEntry {
            slug: slug.to_string(),
            seat_delta,
            idempotency_key: idempotency_key.to_string(),
            sequence: *next,
        };

        let mut by_key = self.by_key.lock().unwrap();
        by_key.insert(idempotency_key.to_string(), entry.clone());

        AppendOutcome::Appended(entry)
    }
}
