/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part16.rs
Description: Advanced Application Implementation
==========================================
*/

// crates/audit/tests/immutability.rs

use audit::writer::{AppendOutcome, AuditWriter};

#[test]
// r[verify PROV-010]
fn first_append_returns_fresh_sequence() {
    let writer = AuditWriter::default();
    match writer.append("acme", 25, "idem-1") {
        AppendOutcome::Appended(entry) => {
            assert_eq!(entry.sequence, 1);
            assert_eq!(entry.slug, "acme");
            assert_eq!(entry.seat_delta, 25);
        }
        other => panic!("expected fresh append, got {other:?}"),
    }
}

#[test]
// r[verify PROV-010]
fn replayed_append_does_not_allocate_new_sequence() {
    let writer = AuditWriter::default();
    let _ = writer.append("acme", 25, "idem-1");
    match writer.append("acme", 25, "idem-1") {
        AppendOutcome::Replayed(entry) => assert_eq!(entry.sequence, 1),
        other => panic!("expected replay, got {other:?}"),
    }
}

#[test]
// r[verify prov.audit.sequence-monotonic]
fn sequences_are_strictly_increasing_per_tenant() {
    let writer = AuditWriter::default();
    let seqs: Vec<u64> = ["a", "b", "c"]
        .iter()
        .enumerate()
        .map(|(i, _)| {
            match writer.append("acme", 1, &format!("idem-{i}")) {
                AppendOutcome::Appended(e) => e.sequence,
                _ => panic!("expected append"),
            }
        })
        .collect();
    assert_eq!(seqs, vec![1, 2, 3]);
}
