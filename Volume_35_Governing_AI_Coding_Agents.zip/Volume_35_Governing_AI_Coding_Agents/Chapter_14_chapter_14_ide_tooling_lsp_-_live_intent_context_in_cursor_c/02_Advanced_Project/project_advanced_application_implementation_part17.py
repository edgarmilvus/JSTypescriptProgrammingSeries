# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_implementation_part17.py
# Description: Advanced Application Implementation
# ==========================================

# workers/reconciler/reconcile.py
"""Quota reconciliation worker.

Reconciles local seat counters against the billing provider's view of the
tenant. The worker is idempotent: replaying the same delta twice yields the
same final counter value, and no-op reconciliations emit a telemetry event.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class CounterStore(Protocol):
    def get_counter(self, tenant_id: str) -> int: ...
    def set_counter(self, tenant_id: str, value: int) -> None: ...


class Telemetry(Protocol):
    def emit(self, name: str, payload: dict[str, object]) -> None: ...


@dataclass(frozen=True)
class ReconcileResult:
    tenant_id: str
    previous: int
    current: int
    changed: bool


# r[impl prov.tenant.quota+2]
def reconcile_counter(
    tenant_id: str,
    remote_value: int,
    store: CounterStore,
    telemetry: Telemetry,
) -> ReconcileResult:
    """Reconcile the local counter for ``tenant_id`` against ``remote_value``.

    If the local and remote counters already agree, the function is a no-op
    and emits ``reconcile.noop``. Otherwise, the local counter is set to the
    remote value and a ``reconcile.updated`` event is emitted.

    Replay safety: calling this function twice with the same ``remote_value``
    produces identical final state and identical telemetry semantics.
    """
    previous = store.get_counter(tenant_id)

    if previous == remote_value:
        telemetry.emit("reconcile.noop", {"tenant_id": tenant_id})
        return ReconcileResult(
            tenant_id=tenant_id,
            previous=previous,
            current=previous,
            changed=False,
        )

    store.set_counter(tenant_id, remote_value)
    telemetry.emit(
        "reconcile.updated",
        {"tenant_id": tenant_id, "previous": previous, "current": remote_value},
    )
    return ReconcileResult(
        tenant_id=tenant_id,
        previous=previous,
        current=remote_value,
        changed=True,
    )
