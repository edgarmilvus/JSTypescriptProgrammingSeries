# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_implementation_part18.py
# Description: Advanced Application Implementation
# ==========================================

# workers/reconciler/tests/test_reconcile.py
"""Idempotency and telemetry tests for the reconciliation worker."""

from reconciler.reconcile import reconcile_counter


class MemoryStore:
    def __init__(self) -> None:
        self.counters: dict[str, int] = {}

    def get_counter(self, tenant_id: str) -> int:
        return self.counters.get(tenant_id, 0)

    def set_counter(self, tenant_id: str, value: int) -> None:
        self.counters[tenant_id] = value


class MemoryTelemetry:
    def __init__(self) -> None:
        self.events: list[tuple[str, dict[str, object]]] = []

    def emit(self, name: str, payload: dict[str, object]) -> None:
        self.events.append((name, payload))


# r[verify prov.tenant.quota+2]
def test_reconcile_updates_counter_and_emits_event() -> None:
    store = MemoryStore()
    telemetry = MemoryTelemetry()

    result = reconcile_counter("acme", 30, store, telemetry)

    assert result.changed is True
    assert store.get_counter("acme") == 30
    assert telemetry.events == [
        ("reconcile.updated", {"tenant_id": "acme", "previous": 0, "current": 30})
    ]


# r[verify prov.tenant.quota+2]
def test_reconcile_is_idempotent_on_replay() -> None:
    store = MemoryStore()
    telemetry = MemoryTelemetry()

    reconcile_counter("acme", 30, store, telemetry)
    reconcile_counter("acme", 30, store, telemetry)

    assert store.get_counter("acme") == 30
    assert telemetry.events[-1] == (
        "reconcile.noop",
        {"tenant_id": "acme"},
    )
