<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: project_advanced_application_implementation_part2.md
Description: Advanced Application Implementation
==========================================
-->

# Quota Reconciliation Rules

> r[prov.tenant.quota+2]
> The reconciliation worker MUST be idempotent: applying the same delta twice
> MUST produce the same final counter value. The worker MUST emit a
> `reconcile.noop` telemetry event whenever it observes that the remote and
> local counters already agree.

> r[prov.tenant.provisioning-rollback]
> When the audit append fails after the tenant record has been staged, the
> control plane MUST issue a compensating rollback that removes the staged
> tenant record and releases the reserved idempotency key.

> r[prov.audit.sequence-monotonic]
> The audit sequence number MUST be strictly increasing per tenant. Gaps are
> permitted during rollback but never re-used.
