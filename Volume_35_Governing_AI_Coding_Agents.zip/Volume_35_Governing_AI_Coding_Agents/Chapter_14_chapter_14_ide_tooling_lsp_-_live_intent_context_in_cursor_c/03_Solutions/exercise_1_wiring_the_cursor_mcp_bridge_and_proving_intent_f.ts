/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_wiring_the_cursor_mcp_bridge_and_proving_intent_f.ts
Description: Solutions and Explanations
==========================================
*/

// =============================================================================
// File: .cursor/mcp.json  (workspace root)
// =============================================================================
// {
//   "mcpServers": {
//     "tracey": {
//       "command": "tracey",
//       "args": ["mcp"],
//       "cwd": "${workspaceFolder}"
//     }
//   }
// }
//
// StrictDoc is intentionally NOT registered as an MCP server. StrictDoc is a
// CLI / web-server tool (strictdoc export, strictdoc server) with no stdio
// JSON-RPC entrypoint. Cursor invokes it through ordinary shell tasks or via
// the Tracey MCP tools that read .sdoc files directly. Adding a bogus server
// here would mislead the agent.
//
// =============================================================================
// File: .config/tracey/config.styx
// =============================================================================
// specs (
//   {
//     name api
//     include (docs/spec/**/*.md)
//     impls (
//       {
//         name typescript
//         include (src/**/*.ts)
//         exclude (src/**/*.spec.ts node_modules/**)
//         test_include (tests/**/*.ts src/**/*.spec.ts)
//       }
//     )
//   }
// )
//
// =============================================================================
// File: docs/spec/api.md
// =============================================================================
// # API Specification
//
// ## Authentication
//
// r[api.auth.login]
// The system must accept a username and password and return a session token on success.
//
// =============================================================================
// File: src/auth.ts
// =============================================================================
// // r[impl api.auth.login]
// export async function login(username: string, password: string): Promise<string> {
//   if (!username || !password) throw new Error("credentials required");
//   return `token:${username}`;
// }
//
// =============================================================================
// File: tests/auth.test.ts
// =============================================================================
// import { describe, it, expect } from "vitest";
// import { login } from "../src/auth";
//
// // r[verify api.auth.login]
// describe("login", () => {
//   it("returns a session token", async () => {
//     expect(await login("alice", "correct")).toMatch(/^token:/);
//   });
// });
//
// =============================================================================
// File: docs/notes/mcp-wiring.md (abridged)
// =============================================================================
// # MCP wiring: three layers, one intent graph
//
// 1. **Tracey daemon** — a persistent, per-workspace process. Owns the
//    in-memory spec/impl/verify graph. Communicates over a Unix socket at
//    `.tracey/daemon.sock` using roam RPC. Auto-starts on demand and exits
//    after ~10 minutes of inactivity.
// 2. **MCP stdio bridge (`tracey mcp`)** — a stateless shim spawned by Cursor
//    once per conversation. Speaks JSON-RPC over stdin/stdout, translates each
//    MCP `tools/call` into a roam RPC against the daemon socket. It does NOT
//    independently parse your spec.
// 3. **CLI (`tracey query …`)** — a one-shot bridge that connects to the same
//    daemon, runs one query, prints text, exits. Identical data as the MCP
//    tools, different framing.
//
// Failure diagnosis: if `tools/list` returns an empty array, the bridge
// spawned but the daemon failed. If `tools/call` returns stale data, the
// daemon is watching the wrong workspace (check `cwd`).
//
// =============================================================================
// File: src/mcp/cursorConfig.spec.ts
// =============================================================================
import { beforeAll, describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

type McpServerDecl = {
  command?: string;
  args?: string[];
  cwd?: string;
  env?: Record<string, string>;
  url?: string;
};

type McpConfig = { mcpServers: Record<string, McpServerDecl> };

const here = dirname(fileURLToPath(import.meta.url));
const configPath = resolve(here, "../../.cursor/mcp.json");

function loadConfig(): McpConfig {
  return JSON.parse(readFileSync(configPath, "utf8")) as McpConfig;
}

describe(".cursor/mcp.json — schema and Tracey registration", () => {
  let cfg: McpConfig;

  beforeAll(() => {
    cfg = loadConfig();
  });

  it("declares a top-level mcpServers object", () => {
    expect(cfg.mcpServers).toBeTypeOf("object");
    expect(cfg.mcpServers).not.toBeNull();
    expect(Object.keys(cfg.mcpServers).length).toBeGreaterThan(0);
  });

  it("registers a tracey server that runs `tracey mcp` over stdio", () => {
    const t = cfg.mcpServers.tracey;
    expect(t, "mcpServers.tracey missing").toBeDefined();
    expect(t.command).toBe("tracey");
    expect(Array.isArray(t.args)).toBe(true);
    expect(t.args?.[0]).toBe("mcp");
  });

  it("pins the working directory to the workspace root", () => {
    const t = cfg.mcpServers.tracey;
    expect(t.cwd, "cwd is required in monorepos").toBeDefined();
    // Accept either Cursor's expansion token or an absolute path.
    expect(t.cwd).toMatch(/\$\{workspaceFolder\}$|^\/|^[A-Za-z]:[\\/]/);
  });

  it("every server declares a well-formed command + args pair", () => {
    for (const [name, s] of Object.entries(cfg.mcpServers)) {
      expect(s.command, `server ${name}: missing command`).toBeTypeOf("string");
      expect(Array.isArray(s.args), `server ${name}: args must be an array`).toBe(true);
      for (const a of s.args ?? []) {
        expect(typeof a, `server ${name}: args entries must be strings`).toBe("string");
      }
    }
  });

  it("no server mixes stdio (command) with SSE/HTTP (url)", () => {
    for (const [name, s] of Object.entries(cfg.mcpServers)) {
      const ambiguous = s.command !== undefined && s.url !== undefined;
      expect(ambiguous, `server ${name}: declares both command and url`).toBe(false);
    }
  });
});
