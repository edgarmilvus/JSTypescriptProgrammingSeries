/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_building_a_vitest-testable_lsp_diagnostic_classif.ts
Description: Solutions and Explanations
==========================================
*/

import { describe, expect, it } from "vitest";

// ─────────────────────────────────────────────────────────────────────────────
// Domain types
// ─────────────────────────────────────────────────────────────────────────────

export type IntentDiagnostic = {
  uri: string;
  range: {
    start: { line: number; character: number };
    end: { line: number; character: number };
  };
  severity: 1 | 2 | 3 | 4; // Error, Warning, Information, Hint (per LSP)
  code: string;
  message: string;
};

export type IntentVerdict = {
  verdict: "clean" | "blocked" | "acknowledged";
  reasons: string[];
};

const ACK_MARKER = "@tracey:acknowledged-stale";
const STALE_CODE = "stale-reference";

// ─────────────────────────────────────────────────────────────────────────────
// Pure classifier
// ─────────────────────────────────────────────────────────────────────────────
//
// Decoupled from transport on purpose. The SAME function is used by:
//   • a pre-commit hook  (feeds diagnostics from `tracey query validate`),
//   • a CI gate          (feeds diagnostics from the LSP server's stderr dump),
//   • an editor overlay  (feeds diagnostics from the LSP push channel).
// Keeping it pure is what makes those three consumers share semantics without
// sharing an editor API.
export function classifyFileIntent(params: {
  uri: string;
  text: string;
  diagnostics: IntentDiagnostic[];
}): IntentVerdict {
  const lines = params.text.split(/\r?\n/);
  const reasons: string[] = [];
  let sawStale = false;
  let allStaleAcked = true;

  for (const d of params.diagnostics) {
    const humanLine = d.range.start.line + 1; // LSP is 0-based; humans aren't.

    // Hard error: always blocks, no acknowledgement possible.
    if (d.severity === 1) {
      reasons.push(`error ${d.code} at L${humanLine}: ${d.message}`);
      return { verdict: "blocked", reasons };
    }

    if (d.code === STALE_CODE) {
      sawStale = true;
      const lineText = lines[d.range.start.line] ?? "";
      if (!lineText.includes(ACK_MARKER)) {
        allStaleAcked = false;
        reasons.push(`unacknowledged stale ref at L${humanLine}: ${d.message}`);
      }
      continue;
    }

    // Non-stale warnings are advisory only: they never block, but we report
    // them so an editor overlay can show them without treating them as errors.
    reasons.push(`advisory ${d.code} at L${humanLine}: ${d.message}`);
  }

  if (sawStale) {
    return allStaleAcked
      ? { verdict: "acknowledged", reasons: [] }
      : { verdict: "blocked", reasons };
  }
  return { verdict: "clean", reasons };
}

// ─────────────────────────────────────────────────────────────────────────────
// UID extraction from human-readable messages
// ─────────────────────────────────────────────────────────────────────────────
//
// Tracey does not (yet) expose the UID as a first-class field in the LSP
// diagnostic; it is embedded in the message text:
//
//   "Unknown requirement 'auth.tokn.verify'. Did you mean 'auth.token.verify'?"
//   "Stale reference to 'auth.login' (code was written against v1, spec is v2)"
//
// The regex below is deliberately narrow: it matches a quoted, dotted,
// lowercase identifier. That excludes the quoted suggestion word in the
// "Did you mean ..." tail and any incidental quoted English. Widening the
// regex will start matching paraphrases. The correct long-term fix is to ask
// the Tracey authors to populate the LSP `Diagnostic.data` slot with a
// structured `{ uid: "…" }` field — that is what we recommend in the note.
const UID_PATTERN = /'([a-z][a-z0-9_-]*(?:\.[a-z0-9_-]+)+)'/i;

export function extractUid(message: string): string | null {
  const m = message.match(UID_PATTERN);
  return m ? m[1] : null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Interactive Challenge: summarize by requirement
// ─────────────────────────────────────────────────────────────────────────────

export type RequirementSummary = {
  errors: number;
  warnings: number;
  stale: number;
};

export function summarizeByRequirement(
  diagnostics: IntentDiagnostic[],
): Map<string, RequirementSummary> {
  const out = new Map<string, RequirementSummary>();
  for (const d of diagnostics) {
    const uid = extractUid(d.message);
    if (!uid) continue;
    const cur =
      out.get(uid) ?? { errors: 0, warnings: 0, stale: 0 };
    if (d.severity === 1) cur.errors += 1;
    else if (d.code === STALE_CODE) cur.stale += 1;
    else cur.warnings += 1;
    out.set(uid, cur);
  }
  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// Vitest suite
// ─────────────────────────────────────────────────────────────────────────────

type D = Partial<IntentDiagnostic> & Pick<IntentDiagnostic, "code" | "message" | "severity">;

function diag(line: number, d: D): IntentDiagnostic {
  return {
    uri: "file:///src/auth.ts",
    range: { start: { line, character: 0 }, end: { line, character: 40 } },
    ...d,
  } as IntentDiagnostic;
}

describe("classifyFileIntent", () => {
  const baseText = [
    '// r[impl auth.login]',
    'export function login() {}',
    '// r[verify auth.login]',
    'it("works", () => {});',
  ].join("\n");

  it("clean when there are no diagnostics", () => {
    expect(classifyFileIntent({ uri: "u", text: baseText, diagnostics: [] }))
      .toEqual({ verdict: "clean", reasons: [] });
  });

  it("blocked on any severity-1 error", () => {
    const out = classifyFileIntent({
      uri: "u",
      text: baseText,
      diagnostics: [diag(0, { severity: 1, code: "unknown-requirement",
        message: "Unknown requirement 'auth.tokn.verify'. Did you mean 'auth.token.verify'?" })],
    });
    expect(out.verdict).toBe("blocked");
    expect(out.reasons[0]).toMatch(/unknown-requirement/);
  });

  it("blocked when a stale-ref warning is not acknowledged on its line", () => {
    const out = classifyFileIntent({
      uri: "u",
      text: baseText,
      diagnostics: [diag(0, { severity: 2, code: "stale-reference",
        message: "Stale reference to 'auth.login'" })],
    });
    expect(out.verdict).toBe("blocked");
  });

  it("acknowledged when the stale-ref line carries the marker", () => {
    const text = "// r[impl auth.login] @tracey:acknowledged-stale\nfn x() {}";
    const out = classifyFileIntent({
      uri: "u",
      text,
      diagnostics: [diag(0, { severity: 2, code: "stale-reference",
        message: "Stale reference to 'auth.login'" })],
    });
    expect(out).toEqual({ verdict: "acknowledged", reasons: [] });
  });

  it("blocked when one of two stale refs is unacknowledged", () => {
    const text = [
      "// r[impl auth.login] @tracey:acknowledged-stale",
      "// r[impl auth.token.expiry]",
    ].join("\n");
    const out = classifyFileIntent({
      uri: "u",
      text,
      diagnostics: [
        diag(0, { severity: 2, code: "stale-reference", message: "Stale 'auth.login'" }),
        diag(1, { severity: 2, code: "stale-reference", message: "Stale 'auth.token.expiry'" }),
      ],
    });
    expect(out.verdict).toBe("blocked");
    expect(out.reasons).toHaveLength(1);
  });

  it("blocked when the marker is on a different line (line precision matters)", () => {
    const text = [
      "// r[impl auth.login]",
      "// @tracey:acknowledged-stale",
    ].join("\n");
    const out = classifyFileIntent({
      uri: "u",
      text,
      diagnostics: [diag(0, { severity: 2, code: "stale-reference",
        message: "Stale 'auth.login'" })],
    });
    expect(out.verdict).toBe("blocked");
  });
});

describe("summarizeByRequirement", () => {
  it("groups diagnostics by UID and classifies counts", () => {
    const summary = summarizeByRequirement([
      diag(0, { severity: 1, code: "unknown-requirement",
        message: "Unknown requirement 'auth.tokn.verify'" }),
      diag(1, { severity: 2, code: "stale-reference",
        message: "Stale reference to 'auth.login'" }),
      diag(2, { severity: 2, code: "unknown-verb",
        message: "Unknown verb in reference to 'auth.login'" }),
    ]);
    expect(summary.get("auth.tokn.verify")).toEqual({ errors: 1, warnings: 0, stale: 0 });
    expect(summary.get("auth.login")).toEqual({ errors: 0, warnings: 1, stale: 1 });
  });

  it("ignores messages without a dotted quoted UID", () => {
    const summary = summarizeByRequirement([
      diag(0, { severity: 2, code: "unknown-verb",
        message: "Unrecognized verb 'foo'" }),
    ]);
    expect(summary.size).toBe(0);
  });
});
