/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_react_component_a_live_intent_badge.tsx
Description: Solutions and Explanations
==========================================
*/

// =============================================================================
// File: src/intent/types.ts
// =============================================================================

export type IntentStatus =
  | { kind: "covered"; impls: number; verifies: number }
  | { kind: "uncovered" }
  | { kind: "untested"; impls: number }
  | { kind: "stale"; staleSinceVersion: number; currentVersion: number };

export interface IntentProvider {
  getRequirementStatus(uid: string): Promise<IntentStatus>;
}

// =============================================================================
// File: src/intent/context.ts
// =============================================================================

import { createContext, useContext } from "react";
import type { IntentProvider } from "./types";

export const IntentProviderContext = createContext<IntentProvider | null>(null);

export function useIntentProvider(): IntentProvider {
  const ctx = useContext(IntentProviderContext);
  if (!ctx) throw new Error("IntentBadge rendered outside IntentProviderBoundary");
  return ctx;
}

// =============================================================================
// File: src/intent/IntentBadge.tsx
// =============================================================================

import React, { useEffect, useState } from "react";
import { IntentProviderContext } from "./context";
import type { IntentProvider, IntentStatus } from "./types";

type AsyncState =
  | { phase: "loading" }
  | { phase: "error"; message: string }
  | { phase: "ready"; value: IntentStatus };

const PRESENTATION: Record<IntentStatus["kind"], { dot: string; short: string; abbr: string }> = {
  covered: {
    dot: "#2e7d32",
    short: "covered",
    abbr: "covered — has at least one impl reference and at least one verify reference",
  },
  uncovered: {
    dot: "#9e9e9e",
    short: "uncovered",
    abbr: "uncovered — no implementation references this requirement",
  },
  untested: {
    dot: "#f9a825",
    short: "untested",
    abbr: "untested — implemented but has no verify reference",
  },
  stale: {
    dot: "#c62828",
    short: "stale",
    abbr: "stale — implementation references an earlier requirement version",
  },
};

export type IntentBadgeProps = {
  requirementId: string;
  provider?: IntentProvider;
  onClick?: (uid: string, status: IntentStatus) => void;
};

export function IntentBadge({ requirementId, provider, onClick }: IntentBadgeProps) {
  const ctx = React.useContext(IntentProviderContext);
  const effective = provider ?? ctx;

  const [state, setState] = useState<AsyncState>({ phase: "loading" });

  useEffect(() => {
    let cancelled = false;
    if (!effective) {
      setState({ phase: "error", message: "No IntentProvider in scope" });
      return;
    }
    setState({ phase: "loading" });
    effective
      .getRequirementStatus(requirementId)
      .then(
        (value) => { if (!cancelled) setState({ phase: "ready", value }); },
        (err: unknown) => {
          if (!cancelled) {
            const message = err instanceof Error ? err.message : String(err);
            setState({ phase: "error", message });
          }
        },
      );
    return () => { cancelled = true; };
  }, [effective, requirementId]);

  // Note: at this point a caching layer would live. A page that renders the
  // same UID 50 times (a PR diff) will fire 50 fetches. Wrap `effective` in a
  // memoizing adapter (TanStack Query / SWR) at the context boundary rather
  // than sprinkling caches into the component.

  if (state.phase === "loading") {
    return (
      <span
        role="status"
        aria-label={`loading intent for ${requirementId}`}
        style={{ display: "inline-block", width: 12, height: 12, borderRadius: "50%", background: "#ddd" }}
      />
    );
  }

  if (state.phase === "error") {
    // A red-with-cross is deliberately NOT "covered" red; it is a distinct
    // "unknown" affordance — using the same dot as "stale" would lie.
    return (
      <span
        aria-label={`intent unknown for ${requirementId}: ${state.message}`}
        title={state.message}
        style={{ color: "#c62828" }}
      >
        ✖
      </span>
    );
  }

  const { value } = state;
  const p = PRESENTATION[value.kind];
  const label = `${p.short} — ${requirementId}`;

  return (
    <button
      type="button"
      onClick={() => onClick?.(requirementId, value)}
      aria-label={label}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        background: "transparent",
        border: 0,
        padding: 0,
        cursor: onClick ? "pointer" : "default",
      }}
    >
      <span
        aria-hidden="true"
        style={{ width: 10, height: 10, borderRadius: "50%", background: p.dot }}
      />
      <abbr title={p.abbr}>{p.short}</abbr>
    </button>
  );
}

// =============================================================================
// File: src/intent/__tests__/IntentBadge.test.tsx
// =============================================================================

import React from "react";
import { describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { http, HttpResponse } from "msw";
import { setupServer } from "msw/node";
import { IntentBadge } from "../IntentBadge";
import { IntentProviderContext } from "../context";
import type { IntentProvider, IntentStatus } from "../types";

const server = setupServer();
beforeAll(() => server.listen({ onUnhandledRequest: "error" }));
afterAll(() => server.close());
afterEach(() => server.resetHandlers());

function providerReturning(s: IntentStatus): IntentProvider {
  return { getRequirementStatus: async () => s };
}

describe("<IntentBadge /> states", () => {
  it("renders covered in green with the correct aria-label", async () => {
    render(
      <IntentBadge
        requirementId="auth.login"
        provider={providerReturning({ kind: "covered", impls: 2, verifies: 1 })}
      />,
    );
    await waitFor(() => screen.getByLabelText(/covered/i));
    expect(screen.getByLabelText("covered — auth.login")).toBeInTheDocument();
  });

  it("renders uncovered in grey", async () => {
    render(
      <IntentBadge
        requirementId="auth.login"
        provider={providerReturning({ kind: "uncovered" })}
      />,
    );
    expect(await screen.findByLabelText(/uncovered/i)).toBeInTheDocument();
  });

  it("renders untested in yellow", async () => {
    render(
      <IntentBadge
        requirementId="auth.login"
        provider={providerReturning({ kind: "untested", impls: 1 })}
      />,
    );
    expect(await screen.findByLabelText(/untested/i)).toBeInTheDocument();
  });

  it("renders stale in red and does not label it as covered", async () => {
    render(
      <IntentBadge
        requirementId="auth.login"
        provider={providerReturning({ kind: "stale", staleSinceVersion: 1, currentVersion: 2 })}
      />,
    );
    const el = await screen.findByLabelText(/stale/i);
    expect(el).toBeInTheDocument();
    expect(screen.queryByLabelText(/covered/i)).toBeNull();
  });

  it("shows a loading state before the provider resolves", () => {
    const never: IntentProvider = { getRequirementStatus: () => new Promise(() => {}) };
    render(<IntentBadge requirementId="auth.login" provider={never} />);
    expect(screen.getByRole("status", { name: /loading intent/i })).toBeInTheDocument();
  });

  it("renders an unknown state (not covered) when the provider rejects", async () => {
    const provider: IntentProvider = {
      getRequirementStatus: async () => { throw new Error("daemon offline"); },
    };
    render(<IntentBadge requirementId="auth.login" provider={provider} />);
    const el = await screen.findByLabelText(/intent unknown/i);
    expect(el).toBeInTheDocument();
    expect(screen.queryByLabelText(/covered/i)).toBeNull();
  });

  it("invokes onClick with the UID and the resolved status", async () => {
    const onClick = vi.fn();
    render(
      <IntentBadge
        requirementId="auth.login"
        provider={providerReturning({ kind: "covered", impls: 1, verifies: 1 })}
        onClick={onClick}
      />,
    );
    fireEvent.click(await screen.findByLabelText(/covered/i));
    expect(onClick).toHaveBeenCalledWith("auth.login",
      expect.objectContaining({ kind: "covered" }));
  });

  it("uses the context provider when no explicit provider prop is given", async () => {
    render(
      <IntentProviderContext.Provider
        value={providerReturning({ kind: "untested", impls: 3 })}
      >
        <IntentBadge requirementId="api.token.issue" />
      </IntentProviderContext.Provider>,
    );
    expect(await screen.findByLabelText(/untested/i)).toBeInTheDocument();
  });
});

describe("<IntentBadge /> via a JSON-RPC backed provider", () => {
  // The endpoint is fictional; we are proving that the provider abstraction
  // accepts a network-backed implementation without the component knowing.
  it("renders the state returned by POST /intent/rpc", async () => {
    server.use(
      http.post("/intent/rpc", async () => {
        return HttpResponse.json({
          result: {
            content: [{ type: "text", text: "3 impls, 1 test, no staleness" }],
            structuredContent: { kind: "covered", impls: 3, verifies: 1 },
          },
        });
      }),
    );

    const provider: IntentProvider = {
      async getRequirementStatus(uid) {
        const r = await fetch("/intent/rpc", {
          method: "POST",
          body: JSON.stringify({ method: "tracey_rule", params: { uid } }),
        });
        const json = await r.json();
        return json.result.structuredContent as IntentStatus;
      },
    };

    render(<IntentBadge requirementId="auth.login" provider={provider} />);
    expect(await screen.findByLabelText("covered — auth.login")).toBeInTheDocument();
  });
});
