/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_semantic_tokens_hover_and_completions_without_tra.ts
Description: Solutions and Explanations
==========================================
*/

// =============================================================================
// File: src/editor/model.ts  — LSP-shaped input model
// =============================================================================

export type RefVerb = "impl" | "verify" | "depends" | "related";

export type Ref = {
  verb: RefVerb;
  file: string;
  line: number;        // 0-based, matching LSP positions
  character: number;   // column of the opening `r[` marker
  version: number;
};

export type Requirement = {
  uid: string;
  title: string;
  statement: string;
  version: number;
  refs: Ref[];
};

// =============================================================================
// File: src/editor/hover.ts
// =============================================================================
//
// Simplification: LSP hover receives the document text via the `uri` and a
// virtual filesystem overlay. This exercise omits that plumbing and instead
// matches on `(file, line)`. If two markers share a line, the first wins —
// this is a documented limitation of the mock, not of Tracey's real LSP.
export function getHover(
  uri: string,
  position: { line: number; character: number },
  requirements: Requirement[],
): { markdown: string } | null {
  for (const r of requirements) {
    for (const ref of r.refs) {
      if (ref.file !== uri || ref.line !== position.line) continue;

      const impls = r.refs.filter((x) => x.verb === "impl").length;
      const verifies = r.refs.filter((x) => x.verb === "verify").length;
      const stale = r.refs.some((x) => x.version < r.version);

      const summary = `${impls} impls, ${verifies} test${verifies === 1 ? "" : "s"}${
        stale ? " (stale)" : ""
      }`;

      return {
        markdown: `### ${r.uid}\n\n${r.statement}\n\n_${summary}_`,
      };
    }
  }
  return null;
}

// =============================================================================
// File: src/editor/completions.ts
// =============================================================================

function scoreMatch(query: string, candidate: string): number {
  // Tier 1: prefix match.
  if (candidate.startsWith(query)) return 1000 - candidate.length;

  // Tier 2: subsequence match with a contiguous-run bonus.
  let qi = 0;
  let run = 0;
  let bestRun = 0;
  let lastHit = -1;
  for (let ci = 0; ci < candidate.length && qi < query.length; ci++) {
    if (candidate[ci] === query[qi]) {
      qi++;
      run++;
      if (run > bestRun) bestRun = run;
      lastHit = ci;
    } else {
      run = 0;
    }
  }
  if (qi < query.length) return -1; // not a subsequence at all
  // Prefer long contiguous runs, then prefer earlier hits.
  return bestRun * 10 - (lastHit + 1);
}

export function getCompletions(
  prefixText: string,
  requirements: Requirement[],
): { label: string; detail: string }[] {
  // `prefixText` is the comment fragment up to the cursor: e.g. "// r[auth.tok"
  const m = prefixText.match(/r\[(?:(\w+)\s+)?([\w.-]*)$/);
  if (!m) return [];
  const query = (m[2] ?? "").toLowerCase();

  if (!query) {
    return requirements.map((r) => ({ label: r.uid, detail: r.title }));
  }

  return requirements
    .map((r) => ({ r, s: scoreMatch(query, r.uid.toLowerCase()) }))
    .filter((x) => x.s >= 0)
    .sort((a, b) => b.s - a.s)
    .map((x) => ({ label: x.r.uid, detail: x.r.title }));
}

// =============================================================================
// File: src/editor/semanticTokens.ts
// =============================================================================

export type SemanticTokenType = "prefix" | "verb" | "uid";

export type SemanticToken = {
  line: number;        // 0-based
  startChar: number;   // 0-based, absolute within the line
  length: number;
  tokenType: SemanticTokenType;
};

const VERB_RE = /^(impl|verify|depends|related)$/;

export function getSemanticTokens(text: string): SemanticToken[] {
  const tokens: SemanticToken[] = [];
  const lines = text.split(/\r?\n/);

  lines.forEach((line, lineIdx) => {
    const re = /r\[([^\]]*)\]/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(line)) !== null) {
      const outerStart = m.index;     // index of 'r'
      const inner = m[1];
      const innerStart = outerStart + 2;

      // Prefix token: the literal `r`.
      tokens.push({ line: lineIdx, startChar: outerStart, length: 1, tokenType: "prefix" });

      const parsed = inner.match(/^(?:(\w+)\s+)?([a-z][\w.-]*)(\+\d+)?$/i);
      if (!parsed) continue;

      const [, rawVerb, uid] = parsed;
      let cursor = innerStart;

      if (rawVerb && VERB_RE.test(rawVerb)) {
        tokens.push({ line: lineIdx, startChar: cursor, length: rawVerb.length, tokenType: "verb" });
        cursor += rawVerb.length;
        while (cursor < innerStart + inner.length && line[cursor] === " ") cursor++;
      }
      // Deliberate decision: when the verb is omitted (`r[auth.login]`), we do
      // NOT emit a synthetic zero-length verb token. Zero-length tokens are
      // technically legal but useless for highlighters and confusing to editor
      // UI that measures token width. The editor will simply render the UID
      // starting at the correct column, which is semantically honest.

      tokens.push({ line: lineIdx, startChar: cursor, length: uid.length, tokenType: "uid" });
    }
  });

  // Return in document order (linters and clients expect stable ordering).
  return tokens.sort((a, b) => a.line - b.line || a.startChar - b.startChar);
}

// =============================================================================
// Fixture: requirements  (hand-author these into a test setup — see below)
// =============================================================================

export const FIXTURE: Requirement[] = [
  {
    uid: "auth.token.verify",
    title: "Verify session tokens",
    statement: "The system must verify session tokens before granting access.",
    version: 2,
    refs: [
      { verb: "impl",   file: "file:///src/auth.ts",       line: 10, character: 3, version: 2 },
      { verb: "impl",   file: "file:///src/session.ts",    line: 22, character: 3, version: 2 },
      { verb: "verify", file: "file:///tests/auth.test.ts",line: 4,  character: 3, version: 2 },
    ],
  },
  {
    uid: "auth.token.issue",
    title: "Issue session tokens",
    statement: "The system must issue a session token on successful login.",
    version: 1,
    refs: [
      { verb: "impl", file: "file:///src/auth.ts", line: 4, character: 3, version: 1 },
    ],
  },
  {
    uid: "auth.rate.limit",
    title: "Rate limit login attempts",
    statement: "Failed logins must be rate-limited per client IP.",
    version: 1,
    refs: [],
  },
];

// =============================================================================
// Vitest suite
// =============================================================================

import { describe, expect, it } from "vitest";

describe("getHover", () => {
  it("returns markdown for a valid reference and shows coverage summary", () => {
    const h = getHover("file:///src/auth.ts", { line: 10, character: 3 }, FIXTURE);
    expect(h).not.toBeNull();
    expect(h!.markdown).toContain("### auth.token.verify");
    expect(h!.markdown).toContain("The system must verify session tokens");
    expect(h!.markdown).toMatch(/2 impls, 1 test/);
  });

  it("returns null when the position does not sit on a known marker", () => {
    const h = getHover("file:///src/auth.ts", { line: 999, character: 3 }, FIXTURE);
    expect(h).toBeNull();
  });
});

describe("getCompletions", () => {
  it("returns the two auth.token.* candidates for `r[auth.tok`", () => {
    const out = getCompletions("// r[auth.tok", FIXTURE);
    const labels = out.map((x) => x.label);
    expect(labels).toContain("auth.token.verify");
    expect(labels).toContain("auth.token.issue");
  });

  it("ranks prefix matches above substring matches", () => {
    const reqs: Requirement[] = [
      { ...FIXTURE[0], uid: "auth.token.verify" },
      { ...FIXTURE[0], uid: "something.auth.token.verify" },
    ];
    const out = getCompletions("// r[auth.tok", reqs);
    expect(out[0].label).toBe("auth.token.verify");
    expect(out[1].label).toBe("something.auth.token.verify");
  });

  it("returns everything for an empty query", () => {
    const out = getCompletions("// r[", FIXTURE);
    expect(out).toHaveLength(FIXTURE.length);
  });
});

describe("getSemanticTokens", () => {
  it("emits prefix+verb+uid for the explicit form", () => {
    const text = "// r[impl auth.login]";
    const toks = getSemanticTokens(text);
    expect(toks).toContainEqual({ line: 0, startChar: 3, length: 1, tokenType: "prefix" });
    expect(toks).toContainEqual({ line: 0, startChar: 5, length: 4, tokenType: "verb" });
    expect(toks).toContainEqual({ line: 0, startChar: 10, length: 10, tokenType: "uid" });
  });

  it("emits prefix+uid (no verb) for the verb-omitted form", () => {
    const text = "// r[auth.login]";
    const toks = getSemanticTokens(text);
    expect(toks.some((t) => t.tokenType === "verb")).toBe(false);
    const uid = toks.find((t) => t.tokenType === "uid")!;
    expect(text.slice(uid.startChar, uid.startChar + uid.length)).toBe("auth.login");
  });

  it("handles all four explicit verbs", () => {
    const text = [
      "// r[impl a.b]",
      "// r[verify c.d]",
      "// r[depends e.f]",
      "// r[related g.h]",
    ].join("\n");
    const toks = getSemanticTokens(text);
    const verbs = toks.filter((t) => t.tokenType === "verb");
    expect(verbs.map((t) => t.length)).toEqual([4, 6, 7, 7]);
  });

  it("returns tokens in document order", () => {
    const toks = getSemanticTokens("// r[impl z.z]\n// r[impl a.a]");
    for (let i = 1; i < toks.length; i++) {
      const prev = toks[i - 1];
      const cur = toks[i];
      expect(cur.line > prev.line || (cur.line === prev.line && cur.startChar >= prev.startChar))
        .toBe(true);
    }
  });
});
