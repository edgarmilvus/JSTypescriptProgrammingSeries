/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_interactive_challenge_the_pre-commit_gate_that_re.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * @file scripts/governance/preCommitGate.ts
 *
 * Pre-commit gate for the Tracey + StrictDoc governance stack.
 *
 * Authority model (see docs/adr/0001-pre-commit-authority.md):
 *   • Editor LSP diagnostics  → advisory. They flicker, they debounce, and
 *     they reflect unsaved buffers. Never block a commit on them.
 *   • MCP agent advisories    → advisory. The agent's `tracey_validate` call
 *     is one opinion among many; treat it as a hint to the human.
 *   • This pre-commit gate    → authoritative. It reads the git index or the
 *     working tree, runs Tracey once, and returns a single verdict. It is the
 *     ONLY component permitted to fail a commit.
 *
 * This module is transport-free. It shells out to `tracey` and `git` via
 * `child_process.execFile`, parses their output, and returns a structured
 * verdict. It never throws on a "governance failure" — it throws only on
 * transport / config errors that mean the gate itself is broken.
 */

export type GovernanceDiagnostic = {
  source: "tracey-pre-commit" | "tracey-validate" | "tracey-bump";
  severity: "error" | "warning";
  code: string;
  uid?: string;
  file?: string;
  line?: number;
  message: string;
};

export type GateResult = {
  ok: boolean;
  blocking: GovernanceDiagnostic[];
  advisories: GovernanceDiagnostic[];
};

export type GateMode = "index" | "worktree";

export type GateOptions = {
  /** Directory that contains .config/tracey/config.styx. */
  cwd: string;
  /** index = evaluate staged content; worktree = evaluate working-tree files. */
  mode: GateMode;
  /** When true (and mode === "index"), run `tracey bump` and re-stage. */
  autoBump?: boolean;
};

/**
 * Run the pre-commit gate. Idempotent in both modes:
 *
 *   mode = "index" (default for humans):
 *     1. If autoBump, run `tracey bump`, then `git add -u`, then re-read index.
 *     2. Run `tracey pre-commit` (staged-only check).
 *     3. Run `tracey query validate --deny warnings` over the whole workspace.
 *     4. Merge outputs, partition into blocking/advisories, return verdict.
 *
 *   mode = "worktree" (default for agents, detected via STRICTDOC_AGENT=1):
 *     1. Skip `tracey bump` — agents edit the working tree, not the index.
 *     2. Run `tracey query validate --deny warnings` over the working tree.
 *     3. Return verdict; the caller is responsible for `git add`.
 *
 * The implementation is intentionally stubbed. The exercise is about the
 * contract and the reasoning, not the orchestrator. Implementors fill in the
 * four TODO blocks, one subprocess call at a time, and add integration tests
 * against a fixture repo.
 */
export async function run(options: GateOptions): Promise<GateResult> {
  // TODO(governance): if (options.mode === "index" && options.autoBump) {
  //   execFileSync("tracey", ["bump"], { cwd });
  //   execFileSync("git", ["add", "-u"], { cwd });
  // }
  // TODO(governance): if (options.mode === "index") {
  //   const out = execFileSync("tracey", ["pre-commit"], { cwd, encoding: "utf8" });
  //   diagnostics.push(...parsePreCommit(out));
  // }
  // TODO(governance): const validate = execFileSync(
  //   "tracey", ["query", "validate", "--deny", "warnings"],
  //   { cwd, encoding: "utf8" });
  // diagnostics.push(...parseValidate(validate));
  // TODO(governance): partition diagnostics into blocking vs advisory and
  // return { ok: blocking.length === 0, blocking, advisories }.
  void options;
  throw new Error("preCommitGate.run: see docs/adr/0001-pre-commit-authority.md");
}
