/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_interactive_challenge_the_pre-commit_gate_that_re_part2.ts
Description: Solutions and Explanations
==========================================
*/

/* =========================================================================
 * File: .git/hooks/pre-commit   (or .pre-commit-config.yaml, see below)
 * =========================================================================
 *
 *   #!/usr/bin/env sh
 *   set -eu
 *
 *   # Detect agent mode: Codex CLI, Claude Code and Cursor Composer all set
 *   # a distinguishing environment variable. Map to the gate's --mode flag.
 *   if [ "${STRICTDOC_AGENT:-0}" = "1" ] || [ "${CODEX_CI:-0}" = "1" ]; then
 *       MODE=worktree
 *   else
 *       MODE=index
 *   fi
 *
 *   exec node --loader ts-node/esm scripts/governance/preCommitGate.ts \
 *       --mode="$MODE" --auto-bump
 *
 * -------------------------------------------------------------------------
 * File: .pre-commit-config.yaml   (equivalent wiring for the Python-based
 *                                   pre-commit framework)
 * -------------------------------------------------------------------------
 *
 *   repos:
 *     - repo: local
 *       hooks:
 *         - id: tracey-gate
 *           name: Tracey intent gate (single authority)
 *           entry: node --loader ts-node/esm scripts/governance/preCommitGate.ts
 *           language: system
 *           pass_filenames: false
 *           files: ^(docs/spec/.*\.(md|sdoc)|src/.*\.(ts|tsx)|tests/.*\.ts)$
 *
 * =========================================================================
 * File: docs/adr/0001-pre-commit-authority.md  (MADR template, abridged)
 * =========================================================================
 *
 * # ADR 0001 — The pre-commit gate is the single authority on intent drift
 *
 * ## Context
 *
 * Three lifecycle stages produce views of "the current state of intent":
 *
 *   • The editor sees the working tree plus unsaved buffers.
 *   • The MCP agent sees whatever it reads/writes to disk, plus the daemon's
 *     in-memory graph (rebuilt on debounced filesystem events).
 *   • The pre-commit hook sees only the git index.
 *
 * Without a single authority, three surfaces disagree, and developers learn
 * that warnings are noise AND that commits sometimes fail for inexplicable
 * reasons — the worst of both worlds.
 *
 * ## Decision — answers to the five design questions
 *
 * ### 1. Authority
 *
 * Only the pre-commit gate may block a commit. Editor diagnostics are
 * advisory because they operate on unsaved buffers, they debounce, and they
 * are inevitably stale by a few hundred milliseconds — a false block here
 * would train developers to disable the extension. MCP advisories are also
 * advisory, but for a different reason: the agent's `tracey_validate` call
 * is one tool invocation inside a larger reasoning loop, and treating its
 * output as authoritative would let a hallucinated UID in one turn block a
 * commit in the next. The pre-commit gate has three properties the other
 * layers lack: (a) it runs against a frozen input (the index), (b) it runs
 * exactly once per commit attempt, (c) it is bypassable only with an explicit
 * `--no-verify`, which is auditable in shell history. That combination makes
 * it the correct seat of authority.
 *
 * ### 2. Idempotence
 *
 * `run()` must return the same verdict for the same staged content,
 * regardless of how many times it is invoked. When `autoBump` is enabled,
 * the sequence is: (i) run `tracey bump` to increment version markers on
 * requirements whose text changed; (ii) run `git add -u` to re-stage the
 * files the bump touched; (iii) re-read the index from scratch. From step
 * (iii) onward, the gate is idempotent because the index is now stable —
 * running the hook again will find nothing to bump and will reproduce the
 * same pre-commit/validate output. Without the explicit re-stage, a second
 * run would see the *old* index and re-report the same violation, producing
 * the "bite twice" UX the team complained about.
 *
 * ### 3. Partial staging
 *
 * Partial staging (staged+unstaged edits to the same file) is the hardest
 * problem in any pre-commit gate. We adopt the following policy, chosen
 * explicitly and enforced by the gate:
 *
 *   POLICY: In `index` mode, if any staged file also has unstaged changes,
 *   the gate refuses to run and prints a message telling the developer to
 *   commit or stash the unstaged hunks first. The message must list the
 *   offending files.
 *
 * Rationale: the alternative — a scratch worktree populated from the index —
 * works, but it is expensive, fragile on Windows, and it silently changes
 * the meaning of relative paths in the workspace config (`.config/tracey/
 * config.styx` is anchored to the repo root, which the scratch tree does
 * not share). Refusing to run is the conservative choice: it is safe, it is
 * fast, and it gives the developer a clear action. Agents are unaffected
 * because they default to `worktree` mode, where partial staging is not a
 * concept.
 *
 * ### 4. Agent compatibility
 *
 * Codex CLI, Claude Code, and Cursor Composer all apply edits to the working
 * tree, not the index. The gate therefore accepts `--mode=worktree`, which:
 *   • skips `tracey pre-commit` (that command is index-scoped by design),
 *   • runs only `tracey query validate --deny warnings` over the working tree,
 *   • returns the same verdict shape.
 *
 * Trade-off: `worktree` mode is convenient for agents but strictly weaker —
 * it cannot detect the "bumped requirement without a matching code bump"
 * class of drift, because there is no index to diff against. We accept this
 * trade-off because agents commit in a second step (`git add && git commit`)
 * and that commit will run in `index` mode, catching the drift then. Mode is
 * auto-detected via `STRICTDOC_AGENT=1` / `CODEX_CI=1` and can be overridden
 * with an explicit `--mode` flag.
 *
 * ### 5. Editor feedback loop
 *
 * When the gate fails, the developer is looking at their editor, not at the
 * terminal where the hook wrote its output. We surface the gate's blocking
 * diagnostics back into the Cursor LSP flow by parsing them into LSP-shaped
 * `PublishDiagnosticsParams` and POSTing them to a small local endpoint that
 * a Cursor task (or a companion Cursor extension) listens on. This gives the
 * same diagnostics the gate used (identical codes, identical line numbers)
 * without duplicating the freshness logic. We reject the alternative
 * (invoking `tracey validate` inside the MCP loop and trusting its output as
 * authoritative for the commit attempt) because it re-introduces the
 * second-opinion problem the ADR exists to prevent: the agent's validation
 * would diverge from the gate's, and the developer would face two different
 * answers to the same question.
 *
 * ## Consequences
 *
 *   (+) A single, auditable failure surface: developers learn to trust
 *       exactly one signal.
 *   (−) Partial staging is refused rather than handled, which will frustrate
 *       interactive-rebase-heavy workflows.
 *   (−) Agent commits require two steps (worktree validate, then index
 *       commit) before the gate is authoritative; a hasty agent that skips
 *       the second step bypasses the strongest check.
 *   (⇄) The gate must be kept in lockstep with the LSP server's diagnostic
 *       codes; a divergence between `tracey pre-commit` and `tracey lsp`
 *       would silently weaken the editor feedback loop.
 *
 * ## Alternatives Considered
 *
 *   • Husky + lint-staged — rejected because lint-staged's file-list
 *     granularity is per-file, whereas intent drift is per-requirement, and
 *     the two globs do not line up naturally.
 *   • A CI-only gate (no pre-commit) — rejected as too late: developers
 *     would learn about drift in a red pipeline rather than at the moment of
 *     the commit, which is where the mental context still exists.
 *   • Trusting `tracey query validate --deny warnings` as the sole gate —
 *     rejected because it does not run the index-diff step that
 *     `tracey pre-commit` performs; we would lose the "bumped the requirement
 *     but not the annotation" check.
 */

export {};
