<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: basic_basic_code_example.md
Description: Basic Code Example
==========================================
-->

# Edge API — Living Intent Graph

## Request Validation

r[edge-api.validate.schema]
Incoming JSON requests MUST be validated against a typed runtime schema before any business logic executes.

r[edge-api.validate.reject-invalid]
Invalid requests MUST be rejected with an HTTP 422 response before reaching downstream services.

r[edge-api.validate.strip-unknown]
Unknown properties MUST be stripped from validated payloads to prevent prototype-pollution class attacks.

r[edge-api.validate.latency-budget]
Validation MUST complete within 25 milliseconds at p99 to preserve the edge-first latency budget.

## Error Contract

r[edge-api.error.shape]
Error responses MUST conform to the `ApiError` interface with the fields `code`, `message`, and `requestId`.

r[edge-api.error.no-echo]
Error responses MUST NOT echo back the offending input value, to prevent PII leakage into access logs.
