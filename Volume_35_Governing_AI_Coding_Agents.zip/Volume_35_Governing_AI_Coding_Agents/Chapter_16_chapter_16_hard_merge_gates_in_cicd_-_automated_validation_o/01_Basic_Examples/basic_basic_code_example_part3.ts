/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

/**
 * @file Public wire-format contract for the edge API.
 *
 * Everything exported here is part of the external surface exposed to
 * downstream consumers and MUST NOT change without a corresponding
 * spec change in `docs/spec/edge-api.md`.
 */

/**
 * Standardized error body returned by every failing edge handler.
 *
 * Requirement: `edge-api.error.shape`.
 * Side-channel: `edge-api.error.no-echo` — this interface has no
 * `input` or `rawInput` field on purpose. Adding one would violate the
 * no-echo requirement and the CI gate would catch it.
 */
export interface ApiError {
    readonly code: string;
    readonly message: string;
    readonly requestId: string;
}

/**
 * Successful validation outcome.
 *
 * @typeParam T The downstream, already-validated payload type.
 */
export interface ValidatedRequest<T> {
    readonly ok: true;
    readonly data: T;
    readonly requestId: string;
}

/**
 * Rejected validation outcome.
 */
export interface ValidationFailure {
    readonly ok: false;
    readonly error: ApiError;
}

/**
 * Discriminated union produced by every validator in this module.
 * Consumers narrow on `result.ok` and TypeScript collapses the type
 * without any casting.
 */
export type ValidationResult<T> = ValidatedRequest<T> | ValidationFailure;
