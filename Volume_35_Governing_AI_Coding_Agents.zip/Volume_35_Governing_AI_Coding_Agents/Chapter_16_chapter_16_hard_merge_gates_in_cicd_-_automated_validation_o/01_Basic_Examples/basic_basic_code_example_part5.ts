/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

import { describe, expect, it } from "vitest";
import {
    CreateUserSchema,
    buildValidator,
    toApiError,
    validateCreateUser,
} from "./validate-request";

describe("validateCreateUser", () => {
    // r[verify edge-api.validate.schema]
    // r[verify edge-api.validate.reject-invalid]
    it("accepts a well-formed payload and returns ok:true", () => {
        const result = validateCreateUser({
            email: "ada@acme.dev",
            displayName: "Ada",
            age: 36,
        });

        expect(result.ok).toBe(true);
        if (result.ok) {
            expect(result.data.email).toBe("ada@acme.dev");
            expect(result.requestId).toMatch(/^[0-9a-f-]{36}$/);
        }
    });

    // r[verify edge-api.validate.reject-invalid]
    it("rejects an invalid payload with ok:false", () => {
        const result = validateCreateUser({
            email: "not-an-email",
            displayName: "",
            age: 12,
        });

        expect(result.ok).toBe(false);
        if (!result.ok) {
            expect(result.error.code).toBe("VALIDATION_FAILED");
        }
    });

    // r[verify edge-api.validate.strip-unknown]
    it("strips unknown keys from the validated output", () => {
        const result = validateCreateUser({
            email: "ada@acme.dev",
            displayName: "Ada",
            age: 36,
            // This is the prototype-pollution canary. It must not
            // appear anywhere in the validated output.
            __proto__polluted: true,
            isAdmin: true,
        });

        expect(result.ok).toBe(true);
        if (result.ok) {
            expect(result.data).not.toHaveProperty("isAdmin");
            expect(result.data).not.toHaveProperty("__proto__polluted");
        }
    });

    // r[verify edge-api.error.shape]
    // r[verify edge-api.error.no-echo]
    it("never echoes the offending input in the error body", () => {
        const SECRET = "sk-live-SHOULD-NEVER-LEAK";
        const result = validateCreateUser({
            email: SECRET,
            displayName: "Ada",
            age: 36,
        });

        expect(result.ok).toBe(false);
        if (!result.ok) {
            expect(result.error.message).not.toContain(SECRET);
            expect(Object.values(result.error)).not.toContain(SECRET);
        }
    });

    // r[verify edge-api.error.shape]
    it("projects Zod failures through toApiError without leaking paths", () => {
        const parsed = CreateUserSchema.safeParse({ email: 42 });
        if (parsed.success) throw new Error("expected failure");

        const apiError = toApiError(parsed.error, "req-123");
        expect(apiError).toEqual({
            code: "VALIDATION_FAILED",
            message: expect.stringContaining("email"),
            requestId: "req-123",
        });
    });

    // r[verify edge-api.validate.latency-budget]
    it("validates a typical payload well within the 25ms budget", () => {
        const payload = {
            email: "ada@acme.dev",
            displayName: "Ada",
            age: 36,
        };

        const start = performance.now();
        for (let i = 0; i < 1000; i += 1) {
            validateCreateUser(payload);
        }
        const elapsed = performance.now() - start;

        // 1000 iterations should complete in a small fraction of a
        // second; assert with generous headroom so the test is stable
        // on CI runners.
        expect(elapsed).toBeLessThan(250);
    });
});

describe("buildValidator", () => {
    // r[verify edge-api.validate.schema]
    it("preserves the generic parameter T across the returned validator", () => {
        const v = buildValidator(CreateUserSchema);
        const out = v({ email: "a@b.c", displayName: "A", age: 20 });
        expect(out.ok).toBe(true);
    });
});
