/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part3.ts
Description: Advanced Application Implementation
==========================================
*/

// packages/sdk/src/planner/ModelSelector.ts

/**
 * @file Model selection and execution-provider binding for the EdgeInfer
 * browser SDK. This module is the single authority for choosing between
 * `webgpu`, `wasm-simd`, and `wasm` execution providers.
 *
 * @packageDocumentation
 */

// edge[impl EDGE-MODEL-001]
// edge[impl EDGE-MODEL-002]
// edge[impl EDGE-MODEL-003]
// edge[impl EDGE-MEM-001]
// edge[impl EDGE-MEM-002]
// edge[impl EDGE-OBS-001]
// edge[impl EDGE-OBS-002]

/**
 * The set of execution providers that the edge runtime may bind.
 *
 * @remarks
 * The ordering of this union is normative — see EDGE-MODEL-002 for the
 * fallback contract.
 */
export type ExecutionProvider = 'webgpu' | 'wasm-simd' | 'wasm';

/**
 * A signed tenant policy manifest, as fetched from the control plane.
 *
 * @remarks
 * The `signature` field is opaque to the selector; verification is performed
 * by `verifyManifestSignature` before any field of this interface is read.
 * See EDGE-EDGE-001.
 */
export interface PolicyManifest {
  schema: 'edge.v1';
  tenantId: string;
  allowProviders: ExecutionProvider[];
  allowGpu: boolean;
  memoryCeilingBytesOverride?: number;
  expiresAt: number;
  signature: Uint8Array;
}

/**
 * A structured telemetry event, conforming to the edge.v1 envelope.
 */
export interface TelemetryEvent {
  schema: 'edge.v1';
  event: string;
  ts: number;
  tenantId: string;
  payload: Record<string, unknown>;
}

/**
 * The runtime capabilities that the selector must reason about. All values
 * are probed at SDK initialization time; the selector itself is pure.
 */
export interface RuntimeCapabilities {
  hasWebGpuAdapter: boolean;
  webGpuMaxBufferSize: number;
  hasWasmSimd: boolean;
  deviceMemoryGiB: number;
}

/** Hard ceiling, per EDGE-MEM-001. */
const HARD_MEMORY_CEILING_BYTES = 2048 * 1024 * 1024;

/** Per-GiB multiplier, per EDGE-MEM-001. */
const BYTES_PER_DEVICE_GIB = 512 * 1024 * 1024;

/** Minimum WebGPU buffer size, per EDGE-MODEL-001. */
const MIN_WEBGPU_BUFFER_BYTES = 256 * 1024 * 1024;

/**
 * Thrown when a tenant policy intersects the supported provider set to the
 * empty set. See EDGE-MODEL-003.
 */
export class ProviderNotAvailableError extends Error {
  constructor(
    public readonly requested: ExecutionProvider[],
    public readonly supported: ExecutionProvider[],
  ) {
    super(
      `No execution provider satisfies tenant policy: ` +
        `requested=[${requested.join(',')}] supported=[${supported.join(',')}]`,
    );
    this.name = 'ProviderNotAvailableError';
  }
}

/**
 * The selector's public surface. Consumers only depend on this interface,
 * which is why it lives at the top of the module — changes here are
 * breaking changes and must be reflected as a requirement bump.
 */
export interface IModelPlanner {
  /**
   * Choose an execution provider given capabilities and a policy manifest.
   * Throws {@link ProviderNotAvailableError} when no provider satisfies
   * both the policy and local capabilities.
   */
  selectProvider(
    caps: RuntimeCapabilities,
    policy: PolicyManifest,
  ): ExecutionProvider;

  /**
   * Compute the effective WASM heap size, clamped per EDGE-MEM-001.
   * Emits `edge.memory.clamped` via the supplied telemetry sink when a
   * clamp occurs.
   */
  computeHeapSize(
    requestedBytes: number,
    caps: RuntimeCapabilities,
    policy: PolicyManifest,
  ): number;
}

/**
 * A minimal telemetry sink contract. The real SDK wires this to a batched
 * collector (see EDGE-OBS-002); tests inject a spy.
 */
export interface ITelemetrySink {
  emit(event: TelemetryEvent): void;
}

/**
 * Default implementation of {@link IModelPlanner}.
 *
 * @remarks
 * This class is intentionally stateless. Every input is passed explicitly so
 * that the selector can be exercised in isolation — a requirement for the
 * end-to-end merge gate to be meaningful.
 */
export class ModelPlanner implements IModelPlanner {
  constructor(
    private readonly telemetry: ITelemetrySink,
    private readonly tenantId: string,
  ) {}

  /**
   * @inheritDoc
   *
   * @remarks Implements EDGE-MODEL-001, EDGE-MODEL-002, EDGE-MODEL-003.
   */
  selectProvider(
    caps: RuntimeCapabilities,
    policy: PolicyManifest,
  ): ExecutionProvider {
    const preferred = this.computePreferredChain(caps, policy);

    // Intersect with the tenant's allow-list. A tenant that omits
    // allowProviders gets the full chain — this is the common case.
    const allowed =
      policy.allowProviders.length > 0
        ? preferred.filter((p) => policy.allowProviders.includes(p))
        : preferred;

    const chosen = allowed[0];
    if (!chosen) {
      // EDGE-MODEL-003: empty intersection is an error, not a silent fallback.
      throw new ProviderNotAvailableError(policy.allowProviders, preferred);
    }

    // Emit a fallback event whenever we did not select the top preference.
    // Note that 'preferred[0]' is always defined because computePreferredChain
    // unconditionally appends 'wasm' as the terminal element.
    if (chosen !== preferred[0]) {
      this.telemetry.emit({
        schema: 'edge.v1',
        event: 'edge.provider.fallback',
        ts: Date.now(),
        tenantId: this.tenantId,
        payload: {
          previousProvider: preferred[0],
          selectedProvider: chosen,
          reason: 'policy-or-capability',
        },
      });
    }

    return chosen;
  }

  /**
   * @inheritDoc
   *
   * @remarks Implements EDGE-MEM-001, EDGE-MEM-002.
   */
  computeHeapSize(
    requestedBytes: number,
    caps: RuntimeCapabilities,
    policy: PolicyManifest,
  ): number {
    const ceiling =
      policy.memoryCeilingBytesOverride ??
      Math.min(
        caps.deviceMemoryGiB * BYTES_PER_DEVICE_GIB,
        HARD_MEMORY_CEILING_BYTES,
      );

    if (requestedBytes <= ceiling) {
      return requestedBytes;
    }

    this.telemetry.emit({
      schema: 'edge.v1',
      event: 'edge.memory.clamped',
      ts: Date.now(),
      tenantId: this.tenantId,
      payload: {
        requestedBytes,
        effectiveBytes: ceiling,
        reason: policy.memoryCeilingBytesOverride
          ? 'policy-override'
          : 'device-memory-heuristic',
      },
    });

    return ceiling;
  }

  /**
   * Compute the ordered preference chain before policy filtering.
   *
   * @internal
   */
  private computePreferredChain(
    caps: RuntimeCapabilities,
    policy: PolicyManifest,
  ): ExecutionProvider[] {
    const chain: ExecutionProvider[] = [];

    // EDGE-MODEL-001: WebGPU requires (a) an adapter, (b) sufficient buffer
    // size, and (c) a policy that has not disabled GPU.
    if (
      caps.hasWebGpuAdapter &&
      caps.webGpuMaxBufferSize >= MIN_WEBGPU_BUFFER_BYTES &&
      policy.allowGpu
    ) {
      chain.push('webgpu');
    }

    // EDGE-MODEL-002: SIMD before plain WASM.
    if (caps.hasWasmSimd) {
      chain.push('wasm-simd');
    }

    // Terminal fallback — always present, so callers can rely on chain[0]
    // being defined.
    chain.push('wasm');

    return chain;
  }
}
