/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part4.ts
Description: Advanced Application Implementation
==========================================
*/

// packages/sdk/src/planner/ModelSelector.test.ts

import { describe, expect, it, vi } from 'vitest';
import {
  ModelPlanner,
  ProviderNotAvailableError,
  type ITelemetrySink,
  type PolicyManifest,
  type RuntimeCapabilities,
  type TelemetryEvent,
} from './ModelSelector';

/**
 * A spy-based telemetry sink. Every emitted event is retained on
 * `captured` so that assertions can inspect the payload shape.
 */
class SpySink implements ITelemetrySink {
  public captured: TelemetryEvent[] = [];
  emit(event: TelemetryEvent): void {
    this.captured.push(event);
  }
}

const TENANT = 'tenant-test-0001';

const baseCaps = (overrides: Partial<RuntimeCapabilities> = {}): RuntimeCapabilities => ({
  hasWebGpuAdapter: true,
  webGpuMaxBufferSize: 512 * 1024 * 1024,
  hasWasmSimd: true,
  deviceMemoryGiB: 4,
  ...overrides,
});

const basePolicy = (overrides: Partial<PolicyManifest> = {}): PolicyManifest => ({
  schema: 'edge.v1',
  tenantId: TENANT,
  allowProviders: [],
  allowGpu: true,
  expiresAt: Date.now() + 60_000,
  signature: new Uint8Array(64),
  ...overrides,
});

// edge[verify EDGE-MODEL-001]
describe('EDGE-MODEL-001 — WebGPU provider preference', () => {
  it('selects webgpu when adapter, buffer, and policy all agree', () => {
    const sink = new SpySink();
    const planner = new ModelPlanner(sink, TENANT);
    const chosen = planner.selectProvider(baseCaps(), basePolicy());
    expect(chosen).toBe('webgpu');
    expect(sink.captured).toHaveLength(0);
  });

  it('rejects webgpu when the adapter buffer size is below the floor', () => {
    const sink = new SpySink();
    const planner = new ModelPlanner(sink, TENANT);
    const chosen = planner.selectProvider(
      baseCaps({ webGpuMaxBufferSize: 128 * 1024 * 1024 }),
      basePolicy(),
    );
    expect(chosen).not.toBe('webgpu');
  });
});

// edge[verify EDGE-MODEL-002]
describe('EDGE-MODEL-002 — WASM-SIMD fallback ordering', () => {
  it('selects wasm-simd before plain wasm when no GPU is available', () => {
    const planner = new ModelPlanner(new SpySink(), TENANT);
    const chosen = planner.selectProvider(
      baseCaps({ hasWebGpuAdapter: false }),
      basePolicy(),
    );
    expect(chosen).toBe('wasm-simd');
  });

  it('emits edge.provider.fallback when the top preference is filtered', () => {
    const sink = new SpySink();
    const planner = new ModelPlanner(sink, TENANT);
    planner.selectProvider(baseCaps(), basePolicy({ allowGpu: false }));

    const fallback = sink.captured.find((e) => e.event === 'edge.provider.fallback');
    expect(fallback).toBeDefined();
    expect(fallback!.payload).toMatchObject({
      previousProvider: 'webgpu',
      selectedProvider: 'wasm-simd',
    });
  });
});

// edge[verify EDGE-MODEL-003]
describe('EDGE-MODEL-003 — Tenant policy override', () => {
  it('restricts selection to the intersection of policy and capabilities', () => {
    const planner = new ModelPlanner(new SpySink(), TENANT);
    const chosen = planner.selectProvider(
      baseCaps(),
      basePolicy({ allowProviders: ['wasm'] }),
    );
    expect(chosen).toBe('wasm');
  });

  it('throws ProviderNotAvailableError on empty intersection', () => {
    const planner = new ModelPlanner(new SpySink(), TENANT);
    // A policy that permits only webgpu, but the device has no adapter.
    expect(() =>
      planner.selectProvider(
        baseCaps({ hasWebGpuAdapter: false, hasWasmSimd: false }),
        basePolicy({ allowProviders: ['webgpu'] }),
      ),
    ).toThrow(ProviderNotAvailableError);
  });
});

// edge[verify EDGE-MEM-001]
describe('EDGE-MEM-001 — Heap ceiling enforcement', () => {
  it('never exceeds deviceMemoryGiB * 512MiB', () => {
    const planner = new ModelPlanner(new SpySink(), TENANT);
    const effective = planner.computeHeapSize(
      8 * 1024 * 1024 * 1024,
      baseCaps({ deviceMemoryGiB: 2 }),
      basePolicy(),
    );
    expect(effective).toBe(1024 * 1024 * 1024);
  });

  it('never exceeds the hard 2048 MiB ceiling', () => {
    const planner = new ModelPlanner(new SpySink(), TENANT);
    const effective = planner.computeHeapSize(
      16 * 1024 * 1024 * 1024,
      baseCaps({ deviceMemoryGiB: 64 }),
      basePolicy(),
    );
    expect(effective).toBe(2048 * 1024 * 1024);
  });

  it('honours a policy override that raises the ceiling', () => {
    const planner = new ModelPlanner(new SpySink(), TENANT);
    const effective = planner.computeHeapSize(
      3000 * 1024 * 1024,
      baseCaps({ deviceMemoryGiB: 1 }),
      basePolicy({ memoryCeilingBytesOverride: 3500 * 1024 * 1024 }),
    );
    expect(effective).toBe(3000 * 1024 * 1024);
  });
});

// edge[verify EDGE-MEM-002]
describe('EDGE-MEM-002 — Ceiling negotiation telemetry', () => {
  it('emits edge.memory.clamped with the three required payload fields', () => {
    const sink = new SpySink();
    const planner = new ModelPlanner(sink, TENANT);
    planner.computeHeapSize(
      4 * 1024 * 1024 * 1024,
      baseCaps({ deviceMemoryGiB: 2 }),
      basePolicy(),
    );
    const clamped = sink.captured.find((e) => e.event === 'edge.memory.clamped');
    expect(clamped).toBeDefined();
    expect(clamped!.payload).toHaveProperty('requestedBytes');
    expect(clamped!.payload).toHaveProperty('effectiveBytes');
    expect(clamped!.payload).toHaveProperty('reason');
  });

  it('does not emit when no clamp occurs', () => {
    const sink = new SpySink();
    const planner = new ModelPlanner(sink, TENANT);
    planner.computeHeapSize(
      128 * 1024 * 1024,
      baseCaps(),
      basePolicy(),
    );
    expect(sink.captured).toHaveLength(0);
  });
});

// edge[verify EDGE-OBS-001]
describe('EDGE-OBS-001 — Structured event envelope', () => {
  it('emits events with the edge.v1 schema and required envelope fields', () => {
    const sink = new SpySink();
    const planner = new ModelPlanner(sink, TENANT);
    planner.selectProvider(baseCaps(), basePolicy({ allowGpu: false }));
    for (const event of sink.captured) {
      expect(event.schema).toBe('edge.v1');
      expect(event.tenantId).toBe(TENANT);
      expect(typeof event.event).toBe('string');
      expect(typeof event.ts).toBe('number');
      expect(typeof event.payload).toBe('object');
    }
  });
});
