/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_gate_as_code_authoring_the_strictdoc_fragment_and.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * packages/gate-artifacts/src/gate-artifacts.ts
 *
 * "Gate as code". The three artifacts that decide whether a merge is allowed are
 * exported from one typed module, so review, generation and drift-checking all
 * read the same source of truth. The files on disk
 * (docs/spec/payments.sdoc, .config/tracey/config.styx,
 * .github/workflows/spec-assurance.yml) are treated as build outputs of this
 * module; a separate drift check re-renders and diffs them, so a hand edit in
 * the repository cannot silently diverge from the reviewed source.
 */

// ---------------------------------------------------------------------------
// Artifact 1: the StrictDoc fragment, docs/spec/payments.sdoc
// ---------------------------------------------------------------------------
//
// Design decisions baked into this document, all of them deliberate:
//
// 1. Every invariant is its own requirement. "Idempotent settlement" and
//    "retry backoff" are testable independently, so folding them into one
//    statement would make the coverage metric lie: a single passing test would
//    mark the whole cluster as implemented.
// 2. The word "shall" appears exactly once per statement, in the EARS shape
//    (ubiquitous / when / while / if). This keeps the statement testable and
//    keeps the L2 -> L3 flowdown machine-checkable later.
// 3. Every STATEMENT is a heredoc so multiline statements survive the StrictDoc
//    read/write round-trip byte-for-byte.
// 4. ENABLE_MID is enabled because later pipeline stages (asset upload, diff
//    matching, this gate's own reporting) need an identifier that survives UID
//    renames. Per the StrictDoc user guide, enabling MIDs requires an explicit
//    [GRAMMAR] whose elements declare a MID field, so the grammar below is not
//    optional decoration.
// 5. AUTO_UIDS is enabled as well, matching the Tracey-facing cheat sheet. If
//    the pinned StrictDoc version rejects AUTO_UIDS in OPTIONS, the equivalent
//    behaviour is the document PREFIX plus `strictdoc manage auto-uid`; the
//    drift check will surface that as a build failure rather than a silent
//    no-op.
// 6. [[SECTION]] (composite syntax) is used, never Markdown headings, and never
//    the legacy [SECTION] form which was removed in StrictDoc 0.14.0.

export const PAYMENTS_SDOC: string = `[DOCUMENT]
TITLE: Payments Sub-domain Invariants
UID: PAY-DOC-001
OPTIONS:
  AUTO_UIDS: True
  ENABLE_MID: True
  MARKUP: Text

[GRAMMAR]
ELEMENTS:
- TAG: TEXT
  FIELDS:
  - TITLE: MID
    TYPE: String
    REQUIRED: True
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
- TAG: REQUIREMENT
  FIELDS:
  - TITLE: MID
    TYPE: String
    REQUIRED: True
  - TITLE: UID
    TYPE: String
    REQUIRED: True
  - TITLE: STATUS
    TYPE: String
    REQUIRED: True
  - TITLE: TITLE
    TYPE: String
    REQUIRED: True
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
  RELATIONS:
  - TYPE: Parent

[[SECTION]]
TITLE: Root

[REQUIREMENT]
MID: 1f0c8a2e4b6d4f1093c7a5e2b8d14f31
UID: PAY-ROOT-000
STATUS: Active
TITLE: Payments sub-domain root
STATEMENT: >>>
The payments sub-domain shall expose a single traceability root, and every
payments invariant shall be directly or transitively linked to that root.
<<<

[[/SECTION]]

[[SECTION]]
TITLE: Settlement

[REQUIREMENT]
MID: 2a1d9b3f5c7e4a0192d8b6f3c9e25a42
UID: PAY-SETTLEMENT-001
STATUS: Approved
TITLE: Idempotent settlement
STATEMENT: >>>
When a settlement request is submitted with an idempotency key that has already
been observed, the ledger shall return the original settlement result and shall
not create an additional ledger entry.
<<<

[[/SECTION]]

[[SECTION]]
TITLE: Ledger

[REQUIREMENT]
MID: 3b2e0c4a6d8f4b1203e9c7a4d0f36b53
UID: PAY-LEDGER-002
STATUS: Approved
TITLE: Currency pinning on every ledger entry
STATEMENT: >>>
Every ledger entry shall record the ISO-4217 currency of the settlement that
produced it, and the ledger shall reject any entry whose currency does not match
the settlement currency.
<<<

[[/SECTION]]

[[SECTION]]
TITLE: Retry policy

[REQUIREMENT]
MID: 4c3f1d5b7e9a4c2314f0d8b5e1a47c64
UID: PAY-RETRY-003
STATUS: Approved
TITLE: Exponential backoff with a hard cap
STATEMENT: >>>
While a settlement attempt has not been acknowledged by the acquirer, the
payments gateway shall retry with an exponentially increasing delay, and shall
abandon the request once the configured hard cap is reached.
<<<

[[/SECTION]]

[[SECTION]]
TITLE: Replay protection

[REQUIREMENT]
MID: 5d4a2e6c8f0b4d3415a1e9c6f2b58d75
UID: PAY-REPLAY-004
STATUS: Approved
TITLE: Replay protection
STATEMENT: >>>
If a settlement request is replayed with a nonce that has already been consumed,
the gateway shall reject the request before any ledger mutation occurs.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: PAY-ROOT-000

[[/SECTION]]
`;

// ---------------------------------------------------------------------------
// Artifact 2: the Tracey routing layer, appended to
// .config/tracey/config.styx
// ---------------------------------------------------------------------------
//
// Notes that matter for review:
//   * `include` lists both the Markdown entry point and the .sdoc fragment
//     because the team is mid-migration. Tracey mixes .md and .sdoc inside one
//     spec entry freely; the .sdoc file gets the synthetic prefix `r`, so all
//     source annotations for these requirements read `r[impl PAY-LEDGER-002]`.
//     UID case is preserved end to end, so `PAY-LEDGER-002` never becomes
//     `pay-ledger-002`.
//   * `test_include` is a separate key, not an `exclude`. Files matched there
//     may only carry `verify` annotations; an `impl` annotation inside them is a
//     hard error, which is exactly the class of bug the gate in Exercise 4
//     catches in the wild.
//   * `exclude` is only for generated code. `target/` and `node_modules/` are
//     gitignored and therefore already skipped by Tracey's gitignore-aware
//     walker.

export const TRACEY_CONFIG_APPEND: string = `
specs (
    {
        name payments
        include (docs/spec/payments.md docs/spec/payments.sdoc)
        impls (
            {
                name typescript
                include (src/payments/**/*.ts)
                exclude (src/payments/**/*.generated.ts)
                test_include (tests/payments.spec.ts)
            }
        )
    }
)
`;

// ---------------------------------------------------------------------------
// Artifact 3: the enforcement layer,
// .github/workflows/spec-assurance.yml
// ---------------------------------------------------------------------------

export const SPEC_ASSURANCE_WORKFLOW: string = `name: Specification Assurance Gate
on: [push, pull_request]

# A gate that can mutate repository state is not a gate. The runner gets read
# access and nothing else, so a compromised or misbehaving validation step can
# never push, comment, or force-push on the PR it is judging.
permissions:
  contents: read

jobs:
  verify-intent:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install StrictDoc
        run: |
          python -m pip install --upgrade pip
          pip install strictdoc

      - name: Install Tracey
        run: |
          curl --proto '=https' --tlsv1.2 -LsSf https://github.com/bearcove/tracey/releases/latest/download/tracey-installer.sh | sh
          echo "$HOME/.cargo/bin" >> $GITHUB_PATH

      # ---------------------------------------------------------------------
      # Why three ordered stages instead of one combined job.
      #
      # Stage 1 answers "is the document well formed?" It runs StrictDoc's
      # exporter, which parses the grammar, resolves relations, and fails on
      # malformed SDoc. It knows nothing about source code and nothing about
      # coverage. Its failure mode is syntax, grammar and relation-shape errors:
      # a requirement deleted by accident, a heredoc left unclosed, a Parent
      # pointing at a UID that does not exist.
      #
      # Stage 2 answers "is the document consistent with itself and with the
      # code?" It runs Tracey's semantic linter, which resolves every annotation
      # against the spec graph and fails on cycles, orphans, duplicates, unknown
      # prefixes, stale references and malformed annotation UIDs. Its failure
      # mode is drift: the spec and the repository disagree about what exists.
      #
      # Stage 3 answers "do we still tolerate the coverage we have?" It runs the
      # coverage queries and the threshold policy. Its failure mode is erosion:
      # everything is individually valid, but the aggregate moved below the bar
      # the team agreed on.
      #
      # The order is not cosmetic. Tracey's daemon keeps an in-memory graph and
      # can serve queries from a cached parse. If Tracey ran first and StrictDoc
      # second, a reviewer could see "Tracey: pass" followed by "StrictDoc:
      # document will not parse", which reads like a flake. Ordered stages make
      # the failure story linear: first "your document is malformed", then "your
      # document is well formed but inconsistent with your code", then "your
      # document and code agree but no longer cover the agreed invariants".
      #
      # Note on caching: if a cache step is ever added, it must exclude
      # .tracey/ explicitly. The daemon writes .tracey/daemon.pid and
      # .tracey/daemon.log; a restored stale PID points at a dead process and
      # produces nondeterministic first-query behaviour.
      # ---------------------------------------------------------------------

      - name: "Gate stage 1: StrictDoc document tree is well formed"
        run: strictdoc export --formats=html .

      - name: "Gate stage 2: Tracey semantic validation (warnings are fatal)"
        run: tracey query validate --deny warnings

      - name: "Gate stage 3: coverage tolerance"
        run: |
          set -euo pipefail
          tracey query status
          tracey query uncovered
          tracey query untested
          tracey query stale
          # We deliberately do not parse Tracey's human-readable output in bash.
          # The threshold decision lives in one typed place (the gate-runner
          # client), which speaks the MCP surface and emits a normalized report.
          pnpm --filter gate-runner start -- --mode=local --quiet --report-out=.gate/report.json

      - name: Upload gate report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: gate-report
          path: .gate/report.json
          if-no-files-found: ignore
`;

/** The three artifacts, keyed by their path in the repository. */
export const GATE_ARTIFACTS: Readonly<Record<string, string>> = {
  'docs/spec/payments.sdoc': PAYMENTS_SDOC,
  '.config/tracey/config.styx': TRACEY_CONFIG_APPEND,
  '.github/workflows/spec-assurance.yml': SPEC_ASSURANCE_WORKFLOW,
};
