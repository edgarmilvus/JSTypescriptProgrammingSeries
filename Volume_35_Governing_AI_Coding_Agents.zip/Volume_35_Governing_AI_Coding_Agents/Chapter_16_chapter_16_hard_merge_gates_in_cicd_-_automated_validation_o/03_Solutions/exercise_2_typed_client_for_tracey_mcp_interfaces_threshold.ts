/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_typed_client_for_tracey_mcp_interfaces_threshold.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * packages/gate-runner/src/protocol.ts
 *
 * The public contract of the gate runner. These interfaces are consumed by the
 * CI stage in Exercise 1, by the local CLI, and by the React panel in
 * Exercise 3, so they are `interface` declarations rather than `type` aliases:
 * interfaces are open to declaration merging and produce better error messages
 * when a consumer gets a field wrong.
 */

// ---------------------------------------------------------------------------
// Failure signatures
// ---------------------------------------------------------------------------

/**
 * One code, one meaning. The React panel keys its rendering off these values,
 * so a code that covers two situations forces branching logic in the UI that
 * contradicts the code's own name. If you are tempted to add a code, ask
 * whether the UI would render it differently from every existing code.
 */
export type GateFailureCode =
  | 'COVERAGE_IMPL_UNDER_THRESHOLD'
  | 'COVERAGE_VERIFY_UNDER_THRESHOLD'
  | 'STALE_BUDGET_EXCEEDED'
  | 'VALIDATION_WARNINGS_DENIED'
  | 'UNKNOWN_REQUIREMENT_REFERENCE'
  | 'MCP_PARSE_ERROR';

export interface GateFailure {
  readonly code: GateFailureCode;
  readonly message: string;
  readonly details?: Readonly<Record<string, unknown>>;
}

// ---------------------------------------------------------------------------
// Policy
// ---------------------------------------------------------------------------

export interface GatePolicy {
  /** Minimum implementation coverage per spec/impl pair, in percent. */
  readonly minImplPercent: number;
  /** Minimum verification coverage per spec/impl pair, in percent. */
  readonly minVerifyPercent: number;
  /** Budget for references pointing at older rule versions. */
  readonly maxStaleReferences: number;
  /** Mirrors `tracey query validate --deny warnings`. */
  readonly denyWarnings: boolean;
}

export const DEFAULT_POLICY: GatePolicy = {
  minImplPercent: 75,
  minVerifyPercent: 75,
  maxStaleReferences: 0,
  denyWarnings: true,
};

// ---------------------------------------------------------------------------
// Normalized report
// ---------------------------------------------------------------------------

export interface ValidationIssue {
  readonly kind:
    | 'unknown-requirement-reference'
    | 'stale-reference'
    | 'impl-in-test-file'
    | 'other';
  /** Null when the issue is not attributable to a single requirement. */
  readonly requirementUid: string | null;
  /** Null when the daemon did not report a source location. */
  readonly location: string | null;
  /** The verbatim line, preserved so downstream tools can re-parse if needed. */
  readonly raw: string;
}

export interface ValidationSummary {
  readonly errorCount: number;
  readonly warningCount: number;
  readonly errors: readonly ValidationIssue[];
  readonly warnings: readonly ValidationIssue[];
}

export interface SpecCoverage {
  /** Canonical "spec/impl" key, e.g. "payments/typescript". */
  readonly specImpl: string;
  readonly implPercent: number;
  readonly verifyPercent: number;
  readonly uncoveredRequirementUids: readonly string[];
  readonly untestedRequirementUids: readonly string[];
  readonly staleRequirementUids: readonly string[];
  /**
   * Optional raw denominator. Percentages alone cannot express the difference
   * between "0 of 0 requirements covered" and "0 of 12 covered"; the UI needs
   * the count to render an honest empty state instead of a misleading 0.0%.
   */
  readonly requirementCount?: number;
}

export interface NormalizedCoverageReport {
  readonly generatedAt: string;
  /**
   * The daemon's data version for the snapshot these numbers came from. Without
   * it, a report assembled across five tool calls cannot be proven to describe
   * one consistent state of the graph.
   */
  readonly dataVersion: string;
  readonly decision: 'pass' | 'fail';
  readonly policy: GatePolicy;
  readonly specs: readonly SpecCoverage[];
  readonly validation: ValidationSummary;
  readonly failures: readonly GateFailure[];
}

// ---------------------------------------------------------------------------
// MCP transport contract
// ---------------------------------------------------------------------------

export interface McpTransportOptions {
  readonly command: string;
  readonly args: readonly string[];
}

/**
 * The seam. `--mode=local` injects a stdio transport; `--mode=replay` injects a
 * transcript-reading transport. Nothing above this interface knows which one is
 * in play, which is what makes the tool testable without spawning a daemon.
 */
export interface McpTransport {
  request(method: string, params: unknown): Promise<unknown>;
  notify(method: string, params: unknown): Promise<void>;
  close(): Promise<void>;
}

// ---------------------------------------------------------------------------
// CLI surface: exactly four flags, no more
// ---------------------------------------------------------------------------

export type GateMode = 'local' | 'replay';

/** The literal string `stdout` selects standard output as the report sink. */
export type ReportSink = 'stdout' | string;

export interface GateCliOptions {
  readonly mode: GateMode;
  readonly configPath: string;
  readonly reportOut: ReportSink;
  readonly quiet: boolean;
}

export const EXIT_PASS = 0;
export const EXIT_FAIL = 1;

/**
 * Rejects unknown flags outright. The React dev-server proxy in Exercise 3
 * spawns this process; a silently-ignored flag there is a bug that only shows
 * up as "the panel says something different from CI".
 */
export function parseGateCliArgs(argv: readonly string[]): GateCliOptions {
  const defaultConfig = 'gate.config.json';
  const defaultReportOut = './.gate/report.json';

  let mode: GateMode = 'local';
  let configPath = defaultConfig;
  let reportOut: ReportSink = defaultReportOut;
  let quiet = false;

  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i] as string;
    const [flag, inlineValue] = token.includes('=')
      ? [token.slice(0, token.indexOf('=')), token.slice(token.indexOf('=') + 1)]
      : [token, undefined];

    const takeValue = (): string => {
      if (inlineValue !== undefined) return inlineValue;
      const next = argv[i + 1];
      if (next === undefined) throw new Error(`gate-runner: ${flag} requires a value`);
      i += 1;
      return next;
    };

    switch (flag) {
      case '--mode': {
        const value = takeValue();
        if (value !== 'local' && value !== 'replay') {
          throw new Error(`gate-runner: --mode must be 'local' or 'replay', got '${value}'`);
        }
        mode = value;
        break;
      }
      case '--config':
        configPath = takeValue();
        break;
      case '--report-out':
        reportOut = takeValue();
        break;
      case '--quiet':
        quiet = true;
        break;
      default:
        throw new Error(`gate-runner: unknown flag '${token}'`);
    }
  }

  return { mode, configPath, reportOut, quiet };
}
