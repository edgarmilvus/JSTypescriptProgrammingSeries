/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_typed_client_for_tracey_mcp_interfaces_threshold_part2.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * packages/gate-runner/src/policy.ts
 *
 * The threshold enforcer. This is the only place in the tool that decides
 * pass/fail, and it is a pure function so that the decision is reproducible
 * from (report, policy) alone.
 */

import {
  type GateFailure,
  type GatePolicy,
  type NormalizedCoverageReport,
} from './protocol.js';

export function evaluatePolicy(
  report: NormalizedCoverageReport,
  policy: GatePolicy,
): readonly GateFailure[] {
  const failures: GateFailure[] = [];

  for (const spec of report.specs) {
    // A non-finite percentage is not "very low coverage", it is a broken
    // parse. Treating it as a coverage failure would hide a protocol bug
    // behind a plausible-looking red build.
    if (!Number.isFinite(spec.implPercent) || !Number.isFinite(spec.verifyPercent)) {
      failures.push({
        code: 'MCP_PARSE_ERROR',
        message: `Non-finite coverage value for ${spec.specImpl}`,
        details: { specImpl: spec.specImpl, implPercent: spec.implPercent },
      });
      continue;
    }

    if (spec.implPercent < policy.minImplPercent) {
      failures.push({
        code: 'COVERAGE_IMPL_UNDER_THRESHOLD',
        message:
          `Implementation coverage for ${spec.specImpl} is ${spec.implPercent}%, ` +
          `below the required ${policy.minImplPercent}%`,
        details: {
          specImpl: spec.specImpl,
          actual: spec.implPercent,
          required: policy.minImplPercent,
          requirementUids: spec.uncoveredRequirementUids,
        },
      });
    }

    if (spec.verifyPercent < policy.minVerifyPercent) {
      failures.push({
        code: 'COVERAGE_VERIFY_UNDER_THRESHOLD',
        message:
          `Verification coverage for ${spec.specImpl} is ${spec.verifyPercent}%, ` +
          `below the required ${policy.minVerifyPercent}%`,
        details: {
          specImpl: spec.specImpl,
          actual: spec.verifyPercent,
          required: policy.minVerifyPercent,
          requirementUids: spec.untestedRequirementUids,
        },
      });
    }
  }

  // Stale references are counted across the whole report, not per spec, because
  // the budget is a repository-level agreement. The offending UIDs are carried
  // in `details` so the UI can render the specific requirements.
  const staleLocations = report.specs.flatMap((spec) =>
    spec.staleRequirementUids.map((uid) => ({ specImpl: spec.specImpl, uid })),
  );

  if (staleLocations.length > policy.maxStaleReferences) {
    failures.push({
      code: 'STALE_BUDGET_EXCEEDED',
      message:
        `${staleLocations.length} stale reference(s), budget is ` +
        `${policy.maxStaleReferences}`,
      details: { staleLocations },
    });
  }

  if (policy.denyWarnings && report.validation.warningCount > 0) {
    failures.push({
      code: 'VALIDATION_WARNINGS_DENIED',
      message:
        `${report.validation.warningCount} validation warning(s) observed while ` +
        `denyWarnings is enabled`,
      details: { warnings: report.validation.warnings },
    });
  }

  // Errors are always fatal, independently of the warning policy: an unknown
  // requirement reference means the annotation and the spec disagree about what
  // exists, which invalidates every coverage number derived from them.
  const unknownReferences = report.validation.errors.filter(
    (issue) => issue.kind === 'unknown-requirement-reference',
  );

  if (unknownReferences.length > 0) {
    failures.push({
      code: 'UNKNOWN_REQUIREMENT_REFERENCE',
      message: `${unknownReferences.length} annotation(s) reference an unknown requirement`,
      details: { issues: unknownReferences },
    });
  }

  return failures;
}

export function decide(failures: readonly GateFailure[]): 'pass' | 'fail' {
  return failures.length === 0 ? 'pass' : 'fail';
}
