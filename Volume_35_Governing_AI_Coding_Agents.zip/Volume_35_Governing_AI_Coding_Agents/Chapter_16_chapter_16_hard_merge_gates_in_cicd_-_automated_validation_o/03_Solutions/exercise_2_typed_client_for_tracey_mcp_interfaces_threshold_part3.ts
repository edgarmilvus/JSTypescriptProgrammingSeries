/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_typed_client_for_tracey_mcp_interfaces_threshold_part3.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * packages/gate-runner/src/mcpTransport.ts
 *
 * NOTE: this file's only exported symbol is `createTransport`, by contract.
 * The `McpTransport` and `McpTransportOptions` types live in protocol.ts so
 * that the transport module stays a single-responsibility factory.
 *
 * Framing: newline-delimited JSON-RPC 2.0 over the child process's stdio, which
 * is what `tracey mcp` speaks.
 */

import { spawn } from 'node:child_process';
import type { McpTransport, McpTransportOptions } from './protocol.js';

interface PendingCall {
  resolve: (value: unknown) => void;
  reject: (reason: Error) => void;
  timer: NodeJS.Timeout;
}

export function createTransport(opts: McpTransportOptions): McpTransport {
  const child = spawn(opts.command, [...opts.args], { stdio: ['pipe', 'pipe', 'pipe'] });

  const pending = new Map<number, PendingCall>();
  let nextId = 1;
  let buffer = '';
  let closed = false;

  const failEverything = (reason: Error): void => {
    for (const [, call] of pending) {
      clearTimeout(call.timer);
      call.reject(reason);
    }
    pending.clear();
  };

  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk: string) => {
    buffer += chunk;
    // Responses are newline-delimited; a partial line stays in the buffer until
    // the next chunk arrives. Splitting on '\n' only is correct: '\r\n' from a
    // Windows build leaves a trailing '\r' which JSON.parse tolerates.
    let newlineIndex = buffer.indexOf('\n');
    while (newlineIndex !== -1) {
      const line = buffer.slice(0, newlineIndex).trim();
      buffer = buffer.slice(newlineIndex + 1);
      if (line.length > 0) handleLine(line);
      newlineIndex = buffer.indexOf('\n');
    }
  });

  const handleLine = (line: string): void => {
    let message: unknown;
    try {
      message = JSON.parse(line);
    } catch {
      // A non-JSON line on stdout is a protocol violation, not a tool result.
      failEverything(new Error(`tracey mcp emitted a non-JSON line: ${line.slice(0, 200)}`));
      return;
    }

    const envelope = message as { id?: number; result?: unknown; error?: unknown };

    // Server-initiated notifications have no id. We have no handler in this
    // contract, so they are dropped rather than mistaken for responses. They go
    // to stderr so a developer debugging a hung session can still see them.
    if (envelope.id === undefined) {
      process.stderr.write(`gate-runner: ignoring server notification: ${line}\n`);
      return;
    }

    const call = pending.get(envelope.id);
    if (call === undefined) return;

    pending.delete(envelope.id);
    clearTimeout(call.timer);

    if (envelope.error !== undefined && envelope.error !== null) {
      call.reject(new Error(`tracey mcp error: ${JSON.stringify(envelope.error)}`));
      return;
    }
    call.resolve(envelope.result);
  };

  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk: string) => {
    // The daemon's diagnostics go to our diagnostics stream, never to stdout,
    // because stdout may be the JSON report sink.
    process.stderr.write(chunk);
  });

  child.on('exit', (code, signal) => {
    failEverything(
      new Error(`tracey mcp exited early (code=${code ?? 'null'}, signal=${signal ?? 'null'})`),
    );
  });

  return {
    request(method, params): Promise<unknown> {
      if (closed) return Promise.reject(new Error('transport is closed'));

      const id = nextId;
      nextId += 1;

      return new Promise<unknown>((resolve, reject) => {
        const timer = setTimeout(() => {
          pending.delete(id);
          reject(new Error(`tracey mcp request '${method}' timed out after 30000ms`));
        }, 30_000);

        pending.set(id, { resolve, reject, timer });
        child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', id, method, params })}\n`);
      });
    },

    notify(method, params): Promise<void> {
      if (closed) return Promise.reject(new Error('transport is closed'));
      child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', method, params })}\n`);
      return Promise.resolve();
    },

    close(): Promise<void> {
      if (closed) return Promise.resolve();
      closed = true;

      return new Promise<void>((resolve) => {
        child.stdin.end();
        const killTimer = setTimeout(() => child.kill('SIGKILL'), 2_000);
        child.once('exit', () => {
          clearTimeout(killTimer);
          resolve();
        });
      });
    },
  };
}
