/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_typed_client_for_tracey_mcp_interfaces_threshold_part4.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * packages/gate-runner/src/mcpTransportReplay.ts
 *
 * The test seam. Reads pre-recorded transcripts from a directory. Filenames are
 * `<sequence>-<toolName>.txt`, e.g. `010-tracey_status.txt`. The leading
 * `>>> tracey_status` prompt line that a human transcript contains is stripped
 * here, not in the parser, because it is an artifact of copying text out of a
 * terminal and never appears on the wire.
 */

import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import type { McpTransport } from './protocol.js';

export async function createReplayTransport(directory: string): Promise<McpTransport> {
  const entries = (await readdir(directory)).sort();
  const responses = new Map<string, string>();

  for (const entry of entries) {
    const toolName = entry.replace(/^\d+-/, '').replace(/\.txt$/, '');
    const raw = await readFile(path.join(directory, entry), 'utf8');
    responses.set(toolName, stripTranscriptPrompt(raw));
  }

  return {
    request(method: string): Promise<unknown> {
      const body = responses.get(method);
      if (body === undefined) {
        return Promise.reject(new Error(`no recorded transcript for '${method}' in ${directory}`));
      }
      return Promise.resolve(body);
    },
    notify: () => Promise.resolve(),
    close: () => Promise.resolve(),
  };
}

function stripTranscriptPrompt(raw: string): string {
  return raw
    .split('\n')
    .filter((line) => !line.startsWith('>>> '))
    .join('\n')
    .trim();
}
