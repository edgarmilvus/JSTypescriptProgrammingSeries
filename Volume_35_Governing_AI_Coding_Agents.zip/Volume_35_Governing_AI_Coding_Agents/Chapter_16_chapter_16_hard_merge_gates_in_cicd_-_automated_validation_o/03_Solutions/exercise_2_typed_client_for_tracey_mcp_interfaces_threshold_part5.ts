/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_typed_client_for_tracey_mcp_interfaces_threshold_part5.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * packages/gate-runner/src/parsing-design-note.ts (design artifact)
 *
 * ---------------------------------------------------------------------------
 * docs/design/gate-runner-parsing.md
 * ---------------------------------------------------------------------------
 *
 * Parser design for Tracey's human-readable MCP output.
 *
 * The parser's single job is to turn five text responses into one
 * `NormalizedCoverageReport`. It never guesses: anything it cannot derive
 * deterministically becomes an `MCP_PARSE_ERROR`, because a plausible-looking
 * wrong number is worse than an honest failure.
 *
 * 1.  Section headers are matched as literal prefixes with an optional leading
 *     two-space indent: `Status:`, `Spec/Impl:`, `Delta since last query:`,
 *     `Hints:`, `Validation:`, `Errors:`, `Warnings:`.
 * 2.  `Spec/Impl:` is a stateful scope marker. Every indented entry that
 *     follows it belongs to that scope until the next `Spec/Impl:` or a
 *     top-level header. The parser must never assume one scope per response.
 * 3.  Split the scope key on the LAST `/`, not the first: spec names are free
 *     text from the Styx config and may themselves contain a slash, while impl
 *     names are single tokens in every configuration we control. A scope header
 *     with no `/` at all is a parse error, not a spec named "payments".
 * 4.  `(none)` is a sentinel, not an entry. A scope present with `(none)` maps
 *     to an empty array. It must produce a `SpecCoverage` object, never a
 *     missing map key, or the "no findings" and "no requirements" cases become
 *     indistinguishable in the report.
 * 5.  Percentages match `^(\d{1,3}\.\d)%$`. `100.0%` and `0.0%` are both
 *     valid and must not be conflated with the `(none)` sentinel. Anything else
 *     (including `NaN`, `100%`, `1e2%`) is a parse error.
 * 6.  The `Delta` line is optional. A cold daemon that has served only one
 *     query emits no delta or an empty one; absence is not an error.
 * 7.  Delta values are extracted with a global regex over
 *     `([+-]?\d+\.\d+) ppt \((impl|verify)\)` rather than by splitting on
 *     commas, because the parenthetical direction label is the only reliable
 *     discriminator between the two numbers.
 * 8.  The `Hints:` line is prose and is never parsed for numbers. It contains
 *     a count ("4 requirement(s) uncovered") that can disagree with the
 *     `tracey_uncovered` list when the two responses straddle a rebuild.
 *     Hints go into `details`, never into the gate decision.
 * 9.  Truncation is detected three ways: a final line with no trailing
 *     newline, a `Validation:` header whose declared counts exceed the number
 *     of parsed entries, or a `Status:` block with zero scopes. Any of the
 *     three yields `MCP_PARSE_ERROR` rather than a partial report, because a
 *     partial coverage number silently lowers the threshold's meaning.
 * 10. Entries in uncovered/untested/stale are `<UID>` followed by two or more
 *     spaces and a human description. Split on the FIRST run of two or more
 *     spaces and trim only the right-hand side. UIDs are never trimmed.
 * 11. Trailing whitespace inside a UID is semantically significant and must be
 *     preserved verbatim in `details`. The daemon quotes the offending token,
 *     so `'PAY-settlement-003 '` is a five-character-suffix bug, not noise.
 * 12. Validation entries may wrap onto continuation lines. A line that is more
 *     deeply indented than the previous entry is appended to that entry, with
 *     the indentation collapsed to a single space.
 * 13. `at <path>:<line>` suffixes are optional. A warning with no location is
 *     still counted toward `warningCount`; it simply has `location: null`.
 * 14. Warning kinds are classified by matching stable sentence prefixes
 *     (`Unknown requirement reference`, `Stale reference`, `Impl annotation in
 *     a test file`). Matching on requirement IDs would break the moment a team
 *     named a requirement "Stale".
 * 15. The `Validation:` header counts are used as a checksum against the number
 *     of parsed bullet entries. A mismatch is an `MCP_PARSE_ERROR`; it means we
 *     lost an entry somewhere and every downstream count is suspect.
 * 16. The `Validation:` header may report zero errors and zero warnings with no
 *     `Errors:`/`Warnings:` blocks at all. That is a valid, clean response.
 * 17. Scope order is not guaranteed across responses. Sort scopes by
 *     `specImpl` before merging, so the report is byte-stable across runs and
 *     diffable in CI artifacts.
 * 18. Numbers use `.` as the decimal separator and never thousands separators.
 *     Parse with a regex, never with `Number()` on a locale-formatted string.
 * 19. An empty tool response (a tool that legitimately returns nothing) means
 *     "no findings", not a parse error. Only a response that fails a structural
 *     expectation is an error.
 * 20. Responses from different tools are stamped with the same `dataVersion`.
 *     If they are not, the merged report is marked `MCP_PARSE_ERROR` with
 *     `details.reason = 'data-version-skew'`, because coverage percentages from
 *     one graph revision cannot be compared with validation output from
 *     another.
 *
 * Test list for `--mode=replay` (names only; assertions are the implementer's):
 *
 *   'returns COVERAGE_VERIFY_UNDER_THRESHOLD for a spec below the verify bar'
 *   'returns no failures for a transcript whose numbers clear every threshold'
 *   'treats (none) as an empty array rather than a missing scope'
 *   'rejects a scope key with no slash as MCP_PARSE_ERROR'
 *   'preserves a trailing space inside a quoted requirement UID'
 *   'classifies a wrapped validation entry as a single issue'
 *   'raises MCP_PARSE_ERROR when Validation counts exceed parsed entries'
 *   'raises MCP_PARSE_ERROR when a percentage is NaN'
 *   'raises MCP_PARSE_ERROR when the status block is truncated mid-line'
 *   'raises MCP_PARSE_ERROR when two tool responses carry different dataVersions'
 *   'ignores the Hints line when computing coverage failures'
 *   'is byte-stable across repeated runs when scope order is shuffled'
 *   'exits 1 without writing to stdout when --quiet and --report-out=stdout'
 *   'writes a report even when the parse fails, with MCP_PARSE_ERROR inside it'
 *   'accepts a config with only minVerifyPercent overridden and defaults the rest'
 *   'rejects an unknown flag rather than ignoring it'
 */
