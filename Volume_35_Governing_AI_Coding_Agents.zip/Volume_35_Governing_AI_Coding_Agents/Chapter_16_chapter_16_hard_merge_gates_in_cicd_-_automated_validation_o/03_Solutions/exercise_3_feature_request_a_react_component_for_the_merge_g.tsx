/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_a_react_component_for_the_merge_g.tsx
Description: Solutions and Explanations
==========================================
*/

/**
 * ui/src/features/merge-gate/MergeGateStatusPanel.tsx
 *
 * A pure view over one NormalizedCoverageReport. It does not fetch, poll, cache,
 * or recompute percentages. The `report` prop is the entire state; the only
 * internal state is which failure badge is expanded, which is presentation, not
 * data.
 *
 * NOTE ON THE DELIVERABLE: the exercise asks for a specification, not an
 * implementation. The code below is the minimum realisation of that
 * specification — enough for the type checker and the tests to be written
 * against a real contract, with every deliberate omission marked `SPEC:`.
 */

import { useId, useState } from 'react';
import type {
  GateFailure,
  GateFailureCode,
  NormalizedCoverageReport,
  SpecCoverage,
} from '../../../packages/gate-runner/src/protocol';
import css from './MergeGateStatusPanel.module.css';

export type MergeGateDensity = 'compact' | 'comfortable';

export interface MergeGateStatusPanelProps {
  readonly report: NormalizedCoverageReport;
  readonly onRefresh?: () => void;
  readonly density?: MergeGateDensity;
  /** Composes every data-testid as `${testIdPrefix}-...`. */
  readonly testIdPrefix?: string;
  /** Overrides the default timestamp formatter; the default is locale-sensitive. */
  readonly formatTimestamp?: (iso: string) => string;
}

/**
 * The rendering order of failure codes. Declared, not derived, so that adding a
 * code to the union in Exercise 2 fails the build here until it is given a
 * position — a deliberate tripwire, because a new failure mode that renders
 * somewhere unpredictable is a new failure mode reviewers will miss.
 */
const FAILURE_CODE_ORDER: readonly GateFailureCode[] = [
  'UNKNOWN_REQUIREMENT_REFERENCE',
  'MCP_PARSE_ERROR',
  'COVERAGE_IMPL_UNDER_THRESHOLD',
  'COVERAGE_VERIFY_UNDER_THRESHOLD',
  'STALE_BUDGET_EXCEEDED',
  'VALIDATION_WARNINGS_DENIED',
];

const FAILURE_CODE_LABEL: Readonly<Record<GateFailureCode, string>> = {
  UNKNOWN_REQUIREMENT_REFERENCE: 'Unknown reference',
  MCP_PARSE_ERROR: 'Report unreadable',
  COVERAGE_IMPL_UNDER_THRESHOLD: 'Impl coverage',
  COVERAGE_VERIFY_UNDER_THRESHOLD: 'Verify coverage',
  STALE_BUDGET_EXCEEDED: 'Stale refs',
  VALIDATION_WARNINGS_DENIED: 'Warnings denied',
};

/**
 * The UI-layer grouping. If a future product decision wants "quality issues" to
 * collapse two codes into one badge, the mapping goes HERE — never by widening
 * the union in Exercise 2, which would destroy the CLI's stable keys.
 */
const BADGE_GROUPING: Readonly<Record<GateFailureCode, string>> = {
  UNKNOWN_REQUIREMENT_REFERENCE: 'correctness',
  MCP_PARSE_ERROR: 'correctness',
  COVERAGE_IMPL_UNDER_THRESHOLD: 'coverage',
  COVERAGE_VERIFY_UNDER_THRESHOLD: 'coverage',
  STALE_BUDGET_EXCEEDED: 'freshness',
  VALIDATION_WARNINGS_DENIED: 'freshness',
};

function groupFailuresByCode(
  failures: readonly GateFailure[],
): ReadonlyMap<GateFailureCode, readonly GateFailure[]> {
  const grouped = new Map<GateFailureCode, GateFailure[]>();
  for (const failure of failures) {
    const bucket = grouped.get(failure.code);
    if (bucket === undefined) grouped.set(failure.code, [failure]);
    else bucket.push(failure);
  }
  return grouped;
}

/** Clamped for the bar; the exact unrounded value is what the label shows. */
function clampPercent(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.min(100, Math.max(0, value));
}

function formatPercent(value: number): string {
  return Number.isFinite(value) ? `${value.toFixed(1)}%` : '—';
}

function defaultFormatTimestamp(iso: string): string {
  // Not `toLocaleString` without an explicit locale: the same report must not
  // render differently on two machines that share a snapshot in a bug report.
  return new Date(iso).toISOString().replace('T', ' ').replace('Z', ' UTC');
}

export function MergeGateStatusPanel(
  props: MergeGateStatusPanelProps,
): JSX.Element {
  const {
    report,
    onRefresh,
    density = 'comfortable',
    testIdPrefix = 'merge-gate',
    formatTimestamp = defaultFormatTimestamp,
  } = props;

  const [expandedCode, setExpandedCode] = useState<GateFailureCode | null>(null);
  const detailIdBase = useId();

  const grouped = groupFailuresByCode(report.failures);
  const status = report.failures.length === 0 ? 'pass' : 'fail';

  return (
    <section
      className={`${css.panel} ${density === 'compact' ? css.compact : css.comfortable}`}
      data-testid={`${testIdPrefix}-panel`}
      data-status={status}
    >
      <header className={css.header}>
        <span
          className={status === 'pass' ? css.statusPass : css.statusFail}
          data-testid={`${testIdPrefix}-status`}
          aria-hidden="true"
        >
          {status === 'pass' ? 'PASS' : 'FAIL'}
        </span>
        <span className={css.visuallyHidden} role="status">
          {status === 'pass'
            ? 'Merge gate is passing.'
            : `Merge gate is failing with ${report.failures.length} problem(s).`}
        </span>

        <time className={css.timestamp} dateTime={report.generatedAt}>
          {formatTimestamp(report.generatedAt)}
        </time>

        {onRefresh !== undefined && (
          <button
            type="button"
            className={css.refreshButton}
            onClick={onRefresh}
            data-testid={`${testIdPrefix}-refresh`}
          >
            Refresh
          </button>
        )}
      </header>

      {report.failures.length === 0 ? (
        <p className={css.emptyState} data-testid={`${testIdPrefix}-empty`}>
          No gate failures recorded in this report.
        </p>
      ) : (
        <ul className={css.failureList} data-testid={`${testIdPrefix}-failures`}>
          {FAILURE_CODE_ORDER.filter((code) => grouped.has(code)).map((code) => {
            const bucket = grouped.get(code) as readonly GateFailure[];
            const isExpanded = expandedCode === code;
            const detailId = `${detailIdBase}-${code}`;

            return (
              <li key={code} className={css.failureItem}>
                {/* A real <button>, not role="button": free keyboard support,
                    free focus management, free Enter/Space handling. */}
                <button
                  type="button"
                  className={`${css.failureBadge} ${isExpanded ? css.failureBadgeExpanded : ''}`}
                  aria-expanded={isExpanded}
                  aria-controls={detailId}
                  data-testid={`${testIdPrefix}-badge-${code}`}
                  data-group={BADGE_GROUPING[code]}
                  onClick={() => setExpandedCode(isExpanded ? null : code)}
                >
                  {FAILURE_CODE_LABEL[code]}
                  <span className={css.badgeCount}>{bucket.length}</span>
                </button>

                {isExpanded && (
                  <div
                    id={detailId}
                    className={css.failureDetails}
                    data-testid={`${testIdPrefix}-details-${code}`}
                  >
                    <code className={css.failureDetailsCode}>{code}</code>
                    <ul>
                      {bucket.map((failure, index) => (
                        <li key={`${code}-${index}`}>
                          {failure.message}
                          {failure.details !== undefined && (
                            <pre className={css.failureDetailsPayload}>
                              {JSON.stringify(failure.details, null, 2)}
                            </pre>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}

      <table className={css.specTable} data-testid={`${testIdPrefix}-specs`}>
        <caption className={css.visuallyHidden}>
          Implementation and verification coverage per spec
        </caption>
        <thead>
          <tr>
            <th scope="col">Spec</th>
            <th scope="col">Implementation</th>
            <th scope="col">Verification</th>
          </tr>
        </thead>
        <tbody>
          {report.specs.length === 0 ? (
            <tr>
              <td colSpan={3} className={css.emptyState}>
                No specs configured.
              </td>
            </tr>
          ) : (
            report.specs.map((spec: SpecCoverage) => (
              <tr key={spec.specImpl} data-testid={`${testIdPrefix}-spec-${spec.specImpl}`}>
                <td className={css.specName}>{spec.specImpl}</td>
                <CoverageCell
                  testIdPrefix={testIdPrefix}
                  specImpl={spec.specImpl}
                  kind="impl"
                  percent={spec.implPercent}
                  requirementCount={spec.requirementCount}
                />
                <CoverageCell
                  testIdPrefix={testIdPrefix}
                  specImpl={spec.specImpl}
                  kind="verify"
                  percent={spec.verifyPercent}
                  requirementCount={spec.requirementCount}
                />
              </tr>
            ))
          )}
        </tbody>
      </table>

      {report.validation.warningCount > 0 && (
        <p className={css.validationSummary} data-testid={`${testIdPrefix}-warnings`}>
          {report.validation.errorCount} error(s), {report.validation.warningCount} warning(s)
        </p>
      )}
    </section>
  );
}

interface CoverageCellProps {
  readonly testIdPrefix: string;
  readonly specImpl: string;
  readonly kind: 'impl' | 'verify';
  readonly percent: number;
  /** Present only when the producer could compute a denominator. */
  readonly requirementCount: number | undefined;
}

function CoverageCell(props: CoverageCellProps): JSX.Element {
  const { testIdPrefix, specImpl, kind, percent, requirementCount } = props;

  // A percentage without a denominator cannot distinguish "0 of 0" from "0 of
  // 12". When the count is known and zero we say so; when it is unknown we
  // render the number but flag the ambiguity rather than inventing a meaning.
  const isVacuous = requirementCount === 0;
  const isUnavailable = !Number.isFinite(percent);

  return (
    <td className={css.coverageCell} data-testid={`${testIdPrefix}-${kind}-${specImpl}`}>
      {isVacuous ? (
        <span className={css.coverageNa}>n/a (no requirements)</span>
      ) : isUnavailable ? (
        <span className={css.coverageNa}>—</span>
      ) : (
        <>
          <progress
            className={css.coverageBar}
            value={clampPercent(percent)}
            max={100}
            aria-label={`${kind === 'impl' ? 'Implementation' : 'Verification'} coverage for ${specImpl}`}
            data-testid={`${testIdPrefix}-bar-${kind}-${specImpl}`}
          />
          <span
            className={css.coverageLabel}
            title={`${percent}% (${clampPercent(percent)}% shown on the bar)`}
          >
            {formatPercent(percent)}
          </span>
        </>
      )}
    </td>
  );
}

// ---------------------------------------------------------------------------
// CSS module inventory: ui/src/features/merge-gate/MergeGateStatusPanel.module.css
// ---------------------------------------------------------------------------
//
//  .panel                 Root wrapper; establishes the panel's border, radius and
//                         stacking context so nested badges cannot escape it.
//  .header                Flex row holding the status indicator, timestamp and
//                         refresh control; wraps at narrow widths.
//  .statusPass            Colour treatment for the overall pass indicator, driven
//                         only by report.failures.length.
//  .statusFail            Colour treatment for the overall fail indicator.
//  .timestamp             Muted, tabular-numerals time stamp so snapshots line up.
//  .refreshButton         Explicit refresh control; owns the 44px minimum hit area.
//  .failureList           Vertical list of failure badges and their detail panels.
//  .failureItem           One badge plus its optional detail panel.
//  .failureBadge          The per-code <button>; enforces min-block-size 44px even
//                         in compact density, so the touch target never shrinks.
//  .failureBadgeExpanded  Pressed/expanded visual state for the badge.
//  .badgeCount            Small count chip inside the badge, tabular numerals.
//  .failureDetails        Expandable region; visually subordinate to the badge.
//  .failureDetailsCode    Monospace rendering of the stable GateFailureCode.
//  .failureDetailsPayload Monospace <pre> for the raw `details` object.
//  .specTable             The spec health table; fixed layout so columns do not
//                         jump between reports.
//  .specName              Monospace "spec/impl" label.
//  .coverageCell          One cell containing a progress bar plus its exact label.
//  .coverageBar           Styling for the native <progress> element.
//  .coverageLabel         The exact percentage text; tabular numerals.
//  .coverageNa            The "—" / "n/a" rendering for unknown or vacuous values.
//  .validationSummary     Footer line summarising error and warning counts.
//  .emptyState            Neutral text for a legitimately empty region.
//  .compact               Density modifier; reduces padding but preserves hit areas.
//  .comfortable           Default density modifier.
//  .visuallyHidden        Screen-reader-only helper for the status announcement.
//
// Representative rules that encode the two non-obvious decisions:
//
//  .failureBadge {
//    min-block-size: 44px;   /* touch target never shrinks, even in compact */
//    min-inline-size: 44px;
//  }
//  .compact .failureBadge {
//    padding-block: 2px;     /* visual density changes, hit area does not */
//    padding-inline: 6px;
//  }
