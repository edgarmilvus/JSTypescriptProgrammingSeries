/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_interactive_challenge_offline_validation_of_a_tra.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * docs/challenges/gate-transcript-analysis.md (delivered as an artifact here so
 * that the prose and the executable evaluation live in one reviewable unit).
 *
 * The first half of this file is the typed transcript: the raw text is encoded
 * as data so the gate evaluation is executable rather than argued. The second
 * half is the analysis document itself.
 */

import {
  type GatePolicy,
  type NormalizedCoverageReport,
  type SpecCoverage,
  type ValidationIssue,
  type ValidationSummary,
} from '../../packages/gate-runner/src/protocol';
import { evaluatePolicy } from '../../packages/gate-runner/src/policy';

// ---------------------------------------------------------------------------
// The transcript, as data. UIDs are reproduced verbatim and never normalised.
// ---------------------------------------------------------------------------

export const RAW_TRANSCRIPTS = {
  tracey_status: `Status: configured 2 spec(s)
  - payments/typescript  impl 78.6%  verify 42.9%
  - gateway/typescript   impl 100.0% verify 100.0%
Delta since last query: coverage +3.2 ppt (impl), -1.4 ppt (verify)
Hints: 4 requirement(s) uncovered. Run tracey_uncovered.`,

  tracey_uncovered: `Spec/Impl: payments/typescript
  PAY-settlement-003  Idempotent settlement — no impl reference
  PAY-ledger-007      Currency pinning on every entry — no impl reference
  PAY-retry-002       Exponential backoff with hard cap — no impl reference
  PAY-replay-004      Replay protection — no impl reference
Spec/Impl: gateway/typescript
  (none)`,

  tracey_untested: `Spec/Impl: payments/typescript
  PAY-settlement-003
  PAY-ledger-007
  PAY-retry-002
  PAY-replay-004
  PAY-settlement-001
Spec/Impl: gateway/typescript
  (none)`,

  tracey_stale: `Spec/Impl: payments/typescript
  PAY-settlement-001  reference at v1, spec at v3
Spec/Impl: gateway/typescript
  (none)`,

  tracey_validate: `Validation: 1 error(s), 2 warning(s)
Errors:
  - Unknown requirement reference 'PAY-settlement-003 ' (trailing space)
    at src/payments/ledger.ts:118
Warnings:
  - Stale reference 'PAY-settlement-001' at src/payments/settlement.ts:44
  - Impl annotation in a test file 'tests/payments.spec.ts:9'
    (grammar: 'r[impl PAY-ledger-007]' declared but file is test_include)`,
} as const;

// ---------------------------------------------------------------------------
// The typed report assembled from the transcript, using the interfaces from
// Exercise 2. This is the input the policy evaluates.
// ---------------------------------------------------------------------------

export const TRANSCRIPT_REPORT: NormalizedCoverageReport = {
  generatedAt: '2026-09-16T00:00:00Z',
  dataVersion: 'unavailable-in-transcript',
  decision: 'fail',
  policy: {
    minImplPercent: 75,
    minVerifyPercent: 75,
    maxStaleReferences: 0,
    denyWarnings: true,
  },
  specs: [
    {
      specImpl: 'payments/typescript',
      implPercent: 78.6,
      verifyPercent: 42.9,
      uncoveredRequirementUids: [
        'PAY-settlement-003',
        'PAY-ledger-007',
        'PAY-retry-002',
        'PAY-replay-004',
      ],
      untestedRequirementUids: [
        'PAY-settlement-003',
        'PAY-ledger-007',
        'PAY-retry-002',
        'PAY-replay-004',
        'PAY-settlement-001',
      ],
      staleRequirementUids: ['PAY-settlement-001'],
    },
    {
      specImpl: 'gateway/typescript',
      implPercent: 100.0,
      verifyPercent: 100.0,
      uncoveredRequirementUids: [],
      untestedRequirementUids: [],
      staleRequirementUids: [],
    },
  ],
  validation: {
    errorCount: 1,
    warningCount: 2,
    errors: [
      {
        kind: 'unknown-requirement-reference',
        requirementUid: 'PAY-settlement-003 ', // trailing space preserved
        location: 'src/payments/ledger.ts:118',
        raw: "Unknown requirement reference 'PAY-settlement-003 ' (trailing space)",
      },
    ],
    warnings: [
      {
        kind: 'stale-reference',
        requirementUid: 'PAY-settlement-001',
        location: 'src/payments/settlement.ts:44',
        raw: "Stale reference 'PAY-settlement-001' at src/payments/settlement.ts:44",
      },
      {
        kind: 'impl-in-test-file',
        requirementUid: 'PAY-ledger-007',
        location: 'tests/payments.spec.ts:9',
        raw: "Impl annotation in a test file 'tests/payments.spec.ts:9'",
      },
    ],
  },
  failures: [], // filled below by evaluatePolicy, deliberately not hand-written
};

// ---------------------------------------------------------------------------
// Q1, executable: run the gate against the transcript under the stated policy.
// ---------------------------------------------------------------------------

export function evaluateTranscriptGate(
  policy: GatePolicy,
): ReturnType<typeof evaluatePolicy> {
  return evaluatePolicy({ ...TRANSCRIPT_REPORT, policy }, policy);
}

/**
 * Observed result under the stated policy
 * (minImpl 75, minVerify 75, maxStale 0, denyWarnings true):
 *
 * [
 *   { code: 'COVERAGE_VERIFY_UNDER_THRESHOLD',  details: { actual: 42.9, required: 75 } },
 *   { code: 'STALE_BUDGET_EXCEEDED',            details: { 1 stale > budget 0 } },
 *   { code: 'VALIDATION_WARNINGS_DENIED',       details: { warningCount: 2 } },
 *   { code: 'UNKNOWN_REQUIREMENT_REFERENCE',    details: { requirementUid: 'PAY-settlement-003 ' } },
 * ]
 *
 * Four codes fire. Two do not:
 *   - COVERAGE_IMPL_UNDER_THRESHOLD: payments impl is 78.6% >= 75%.
 *   - MCP_PARSE_ERROR: all five responses parsed and the declared validation
 *     counts match the parsed entries, so the report is structurally sound.
 *
 * The decision is 'fail'. Note that three of the four failures are independent:
 * fixing the verification coverage would still leave the gate red on staleness
 * and on the denied warnings.
 */

// ---------------------------------------------------------------------------
// The analysis document. This is the content of
// docs/challenges/gate-transcript-analysis.md.
// ---------------------------------------------------------------------------

/**
 * ## Q1
 *
 * The gate fails, and it fails for four independent reasons. Implementation
 * coverage clears the bar — `payments/typescript  impl 78.6%` against a
 * required 75% — so `COVERAGE_IMPL_UNDER_THRESHOLD` does NOT fire. Verification
 * coverage does not: `verify 42.9%` against a required 75% fires
 * `COVERAGE_VERIFY_UNDER_THRESHOLD`, and the offending UIDs are the five listed
 * under `Spec/Impl: payments/typescript` in the untested output. Staleness fires
 * `STALE_BUDGET_EXCEEDED`, because the budget is zero and the stale output
 * contains one entry. Warnings fire `VALIDATION_WARNINGS_DENIED`, because
 * `denyWarnings` is true and the validation output declares two warnings.
 * Finally, `UNKNOWN_REQUIREMENT_REFERENCE` fires: the validation output reports
 * one hard error, and an error is fatal independently of the warning policy,
 * because an annotation that names a requirement the spec does not contain
 * invalidates every coverage number derived from that annotation. Only
 * `MCP_PARSE_ERROR` does not fire, and it does not fire because the declared
 * counts are internally consistent with the parsed entries: one error, two
 * warnings, three bullets.
 *
 * The subtlety worth recording is that the failing checks cannot all be
 * repaired by the same action. Raising verification coverage would not touch
 * the stale reference. Bumping the stale annotation would not touch the
 * warnings. Only the unknown reference is arguably a subset of the warnings
 * story, and even then its fix lives in a different file.
 *
 * > `Validation: 1 error(s), 2 warning(s)`
 *
 * > `  - payments/typescript  impl 78.6%  verify 42.9%`
 *
 * ## Q2
 *
 * Everything inside the brackets is semantic; everything after the closing
 * bracket is comment. Tracey's annotating-code reference is explicit that text
 * following the closing bracket is ignored by the parser — `// r[impl
 * PAY-settlement-003]: handled here` parses identically to the bare form. The
 * content between the brackets, by contrast, is tokenised into a verb and a
 * requirement identifier, and the identifier is matched against the spec's UIDs
 * exactly, case included. A trailing space inside the brackets therefore becomes
 * part of the identifier: the parser looks for a requirement whose UID is the
 * five-character-suffix string `PAY-settlement-003 ` and finds none. The same
 * rule that makes `CH-001` and `ch-001` distinct UIDs — UID case is preserved
 * end to end — makes `PAY-settlement-003` and `PAY-settlement-003 ` distinct
 * identifiers.
 *
 * The fix belongs in the source file, at `src/payments/ledger.ts:118`, not in
 * the spec. The spec UID is correct; the annotation is malformed. Editing the
 * spec to add the trailing space would be catastrophic: it would create a
 * second, space-suffixed UID, break every other correct annotation for that
 * requirement, and enshrine a typo as normative text. The repair is to strip
 * the whitespace inside the brackets and re-run the gate.
 *
 * > `  - Unknown requirement reference 'PAY-settlement-003 ' (trailing space)`
 *
 * ## Q3
 *
 * Staleness is a property of a reference that EXISTS. Untested-ness is a
 * property of a reference that is ABSENT. A requirement can therefore be both
 * stale and untested with no contradiction: it has at least one implementation
 * annotation, that annotation names an old version of the rule, and it has no
 * verification annotation at all. `PAY-settlement-001` is exactly this case. It
 * appears in the stale output because some annotation points at version 1 of a
 * rule that is now at version 3, and it appears in the untested output because
 * nothing verifies it. Staleness does not imply untested-ness for the same
 * reason: a requirement with a stale implementation reference and a current
 * verification reference would be stale and tested.
 *
 * Fixing only the verification side changes one thing. Adding
 * `// r[verify PAY-settlement-001+3]` removes `PAY-settlement-001` from the
 * untested list and raises the verification percentage, but the stale
 * implementation reference at `src/payments/settlement.ts:44` remains, so the
 * requirement stays in the stale output and `STALE_BUDGET_EXCEEDED` still
 * fires. Tracey's versioning documentation is emphatic about the order of
 * operations: update the implementation to match the new rule text first, and
 * only then bump the annotation. A verification annotation bumped in isolation
 * is a claim about a rule version that nobody has re-checked.
 *
 * There is a third consequence worth flagging, because it is the seam where the
 * gate can silently lie. Stale requirements are not counted as covered, so
 * `PAY-settlement-001` is neither in the uncovered list nor in the covered
 * count. The uncovered list answers "which requirements lack an implementation
 * reference?", not "which requirements lack a CURRENT implementation
 * reference?". A gate that consults only the uncovered list would miss this
 * requirement entirely, which is why the stale list and its budget are part of
 * the policy rather than an advisory footnote.
 *
 * > `  PAY-settlement-001  reference at v1, spec at v3`
 *
 * ## Q4
 *
 * `gateway/typescript` is consistent with any non-negative integer count of
 * requirements. Every Tracey coverage figure is a ratio, and a ratio over an
 * empty denominator is vacuously satisfied: a spec with zero requirements
 * reports 100% implementation coverage and 100% verification coverage because
 * there is no requirement that fails to be covered. So the range is
 * `N in {0, 1, 2, 3, ...}` — a half-open range bounded below by zero and
 * unbounded above. The minimum plausible value is zero, and the transcript
 * gives us nothing that would exclude it: `Spec/Impl: gateway/typescript`
 * followed by `(none)` is emitted for a configured spec/impl pair whether that
 * pair contains zero requirements or twenty fully covered ones.
 *
 * Two refinements sharpen the answer. First, `100.0%` is a rounded display of
 * anything in `[99.95, 100.0]`, so even a non-zero count does not strictly
 * imply zero uncovered requirements — one uncovered requirement out of two
 * thousand would round to `100.0%`. Second, this is a genuine gate blind spot
 * rather than a curiosity: if `N` is zero, the 75% threshold is trivially
 * satisfied and the spec is effectively unmonitored while reporting perfect
 * health. That is the argument for a `minRequirementCount` field on the policy,
 * which the current four-field gate does not have.
 *
 * The question is a trick because "how many requirements could it contain?" has
 * no upper bound and a vacuous lower bound. The honest answer is a range plus a
 * recommendation, not a number.
 *
 * > `  - gateway/typescript   impl 100.0% verify 100.0%`
 *
 * ## Q5
 *
 * `test_include` designates files that may only carry `verify` annotations. Its
 * semantic purpose is to keep the two halves of the coverage metric measuring
 * different things: `impl` means "production code satisfies this requirement",
 * `verify` means "a test exercises this requirement". A file matched by
 * `test_include` is declaring that it contains no production code, so an `impl`
 * annotation inside it is a category error, and Tracey treats it as a hard
 * error rather than a warning.
 *
 * The bug class this prevents is false-positive implementation coverage. If
 * `impl` annotations were permitted in test files, a requirement could reach
 * 100% implementation coverage while no production code implements it — the
 * test merely mentions it. The gate would go green on a feature that does not
 * exist, which is the single worst failure mode a merge gate can have, because
 * it manufactures confidence in exactly the situation that needs scrutiny.
 *
 * Moving `tests/payments.spec.ts` out of `test_include` would silence the
 * warning while making the underlying problem worse in three ways. It would
 * legitimise the misplaced annotation, so `PAY-ledger-007` would begin counting
 * toward implementation coverage from a test file rather than from `src/`. It
 * would remove the check that catches the next contributor who makes the same
 * mistake, since the file would no longer be special-cased. And it would erase
 * the evidence that someone believed currency pinning was implemented somewhere
 * other than the ledger source — which, given that `PAY-ledger-007` is also
 * listed as uncovered, is very likely a real gap that the annotation was
 * masking.
 *
 * The correct fix is to change the verb in the test file from `impl` to
 * `verify`, or, if the requirement genuinely has no implementation yet, to
 * delete the annotation and let the requirement stay uncovered so the gate
 * fails for the right reason.
 *
 * > `  - Impl annotation in a test file 'tests/payments.spec.ts:9'`
 *
 * ## Q6
 *
 * The delta is not verifiable from this transcript. `Delta since last query` is
 * computed relative to the previous query in the same daemon session, and this
 * transcript contains exactly one `tracey_status` response. The baseline it
 * refers to is a query we cannot see, so there is nothing in the transcript to
 * compare against. All we can do is state what the baseline would have to have
 * been for the delta to be arithmetically consistent: implementation coverage
 * of `78.6 - 3.2 = 75.4` percent and verification coverage of
 * `42.9 + 1.4 = 44.3` percent at the previous query. Nothing in the transcript
 * confirms or refutes either number.
 *
 * A second, deeper problem is that the percentages do not cleanly reconstruct
 * into integer counts under a single consistent model, which means even a
 * correct baseline would not be sufficient to verify the delta. Attempting the
 * reconstruction: the uncovered list gives payments four requirements without
 * any implementation reference, and the stale list gives one requirement with
 * only a stale implementation reference, which by the versioning rules is not
 * counted as covered. If the numerator is therefore `N - 5` and the denominator
 * is `N`, then `(N - 5) / N = 0.786` requires `N` approximately equal to 23.36
 * — not an integer, and no nearby integer produces a figure that rounds to
 * `78.6`. Either the percentages are not requirement-count ratios, or the lists
 * come from a different snapshot than the percentage, or both. The transcript
 * cannot tell us which.
 *
 * What a deterministic verification would require is: the previous snapshot's
 * raw counts and percentages, the daemon's data version before and after, the
 * file-change set that triggered the rebuild, and an explicit statement of the
 * denominator the percentage is computed over. The most useful single addition
 * is the data version pair, because the delta's meaning depends entirely on
 * whether the two observations describe the same graph revision.
 *
 * A concrete engineering consequence: the local `gate-runner` client must
 * record the `dataVersion` of every report it writes. Without it, two reports
 * that disagree cannot be ordered, only argued about.
 *
 * > `Delta since last query: coverage +3.2 ppt (impl), -1.4 ppt (verify)`
 *
 * ## Q7
 *
 * The single call that would most reduce the ambiguity is a new tool,
 * `tracey_gate`, which returns a normalized, decision-ready report instead of
 * five human-readable ones.
 *
 * Input shape:
 *
 *     { method: "tracey_gate",
 *       params: {
 *         policy: { minImplPercent, minVerifyPercent,
 *                   maxStaleReferences, denyWarnings },
 *         minRequirementCount: number,
 *         specImpl: string | null
 *       } }
 *
 * Output shape (pseudocode, not real JSON):
 *
 *     GateReport {
 *       dataVersion: string
 *       generatedAt: string
 *       decision: "pass" | "fail"
 *       specs: [ SpecSnapshot {
 *         specImpl: string
 *         requirementCount: int
 *         implCoveredCount: int
 *         verifyCoveredCount: int
 *         implPercent: float
 *         verifyPercent: float
 *         uncoveredUids: [UID]
 *         untestedUids: [UID]
 *         staleUids: [UID]
 *       } ]
 *       validation: { errorCount: int, warningCount: int,
 *                     entries: [ { kind, uid, location } ] }
 *       failures: [ { code, message, details } ]
 *     }
 *
 * Implementation: it is a single read-locked pass over the daemon's existing
 * in-memory coverage and validation state — the same state the five existing
 * query paths already read — assembled under one data version and one timestamp
 * so that no sub-query can observe a rebuild that another does not.
 *
 * Why this and not `tracey_rule PAY-settlement-001`. `tracey_rule` is the best
 * existing tool for Q2 and Q3 in isolation: it returns the requirement's current
 * text, its version history, and every reference pointing at it, which would
 * settle whether `PAY-settlement-001` has a verification annotation anywhere and
 * what the version-3 text actually says. But it cannot address Q1's composite
 * verdict, Q4's denominator problem, or Q6's snapshot problem, because those are
 * cross-spec and cross-response properties. By collapsing five round-trips into
 * one stamped object, `tracey_gate` removes the parsing ambiguity that the
 * Exercise 2 client exists to paper over, removes the snapshot skew that
 * invalidates the delta, and exposes the raw counts that make the empty-spec
 * blind spot in Q4 detectable rather than invisible.
 *
 * > `Hints: 4 requirement(s) uncovered. Run tracey_uncovered.`
 *
 * Note the last ambiguity this resolves: the hints line asserts a count of four
 * uncovered requirements, and the `tracey_uncovered` output does list four. They
 * agree here, but nothing in the protocol guarantees that they are derived from
 * the same snapshot, because they come from two separate tool calls against a
 * daemon that rebuilds on filesystem changes. A single stamped call makes
 * agreement structural instead of accidental.
 */
export const GATE_TRANSCRIPT_ANALYSIS_MD = 'see docs/challenges/gate-transcript-analysis.md';
