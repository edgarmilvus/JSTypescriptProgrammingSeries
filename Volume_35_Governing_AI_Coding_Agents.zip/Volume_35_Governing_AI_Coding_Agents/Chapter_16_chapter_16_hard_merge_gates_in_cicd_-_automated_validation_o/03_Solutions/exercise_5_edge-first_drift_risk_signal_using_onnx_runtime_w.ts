/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_edge-first_drift_risk_signal_using_onnx_runtime_w.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * ui/src/features/merge-gate/drift-risk/types.ts
 *
 * Advisory-only types. Nothing in this module is imported by the gate decision
 * path; the compiler will let you, the reviewer will not.
 */

import type { NormalizedCoverageReport } from '../../../../../packages/gate-runner/src/protocol';

/**
 * Everything the feature extractor needs that is not already in the coverage
 * report.
 *
 * Two fields beyond the four the exercise mandates, both justified:
 *
 *   - `modifiedSpecFiles` is required by feature 3 ("fraction of requirements
 *     whose spec text was modified since the last green build"). Deriving it
 *     from `modifiedSourceFiles` would silently under-count, because spec files
 *     are not source files under any glob in the Tracey config.
 *   - `specContributors24h` is required by feature 10. Without it, feature 10
 *     would be a permanent constant zero, and a permanently-zero input is worse
 *     than a declared default: the model would learn nothing from it while the
 *     UI implied it was being considered.
 */
export interface WorkingTreeContext {
  readonly lastGreenBuildAt: string; // ISO 8601
  readonly modifiedSourceFiles: readonly string[];
  readonly modifiedTestFiles: readonly string[];
  readonly reviewCommentCount: number;
  readonly modifiedSpecFiles: readonly string[];
  readonly specContributors24h: number;
}

export type DriftRiskLabel = 'LOW' | 'MEDIUM' | 'HIGH';

export type DriftRiskUnavailableReason =
  | 'model-load-failed'
  | 'schema-mismatch'
  | 'empty-report'
  | 'input-out-of-range';

/**
 * An interface rather than a discriminated union, because the panel renders the
 * same three regions in both states and only the badge text differs. The cost is
 * that `score` is optional; the benefit is that consumers do not need a type
 * guard at every use site.
 */
export interface DriftRiskState {
  readonly status: 'idle' | 'loading' | 'available' | 'unavailable';
  readonly score: DriftRiskScore | null;
  readonly unavailableReason: DriftRiskUnavailableReason | null;
}

export interface DriftRiskScore {
  readonly label: DriftRiskLabel;
  readonly confidence: number; // max class probability
  readonly probabilities: Readonly<Record<DriftRiskLabel, number>>;
  readonly schemaVersion: number;
}

// ---------------------------------------------------------------------------
// Feature vector
// ---------------------------------------------------------------------------

/**
 * Bump when the MEANING of any feature changes, not when a feature value
 * changes. The model's metadata carries the version it was trained against; a
 * mismatch disables the panel rather than producing a plausible wrong number.
 */
export const DRIFT_FEATURE_SCHEMA_VERSION = 3;

export const DRIFT_FEATURE_COUNT = 12;

/**
 * Input length is 2x the feature count. The duplication exists purely for
 * forward compatibility: the input tensor shape never changes, so a future
 * schema can widen the feature set without a model-shape break. Features 0..11
 * are authoritative; 12..23 mirror them.
 */
export const DRIFT_INPUT_LENGTH = DRIFT_FEATURE_COUNT * 2;

function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.min(1, Math.max(0, value));
}

function fraction(part: number, whole: number): number {
  if (whole <= 0) return 0;
  return clamp01(part / whole);
}

/**
 * Feature definitions, one line each, in the order the model was trained on.
 *
 *  0. fraction of requirements with at least one impl reference
 *  1. fraction of requirements with at least one verify reference
 *  2. fraction of requirements whose spec text changed since the last green build
 *  3. fraction of requirements with at least one stale reference
 *  4. validation warnings, normalised by 20 and clamped
 *  5. validation errors, normalised by 5 and clamped
 *  6. fraction of implementation files changed since the last green build
 *  7. fraction of test files changed since the last green build
 *  8. elapsed time since the last green build, normalised by 86400s
 *  9. contributors to the spec directory in the last 24h, normalised by 10
 * 10. unresolved review comments, normalised by 20
 * 11. constant bias term, 1.0
 */
export function buildFeatureVector(
  report: NormalizedCoverageReport,
  context: WorkingTreeContext,
): Float32Array {
  const requirementCount = report.specs.reduce(
    (sum, spec) => sum + (spec.requirementCount ?? 0),
    0,
  );

  const uncovered = report.specs.reduce(
    (sum, spec) => sum + spec.uncoveredRequirementUids.length,
    0,
  );
  const untested = report.specs.reduce(
    (sum, spec) => sum + spec.untestedRequirementUids.length,
    0,
  );
  const stale = report.specs.reduce(
    (sum, spec) => sum + spec.staleRequirementUids.length,
    0,
  );

  const elapsedSeconds =
    (Date.now() - new Date(context.lastGreenBuildAt).getTime()) / 1000;

  const features: readonly number[] = [
    fraction(requirementCount - uncovered, requirementCount),
    fraction(requirementCount - untested, requirementCount),
    fraction(context.modifiedSpecFiles.length, Math.max(requirementCount, 1)),
    fraction(stale, Math.max(requirementCount, 1)),
    clamp01(report.validation.warningCount / 20),
    clamp01(report.validation.errorCount / 5),
    clamp01(context.modifiedSourceFiles.length / 20),
    clamp01(context.modifiedTestFiles.length / 10),
    clamp01(elapsedSeconds / 86_400),
    clamp01(context.specContributors24h / 10),
    clamp01(context.reviewCommentCount / 20),
    1.0, // bias
  ];

  // Duplicate for forward compatibility; shape is fixed for the model's life.
  const vector = new Float32Array(DRIFT_INPUT_LENGTH);
  for (let i = 0; i < DRIFT_FEATURE_COUNT; i += 1) {
    vector[i] = features[i] as number;
    vector[i + DRIFT_FEATURE_COUNT] = features[i] as number;
  }

  // Invariant: the model must never receive a non-finite value. A NaN here is
  // a bug in a feature definition, and clamping it to 0 would hide it.
  for (let i = 0; i < DRIFT_INPUT_LENGTH; i += 1) {
    if (!Number.isFinite(vector[i] as number)) {
      throw new Error(`drift-risk: non-finite feature at index ${i}`);
    }
  }

  return vector;
}
