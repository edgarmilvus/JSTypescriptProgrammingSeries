/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_edge-first_drift_risk_signal_using_onnx_runtime_w_part2.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * ui/src/features/merge-gate/drift-risk/useDriftRisk.ts
 *
 * Two hooks, deliberately separated.
 *
 * `useOnnxSession` owns the expensive, long-lived resource: one InferenceSession
 * per panel mount, released on unmount. `useDriftRisk` runs inference on every
 * report refresh against the cached session.
 *
 * This split is the crux of the design. Model freshness and input freshness are
 * different problems: the model file is fetched once (aggressively cached by the
 * browser via a versioned URL), while the input vector is rebuilt from fresh
 * data on every refresh. Collapsing them into one effect would either re-download
 * the model on every refresh or serve a stale score.
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import * as ort from 'onnxruntime-web';
import type { NormalizedCoverageReport } from '../../../../../packages/gate-runner/src/protocol';
import {
  DRIFT_FEATURE_SCHEMA_VERSION,
  DRIFT_INPUT_LENGTH,
  buildFeatureVector,
  type DriftRiskLabel,
  type DriftRiskState,
  type WorkingTreeContext,
} from './types';

const LABELS: readonly DriftRiskLabel[] = ['LOW', 'MEDIUM', 'HIGH'];

/**
 * `wasm` is the default. The model is tiny, and WebGPU session creation can cost
 * more than the inference it accelerates; preferring it unconditionally would
 * make first paint worse for a sub-millisecond prediction.
 */
async function pickExecutionProviders(): Promise<readonly string[]> {
  if (typeof navigator === 'undefined' || !('gpu' in navigator)) return ['wasm'];
  try {
    const gpu = (navigator as Navigator & {
      gpu?: { requestAdapter(): Promise<unknown> };
    }).gpu;
    const adapter = await gpu?.requestAdapter();
    return adapter ? ['webgpu', 'wasm'] : ['wasm'];
  } catch {
    return ['wasm'];
  }
}

interface OnnxSessionState {
  readonly session: ort.InferenceSession | null;
  readonly error: string | null;
}

function useOnnxSession(modelUrl: string): OnnxSessionState {
  const [state, setState] = useState<OnnxSessionState>({ session: null, error: null });
  const sessionRef = useRef<ort.InferenceSession | null>(null);

  useEffect(() => {
    let cancelled = false;

    void (async () => {
      try {
        const executionProviders = await pickExecutionProviders();
        const session = await ort.InferenceSession.create(modelUrl, {
          executionProviders: [...executionProviders],
          graphOptimizationLevel: 'all',
        });

        if (cancelled) {
          // Unmounted while loading: release immediately rather than leaking a
          // WASM allocation the JS GC will never reclaim.
          await session.release();
          return;
        }

        sessionRef.current = session;
        setState({ session, error: null });
      } catch (error) {
        if (!cancelled) {
          setState({ session: null, error: String(error) });
        }
      }
    })();

    return () => {
      cancelled = true;
      const session = sessionRef.current;
      sessionRef.current = null;
      if (session !== null) {
        // Disposal on unmount is mandatory: each session allocates WASM memory.
        void session.release();
      }
    };
  }, [modelUrl]);

  return state;
}

export function useDriftRisk(
  modelUrl: string,
  report: NormalizedCoverageReport,
  context: WorkingTreeContext,
): DriftRiskState {
  const { session, error } = useOnnxSession(modelUrl);
  const [state, setState] = useState<DriftRiskState>({
    status: 'idle',
    score: null,
    unavailableReason: null,
  });

  const vector = useMemo(
    () => (report.specs.length === 0 ? null : buildFeatureVector(report, context)),
    [report, context],
  );

  useEffect(() => {
    if (vector === null) {
      setState({ status: 'unavailable', score: null, unavailableReason: 'empty-report' });
      return;
    }
    if (error !== null) {
      setState({
        status: 'unavailable',
        score: null,
        unavailableReason: 'model-load-failed',
      });
      return;
    }
    if (session === null) return;

    const modelSchemaVersion = Number(
      (session as unknown as { metadata?: Record<string, string> }).metadata
        ?.drift_feature_schema_version ?? Number.NaN,
    );

    if (modelSchemaVersion !== DRIFT_FEATURE_SCHEMA_VERSION) {
      // The client and the model disagree about what feature 9 means. A number
      // produced here would be plausible and meaningless.
      setState({ status: 'unavailable', score: null, unavailableReason: 'schema-mismatch' });
      return;
    }

    let cancelled = false;
    setState({ status: 'loading', score: null, unavailableReason: null });

    void (async () => {
      try {
        const tensor = new ort.Tensor('float32', vector, [1, DRIFT_INPUT_LENGTH]);
        const feeds: Record<string, ort.Tensor> = { input: tensor };
        const output = await session.run(feeds);
        const logits = output.output?.data as Float32Array | undefined;

        if (logits === undefined || logits.length !== LABELS.length) {
          if (!cancelled) {
            setState({
              status: 'unavailable',
              score: null,
              unavailableReason: 'input-out-of-range',
            });
          }
          return;
        }

        const probabilities = normalize(logits);
        const argmax = probabilities.indexOf(Math.max(...probabilities));

        if (!cancelled) {
          setState({
            status: 'available',
            score: {
              label: LABELS[argmax] as DriftRiskLabel,
              confidence: probabilities[argmax] as number,
              probabilities: {
                LOW: probabilities[0] as number,
                MEDIUM: probabilities[1] as number,
                HIGH: probabilities[2] as number,
              },
              schemaVersion: DRIFT_FEATURE_SCHEMA_VERSION,
            },
            unavailableReason: null,
          });
        }
      } catch {
        if (!cancelled) {
          setState({
            status: 'unavailable',
            score: null,
            unavailableReason: 'model-load-failed',
          });
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [session, vector, error]);

  return state;
}

function normalize(values: Float32Array): readonly number[] {
  const max = Math.max(...values);
  const exps = Array.from(values, (value) => Math.exp(value - max));
  const sum = exps.reduce((total, value) => total + value, 0);
  return exps.map((value) => value / sum);
}
