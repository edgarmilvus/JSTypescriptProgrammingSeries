/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_edge-first_drift_risk_signal_using_onnx_runtime_w_part3.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * ui/src/features/merge-gate/drift-risk/DriftRiskBadge.tsx
 *
 * Four additional CSS module class names plus one for the confidence label, as
 * required. Nothing here participates in the gate decision.
 */

import type { DriftRiskState } from './types';
import css from './DriftRiskBadge.module.css';

export interface DriftRiskBadgeProps {
  readonly state: DriftRiskState;
  readonly testIdPrefix?: string;
}

// Class inventory (DriftRiskBadge.module.css), one sentence each:
//
//  .badgeLow       Neutral/green treatment for a LOW advisory score.
//  .badgeMedium    Amber treatment for a MEDIUM advisory score.
//  .badgeHigh      Red treatment for a HIGH advisory score.
//  .badgeAdvisory  Shared shell applied to all three badges, carrying the
//                  "advisory, not a gate" border style so the visual language
//                  differs from the gate's pass/fail indicator.
//  .confidence     Small tabular-numeral label showing the max class probability.

export function DriftRiskBadge(props: DriftRiskBadgeProps): JSX.Element {
  const { state, testIdPrefix = 'merge-gate' } = props;

  if (state.status !== 'available' || state.score === null) {
    return (
      <span className={css.badgeAdvisory} data-testid={`${testIdPrefix}-drift-risk-unavailable`}>
        drift risk: {state.unavailableReason ?? 'unavailable'}
      </span>
    );
  }

  const className =
    state.score.label === 'LOW'
      ? css.badgeLow
      : state.score.label === 'MEDIUM'
        ? css.badgeMedium
        : css.badgeHigh;

  return (
    <span
      className={`${css.badgeAdvisory} ${className}`}
      data-testid={`${testIdPrefix}-drift-risk-${state.score.label}`}
      // Explicitly advisory: this value never changes a gate decision.
      title="Advisory signal only. The merge gate is decided by declarations, not by this score."
    >
      drift risk: {state.score.label}
      <span className={css.confidence}>
        {(state.score.confidence * 100).toFixed(0)}%
      </span>
    </span>
  );
}
