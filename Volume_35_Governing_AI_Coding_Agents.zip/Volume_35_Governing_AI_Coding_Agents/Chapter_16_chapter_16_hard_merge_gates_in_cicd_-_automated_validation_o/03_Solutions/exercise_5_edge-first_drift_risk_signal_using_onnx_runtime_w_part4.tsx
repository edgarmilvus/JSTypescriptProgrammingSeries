/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_edge-first_drift_risk_signal_using_onnx_runtime_w_part4.tsx
Description: Solutions and Explanations
==========================================
*/

/**
 * docs/design/edge-drift-risk.md (delivered as a typed artifact)
 *
 * # Edge-first drift risk signal
 *
 * ## Why the browser and not CI
 *
 * The signal exists to change what a developer does in the next five minutes,
 * not to produce a dashboard. Computing it in CI would place it behind a push,
 * a queue, a checkout and a build — minutes of latency for a number whose entire
 * value is that it arrives while the working tree is still open. Two concrete
 * CI-only failure modes follow. First, latency: a contributor who would have
 * paused before a risky refactor has already committed by the time the score
 * arrives, so the signal can only ever be retrospective. Second, privacy and
 * cost: a CI-side model would require shipping working-tree diffs, spec text and
 * coverage metrics to a central service, which is both a data-egress decision
 * the team has not agreed to and a per-push compute cost that scales with commit
 * volume. Running the model in the browser means the features are computed from
 * data already in the page, nothing leaves the machine, and the marginal cost of
 * one more developer is zero.
 *
 * ## Architecture
 *
 *   NormalizedCoverageReport + WorkingTreeContext
 *                 |
 *                 v
 *         buildFeatureVector()  -> Float32Array[24]
 *                 |
 *                 v
 *   useDriftRisk(session, vector)  -> DriftRiskScore
 *                 |
 *                 v
 *          <DriftRiskBadge />      (advisory only)
 *
 * ## Execution provider selection
 *
 * `wasm` is the default. The model is small, and WebGPU session creation can
 * exceed the inference it accelerates; the branch in `pickExecutionProviders()`
 * only prefers `webgpu` when `navigator.gpu.requestAdapter()` resolves to a real
 * adapter, and always lists `wasm` as the fallback so a mid-session GPU loss
 * degrades instead of failing.
 *
 * ## Session lifecycle
 *
 * One `InferenceSession` per panel mount. Creating it in `useOnnxSession`'s
 * effect and releasing it in the same effect's cleanup guarantees a single
 * allocation per mount and a single release per unmount, including the
 * unmount-during-load path, where the session is released as soon as it
 * resolves. Leaking a session is not a minor mistake: each one holds WASM
 * linear memory the JS garbage collector cannot reclaim.
 *
 * ## Freshness model
 *
 * Model freshness and input freshness are handled separately. The model is
 * fetched once per mount from a versioned URL, so the browser's HTTP cache
 * serves it for free on every subsequent mount and a model change is an
 * explicit URL change. The input vector is rebuilt on every report refresh,
 * which is what makes the score current. Refetching the model on every refresh
 * would violate the edge-first constraint for no benefit.
 *
 * ## Feature schema guard
 *
 * `DRIFT_FEATURE_SCHEMA_VERSION` is compiled into the client. The same value is
 * embedded in the model's metadata as `drift_feature_schema_version`. They are
 * compared before any inference runs. A mismatch renders "drift risk:
 * schema-mismatch" instead of a number. This is the guard that prevents the
 * silent-disagreement failure mode where feature 9 means "contributors" to the
 * client and "review comments" to the model.
 *
 * ## Explainability decision
 *
 * The panel does NOT attempt per-feature attribution. ONNX Runtime Web exposes
 * no gradient-based attribution for arbitrary models, so any "top contributing
 * features" list would be a fabrication dressed as the model's reasoning. The
 * expander instead shows the raw feature values, which are facts. Fabricated
 * attribution would undermine the same auditability that makes the gate
 * trustworthy.
 *
 * ## Non-goals
 *
 * - No training pipeline. The model is an input, not an output of this work.
 * - No feature store. Features are computed in the page from data already present.
 * - No telemetry. Nothing about the score, the features or the working tree
 *   leaves the developer's machine.
 * - No gate influence. The score is advisory. The merge gate's decision is made
 *   by the declarations in Exercises 1 and 2 and is unaffected by this signal.
 *   If the score and the gate disagree, the gate is correct by definition.
 * - No per-feature attribution, for the reason given above.
 * - No server-side inference fallback. A fallback would reintroduce exactly the
 *   data-egress property the edge-first design exists to avoid.
 * - No mobile-specific layout work; the panel inherits the portal's responsive
 *   behaviour and is out of scope here.
 */

export const DRIFT_RISK_DESIGN_DOC_PATH = 'docs/design/edge-drift-risk.md';

/**
 * ui/src/features/merge-gate/drift-risk/useDriftRisk.test.tsx
 *
 * Test list, ONNX-boundary focused. Assertions are the implementer's job; each
 * name states the observable contract.
 */

export const DRIFT_RISK_TEST_NAMES: readonly string[] = [
  'loads the ONNX session exactly once when the panel mounts',
  'releases the ONNX session exactly once when the panel unmounts',
  'releases the session immediately when unmounting during model load',
  'does not run inference when report.specs is empty',
  'reports schema-mismatch and renders no score when the model metadata version differs',
  'reports model-load-failed and renders no score when the model fetch rejects',
  'falls back to the wasm provider when navigator.gpu.requestAdapter resolves null',
  'prefers webgpu when a real GPU adapter is available',
  'rejects an input tensor whose length is not DRIFT_INPUT_LENGTH',
  'clamps validation warnings above 20 to a feature value of exactly 1.0',
  'clamps elapsed time beyond 24 hours to a feature value of exactly 1.0',
  'treats a NaN coverage percentage as a feature value of 0 instead of NaN',
  'produces a probability distribution whose values sum to 1 within 1e-6',
  'maps the argmax class to the matching LOW/MEDIUM/HIGH badge',
  'makes no network requests after the initial model fetch on a report refresh',
  'does not set state after unmount when inference is still in flight',
  'renders the advisory shell class on all three badges, never the gate pass/fail classes',
];
