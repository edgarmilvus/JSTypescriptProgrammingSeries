/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: script_practical_exercises_part2.ts
Description: Practical Exercises
==========================================
*/

>>> tracey_status
Status: configured 2 spec(s)
  - payments/typescript  impl 78.6%  verify 42.9%
  - gateway/typescript   impl 100.0% verify 100.0%
Delta since last query: coverage +3.2 ppt (impl), -1.4 ppt (verify)
Hints: 4 requirement(s) uncovered. Run tracey_uncovered.

>>> tracey_uncovered
Spec/Impl: payments/typescript
  PAY-settlement-003  Idempotent settlement — no impl reference
  PAY-ledger-007      Currency pinning on every entry — no impl reference
  PAY-retry-002       Exponential backoff with hard cap — no impl reference
  PAY-replay-004      Replay protection — no impl reference
Spec/Impl: gateway/typescript
  (none)

>>> tracey_untested
Spec/Impl: payments/typescript
  PAY-settlement-003
  PAY-ledger-007
  PAY-retry-002
  PAY-replay-004
  PAY-settlement-001
Spec/Impl: gateway/typescript
  (none)

>>> tracey_stale
Spec/Impl: payments/typescript
  PAY-settlement-001  reference at v1, spec at v3
Spec/Impl: gateway/typescript
  (none)

>>> tracey_validate
Validation: 1 error(s), 2 warning(s)
Errors:
  - Unknown requirement reference 'PAY-settlement-003 ' (trailing space)
    at src/payments/ledger.ts:118
Warnings:
  - Stale reference 'PAY-settlement-001' at src/payments/settlement.ts:44
  - Impl annotation in a test file 'tests/payments.spec.ts:9'
    (grammar: 'r[impl PAY-ledger-007]' declared but file is test_include)
