/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

// src/billing/trial.ts

// r[impl billing.trial.duration]
// r[impl billing.trial.grace]
export const TRIAL_DURATION_DAYS = 14;
export const GRACE_PERIOD_DAYS = 3;

export type TrialState = "active" | "grace" | "expired";

export interface TrialRecord {
  accountId: string;
  activatedAt: Date;
}

/**
 * Pure state machine that derives the current trial phase for an account.
 *
 * This function is deliberately pure (no clock, no I/O) so that it can be
 * exhaustively unit-tested against the normative statements in the spec.
 *
 * @param activatedAt - the UTC instant the trial began.
 * @param now - the reference instant; defaults to the current wall clock.
 * @returns the trial phase for the given input pair.
 */
// r[impl billing.trial.duration]
// r[impl billing.trial.grace]
export function computeTrialState(
  activatedAt: Date,
  now: Date = new Date(),
): TrialState {
  const MS_PER_DAY = 1000 * 60 * 60 * 24;
  const elapsedDays = (now.getTime() - activatedAt.getTime()) / MS_PER_DAY;

  if (elapsedDays < TRIAL_DURATION_DAYS) {
    return "active";
  }

  if (elapsedDays < TRIAL_DURATION_DAYS + GRACE_PERIOD_DAYS) {
    return "grace";
  }

  return "expired";
}

/**
 * Express middleware that short-circuits write operations for accounts in
 * the read-only grace window.
 *
 * The middleware is intentionally written against `TrialState` rather than
 * the raw timestamps, so the branching logic that lives here mirrors the
 * normative rules rather than re-deriving them.
 */
// r[impl billing.trial.grace]
export function requireWritableTrial(
  req: { accountId: string; method: string },
  next: () => void,
): void {
  const state = computeTrialState(
    new Date((req as any).trial.activatedAt ?? Date.now()),
  );

  const isWrite = req.method !== "GET" && req.method !== "HEAD";

  if (isWrite && state === "grace") {
    throw Object.assign(new Error("Payment Required"), { status: 402 });
  }

  next();
}
