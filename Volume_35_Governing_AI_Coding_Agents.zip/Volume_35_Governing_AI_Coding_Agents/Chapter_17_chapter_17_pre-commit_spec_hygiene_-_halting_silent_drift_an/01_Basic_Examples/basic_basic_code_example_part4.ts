/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// src/billing/trial.test.ts

import { describe, it, expect } from "vitest";
import {
  computeTrialState,
  TRIAL_DURATION_DAYS,
  GRACE_PERIOD_DAYS,
} from "./trial";

const DAY_MS = 1000 * 60 * 60 * 24;

function daysAfter(base: string, offset: number): Date {
  return new Date(new Date(base).getTime() + offset * DAY_MS);
}

describe("computeTrialState", () => {
  const T0 = "2024-01-01T00:00:00Z";

  // r[verify billing.trial.duration]
  it("returns 'active' strictly before the 14-day mark", () => {
    expect(computeTrialState(new Date(T0), daysAfter(T0, 13.999))).toBe(
      "active",
    );
  });

  // r[verify billing.trial.duration]
  it("leaves 'active' at exactly 14 days", () => {
    expect(computeTrialState(new Date(T0), daysAfter(T0, 14))).toBe("grace");
  });

  // r[verify billing.trial.grace]
  it("returns 'grace' throughout the 3-day grace window", () => {
    expect(computeTrialState(new Date(T0), daysAfter(T0, 15))).toBe("grace");
    expect(computeTrialState(new Date(T0), daysAfter(T0, 16.999))).toBe(
      "grace",
    );
  });

  // r[verify billing.trial.grace]
  it("returns 'expired' at exactly 17 days", () => {
    expect(computeTrialState(new Date(T0), daysAfter(T0, 17))).toBe("expired");
  });

  // r[verify billing.trial.duration]
  it("keeps TRIAL_DURATION_DAYS aligned with the spec", () => {
    expect(TRIAL_DURATION_DAYS).toBe(14);
    expect(GRACE_PERIOD_DAYS).toBe(3);
  });
});
