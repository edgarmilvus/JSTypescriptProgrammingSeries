/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part6.ts
Description: Basic Code Example
==========================================
*/

// scripts/pre-commit-tracey.ts
//
// A Node-based pre-commit driver used when a team prefers a single
// language across the dev toolchain (no shell portability headaches on
// Windows). Runs the same two Tracey checks as the shell hook.

import { spawnSync } from "node:child_process";

type Step = { label: string; argv: string[] };

const STEPS: readonly Step[] = [
  {
    label: "structural — validate intent graph",
    argv: ["tracey", "query", "validate", "--deny", "warnings"],
  },
  {
    label: "temporal — enforce atomic version bumps",
    argv: ["tracey", "pre-commit"],
  },
];

/**
 * Runs one Tracey step synchronously and returns a boolean success flag.
 * We use `spawnSync` (not `exec`) so the child inherits stdio and the
 * developer sees Tracey's native, colourised diagnostics verbatim.
 */
function runStep(step: Step): boolean {
  process.stdout.write(`→ ${step.label}\n`);
  const result = spawnSync(step.argv[0]!, step.argv.slice(1), {
    stdio: "inherit",
  });

  if (result.error) {
    process.stderr.write(
      `✗ failed to spawn '${step.argv.join(" ")}': ${result.error.message}\n`,
    );
    return false;
  }

  return result.status === 0;
}

/**
 * Entry point. Runs every step in sequence and exits non-zero on the
 * first failure, with an actionable fix hint printed for the developer.
 */
function main(): number {
  for (const step of STEPS) {
    if (!runStep(step)) {
      process.stderr.write(
        [
          "",
          "✗ Pre-commit spec hygiene failed.",
          "",
          "  Fix checklist:",
          "    1. Run `tracey query validate` to list broken refs.",
          "    2. Run `tracey query stale` to list stale annotations.",
          "    3. If a rule's text changed, run `tracey bump` to",
          "       increment the +N suffix and re-stage the file.",
          "    4. Re-run `git commit`.",
          "",
        ].join("\n"),
      );
      return 1;
    }
  }

  process.stdout.write("✓ Tracey spec-hygiene gate passed.\n");
  return 0;
}

process.exit(main());
