/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

// src/services/SpecExtractor.ts

import type { StagedRequirementDiff } from "../domain/types.js";

export interface ExtractedRequirement {
  readonly uid: string;
  readonly version: number;
  readonly statement: string;
  readonly title: string;
  readonly rationale: string;
}

const FIELD_RE = /^(STATEMENT|TITLE|RATIONALE|UID|VERSION):\s*(.*)$/;
const HEREDOC_OPEN = ">>>";
const HEREDOC_CLOSE = "<<<";

/**
 * Extracts requirements from a raw `.sdoc` document. Returns a map keyed by
 * UID. Fields are stored verbatim; whitespace differences do not trigger a
 * version-bump requirement.
 *
 * @param source - Raw `.sdoc` file content.
 * @returns A readonly map of UID → extracted requirement.
 */
export function extractRequirements(
  source: string,
): ReadonlyMap<string, ExtractedRequirement> {
  const out = new Map<string, ExtractedRequirement>();
  const lines = source.split(/\r?\n/);

  let inRequirement = false;
  let pending: Partial<ExtractedRequirement> = {};
  let heredocField: "STATEMENT" | "RATIONALE" | "TITLE" | null = null;
  let heredocBuffer: string[] = [];

  for (const rawLine of lines) {
    const line = rawLine;

    if (heredocField !== null) {
      if (line.trim() === HEREDOC_CLOSE) {
        pending[heredocField] = heredocBuffer.join("\n").trim();
        heredocField = null;
        heredocBuffer = [];
      } else {
        heredocBuffer.push(line);
      }
      continue;
    }

    if (line.trim() === "[REQUIREMENT]") {
      if (inRequirement && pending.uid !== undefined) {
        out.set(pending.uid, finalize(pending));
      }
      inRequirement = true;
      pending = {};
      continue;
    }

    if (line.startsWith("[") && !line.startsWith("[REQUIREMENT]")) {
      if (inRequirement && pending.uid !== undefined) {
        out.set(pending.uid, finalize(pending));
      }
      inRequirement = false;
      pending = {};
      continue;
    }

    if (!inRequirement) continue;

    const match = FIELD_RE.exec(line);
    if (!match) continue;
    const [, name, rest = ""] = match;

    if (rest.trim() === HEREDOC_OPEN) {
      heredocField = name as "STATEMENT" | "RATIONALE" | "TITLE";
      continue;
    }

    switch (name) {
      case "UID":
        pending.uid = rest.trim();
        break;
      case "VERSION":
        pending.version = Number.parseInt(rest.trim(), 10);
        break;
      case "TITLE":
        pending.title = rest.trim();
        break;
      case "STATEMENT":
        pending.statement = rest.trim();
        break;
      case "RATIONALE":
        pending.rationale = rest.trim();
        break;
    }
  }

  if (inRequirement && pending.uid !== undefined) {
    out.set(pending.uid, finalize(pending));
  }

  return out;
}

function finalize(partial: Partial<ExtractedRequirement>): ExtractedRequirement {
  if (partial.uid === undefined) {
    throw new Error("Requirement without UID in .sdoc source");
  }
  const uidMatch = /^(.*)\+(\d+)$/.exec(partial.uid);
  const version = partial.version ?? (uidMatch ? Number.parseInt(uidMatch[2], 10) : 1);
  return {
    uid: partial.uid,
    version,
    statement: partial.statement ?? "",
    title: partial.title ?? "",
    rationale: partial.rationale ?? "",
  };
}
