/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part11.ts
Description: Advanced Application Implementation
==========================================
*/

// src/services/VersionBumpDetector.ts

import type { CheckOutcome, PreCommitCheck, StagedRequirementDiff } from "../domain/types.js";
import type { GitPort } from "../ports/GitPort.js";
import { extractRequirements } from "./SpecExtractor.js";

const SDOC_EXT = ".sdoc";

/**
 * Fails when a requirement's statement, title, or rationale changed without a
 * version bump on its UID.
 *
 * Rules:
 *  1. Only `.sdoc` files staged in the index are considered.
 *  2. A field change is defined as a byte-inequality between HEAD and
 *     working-tree after trimming leading/trailing whitespace.
 *  3. A version bump is defined as: new UID suffix = old UID suffix + 1.
 */
export class VersionBumpDetector implements PreCommitCheck {
  public readonly name = "version-bump-integrity";

  public constructor(private readonly git: GitPort) {}

  public async run(): Promise<CheckOutcome> {
    const staged = (await this.git.stagedFiles()).filter((f) => f.endsWith(SDOC_EXT));
    if (staged.length === 0) return { status: "pass" };

    const drifts: StagedRequirementDiff[] = [];

    for (const path of staged) {
      const head = await this.git.showAtHead(path);
      if (head === null) continue; // brand-new file: nothing to compare

      const working = await this.git.readWorkingTree(path);
      const headReqs = extractRequirements(head);
      const workReqs = extractRequirements(working);

      for (const [uid, workReq] of workReqs) {
        const headReq = headReqs.get(uid);
        if (headReq === undefined) continue; // newly added requirement

        const changedFields: StagedRequirementDiff["changedFields"] = [];
        if (headReq.statement.trim() !== workReq.statement.trim()) changedFields.push("STATEMENT");
        if (headReq.title.trim() !== workReq.title.trim()) changedFields.push("TITLE");
        if (headReq.rationale.trim() !== workReq.rationale.trim()) changedFields.push("RATIONALE");

        if (changedFields.length === 0) continue;

        if (workReq.version !== headReq.version + 1) {
          drifts.push({
            uid: workReq.uid,
            filePath: path,
            changedFields,
            previousVersion: headReq.version,
            currentVersion: workReq.version,
          });
        }
      }
    }

    if (drifts.length === 0) return { status: "pass" };

    const reason = [
      `Detected ${drifts.length} requirement(s) whose text changed without a version bump.`,
      ...drifts.map(
        (d) =>
          `  ${d.uid}: fields [${d.changedFields.join(", ")}] — ` +
          `version ${d.previousVersion} → ${d.currentVersion} (expected ${d.previousVersion + 1})`,
      ),
    ].join("\n");

    const remediation = [
      "For each drifted requirement, bump its UID suffix and VERSION field by exactly one:",
      ...drifts.map(
        (d) => `  - ${d.uid}  →  ${d.uid.replace(/\+(\d+)$/, (_, n: string) => `+${Number(n) + 1}`)}`,
      ),
      "Then update every code annotation, test annotation, and dependency annotation that referenced the old version.",
      "Do not commit until all three land together.",
    ];

    return { status: "fail", reason, remediation };
  }
}
