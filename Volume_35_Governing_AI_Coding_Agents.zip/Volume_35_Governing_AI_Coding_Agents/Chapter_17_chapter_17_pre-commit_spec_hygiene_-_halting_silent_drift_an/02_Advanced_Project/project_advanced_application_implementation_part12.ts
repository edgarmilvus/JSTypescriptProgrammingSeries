/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

// src/services/IntentGraphValidator.ts

import type { CheckOutcome, PreCommitCheck } from "../domain/types.js";
import type { TraceyPort } from "../ports/TraceyPort.js";

/**
 * Fails when Tracey's semantic linter reports any validation issue, or when
 * there are stale references in the working tree.
 *
 * The check is intentionally strict: any non-zero exit code from either
 * `validate` or `stale` is a failure, regardless of warning-vs-error severity.
 * This matches the L1-level `Warnings are errors` requirement inherited from
 * StrictDoc (SDOC-SRS-6).
 */
export class IntentGraphValidator implements PreCommitCheck {
  public readonly name = "intent-graph-integrity";

  public constructor(private readonly tracey: TraceyPort) {}

  public async run(): Promise<CheckOutcome> {
    const validation = await this.tracey.validate();
    const stale = await this.tracey.stale();

    const failures: string[] = [];

    if (validation.exitCode !== 0) {
      failures.push("tracey query validate --deny warnings exited non-zero:");
      failures.push(indent(validation.output));
    }

    // `stale` returns non-zero when stale references exist. That is a hard
    // fail for the pre-commit gate: the code says it was written against
    // version N, but the spec is at N+1.
    if (stale.exitCode !== 0) {
      failures.push("tracey query stale reported stale references:");
      failures.push(indent(stale.output));
    }

    if (failures.length === 0) return { status: "pass" };

    return {
      status: "fail",
      reason: failures.join("\n"),
      remediation: [
        "Run `tracey query validate --deny warnings` locally to see the full report.",
        "Run `tracey query stale` to enumerate annotations pointing at older spec versions.",
        "Fix broken UIDs, missing annotations, or version-drifted references before committing.",
      ],
    };
  }
}

function indent(text: string): string {
  return text
    .split("\n")
    .map((line) => `    ${line}`)
    .join("\n");
}
