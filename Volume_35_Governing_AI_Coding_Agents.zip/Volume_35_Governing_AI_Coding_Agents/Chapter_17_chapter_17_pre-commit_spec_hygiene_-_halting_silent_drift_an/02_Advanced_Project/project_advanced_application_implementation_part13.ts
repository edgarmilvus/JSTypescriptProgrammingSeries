/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part13.ts
Description: Advanced Application Implementation
==========================================
*/

// src/services/AtomicityValidator.ts

import type { CheckOutcome, PreCommitCheck } from "../domain/types.js";
import type { GitPort } from "../ports/GitPort.js";
import type { TraceyPort } from "../ports/TraceyPort.js";
import { extractRequirements } from "./SpecExtractor.js";

const ANNOTATION_RE = /r\[(impl|verify|depends|related)\s+([A-Za-z0-9._:+\-]+)\]/g;

/**
 * Enforces that when a requirement's version is bumped, all code and test
 * annotations referencing the old version are staged in the same commit.
 *
 * Algorithm:
 *  1. Compute `bumpedUids`: requirements whose `+N` suffix increased relative
 *     to HEAD. For each, record the *old* UID (e.g. `AUTH-LOGIN+2`).
 *  2. Walk every staged source/test file and extract `r[...]` annotations.
 *  3. Fail if any staged annotation references an *old* UID (that annotation
 *     is stale), or if the reference file is not itself staged.
 */
export class AtomicityValidator implements PreCommitCheck {
  public readonly name = "commit-atomicity";

  public constructor(
    private readonly git: GitPort,
    private readonly tracey: TraceyPort,
  ) {}

  public async run(): Promise<CheckOutcome> {
    const staged = await this.git.stagedFiles();
    const bumpedOldUids = await this.computeBumpedOldUids(staged);

    if (bumpedOldUids.size === 0) return { status: "pass" };

    // Map old UID → new UID for diagnostics.
    const oldToNew = new Map<string, string>();
    for (const [oldUid, newUid] of bumpedOldUids) oldToNew.set(oldUid, newUid);

    // Walk every staged non-spec file and collect annotations.
    const stagedSet = new Set(staged);
    const staleRefs: Array<{ file: string; oldUid: string; newUid: string }> = [];
    const unstagedRefs: Array<{ file: string; oldUid: string; newUid: string }> = [];

    for (const path of staged) {
      if (path.endsWith(".sdoc")) continue;
      const content = await this.git.readWorkingTree(path);
      let match: RegExpExecArray | null;
      ANNOTATION_RE.lastIndex = 0;
      while ((match = ANNOTATION_RE.exec(content)) !== null) {
        const referencedUid = match[2];
        const newUid = oldToNew.get(referencedUid);
        if (newUid !== undefined) {
          // The file still references the old UID — stale annotation.
          staleRefs.push({ file: path, oldUid: referencedUid, newUid });
        }
      }
    }

    // Also detect the reverse: an annotation in a working-tree file that
    // references a newly-bumped UID but the file itself is not staged.
    for (const path of await this.traceyReferencesForUids([...oldToNew.values()])) {
      if (!stagedSet.has(path)) {
        const oldUid = [...oldToNew.entries()].find(([, v]) => v === path)?.[0] ?? "?";
        unstagedRefs.push({ file: path, oldUid, newUid: path });
      }
    }

    if (staleRefs.length === 0 && unstagedRefs.length === 0) {
      return { status: "pass" };
    }

    const lines: string[] = [];
    if (staleRefs.length > 0) {
      lines.push("Stale annotations still reference the pre-bump UID:");
      for (const r of staleRefs) {
        lines.push(`  ${r.file}: ${r.oldUid} → must become ${r.newUid}`);
      }
    }
    if (unstagedRefs.length > 0) {
      lines.push("Files implementing the bumped requirements are not staged:");
      for (const r of unstagedRefs) {
        lines.push(`  ${r.file} (references ${r.newUid})`);
      }
    }

    return {
      status: "fail",
      reason: lines.join("\n"),
      remediation: [
        "Atomic version bumps are mandatory. A single commit must contain:",
        "  1. the .sdoc file with the bumped UID and VERSION field,",
        "  2. every source file whose annotations reference the requirement,",
        "  3. every test file whose `r[verify ...]` annotations reference the requirement.",
        "Run `tracey query stale` to enumerate stale references. Then `git add` the missing files.",
      ],
    };
  }

  private async computeBumpedOldUids(
    staged: readonly string[],
  ): Promise<Map<string, string>> {
    const out = new Map<string, string>();
    for (const path of staged) {
      if (!path.endsWith(".sdoc")) continue;
      const head = await this.git.showAtHead(path);
      if (head === null) continue;
      const working = await this.git.readWorkingTree(path);

      const headReqs = extractRequirements(head);
      const workReqs = extractRequirements(working);

      // Match by base UID (strip the +N suffix) to detect bumps.
      const baseToHeadUid = new Map<string, string>();
      for (const uid of headReqs.keys()) {
        baseToHeadUid.set(stripVersion(uid), uid);
      }

      for (const workUid of workReqs.keys()) {
        const base = stripVersion(workUid);
        const headUid = baseToHeadUid.get(base);
        if (headUid === undefined) continue;
        if (headUid !== workUid) {
          out.set(headUid, workUid);
        }
      }
    }
    return out;
  }

  private async traceyReferencesForUids(
    uids: readonly string[],
  ): Promise<readonly string[]> {
    // In production this consults `tracey query rule <uid>` and extracts the
    // source paths of every reference. The stub returns an empty list.
    void this.tracey;
    void uids;
    return [];
  }
}

function stripVersion(uid: string): string {
  return uid.replace(/\+\d+$/, "");
}
