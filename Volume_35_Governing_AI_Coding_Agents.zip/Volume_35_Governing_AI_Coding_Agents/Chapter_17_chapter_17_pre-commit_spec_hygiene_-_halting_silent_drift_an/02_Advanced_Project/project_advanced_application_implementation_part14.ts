/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part14.ts
Description: Advanced Application Implementation
==========================================
*/

// src/services/PreCommitOrchestrator.ts

import type { CheckOutcome, PreCommitCheck } from "../domain/types.js";

/** Aggregate result of running every registered check. */
export interface GateResult {
  readonly passed: boolean;
  readonly outcomes: readonly { readonly name: string; readonly outcome: CheckOutcome }[];
}

/**
 * Runs every registered check in parallel, aggregates outcomes, and produces
 * a single pass/fail verdict. Checks are independent and order-insensitive.
 */
export class PreCommitOrchestrator {
  public constructor(private readonly checks: readonly PreCommitCheck[]) {}

  public async run(): Promise<GateResult> {
    const settled = await Promise.all(
      this.checks.map(async (check) => ({
        name: check.name,
        outcome: await this.safeRun(check),
      })),
    );

    return {
      passed: settled.every((s) => s.outcome.status === "pass"),
      outcomes: settled,
    };
  }

  private async safeRun(check: PreCommitCheck): Promise<CheckOutcome> {
    try {
      return await check.run();
    } catch (error) {
      return {
        status: "fail",
        reason: `Check '${check.name}' threw: ${(error as Error).message}`,
        remediation: [
          "This is an internal error, not a spec drift.",
          "Re-run the hook with TRACEY_PRECOMMIT_DEBUG=1 for a full stack trace.",
        ],
      };
    }
  }
}
