/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part15.ts
Description: Advanced Application Implementation
==========================================
*/

// src/cli/preCommitCli.ts

import { VersionBumpDetector } from "../services/VersionBumpDetector.js";
import { IntentGraphValidator } from "../services/IntentGraphValidator.js";
import { AtomicityValidator } from "../services/AtomicityValidator.js";
import { PreCommitOrchestrator } from "../services/PreCommitOrchestrator.js";
import { createGitAdapter } from "../adapters/GitAdapter.js";
import { createTraceyAdapter } from "../adapters/TraceyAdapter.js";

async function main(): Promise<number> {
  const git = createGitAdapter(process.cwd());
  const tracey = createTraceyAdapter(process.cwd());

  const orchestrator = new PreCommitOrchestrator([
    new VersionBumpDetector(git),
    new IntentGraphValidator(tracey),
    new AtomicityValidator(git, tracey),
  ]);

  const result = await orchestrator.run();

  if (result.passed) {
    process.stdout.write("intent-guard pre-commit: all checks passed\n");
    return 0;
  }

  process.stderr.write("\nintent-guard pre-commit: commit blocked\n");
  process.stderr.write("====================================\n\n");
  for (const { name, outcome } of result.outcomes) {
    if (outcome.status === "pass") {
      process.stderr.write(`PASS  ${name}\n`);
      continue;
    }
    process.stderr.write(`FAIL  ${name}\n`);
    process.stderr.write(indent(outcome.reason));
    process.stderr.write("\nRemediation:\n");
    for (const step of outcome.remediation) {
      process.stderr.write(`  • ${step}\n`);
    }
    process.stderr.write("\n");
  }
  return 1;
}

function indent(text: string): string {
  return text
    .split("\n")
    .map((line) => `      ${line}`)
    .join("\n") + "\n";
}

main().then(
  (code) => process.exit(code),
  (err) => {
    process.stderr.write(`fatal: ${(err as Error).stack ?? String(err)}\n`);
    process.exit(2);
  },
);
