/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part18.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/gate/VersionBumpDetector.test.ts

import { describe, expect, it, vi } from "vitest";
import { VersionBumpDetector } from "../../src/services/VersionBumpDetector.js";
import type { GitPort } from "../../src/ports/GitPort.js";

const SPEC_V2 = `[DOCUMENT]
TITLE: Test Spec

[REQUIREMENT]
UID: AUTH-LOGIN+2
TITLE: Login
STATEMENT: >>>
Users must log in with a password.
<<<
VERSION: 2
STATUS: Approved
`;

const SPEC_V2_TEXT_CHANGED_NO_BUMP = `[DOCUMENT]
TITLE: Test Spec

[REQUIREMENT]
UID: AUTH-LOGIN+2
TITLE: Login
STATEMENT: >>>
Users must log in with a password and a second factor.
<<<
VERSION: 2
STATUS: Approved
`;

const SPEC_V3 = `[DOCUMENT]
TITLE: Test Spec

[REQUIREMENT]
UID: AUTH-LOGIN+3
TITLE: Login
STATEMENT: >>>
Users must log in with a password and a second factor.
<<<
VERSION: 3
STATUS: Approved
`;

function makeGitPort(head: string, working: string): GitPort {
  return {
    stagedFiles: async () => ["docs/spec/auth.sdoc"],
    showAtHead: async () => head,
    readWorkingTree: async () => working,
  };
}

describe("VersionBumpDetector", () => {
  it("passes when text is unchanged", async () => {
    const check = new VersionBumpDetector(makeGitPort(SPEC_V2, SPEC_V2));
    const outcome = await check.run();
    expect(outcome.status).toBe("pass");
  });

  it("fails when text changes without a version bump", async () => {
    const check = new VersionBumpDetector(
      makeGitPort(SPEC_V2, SPEC_V2_TEXT_CHANGED_NO_BUMP),
    );
    const outcome = await check.run();
    expect(outcome.status).toBe("fail");
    if (outcome.status === "fail") {
      expect(outcome.reason).toContain("AUTH-LOGIN+2");
      expect(outcome.reason).toContain("STATEMENT");
    }
  });

  it("passes when text changes with a proper +1 bump", async () => {
    const check = new VersionBumpDetector(makeGitPort(SPEC_V2, SPEC_V3));
    const outcome = await check.run();
    expect(outcome.status).toBe("pass");
  });
});
