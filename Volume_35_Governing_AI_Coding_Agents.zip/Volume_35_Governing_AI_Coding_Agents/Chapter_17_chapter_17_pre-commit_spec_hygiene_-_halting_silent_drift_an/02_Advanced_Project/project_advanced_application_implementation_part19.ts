/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part19.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/gate/IntentGraphValidator.test.ts

import { describe, expect, it } from "vitest";
import { IntentGraphValidator } from "../../src/services/IntentGraphValidator.js";
import type { TraceyPort } from "../../src/ports/TraceyPort.js";

const makeTracey = (validateExit: number, staleExit: number): TraceyPort => ({
  validate: async () => ({ exitCode: validateExit, output: "" }),
  stale: async () => ({ exitCode: staleExit, output: "" }),
});

describe("IntentGraphValidator", () => {
  it("passes when both tracey queries exit zero", async () => {
    const check = new IntentGraphValidator(makeTracey(0, 0));
    expect((await check.run()).status).toBe("pass");
  });

  it("fails on validate failure", async () => {
    const check = new IntentGraphValidator(makeTracey(1, 0));
    expect((await check.run()).status).toBe("fail");
  });

  it("fails on stale references even when validate passes", async () => {
    const check = new IntentGraphValidator(makeTracey(0, 1));
    const outcome = await check.run();
    expect(outcome.status).toBe("fail");
    if (outcome.status === "fail") {
      expect(outcome.reason).toContain("stale");
    }
  });
});
