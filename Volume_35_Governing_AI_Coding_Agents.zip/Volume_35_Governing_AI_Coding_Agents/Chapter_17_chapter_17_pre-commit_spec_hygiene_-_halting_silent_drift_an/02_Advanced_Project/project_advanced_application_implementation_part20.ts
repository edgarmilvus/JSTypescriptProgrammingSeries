/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part20.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/gate/AtomicityValidator.test.ts

import { describe, expect, it } from "vitest";
import { AtomicityValidator } from "../../src/services/AtomicityValidator.js";
import type { GitPort } from "../../src/ports/GitPort.js";
import type { TraceyPort } from "../../src/ports/TraceyPort.js";

const noopTracey: TraceyPort = {
  validate: async () => ({ exitCode: 0, output: "" }),
  stale: async () => ({ exitCode: 0, output: "" }),
};

const SPEC_HEAD = `[REQUIREMENT]
UID: AUTH-LOGIN+2
VERSION: 2
STATEMENT: "v2"
`;

const SPEC_BUMPED = `[REQUIREMENT]
UID: AUTH-LOGIN+3
VERSION: 3
STATEMENT: "v3"
`;

const SRC_STALE = `// r[impl AUTH-LOGIN+2]\nexport function login() {}\n`;
const SRC_UPDATED = `// r[impl AUTH-LOGIN+3]\nexport function login() {}\n`;

function makeGit(head: string, working: string, src: string): GitPort {
  return {
    stagedFiles: async () => ["docs/spec/auth.sdoc", "src/auth.ts"],
    showAtHead: async (p) => (p.endsWith(".sdoc") ? head : null),
    readWorkingTree: async (p) => (p.endsWith(".sdoc") ? working : src),
  };
}

describe("AtomicityValidator", () => {
  it("fails when a bumped spec is committed alongside a stale annotation", async () => {
    const check = new AtomicityValidator(
      makeGit(SPEC_HEAD, SPEC_BUMPED, SRC_STALE),
      noopTracey,
    );
    const outcome = await check.run();
    expect(outcome.status).toBe("fail");
    if (outcome.status === "fail") {
      expect(outcome.reason).toContain("AUTH-LOGIN+2");
      expect(outcome.reason).toContain("AUTH-LOGIN+3");
    }
  });

  it("passes when the annotation is updated in the same commit", async () => {
    const check = new AtomicityValidator(
      makeGit(SPEC_HEAD, SPEC_BUMPED, SRC_UPDATED),
      noopTracey,
    );
    expect((await check.run()).status).toBe("pass");
  });
});
