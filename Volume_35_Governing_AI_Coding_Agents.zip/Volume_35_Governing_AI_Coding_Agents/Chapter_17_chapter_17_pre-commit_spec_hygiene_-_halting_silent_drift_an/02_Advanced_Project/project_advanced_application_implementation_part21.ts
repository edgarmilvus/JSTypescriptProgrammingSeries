/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part21.ts
Description: Advanced Application Implementation
==========================================
*/

// src/services/SemanticGuard.ts

import type { CheckOutcome, PreCommitCheck } from "../domain/types.js";
import type { GitPort } from "../ports/GitPort.js";
import { extractRequirements } from "./SpecExtractor.js";

interface EmbeddingClient {
  similarity(textA: string, textB: string): Promise<number>;
}

/**
 * Detects sub-threshold semantic drift on requirements marked `RISK: Critical`.
 *
 * The guard is advisory for lower risk tiers (it emits a warning but does not
 * fail the commit) and blocking for `Critical` tier. Blocking on similarity
 * < 0.97 prevents silent normative weakening while allowing legitimate
 * editorial rewording.
 */
export class SemanticGuard implements PreCommitCheck {
  public readonly name = "semantic-guard";

  public constructor(
    private readonly git: GitPort,
    private readonly embeddings: EmbeddingClient,
    private readonly threshold = 0.97,
  ) {}

  public async run(): Promise<CheckOutcome> {
    const staged = (await this.git.stagedFiles()).filter((f) => f.endsWith(".sdoc"));
    if (staged.length === 0) return { status: "pass" };

    const drifts: string[] = [];

    for (const path of staged) {
      const head = await this.git.showAtHead(path);
      if (head === null) continue;
      const working = await this.git.readWorkingTree(path);

      const headReqs = extractRequirements(head);
      const workReqs = extractRequirements(working);

      for (const [uid, workReq] of workReqs) {
        const headReq = headReqs.get(uid);
        if (headReq === undefined) continue;
        if (headReq.statement === workReq.statement) continue;

        // Only guard requirements whose RISK is Critical. RISK is parsed out
        // of the same .sdoc, but to keep this example focused we read it
        // directly from the raw text.
        if (!isCritical(working, uid)) continue;
        if (workReq.version !== headReq.version) continue; // bumped: OK

        const sim = await this.embeddings.similarity(
          headReq.statement,
          workReq.statement,
        );
        if (sim < this.threshold) {
          drifts.push(
            `  ${uid}: cosine similarity ${sim.toFixed(4)} < ${this.threshold} (Critical tier)`,
          );
        }
      }
    }

    if (drifts.length === 0) return { status: "pass" };

    return {
      status: "fail",
      reason: [
        "Semantic drift detected on Critical-tier requirements:",
        ...drifts,
      ].join("\n"),
      remediation: [
        "Either restore the normative strength of the affected requirement,",
        "or bump the version and update the code and tests in the same commit.",
        "Critical-tier requirements cannot be silently reworded.",
      ],
    };
  }
}

function isCritical(source: string, uid: string): boolean {
  const idx = source.indexOf(uid);
  if (idx === -1) return false;
  const slice = source.slice(idx, idx + 800);
  return /RISK:\s*Critical/.test(slice);
}
