/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part4.ts
Description: Advanced Application Implementation
==========================================
*/

// src/auth/session.ts

/**
 * Session-token validation and rotation surface.
 *
 * This module is the sole entry point for session lifecycle operations. It
 * deliberately exposes no side-effecting helpers: callers receive a typed
 * {@link SessionVerdict} and must orchestrate persistence themselves. This
 * keeps the module testable without a database and satisfies the single-
 * responsibility commitment for authentication concerns.
 */

import { isTokenExpired } from "./tokenExpiry.js";
import { rotateOnEscalation } from "./rotation.js";
import type { Clock, Token, SessionVerdict } from "./types.js";

/**
 * Validates a session token against the current clock and the requirement's
 * expiry semantics.
 *
 * @param token - The opaque session token received from the client.
 * @param clock - Injected wall-clock source; tests supply a fake clock.
 * @returns A discriminated union indicating valid, expired, or rotated.
 */
// r[impl AUTH-LOGIN+3]
// r[impl AUTH-TOKEN-EXPIRY+2]
export function validateSession(token: Token, clock: Clock): SessionVerdict {
  if (token.issuedWith === "implicit") {
    return { kind: "rejected", reason: "implicit-flow-prohibited" };
  }

  if (isTokenExpired(token, clock)) {
    return { kind: "expired" };
  }

  const rotated = rotateOnEscalation(token, clock);
  return rotated ? { kind: "valid", token: rotated } : { kind: "valid", token };
}
