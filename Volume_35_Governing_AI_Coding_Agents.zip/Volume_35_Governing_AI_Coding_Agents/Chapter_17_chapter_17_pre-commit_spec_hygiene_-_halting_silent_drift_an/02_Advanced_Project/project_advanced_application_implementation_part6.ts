/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

// src/auth/rotation.ts

/**
 * Privilege-escalation rotation. The requirement mandates token rotation on
 * privilege escalation; the mechanics of the escalation itself are owned by
 * the RBAC module.
 */
import type { Clock, Token } from "./types.js";

/**
 * Rotates a token if and only if its privilege scope changed since issuance.
 *
 * @param token - The candidate token.
 * @param clock - Injected clock for deterministic rotation IDs.
 * @returns A rotated token, or null when no rotation is warranted.
 */
// r[depends AUTH-LOGIN+3]
export function rotateOnEscalation(token: Token, clock: Clock): Token | null {
  if (token.scopeAtIssuance === token.scopeNow) {
    return null;
  }
  return {
    ...token,
    rotatedAt: clock.now(),
    nonce: crypto.randomUUID(),
  };
}
