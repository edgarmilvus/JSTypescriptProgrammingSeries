/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/auth/session.test.ts

import { describe, expect, it } from "vitest";
import { validateSession } from "../../src/auth/session.js";
import type { Clock, Token } from "../../src/auth/types.js";

const fixedClock = (iso: string): Clock => ({
  now: () => new Date(iso),
});

const baseToken: Token = {
  id: "tok-1",
  issuedWith: "authorization-code",
  lastSeenAt: new Date("2026-01-01T00:00:00Z"),
  scopeAtIssuance: "user",
  scopeNow: "user",
  rotatedAt: null,
  nonce: "n-1",
};

describe("validateSession", () => {
  // r[verify AUTH-TOKEN-EXPIRY+2]
  it("expires a token after the idle window", () => {
    const clock = fixedClock("2026-01-02T00:00:00Z"); // 24h later
    const verdict = validateSession(baseToken, clock);
    expect(verdict.kind).toBe("expired");
  });

  // r[verify AUTH-LOGIN+3]
  it("rejects tokens issued via implicit flow", () => {
    const clock = fixedClock("2026-01-01T00:00:01Z");
    const token: Token = { ...baseToken, issuedWith: "implicit" };
    const verdict = validateSession(token, clock);
    expect(verdict).toEqual({
      kind: "rejected",
      reason: "implicit-flow-prohibited",
    });
  });

  // r[verify AUTH-LOGIN+3]
  it("rotates on privilege escalation without losing validity", () => {
    const clock = fixedClock("2026-01-01T00:00:01Z");
    const token: Token = { ...baseToken, scopeNow: "admin" };
    const verdict = validateSession(token, clock);
    expect(verdict.kind).toBe("valid");
    if (verdict.kind === "valid") {
      expect(verdict.token.rotatedAt).not.toBeNull();
    }
  });
});
