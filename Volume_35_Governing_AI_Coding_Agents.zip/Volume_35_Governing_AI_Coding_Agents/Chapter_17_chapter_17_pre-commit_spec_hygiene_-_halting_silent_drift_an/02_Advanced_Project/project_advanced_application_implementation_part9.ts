/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

// src/ports/GitPort.ts

/** Read-only Git surface required by the pre-commit gate. */
export interface GitPort {
  /** Returns the list of files currently staged, relative to the repo root. */
  stagedFiles(): Promise<readonly string[]>;
  /** Returns the HEAD content of a path, or null when the path is new. */
  showAtHead(path: string): Promise<string | null>;
  /** Returns the working-tree content of a path. */
  readWorkingTree(path: string): Promise<string>;
}

// src/ports/TraceyPort.ts

/** Minimal Tracey query surface, executed as a subprocess. */
export interface TraceyPort {
  /**
   * Runs `tracey query validate`.
   * @returns exit code and combined stdout+stderr.
   */
  validate(): Promise<{ readonly exitCode: number; readonly output: string }>;
  /** Runs `tracey query stale` and returns its raw output. */
  stale(): Promise<{ readonly exitCode: number; readonly output: string }>;
}
