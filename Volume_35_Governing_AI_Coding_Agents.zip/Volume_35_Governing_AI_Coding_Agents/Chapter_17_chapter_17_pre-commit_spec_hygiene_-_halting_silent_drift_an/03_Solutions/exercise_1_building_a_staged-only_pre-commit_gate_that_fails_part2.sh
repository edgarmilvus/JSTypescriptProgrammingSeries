# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: exercise_1_building_a_staged-only_pre-commit_gate_that_fails_part2.sh
# Description: Solutions and Explanations
# ==========================================

#!/usr/bin/env bash
# Spec-hygiene pre-commit gate. Staged-only.
#
# Exit codes:
#   0 = clean OR skipped because the daemon was unavailable
#   1 = hard failure (broken ref, unknown prefix, duplicate UID,
#                     impl-in-test, cycle, or strict-stale under
#                     SPEC_HYGIENE_STRICT=1)
#   2 = internal error in the wrapper itself (never conflated with 1)
set -u
set -o pipefail

# Reserve exit code 2 for our own failures so it can never be confused with
# a hygiene violation. A violation is the developer's fault; 2 is ours.
trap 'echo "[spec-hygiene] internal wrapper error at line $LINENO" >&2; exit 2' ERR

ROOT="${TRACEY_ROOT:-$(git rev-parse --show-toplevel 2>/dev/null || pwd)}"
SPEC_IMPL="${SPEC_HYGIENE_SPEC_IMPL:-my-api/rust}"
STRICT="${SPEC_HYGIENE_STRICT:-0}"

# --- 1. Staged-set enumeration ----------------------------------------------
# ACMR = Added, Copied, Modified, Renamed. We deliberately omit D (deleted)
# because a deletion of a spec file carries no version-bump obligation.
mapfile -t STAGED < <(git diff --cached --name-only --diff-filter=ACMR)

# Bail out silently if nothing staged matches a spec or source extension.
relevant=0
for f in "${STAGED[@]:-}"; do
  case "$f" in
    *.sdoc|*.md|*.typ|\
    *.rs|*.ts|*.tsx|*.js|*.jsx|*.py|*.go|\
    *.c|*.cc|*.cpp|*.h|*.hpp|*.java|*.kt|*.swift)
      relevant=1; break ;;
  esac
done
[ "$relevant" -eq 0 ] && exit 0

# --- 2. Daemon liveness ------------------------------------------------------
# We never auto-start a daemon from a pre-commit hook. Starting one would:
#   (a) write to .tracey/ inside the tree the user is about to commit,
#   (b) block the commit for seconds while the daemon indexes the project,
#   (c) hide the fact that the user's dev environment is broken.
# The right move is to skip with a visible warning; CI is the authoritative
# gate and will catch anything the skip missed.
if [ ! -f "$ROOT/.tracey/daemon.pid" ]; then
  echo "[spec-hygiene] skipped: daemon not running (no .tracey/daemon.pid)"
  exit 0
fi
if ! timeout 2 tracey query status "$ROOT" >/dev/null 2>&1; then
  echo "[spec-hygiene] skipped: daemon unreachable within 2s"
  exit 0
fi

# --- 3. Run the two queries --------------------------------------------------
validate_out=""
validate_rc=0
# We use PLAIN `validate`, not `validate --deny warnings`. Rationale:
# stale references are warnings; promoting them to hard failures here would
# double-count the work the separate `pre-commit` hook already does, and
# would punish projects that maintain specs in a separate repo. We elevate
# stale to hard-failure only when SPEC_HYGIENE_STRICT=1 (see below).
validate_out=$(tracey query validate --spec_impl "$SPEC_IMPL" "$ROOT" 2>&1) \
  || validate_rc=$?

stale_out=""
stale_out=$(tracey query stale --spec_impl "$SPEC_IMPL" "$ROOT" 2>&1 || true)

# `tracey pre-commit` is a *narrower* check than `validate`: it compares the
# staged spec text against HEAD and fails only when the requirement text
# mutated without a version bump. `validate` scans the checked-out tree for
# structural problems. Both are wanted; each hook is responsible for its own.
bump_out=""
bump_rc=0
if printf '%s\n' "${STAGED[@]}" | grep -qE '\.(sdoc|md|typ)$'; then
  bump_out=$(tracey pre-commit "$ROOT" 2>&1) || bump_rc=$?
fi

# --- 4. Reformatted single-block report -------------------------------------
echo "────────────────────────────────────────────────────────────────"
echo "spec-hygiene gate report  (root=$ROOT, spec_impl=$SPEC_IMPL)"
echo "────────────────────────────────────────────────────────────────"

if [ -n "$validate_out" ]; then
  echo
  echo "[hard failures]"
  printf '%s\n' "$validate_out" | sed 's/^/  /'
fi

if [ -n "$bump_out" ]; then
  echo
  echo "[spec text changed without a version bump]"
  printf '%s\n' "$bump_out" | sed 's/^/  /'
fi

# Rewrite each stale reference into three lines: code location, UID with
# spec/annotation versions, remediation command. sort -u ensures the block
# is byte-identical across runs against the same staged content. Any
# per-run timestamp the tracey banner emits is stripped by the sort.
if [ -n "$stale_out" ] && [ "$stale_out" != "No stale references." ]; then
  echo
  echo "[advisory: stale references]"
  printf '%s\n' "$stale_out" \
    | grep -vE '^(Tracey|tracey|$)' \
    | grep -vE '^[[:space:]]*[0-9]{4}-[0-9]{2}-[0-9]{2}' \
    | sort -u \
    | awk -F'\t' 'NF >= 4 {
        printf("  - code:        %s\n", $1);
        printf("    requirement: %s (spec v%s, annotation v%s)\n", $2, $3, $4);
        printf("    fix:         tracey query rule %s\n", $2);
      }'
fi

echo "────────────────────────────────────────────────────────────────"

# --- 5. Exit decision --------------------------------------------------------
if [ "$validate_rc" -ne 0 ] || [ "$bump_rc" -ne 0 ]; then
  echo "spec-hygiene: BLOCKED (hard failure)."
  exit 1
fi

if [ "$STRICT" = "1" ] && [ -n "$stale_out" ] && [ "$stale_out" != "No stale references." ]; then
  echo "spec-hygiene: BLOCKED (SPEC_HYGIENE_STRICT=1, stale references present)."
  exit 1
fi

echo "spec-hygiene: OK."
exit 0
