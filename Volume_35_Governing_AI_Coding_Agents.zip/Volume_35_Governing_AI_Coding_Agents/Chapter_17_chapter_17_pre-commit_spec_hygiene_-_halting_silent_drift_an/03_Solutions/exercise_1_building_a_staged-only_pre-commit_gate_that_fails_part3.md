<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_1_building_a_staged-only_pre-commit_gate_that_fails_part3.md
Description: Solutions and Explanations
==========================================
-->

# Spec-Hygiene Gate

Exit codes produced by `scripts/spec-hygiene-gate.sh`. The three codes are
deliberately distinct so a CI job can tell "the commit is broken" apart from
"the wrapper itself broke".

## `0` — Clean (or skipped)

Either no staged file matched a spec or source extension, or the Tracey
daemon was unavailable. A skip is always logged as
`[spec-hygiene] skipped:` on stdout. It is never silently equivalent to a
pass; CI re-runs the check as the authoritative gate.

## `1` — Hard failure

Any of the following was detected:

- Broken reference (annotation points at a UID that does not exist).
- Unknown prefix (annotation uses a prefix no spec claims).
- Duplicate UID inside one spec.
- `impl` annotation in a file matched by `test_include`.
- Link cycle between requirements.
- Requirement text changed without a version bump (`tracey pre-commit`).
- `SPEC_HYGIENE_STRICT=1` and stale references present.

## `2` — Internal error

The wrapper itself failed: a git command errored, awk was missing, an
unbound variable tripped `set -u`. Must never be conflated with `1`. A code
`1` means "your commit is wrong", a code `2` means "the tooling is wrong,
re-run or file an issue".
