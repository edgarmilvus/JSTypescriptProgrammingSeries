# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: exercise_2_enforcing_atomic_version_bumps_across_spec_implem.py
# Description: Solutions and Explanations
# ==========================================

#!/usr/bin/env python3
"""
atomic-bump-audit.py — commit-level atomicity check for spec version bumps.

Runs as BOTH pre-commit and commit-msg hooks. Reads the STAGED INDEX, never
the working tree, so what it audits is exactly what a reviewer will see.

Convention (documented here because it is project-specific): StrictDoc
requirement versions live in a `VERSION:` line inside the same
[REQUIREMENT] block as the `UID:`. Markdown requirements put the version
inline as `+N` on the marker. Both map to the same integer semantics; a
value of 1 is the implicit default.

Exit codes:
  0 = every bumped UID has STATUS=OK (or, for new UIDs, the chosen mode
      permits them without bindings)
  1 = at least one bumped UID is MISSING_IMPL / MISSING_VERIFY / MISSING_BOTH
  2 = git or filesystem failure inside the script itself

Env:
  SPEC_HYGIENE_REQUIRE_NEW_BINDINGS
    "0" (default) — brand-new requirements may land without bindings in
    the same commit. Enables the "draft spec first, wire code later"
    workflow that teams want for early design phases.
    "1" — every new requirement must have at least one `verify` annotation
    in the same commit. Use when the project rule is "no requirement gets
    into main without a test".
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

SPEC_EXTS = (".sdoc", ".md", ".typ")

# Verbatim marker grammar for annotation comments. Verb is optional;
# omitted verb defaults to `impl` per Tracey.
MARKER_RE = re.compile(
    r"^[^A-Za-z0-9]*"
    r"(?P<prefix>[a-z][a-z0-9]*)"
    r"\[(?:(?P<verb>impl|verify|depends|related)\s+)?"
    r"(?P<uid>[A-Za-z0-9._-]+?)"
    r"(?:\+(?P<version>\d+))?\]"
)

# Markdown requirement *definition* marker (may be blockquoted).
MD_DEF_RE = re.compile(
    r"^\s*(?:>\s*)?(?P<prefix>[a-z][a-z0-9]*)\["
    r"(?P<uid>[A-Za-z0-9._-]+?)"
    r"(?:\+(?P<version>\d+))?\]\s*$"
)

SDOC_START_RE = re.compile(r"^\[REQUIREMENT\]\s*$")
SDOC_END_RE = re.compile(r"^\[[A-Z_]+\]\s*$")
SDOC_UID_RE = re.compile(r"^UID:\s*(?P<uid>\S+)\s*$")
SDOC_VER_RE = re.compile(r"^VERSION:\s*(?:v)?(?P<v>\d+)\s*$")


@dataclass
class Bump:
    uid: str
    old: int
    new: int
    impl_bumps: int = 0
    verify_bumps: int = 0
    is_new: bool = False

    @property
    def status(self) -> str:
        if self.is_new:
            return "NEW"
        if self.impl_bumps and self.verify_bumps:
            return "OK"
        if not self.impl_bumps and not self.verify_bumps:
            return "MISSING_BOTH"
        return "MISSING_IMPL" if not self.impl_bumps else "MISSING_VERIFY"


def git(*args: str) -> str:
    return subprocess.run(
        ["git", *args], check=True, capture_output=True, text=True
    ).stdout


def staged_files() -> list[str]:
    return [
        ln
        for ln in git("diff", "--cached", "--name-only", "--diff-filter=ACMR").splitlines()
        if ln
    ]


def head_content(path: str) -> str:
    try:
        return git("show", f"HEAD:{path}")
    except subprocess.CalledProcessError:
        return ""


def staged_content(path: str) -> str:
    try:
        return git("show", f":{path}")
    except subprocess.CalledProcessError:
        return ""


def staged_diff(path: str) -> str:
    # -U0 is essential: with default context, unchanged lines appear on both
    # sides and we would double-count bumps.
    return git("diff", "--cached", "-U0", "--", path)


def scan_md_defs(text: str) -> dict[str, int]:
    out: dict[str, int] = {}
    for line in text.splitlines():
        m = MD_DEF_RE.match(line)
        if m:
            out[m.group("uid")] = int(m.group("version") or 1)
    return out


def scan_sdoc_defs(text: str) -> dict[str, int]:
    """Walk [REQUIREMENT] blocks. UID and VERSION may appear in any order
    inside the block; both must come from the *same* block."""
    out: dict[str, int] = {}
    in_block = False
    uid: str | None = None
    version = 1
    for line in text.splitlines():
        if SDOC_START_RE.match(line):
            in_block, uid, version = True, None, 1
            continue
        if not in_block:
            continue
        if SDOC_END_RE.match(line):
            if uid is not None:
                out[uid] = version
            in_block = False
            continue
        mu = SDOC_UID_RE.match(line)
        if mu:
            uid = mu.group("uid")
            continue
        mv = SDOC_VER_RE.match(line)
        if mv:
            version = int(mv.group("v"))
    return out


def definitions(text: str, path: str) -> dict[str, int]:
    if path.endswith(".sdoc"):
        return scan_sdoc_defs(text)
    if path.endswith((".md", ".typ")):
        return scan_md_defs(text)
    return {}


def detect_bumps(path: str) -> dict[str, Bump]:
    old = definitions(head_content(path), path)
    new = definitions(staged_content(path), path)
    out: dict[str, Bump] = {}
    for uid, nv in new.items():
        if uid not in old:
            out[uid] = Bump(uid=uid, old=0, new=nv, is_new=True)
        elif nv > old[uid]:
            out[uid] = Bump(uid=uid, old=old[uid], new=nv)
    return out


def added_versions(diff_text: str) -> dict[tuple[str, str], int]:
    """Map (uid, verb) -> version on the `+` side of the diff."""
    out: dict[tuple[str, str], int] = {}
    for line in diff_text.splitlines():
        if not line.startswith("+") or line.startswith("+++"):
            continue
        m = MARKER_RE.match(line[1:])
        if not m:
            continue
        verb = m.group("verb") or "impl"
        if verb not in ("impl", "verify"):
            continue
        out[(m.group("uid"), verb)] = int(m.group("version") or 1)
    return out


def removed_versions(diff_text: str) -> dict[tuple[str, str], int]:
    out: dict[tuple[str, str], int] = {}
    for line in diff_text.splitlines():
        if not line.startswith("-") or line.startswith("---"):
            continue
        m = MARKER_RE.match(line[1:])
        if not m:
            continue
        verb = m.group("verb") or "impl"
        if verb not in ("impl", "verify"):
            continue
        out[(m.group("uid"), verb)] = int(m.group("version") or 1)
    return out


def apply_binding_deltas(bumps: dict[str, Bump]) -> None:
    """Walk every non-spec staged file, read its -U0 staged diff, and count
    binding bumps against the target version of each bumped requirement.

    Semantics: a binding is only counted when a `+` line is present with
    the exact bumped-to version. A `-` removal without a matching `+` is a
    demotion — nothing is counted, and the UID is reported MISSING_*.
    """
    for path in staged_files():
        if path.endswith(SPEC_EXTS):
            continue
        diff = staged_diff(path)
        if not diff:
            continue
        adds = added_versions(diff)
        for (uid, verb), version in adds.items():
            if uid not in bumps:
                continue
            target = bumps[uid].new
            if version == target:
                if verb == "impl":
                    bumps[uid].impl_bumps += 1
                else:
                    bumps[uid].verify_bumps += 1


def emit_table(bumps: dict[str, Bump], require_new: bool) -> bool:
    rows = sorted(bumps.values(), key=lambda b: (b.uid, b.old))
    if rows:
        print(f"{'UID':<32} {'OLD':>3} {'NEW':>3} {'IMPL':>4} {'VER':>4}  STATUS")
        print("-" * 64)
        for b in rows:
            status = b.status
            if b.is_new and not require_new:
                status = "NEW"
            print(f"{b.uid:<32} {b.old:>3} {b.new:>3} {b.impl_bumps:>4} {b.verify_bumps:>4}  {status}")
    hard_fail = any(
        b.status in ("MISSING_IMPL", "MISSING_VERIFY", "MISSING_BOTH")
        for b in rows
        if not b.is_new
    )
    if require_new:
        hard_fail = hard_fail or any(b.is_new and b.verify_bumps == 0 for b in rows)
    return hard_fail


def main(argv: list[str]) -> int:
    commit_msg_path: str | None = None
    if len(argv) == 2 and Path(argv[1]).name == "COMMIT_EDITMSG":
        commit_msg_path = argv[1]

    bumps: dict[str, Bump] = {}
    for path in staged_files():
        if path.endswith(SPEC_EXTS):
            for uid, b in detect_bumps(path).items():
                if uid not in bumps or b.new > bumps[uid].new:
                    bumps[uid] = b

    apply_binding_deltas(bumps)

    require_new = os.environ.get("SPEC_HYGIENE_REQUIRE_NEW_BINDINGS", "0") == "1"
    hard_fail = emit_table(bumps, require_new)

    if commit_msg_path is not None:
        # A commit trailer is a *stronger* guarantee than a diff walk because
        # it survives history rewriting: `git log --grep` can find the
        # binding decision months later even if the diff itself was squashed,
        # rebased, or cherry-picked without its sibling. The trailer is the
        # developer's *declared intent*; the diff is merely *evidence*.
        msg = Path(commit_msg_path).read_text(encoding="utf-8", errors="replace")
        declared = set(re.findall(r"^Spec-Bump:\s*(\S+?)@\d+->\d+\s*$", msg, re.M))
        missing = sorted(b.uid for b in bumps.values() if b.uid not in declared)
        if missing:
            print()
            print("commit-msg: missing Spec-Bump trailer(s) for: " + ", ".join(missing))
            return 1

    return 1 if hard_fail else 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv))
    except subprocess.CalledProcessError as exc:
        print(f"atomic-bump-audit: git error: {exc}", file=sys.stderr)
        sys.exit(2)
