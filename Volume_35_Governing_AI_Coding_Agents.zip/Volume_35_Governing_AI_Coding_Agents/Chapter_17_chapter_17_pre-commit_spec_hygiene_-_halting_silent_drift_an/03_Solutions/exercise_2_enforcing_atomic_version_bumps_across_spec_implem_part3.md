<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_2_enforcing_atomic_version_bumps_across_spec_implem_part3.md
Description: Solutions and Explanations
==========================================
-->

# Atomic Bump Audit Fixtures

Four synthetic commits, stored as plain-text unified diffs. Each fixture
is a directory containing `spec.diff`, `src.diff` or `tests.diff`, and
`expected.txt`. The audit script is invoked with those diffs applied to a
temp repo; the assertion is on the summary table line and exit code.

| Fixture        | Bumped UID | Bindings staged | Expected exit | Expected table line                        |
|----------------|------------|-----------------|---------------|--------------------------------------------|
| `ok/`          | auth.login | impl+2, verify+2| 0             | `auth.login         1   2    1    1  OK`   |
| `missing-impl/`| auth.login | verify+2 only   | 1             | `auth.login         1   2    0    1  MISSING_IMPL` |
| `missing-verify/`|auth.login| impl+2 only     | 1             | `auth.login         1   2    1    0  MISSING_VERIFY` |
| `new/`         | auth.new   | none            | 0 (default)   | `auth.new            0   1    0    0  NEW`  |

Under `SPEC_HYGIENE_REQUIRE_NEW_BINDINGS=1`, `new/` must exit 1.
