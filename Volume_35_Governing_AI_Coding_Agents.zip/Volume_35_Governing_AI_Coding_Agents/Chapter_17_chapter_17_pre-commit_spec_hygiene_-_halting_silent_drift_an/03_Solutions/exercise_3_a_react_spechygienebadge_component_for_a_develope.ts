/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_a_react_spechygienebadge_component_for_a_develope.ts
Description: Solutions and Explanations
==========================================
*/

export type HygieneDiagnostic =
  | { kind: 'broken-reference'; file: string; line: number; referencedUid: string; suggestion?: string }
  | { kind: 'missing-verify'; file: string; line: number; uid: string; requirementText: string }
  | { kind: 'stale-reference'; file: string; line: number; uid: string; annotationVersion: number; currentVersion: number };

export type BlockedKind =
  | 'broken-ref'
  | 'unknown-prefix'
  | 'duplicate-uid'
  | 'impl-in-test'
  | 'cycle';

export type PollState =
  | { status: 'loading' }
  | { status: 'ok'; diagnostics: HygieneDiagnostic[] }
  | { status: 'advisory'; diagnostics: HygieneDiagnostic[]; staleCount: number }
  | { status: 'blocked'; diagnostics: HygieneDiagnostic[]; failureKind: BlockedKind }
  | { status: 'error'; error: { kind: 'transport' | 'malformed'; message: string } };

export interface SpecHygieneBadgeProps {
  repositoryId: string;
  mcpEndpoint: string;
  pollIntervalMs?: number;
  onDiagnosticClick?: (diagnostic: HygieneDiagnostic) => void;
}
