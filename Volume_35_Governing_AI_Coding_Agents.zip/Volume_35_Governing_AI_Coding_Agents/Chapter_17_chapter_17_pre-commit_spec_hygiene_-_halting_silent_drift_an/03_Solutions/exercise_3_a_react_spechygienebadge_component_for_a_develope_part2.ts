/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_a_react_spechygienebadge_component_for_a_develope_part2.ts
Description: Solutions and Explanations
==========================================
*/

import { useEffect, useRef, useState } from 'react';
import type { BlockedKind, HygieneDiagnostic, PollState } from './types';

const SPEC_IMPL = 'my-api/rust';

/**
 * JSON-RPC request bodies issued, in order, each with a monotonically
 * increasing `id` per session:
 *
 *   1) {"jsonrpc":"2.0","id":1,"method":"tools/call",
 *       "params":{"name":"tracey_validate",
 *                 "arguments":{"spec_impl":"my-api/rust","deny":false}}}
 *
 *   2) {"jsonrpc":"2.0","id":2,"method":"tools/call",
 *       "params":{"name":"tracey_stale",
 *                 "arguments":{"spec_impl":"my-api/rust"}}}
 *
 *   3) {"jsonrpc":"2.0","id":3,"method":"tools/call",
 *       "params":{"name":"tracey_status","arguments":{}}}
 *
 * We do NOT issue `tracey_uncovered` or `tracey_untested` here: those are
 * completeness queries, not pre-commit blockers, and would dilute the
 * badge to the point of uselessness.
 *
 * `staleCount` is carried on the advisory state separately from
 * `diagnostics.length` because a future Tracey may paginate the diagnostic
 * list and return a `total` field — the badge should show the total, not
 * the page size.
 */
export function useSpecHygiene(
  repositoryId: string,
  mcpEndpoint: string,
  pollIntervalMs: number,
): PollState {
  const [state, setState] = useState<PollState>({ status: 'loading' });
  const inFlight = useRef(false);
  const generation = useRef(0);

  useEffect(() => {
    const myGen = ++generation.current;
    const controller = new AbortController();

    async function call(
      id: number,
      name: string,
      args: Record<string, unknown>,
    ): Promise<string> {
      const body = { jsonrpc: '2.0', id, method: 'tools/call', params: { name, arguments: args } };
      const res = await fetch(mcpEndpoint, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      if (!res.ok) throw { kind: 'transport', message: `HTTP ${res.status}` };
      const json = (await res.json()) as any;
      const text = json?.result?.content?.[0]?.text;
      if (typeof text !== 'string') {
        throw { kind: 'malformed', message: 'missing result.content[0].text' };
      }
      return text;
    }

    async function tick(): Promise<void> {
      if (inFlight.current) return; // skip, do not queue
      inFlight.current = true;
      try {
        // Order matters: validate is the blocker, stale is advisory,
        // status is only needed for the delta report.
        const validateText = await call(1, 'tracey_validate', {
          spec_impl: SPEC_IMPL,
          deny: false,
        });
        const staleText = await call(2, 'tracey_stale', { spec_impl: SPEC_IMPL });
        await call(3, 'tracey_status', {});

        if (myGen !== generation.current) return;

        const hardKinds: BlockedKind[] = [];
        if (/broken reference/i.test(validateText)) hardKinds.push('broken-ref');
        if (/unknown prefix/i.test(validateText)) hardKinds.push('unknown-prefix');
        if (/duplicate/i.test(validateText)) hardKinds.push('duplicate-uid');
        if (/impl.*test_include/i.test(validateText)) hardKinds.push('impl-in-test');
        if (/cycle/i.test(validateText)) hardKinds.push('cycle');

        const staleLines = staleText
          .split('\n')
          .filter((ln) => ln.trim().length > 0 && !/^tracey/i.test(ln));
        const diagnostics: HygieneDiagnostic[] = staleLines.map((ln) => ({
          kind: 'stale-reference' as const,
          file: ln.split('\t')[0] || 'unknown',
          line: 1,
          uid: ln.split('\t')[1] || 'unknown',
          annotationVersion: Number(ln.split('\t')[3] || 0),
          currentVersion: Number(ln.split('\t')[2] || 0),
        }));

        if (hardKinds.length > 0) {
          setState({ status: 'blocked', diagnostics, failureKind: hardKinds[0] });
        } else if (diagnostics.length > 0) {
          setState({ status: 'advisory', diagnostics, staleCount: staleLines.length });
        } else {
          setState({ status: 'ok', diagnostics: [] });
        }
      } catch (e: unknown) {
        if (controller.signal.aborted) return;
        const err = e as { kind?: string; message?: string };
        setState({
          status: 'error',
          error: {
            kind: err.kind === 'malformed' ? 'malformed' : 'transport',
            message: err.message ?? String(e),
          },
        });
      } finally {
        inFlight.current = false;
      }
    }

    void tick();
    const h = window.setInterval(tick, pollIntervalMs);
    return () => {
      window.clearInterval(h);
      controller.abort();
      generation.current++; // invalidate any late response
      inFlight.current = false;
    };
  }, [repositoryId, mcpEndpoint, pollIntervalMs]);

  return state;
}
