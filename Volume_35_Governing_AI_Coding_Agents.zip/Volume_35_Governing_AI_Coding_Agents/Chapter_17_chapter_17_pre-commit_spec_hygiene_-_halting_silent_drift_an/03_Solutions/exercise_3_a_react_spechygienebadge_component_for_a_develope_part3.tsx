/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_a_react_spechygienebadge_component_for_a_develope_part3.tsx
Description: Solutions and Explanations
==========================================
*/

import { memo, useMemo } from 'react';
import { useSpecHygiene } from './useSpecHygiene';
import type { HygieneDiagnostic, SpecHygieneBadgeProps } from './types';

// Severity order also drives the title attribute — the two must stay aligned.
const SEVERITY_ORDER: readonly HygieneDiagnostic['kind'][] = [
  'broken-reference',
  'missing-verify',
  'stale-reference',
];

function count(list: readonly HygieneDiagnostic[], kind: HygieneDiagnostic['kind']): number {
  let n = 0;
  for (const d of list) if (d.kind === kind) n += 1;
  return n;
}

export const SpecHygieneBadge = memo(function SpecHygieneBadge({
  repositoryId,
  mcpEndpoint,
  pollIntervalMs = 30_000,
  onDiagnosticClick,
}: SpecHygieneBadgeProps) {
  const state = useSpecHygiene(repositoryId, mcpEndpoint, pollIntervalMs);

  const title = useMemo(() => {
    if (state.status === 'loading') return 'Checking spec hygiene…';
    if (state.status === 'error') return `Spec hygiene error: ${state.error.message}`;
    const parts = SEVERITY_ORDER.map((k) => `${count(state.diagnostics, k)} ${k}`);
    return parts.join(' · ');
  }, [state]);

  const tone =
    state.status === 'ok'
      ? 'green'
      : state.status === 'advisory'
        ? 'amber'
        : state.status === 'blocked' || state.status === 'error'
          ? 'red'
          : 'grey';

  const label =
    state.status === 'ok'
      ? 'Spec OK'
      : state.status === 'advisory'
        ? `Spec: ${state.staleCount} stale`
        : state.status === 'blocked'
          ? 'Spec BLOCKED'
          : state.status === 'error'
            ? 'Spec ?'
            : 'Spec…';

  const topThree =
    state.status === 'blocked' || state.status === 'advisory'
      ? state.diagnostics.slice(0, 3)
      : [];

  return (
    <div className={`spec-hygiene-badge spec-hygiene-badge--${tone}`} title={title}>
      <span className="spec-hygiene-badge__label">{label}</span>
      {topThree.length > 0 && (
        <ul className="spec-hygiene-badge__panel" role="list">
          {topThree.map((d, i) => (
            <li key={`${d.kind}-${i}`} onClick={() => onDiagnosticClick?.(d)}>
              {d.kind} · {d.file}:{d.line}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
});
