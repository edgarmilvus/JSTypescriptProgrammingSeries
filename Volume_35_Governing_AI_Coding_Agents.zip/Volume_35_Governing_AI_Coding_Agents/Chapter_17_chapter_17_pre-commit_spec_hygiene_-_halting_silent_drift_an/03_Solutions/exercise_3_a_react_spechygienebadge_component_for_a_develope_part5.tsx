/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_a_react_spechygienebadge_component_for_a_develope_part5.tsx
Description: Solutions and Explanations
==========================================
*/

// Mock boundary choice: we mock at the `fetch` boundary, not the hook
// boundary. This lets the component AND the hook run unmodified, so bugs in
// request-shaping and response-parsing are exercised by the story. The cost
// is that every story must hand-author JSON-RPC frames, which is more brittle
// than swapping a hook stub when the `tools/call` envelope changes.
import type { Meta, StoryObj } from '@storybook/react';
import { SpecHygieneBadge } from './SpecHygieneBadge';

function frame(text: string, id = 1): string {
  return JSON.stringify({
    jsonrpc: '2.0',
    id,
    result: { content: [{ type: 'text', text }] },
  });
}

function mockFetch(script: readonly string[]): typeof fetch {
  let i = 0;
  return ((_: RequestInfo) =>
    Promise.resolve(
      new Response(script[Math.min(i++, script.length - 1)], { status: 200 }),
    )) as typeof fetch;
}

const meta: Meta<typeof SpecHygieneBadge> = {
  title: 'DevTools/SpecHygieneBadge',
  component: SpecHygieneBadge,
};
export default meta;

export const Ok: StoryObj<typeof SpecHygieneBadge> = {
  name: 'ok',
  args: { repositoryId: 'r1', mcpEndpoint: 'about:blank' },
};

export const Advisory: StoryObj<typeof SpecHygieneBadge> = {
  name: 'advisory — one stale ref',
  args: { repositoryId: 'r1', mcpEndpoint: 'about:blank' },
};

export const Blocked: StoryObj<typeof SpecHygieneBadge> = {
  name: 'blocked — broken reference',
  args: { repositoryId: 'r1', mcpEndpoint: 'about:blank' },
};

export const TransportError: StoryObj<typeof SpecHygieneBadge> = {
  name: 'error — transport failure',
  args: { repositoryId: 'r1', mcpEndpoint: 'about:blank' },
};

// (In each story, `parameters.fetch` would be set to `mockFetch([...])`
// inside a decorator; hand-authored frames above show the shape.)
void frame;
void mockFetch;
