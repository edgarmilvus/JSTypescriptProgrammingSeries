# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: exercise_5_a_custom_strictdoc_grammar_field_to_bind_review_i_part2.py
# Description: Solutions and Explanations
# ==========================================

from strictdoc.core.project_config import ProjectConfig

def project_config() -> ProjectConfig:
    return ProjectConfig(
        project_title="Spec Hygiene Demo",
        # Idempotent grammar import: StrictDoc reads the .sgra file once per
        # document-tree build. Registering it as an alias makes every
        # document that declares `IMPORT_FROM_FILE: @requirements` pick it up
        # without redeclaring the grammar. The alias lookup is a dict lookup,
        # so re-running export does not accumulate declarations.
        grammar_aliases={"requirements": "docs/grammar/requirements.sgra"},
        # Read at hook-invocation time by the gate, NOT baked into the shell
        # script. Extending the deadline must be a reviewable PR.
        REVIEW_GRACE_PERIOD_END="2026-06-30",
    )
