/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_a_custom_strictdoc_grammar_field_to_bind_review_i_part5.ts
Description: Solutions and Explanations
==========================================
*/

/**
 * A requirement's review record, as parsed from a StrictDoc
 * `REVIEWED_AGAINST` field.
 */
export interface ReviewedAgainstRecord {
  /** Requirement UID, e.g. `AUTH-001`. */
  uid: string;
  /** Current version of the requirement, integer ≥ 1. */
  currentVersion: number;
  /**
   * Raw value of the `REVIEWED_AGAINST` field as parsed from the .sdoc file.
   * `undefined` means the field is absent from the requirement block.
   */
  rawReviewedAgainst: string | undefined;
}

export type ReviewStatus =
  | { kind: 'fresh'; uid: string; version: number }
  | { kind: 'stale'; uid: string; recordedVersion: number; currentVersion: number }
  | { kind: 'unreviewed'; uid: string; reason: 'field-absent' | 'field-malformed' };

/**
 * Decide whether a requirement is fresh, stale, or unreviewed.
 *
 * Behavioural contract:
 *   - The value of `rawReviewedAgainst` MUST match `/^v[1-9][0-9]*$/`.
 *     - `v0` is rejected — version numbers start at 1.
 *     - A bare integer (`2`) is rejected — the `v` prefix is required.
 *     - `v2.0` is rejected — decimals are not allowed.
 *     - `V2` is rejected — the `V` prefix is case-sensitive lowercase.
 *     - Leading or trailing whitespace is rejected.
 *   - If the value is well-formed:
 *       - `recordedVersion === currentVersion` → `{ kind: 'fresh' }`.
 *       - `recordedVersion !== currentVersion` (in either direction) →
 *         `{ kind: 'stale' }`. A version rollback (`v4` vs current `3`) is
 *         reported as stale, not a distinct variant, because rollbacks are
 *         always invalid.
 *   - If the field is absent or empty → `{ kind: 'unreviewed', reason:
 *     'field-absent' }`.
 *   - If the field is present and non-empty but does not match the pattern →
 *     `{ kind: 'unreviewed', reason: 'field-malformed' }`.
 *
 * Duplicate-field handling is performed by the parser before this function
 * is called: StrictDoc's reader raises `StrictDocSemanticError` on duplicate
 * field names, so `classifyReviewStatus` never sees a duplicated
 * `REVIEWED_AGAINST`. The Vitest suite documents the expectation that the
 * parser rejects this.
 *
 * @example Fresh
 *   classifyReviewStatus({ uid: 'AUTH-001', currentVersion: 2,
 *     rawReviewedAgainst: 'v2' });
 *   // → { kind: 'fresh', uid: 'AUTH-001', version: 2 }
 *
 * @example Stale (behind)
 *   classifyReviewStatus({ uid: 'AUTH-002', currentVersion: 3,
 *     rawReviewedAgainst: 'v1' });
 *   // → { kind: 'stale', uid: 'AUTH-002', recordedVersion: 1, currentVersion: 3 }
 *
 * @example Stale (rollback — still stale)
 *   classifyReviewStatus({ uid: 'AUTH-004', currentVersion: 3,
 *     rawReviewedAgainst: 'v4' });
 *   // → { kind: 'stale', uid: 'AUTH-004', recordedVersion: 4, currentVersion: 3 }
 *
 * @example Unreviewed — field absent
 *   classifyReviewStatus({ uid: 'AUTH-003', currentVersion: 1,
 *     rawReviewedAgainst: undefined });
 *   // → { kind: 'unreviewed', uid: 'AUTH-003', reason: 'field-absent' }
 *
 * @example Unreviewed — malformed
 *   classifyReviewStatus({ uid: 'AUTH-005', currentVersion: 2,
 *     rawReviewedAgainst: '2' });
 *   // → { kind: 'unreviewed', uid: 'AUTH-005', reason: 'field-malformed' }
 */
export function classifyReviewStatus(record: ReviewedAgainstRecord): ReviewStatus {
  // TODO: implement against the contract above.
  void record;
  throw new Error('not implemented');
}
