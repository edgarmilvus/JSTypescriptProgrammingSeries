/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_a_custom_strictdoc_grammar_field_to_bind_review_i_part6.ts
Description: Solutions and Explanations
==========================================
*/

import { describe, it } from 'vitest';

describe('classifyReviewStatus', () => {
  describe('fresh', () => {
    it.todo('returns fresh when REVIEWED_AGAINST matches the current version (v2 vs 2)');
    it.todo('returns fresh when current version is 1 and REVIEWED_AGAINST is v1');
  });

  describe('stale', () => {
    it.todo('returns stale when REVIEWED_AGAINST is behind current (v1 vs 3) — the AUTH-002 fixture case');
    it.todo('returns stale when REVIEWED_AGAINST is ahead of current (v4 vs 3) — a rollback is still stale');
  });

  describe('unreviewed — field absent', () => {
    it.todo('returns unreviewed with reason field-absent when REVIEWED_AGAINST is undefined — the AUTH-003 fixture case');
    it.todo('returns unreviewed with reason field-absent when the field is present but its value is an empty string');
  });

  describe('unreviewed — malformed', () => {
    it.todo('returns unreviewed with reason field-malformed for v0 (versions start at 1)');
    it.todo('returns unreviewed with reason field-malformed for a bare integer "2" (v prefix required)');
    it.todo('returns unreviewed with reason field-malformed for v2.0 (decimals rejected)');
    it.todo('returns unreviewed with reason field-malformed for uppercase V2 (case-sensitive lowercase v required)');
    it.todo('returns unreviewed with reason field-malformed for trailing whitespace after v2');
    it.todo('returns unreviewed with reason field-malformed for leading whitespace before v2');
  });

  describe('parser contract (not this function)', () => {
    it.todo('the StrictDoc parser rejects a block with two REVIEWED_AGAINST fields before classifyReviewStatus is ever called');
    it.todo('the StrictDoc parser rejects REVIEWED_AGAINST on a TEXT node because the grammar declares it only on REQUIREMENT');
  });
});
