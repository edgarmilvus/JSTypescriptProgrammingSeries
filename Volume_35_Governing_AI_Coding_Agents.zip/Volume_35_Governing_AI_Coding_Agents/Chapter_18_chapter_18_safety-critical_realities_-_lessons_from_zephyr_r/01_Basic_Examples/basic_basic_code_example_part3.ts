/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

// src/auth/session-validator.ts

import { z } from "zod";
import { createPublicKey, verify as cryptoVerify } from "node:crypto";

/**
 * A narrow shape representing the claims we accept on an inbound session
 * token. TypeScript's structural typing is erased at compile time, so this
 * schema is the *runtime* contract. If a payload does not parse, we do not
 * proceed.
 *
 * `exp` and `iat` are Unix epoch seconds, matching the JWT registered claim
 * names and the wording of requirement AUTH-VALIDATE-001.
 */
const SessionClaimsSchema = z
  .object({
    sub: z.string().min(1),
    iss: z.literal("https://auth.example.com"),
    aud: z.literal("https://api.example.com"),
    exp: z.number().int().positive(),
    iat: z.number().int().positive(),
  })
  .strict(); // Reject unknown claims outright.

/** Inferred TypeScript type — used by callers, never trusted at the boundary. */
export type SessionClaims = z.infer<typeof SessionClaimsSchema>;

/**
 * Thrown when the token fails any validation step. The message is stable so
 * that tests can assert on it without coupling to implementation details.
 */
export class SessionTokenError extends Error {
  constructor(public readonly code: SessionTokenErrorCode, message: string) {
    super(message);
    this.name = "SessionTokenError";
  }
}

export type SessionTokenErrorCode =
  | "MALFORMED"
  | "SIGNATURE_INVALID"
  | "EXPIRED";

/**
 * Decoded-but-unverified envelope: whatever the caller handed us, plus the
 * byte slices we need for signature verification. We never trust `claims`
 * until `cryptoVerify` returns true.
 */
interface DecodedToken {
  readonly headerB64: string;
  readonly payloadB64: string;
  readonly signature: Buffer;
  readonly signingInput: string;
  readonly claims: unknown;
}

function decodeToken(raw: string): DecodedToken {
  const parts = raw.split(".");
  if (parts.length !== 3) {
    throw new SessionTokenError("MALFORMED", "token must have three segments");
  }
  const [headerB64, payloadB64, signatureB64] = parts as [string, string, string];
  const signingInput = `${headerB64}.${payloadB64}`;
  let claims: unknown;
  try {
    claims = JSON.parse(Buffer.from(payloadB64, "base64url").toString("utf8"));
  } catch {
    throw new SessionTokenError("MALFORMED", "payload is not valid JSON");
  }
  return {
    headerB64,
    payloadB64,
    signature: Buffer.from(signatureB64, "base64url"),
    signingInput,
    claims,
  };
}

/**
 * @param raw         The untrusted bearer token, exactly as received on the wire.
 * @param publicKeyPem PEM-encoded RS256 public key used to verify the signature.
 * @param nowSeconds  Current wall-clock time in whole seconds — injected, not read
 *                    from `Date.now()`, so tests can control the boundary.
 *
 * @relation(AUTH-VALIDATE-001, scope=function)
 */
export function validateSessionToken(
  raw: string,
  publicKeyPem: string,
  nowSeconds: number,
): SessionClaims {
  // Step 1 — Structural decode. Cheap, no crypto, may throw MALFORMED.
  const decoded = decodeToken(raw);

  // Step 2 — Signature verification. This is the expensive step; we run it
  // before touching the untrusted `claims` payload. Compliant with the
  // "signature first" ordering from the RATIONALE of AUTH-VALIDATE-001.
  const publicKey = createPublicKey(publicKeyPem);
  const signatureOk = cryptoVerify(
    "RSA-SHA256",
    Buffer.from(decoded.signingInput, "utf8"),
    publicKey,
    decoded.signature,
  );
  if (!signatureOk) {
    throw new SessionTokenError("SIGNATURE_INVALID", "signature does not verify");
  }

  // Step 3 — Runtime schema validation of the now-authenticated claims.
  const parsed = SessionClaimsSchema.safeParse(decoded.claims);
  if (!parsed.success) {
    throw new SessionTokenError("MALFORMED", "claims failed schema validation");
  }
  const claims = parsed.data;

  // Step 4 — Expiry check. The requirement is *strictly greater than* now.
  // Equality is a rejection. This is deliberate and is what the tests below
  // pin down.
  if (!(claims.exp > nowSeconds)) {
    throw new SessionTokenError("EXPIRED", "token has expired");
  }

  return claims;
}
