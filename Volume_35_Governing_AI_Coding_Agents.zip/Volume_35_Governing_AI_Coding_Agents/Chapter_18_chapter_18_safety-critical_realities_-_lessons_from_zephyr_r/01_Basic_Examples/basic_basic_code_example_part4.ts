/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// tests/auth/session-validator.test.ts

import { describe, it, expect } from "vitest";
import { generateKeyPairSync, sign as cryptoSign } from "node:crypto";
import {
  validateSessionToken,
  SessionTokenError,
  type SessionClaims,
} from "../../src/auth/session-validator";

/**
 * Fixture helper: mint a real RS256-signed token for a given payload. Using
 * a real key pair keeps the tests honest — they exercise the same code path
 * that production uses, rather than mocking the crypto layer away.
 */
function mintToken(claims: Record<string, unknown>, privateKeyPem: string): string {
  const header = Buffer.from(
    JSON.stringify({ alg: "RS256", typ: "JWT" }),
  ).toString("base64url");
  const payload = Buffer.from(JSON.stringify(claims)).toString("base64url");
  const signingInput = `${header}.${payload}`;
  const signature = cryptoSign("RSA-SHA256", Buffer.from(signingInput), privateKeyPem);
  return `${signingInput}.${signature.toString("base64url")}`;
}

const { privateKey, publicKey } = generateKeyPairSync("rsa", {
  modulusLength: 2048,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

const NOW = 1_700_000_000; // Deterministic "now" for every test.

function baseClaims(overrides: Partial<SessionClaims> = {}): Record<string, unknown> {
  return {
    sub: "user-123",
    iss: "https://auth.example.com",
    aud: "https://api.example.com",
    iat: NOW - 60,
    exp: NOW + 60,
    ...overrides,
  };
}

// @relation(AUTH-VALIDATE-001, role=Verifies, scope=function)
describe("validateSessionToken — AUTH-VALIDATE-001", () => {
  it("accepts a well-formed, signature-valid, unexpired token", () => {
    const token = mintToken(baseClaims(), privateKey);
    const result = validateSessionToken(token, publicKey, NOW);
    expect(result.sub).toBe("user-123");
  });

  it("rejects a token whose exp equals now (strictly-greater-than boundary)", () => {
    const token = mintToken(baseClaims({ exp: NOW }), privateKey);
    expect(() => validateSessionToken(token, publicKey, NOW)).toThrowError(
      /token has expired/,
    );
  });

  it("rejects a token whose exp is in the past", () => {
    const token = mintToken(baseClaims({ exp: NOW - 1 }), privateKey);
    expect(() => validateSessionToken(token, publicKey, NOW)).toThrow(
      SessionTokenError,
    );
  });

  it("rejects a token with a tampered signature", () => {
    const token = mintToken(baseClaims(), privateKey);
    const [h, p] = token.split(".");
    const forged = `${h}.${p}.${"A".repeat(344)}`; // 2048-bit RSA sig, base64url.
    expect(() => validateSessionToken(forged, publicKey, NOW)).toThrowError(
      /signature does not verify/,
    );
  });

  it("rejects a token whose claims contain unknown fields", () => {
    const token = mintToken(baseClaims({ role: "admin" }), privateKey);
    expect(() => validateSessionToken(token, publicKey, NOW)).toThrowError(
      /claims failed schema validation/,
    );
  });
});
