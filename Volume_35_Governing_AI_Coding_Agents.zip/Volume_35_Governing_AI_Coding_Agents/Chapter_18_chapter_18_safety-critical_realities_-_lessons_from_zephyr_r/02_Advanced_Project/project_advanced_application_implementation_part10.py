# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_implementation_part10.py
# Description: Advanced Application Implementation
# ==========================================

"""Model the Zephyr trace report contract for the Aegis test flow.

The real Zephyr RTOS emits test-suite metadata via its testing subsystem.
Aegis is a Rust-first project, so we model the contract in Python and
assert that the emitted trace report satisfies the requirements in
docs/spec/zephyr_trace_contract.sdoc.

This is a *verification* module: it may only use the `verify` verb.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable


@dataclass(frozen=True)
class ZephyrTestRecord:
    suite: str
    name: str
    #: The macro shape used to declare the test. One of
    #: {"ZTEST", "ZTEST_USER", "ZTEST_F"}.
    macro: str
    #: Tracey annotations harvested from the source comment above the macro.
    tracey_annotations: tuple[str, ...] = field(default_factory=tuple)


# @relation(ZEPHYR-TRACE-001, scope=function, role=Verifies)
def test_ztest_user_is_verification_bearing(records: Iterable[ZephyrTestRecord]) -> None:
    """ZTEST_USER declarations are first-class verifiable units.

    Asserting the trace contract: every ZTEST_USER record with a
    `verify` annotation is surfaced in the traceability graph.
    """
    for rec in records:
        if rec.macro == "ZTEST_USER":
            assert any(
                ann.startswith("verify ") for ann in rec.tracey_annotations
            ), f"ZTEST_USER {rec.suite}/{rec.name} lacks a verify annotation"


# @relation(ZEPHYR-TRACE-002, scope=function, role=Verifies)
def test_ztest_f_may_not_annotate_hlr(records: Iterable[ZephyrTestRecord]) -> None:
    """ZTEST_F fixture tests may only verify LLRs."""
    for rec in records:
        if rec.macro == "ZTEST_F":
            for ann in rec.tracey_annotations:
                _, _, uid = ann.partition(" ")
                assert not uid.startswith("HLR-"), (
                    f"ZTEST_F {rec.suite}/{rec.name} illegally annotates "
                    f"HLR {uid}; fixture tests shall verify LLRs only"
                )


# @relation(ZEPHYR-TRACE-003, scope=function, role=Verifies)
def test_trace_hooks_do_not_alter_binary(tmp_elf_paths: tuple[str, str]) -> None:
    """Trace hooks must be control-flow-free.

    Compare the disassembly of the instrumented and un-instrumented ELF
    images; assert that the text sections are byte-identical after
    stripping the tracing metadata.
    """
    import hashlib
    text_hash_a = _text_section_hash(tmp_elf_paths[0])
    text_hash_b = _text_section_hash(tmp_elf_paths[1])
    assert text_hash_a == text_hash_b


def _text_section_hash(elf_path: str) -> str:
    with open(elf_path, "rb") as fp:
        # Only the .text section matters; a real implementation
        # would use `objcopy --only-section=.text`.
        return hashlib.sha256(fp.read()).hexdigest()
