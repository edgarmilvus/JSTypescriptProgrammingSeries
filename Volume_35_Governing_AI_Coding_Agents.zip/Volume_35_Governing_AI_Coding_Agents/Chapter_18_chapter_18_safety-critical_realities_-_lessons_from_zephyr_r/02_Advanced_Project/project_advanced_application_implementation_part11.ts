/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part11.ts
Description: Advanced Application Implementation
==========================================
*/

// web/src/ledger/command-ledger.ts
//
// Append-only command ledger for the Aegis ground station. The ledger
// produces the operator-facing audit trail required by HLR-AUD-001 and
// is the SaaS surface of LLR-AUD-021.

/**
 * A single journal entry. Every field except `previousHash` is
 * immutable once the entry is written. `previousHash` binds the entry
 * to its predecessor, forming a SHA-256 hash chain.
 */
export interface LedgerEntry {
  /** Monotonic sequence number, starting at 1 for the genesis entry. */
  readonly seq: number;
  /** UTC millisecond timestamp. */
  readonly timestamp: number;
  /** Operator identity — a signed OIDC subject claim. */
  readonly operator: string;
  /** Canonical JSON of the command payload. */
  readonly command: string;
  /** SHA-256 of the *serialized previous entry*, hex-encoded. */
  readonly previousHash: string;
}

/** Genesis hash — the all-zero vector per LLR-AUD-021. */
const GENESIS_HASH =
  "0000000000000000000000000000000000000000000000000000000000000000";

/**
 * Cryptographically chained, append-only ledger.
 *
 * Invariants enforced at the type level and at runtime:
 *  - No public method mutates or deletes a written entry.
 *  - `append` refuses to accept an entry whose `previousHash` does not
 *    match the current head.
 *  - `verify` walks the chain end-to-end and returns the first broken
 *    link, or `undefined` if the chain is intact.
 */
export class CommandLedger {
  private readonly entries: readonly LedgerEntry[] = [];

  /**
   * Append a new entry to the ledger.
   *
   * The caller provides the *payload*; the ledger assigns `seq`,
   * `timestamp`, and `previousHash`. This is the only write path.
   *
   * // r[impl LLR-AUD-021]
   * // @relation(HLR-AUD-001, scope=function, role=Implements)
   */
  async append(operator: string, command: string): Promise<LedgerEntry> {
    const previousHash = this.head()?.previousHash ?? GENESIS_HASH;
    const seq = this.entries.length + 1;
    const entry: LedgerEntry = {
      seq,
      timestamp: Date.now(),
      operator,
      command: canonicalize(command),
      previousHash: await sha256(previousHash),
    };
    this.entries = Object.freeze([...this.entries, entry]);
    return entry;
  }

  /**
   * Verify the hash chain end-to-end.
   *
   * Returns `undefined` if intact, or the index of the first broken
   * link. This is the audit-time entry point used by the DO-178C
   * compliance report generator.
   *
   * // r[verify LLR-AUD-021]
   */
  async verify(): Promise<number | undefined> {
    let expected = GENESIS_HASH;
    for (const [index, entry] of this.entries.entries()) {
      const expectedNext = await sha256(expected);
      if (entry.previousHash !== expectedNext) {
        return index;
      }
      expected = entry.previousHash;
    }
    return undefined;
  }

  /** Snapshot of the current head, if any. */
  head(): LedgerEntry | undefined {
    return this.entries[this.entries.length - 1];
  }

  /** Read-only view for audit tooling. */
  snapshot(): readonly LedgerEntry[] {
    return this.entries;
  }
}

/**
 * Canonical JSON serialization. Field ordering is fixed so that the
 * hash chain is reproducible across runtime implementations.
 */
function canonicalize(value: string): string {
  return JSON.stringify({ v: 1, payload: value });
}

/** SHA-256 in hex. Uses WebCrypto when available. */
async function sha256(input: string): Promise<string> {
  const bytes = new TextEncoder().encode(input);
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)]
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }
  throw new Error("WebCrypto not available — grounding the ledger requires it");
}
