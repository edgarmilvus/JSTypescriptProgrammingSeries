/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

// web/src/ledger/command-ledger.test.ts
//
// Verification suite for HLR-AUD-001 and LLR-AUD-021.
// Per Tracey config: `test_include` files may ONLY contain `verify`
// annotations.

import { describe, it, expect } from "vitest";
import { CommandLedger, type LedgerEntry } from "./command-ledger";

describe("CommandLedger", () => {
  // r[verify LLR-AUD-021]
  it("assigns monotonic sequence numbers starting at 1", async () => {
    const ledger = new CommandLedger();
    const a = await ledger.append("op-1", "arm");
    const b = await ledger.append("op-1", "takeoff");
    expect(a.seq).toBe(1);
    expect(b.seq).toBe(2);
  });

  // r[verify HLR-AUD-001]
  it("persists accepted commands with operator identity and timestamp", async () => {
    const before = Date.now();
    const ledger = new CommandLedger();
    const entry = await ledger.append("op-42", "waypoint:add");
    const after = Date.now();
    expect(entry.operator).toBe("op-42");
    expect(entry.timestamp).toBeGreaterThanOrEqual(before);
    expect(entry.timestamp).toBeLessThanOrEqual(after);
  });

  // r[verify LLR-AUD-021]
  it("chains entries by SHA-256 of the previous entry", async () => {
    const ledger = new CommandLedger();
    const a = await ledger.append("op-1", "arm");
    const b = await ledger.append("op-1", "takeoff");
    expect(a.previousHash).toBe("0".repeat(64));
    expect(b.previousHash).not.toBe(a.previousHash);
  });

  // r[verify LLR-AUD-021]
  it("detects a broken chain during verify()", async () => {
    const ledger = new CommandLedger();
    await ledger.append("op-1", "arm");
    await ledger.append("op-1", "takeoff");
    // Tamper: forcibly corrupt the read view via casting.
    const entries = ledger.snapshot() as unknown as LedgerEntry[];
    (entries[1] as { previousHash: string }).previousHash = "deadbeef";
    const broken = await ledger.verify();
    expect(broken).toBe(1);
  });

  // r[verify HLR-AUD-001]
  it("freezes the entries array after every append", async () => {
    const ledger = new CommandLedger();
    await ledger.append("op-1", "arm");
    expect(Object.isFrozen(ledger.snapshot())).toBe(true);
  });
});
