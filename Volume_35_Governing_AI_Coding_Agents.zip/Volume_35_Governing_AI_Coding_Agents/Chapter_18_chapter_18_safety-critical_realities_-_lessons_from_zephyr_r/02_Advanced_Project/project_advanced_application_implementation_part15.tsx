/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part15.tsx
Description: Advanced Application Implementation
==========================================
*/

// web/src/app/agent/AgentConsole.tsx

"use client";

import { useChat } from "ai/react";

/**
 * Streaming console that surfaces the pre-flight plan, the generated
 * patch, and the Tracey validation report to the operator.
 */
export function AgentConsole({ llrUid }: { llrUid: string }) {
  const { messages, input, handleInputChange, handleSubmit, isLoading } =
    useChat({
      api: "/api/agent",
      body: { llrUid },
    });

  return (
    <section aria-label="Coding agent console">
      <ol>
        {messages.map((m) => (
          <li key={m.id} data-role={m.role}>
            <pre>{m.content}</pre>
          </li>
        ))}
      </ol>
      <form onSubmit={handleSubmit}>
        <textarea
          value={input}
          onChange={handleInputChange}
          placeholder={`Describe the change for ${llrUid}`}
        />
        <button type="submit" disabled={isLoading}>
          {isLoading ? "Generating…" : "Generate patch"}
        </button>
      </form>
    </section>
  );
}
