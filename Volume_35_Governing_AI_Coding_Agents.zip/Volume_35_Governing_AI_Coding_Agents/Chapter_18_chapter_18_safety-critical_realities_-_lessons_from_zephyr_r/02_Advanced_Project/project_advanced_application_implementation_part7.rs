/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.rs
Description: Advanced Application Implementation
==========================================
*/

//! Attitude-control PID with envelope saturation guard.
//!
//! This module discharges LLR-NAV-011, which is a refinement of
//! HLR-NAV-001 ("Attitude Control Loop"). Every public entry point
//! carries a Tracey `impl` annotation so that `tracey query uncovered`
//! returns an empty set for the NAV family.

use core::f64::consts::TAU;

/// Actuator envelope for the elevator axis, in normalized units.
/// Per LLR-NAV-011 this is the hard outer bound; the air-data rate
/// limit is the inner bound and is applied on top.
const ELEVATOR_ENVELOPE: (f64, f64) = (-1.0, 1.0);

/// Maximum angular rate commanded as a rate limit before saturation.
/// Derived from HLR-NAV-001's "air-data-derived rate limit".
const MAX_ANGULAR_RATE: f64 = 2.5; // rad/s

/// Pure PID accumulator over one control cycle.
///
/// # Safety contract
/// `dt` must be strictly positive and no greater than 10 ms to preserve
/// the 400 Hz loop discipline required by HLR-NAV-001.
// r[impl LLR-NAV-011]
pub fn step(
    state: &mut PidState,
    error: f64,
    dt: f64,
    rate_limit: f64,
) -> f64 {
    debug_assert!(dt > 0.0 && dt <= 0.010, "dt outside 400 Hz budget");

    // Integral accumulation in f64 to preserve precision across
    // long-duration flights (LLR-NAV-011: "accumulated in f64").
    state.integral += error * dt;

    // Anti-windup: clamp the integral term using the same envelope
    // as the final output so that recovery from saturation is
    // monotonic.
    state.integral = state.integral.clamp(ELEVATOR_ENVELOPE.0, ELEVATOR_ENVELOPE.1);

    let raw = state.kp * error
        + state.ki * state.integral
        + state.kd * (error - state.prev_error) / dt;
    state.prev_error = error;

    // Single arithmetic step clamping (LLR-NAV-011 constraint).
    clamp_to_envelope(raw, rate_limit)
}

/// Saturation guard. This is the pure-function half of LLR-NAV-011:
/// it has no interior state and returns a bounded scalar.
// r[impl LLR-NAV-011]
#[inline]
pub fn clamp_to_envelope(raw: f64, rate_limit: f64) -> f64 {
    let (lo, hi) = ELEVATOR_ENVELOPE;
    // The effective bound is the stricter of the envelope and the
    // air-data rate limit.
    let eff = rate_limit.clamp(0.0, MAX_ANGULAR_RATE);
    raw.clamp(lo * eff, hi * eff)
}

/// Mutable control-loop state. Isolated here so that the `step`
/// function can be audited as a pure transformation over `PidState`.
#[derive(Clone, Copy)]
pub struct PidState {
    pub kp: f64,
    pub ki: f64,
    pub kd: f64,
    pub integral: f64,
    pub prev_error: f64,
}
