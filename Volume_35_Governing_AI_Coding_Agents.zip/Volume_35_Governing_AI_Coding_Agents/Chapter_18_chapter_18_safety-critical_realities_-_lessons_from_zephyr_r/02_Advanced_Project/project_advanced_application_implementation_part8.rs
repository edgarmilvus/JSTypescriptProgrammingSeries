/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.rs
Description: Advanced Application Implementation
==========================================
*/

//! Waypoint fence intersection testing.
//!
//! Discharges LLR-NAV-012. Uses great-circle segment intersection on the
//! earth-fixed sphere. All angular math is in radians with f64 precision
//! per the LLR's numeric requirements.

use core::f64::consts::PI;

/// Result of a fence-intersection test.
///
/// Carries the intersection point, the segment endpoints, and a monotonic
/// detection counter so that the ground station can journal the event.
#[derive(Debug, Clone, Copy)]
pub struct FenceEvent {
    pub intersection_lat: f64,
    pub intersection_lon: f64,
    pub seg_start_lat: f64,
    pub seg_start_lon: f64,
    pub seg_end_lat: f64,
    pub seg_end_lon: f64,
    pub detection_counter: u64,
}

/// Test whether the great-circle track from `(lat0, lon0)` to
/// `(lat1, lon1)` intersects a registered fence segment.
///
/// Returns `Some(FenceEvent)` when intersection is detected, `None`
/// otherwise. The counter is monotonic across the process lifetime.
// r[impl LLR-NAV-012]
pub fn intersects_fence(
    lat0: f64,
    lon0: f64,
    lat1: f64,
    lon1: f64,
    fence: &Fence,
    counter: &mut u64,
) -> Option<FenceEvent> {
    // Convert degrees to radians once; interior math uses rad only.
    let (a, b, c, d) = (
        to_rad(lat0), to_rad(lon0),
        to_rad(lat1), to_rad(lon1),
    );
    for seg in fence.segments() {
        if let Some((ilat, ilon)) = great_circle_intersect(
            a, b, c, d,
            to_rad(seg.start_lat), to_rad(seg.start_lon),
            to_rad(seg.end_lat),   to_rad(seg.end_lon),
        ) {
            *counter = counter.wrapping_add(1);
            return Some(FenceEvent {
                intersection_lat: to_deg(ilat),
                intersection_lon: to_deg(ilon),
                seg_start_lat:    seg.start_lat,
                seg_start_lon:    seg.start_lon,
                seg_end_lat:      seg.end_lat,
                seg_end_lon:      seg.end_lon,
                detection_counter: *counter,
            });
        }
    }
    None
}

#[inline]
fn to_rad(deg: f64) -> f64 { deg * PI / 180.0 }

#[inline]
fn to_deg(rad: f64) -> f64 { rad * 180.0 / PI }

/// Stub of the spherical geodesic intersection test.
/// The concrete numeric implementation is intentionally omitted here
/// for clarity; the Tracey annotation on `intersects_fence` is what
/// matters for the intent graph.
fn great_circle_intersect(
    _lat0: f64, _lon0: f64, _lat1: f64, _lon1: f64,
    _flat0: f64, _flon0: f64, _flat1: f64, _flon1: f64,
) -> Option<(f64, f64)> {
    // ...
    None
}

pub struct Fence { /* ... */ }

pub struct FenceSegment {
    pub start_lat: f64,
    pub start_lon: f64,
    pub end_lat: f64,
    pub end_lon: f64,
}

impl Fence {
    pub fn segments(&self) -> impl Iterator<Item = &FenceSegment> {
        // ...
        core::iter::empty()
    }
}
