# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_implementation_part9.py
# Description: Advanced Application Implementation
# ==========================================

"""LLR-NAV-011 verification harness.

This module discharges DO-178C objective A-7 for the PID saturation
guard: it establishes that the Rust implementation of `clamp_to_envelope`
saturates exactly at the effective boundary derived from the union of the
actuator envelope and the air-data rate limit.

Verification method: requirements-based test (RBT), black-box against the
WASM-exposed control core. Each test asserts a specific normative clause
of LLR-NAV-011.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

# @relation(LLR-NAV-011, scope=function, role=Verifies)
def test_pid_output_clamped_to_actuator_envelope() -> None:
    """The PID output shall never exceed the actuator envelope.

    Normative clause: "clamp the PID output to the union of the current
    actuator envelope and the air-data-derived rate limit".
    """
    from aegis_wasm import clamp_to_envelope  # WASM binding of the Rust core

    # Envelope is [-1.0, 1.0]; rate_limit is 1.0 so the effective bound
    # is (-1.0, 1.0). Feed wildly out-of-range values and assert.
    assert clamp_to_envelope(10.0, 1.0) == 1.0
    assert clamp_to_envelope(-10.0, 1.0) == -1.0
    assert clamp_to_envelope(0.5, 1.0) == 0.5


# @relation(LLR-NAV-011, scope=function, role=Verifies)
def test_pid_output_respects_rate_limit() -> None:
    """The rate limit shall tighten the envelope, never loosen it.

    Normative clause: "air-data-derived rate limit". The effective bound
    is min(envelope, rate_limit) scaled.
    """
    from aegis_wasm import clamp_to_envelope

    # rate_limit = 0.5 means max magnitude is 0.5 even though the
    # envelope allows 1.0.
    assert clamp_to_envelope(10.0, 0.5) == 0.5
    assert clamp_to_envelope(-10.0, 0.5) == -0.5


# @relation(LLR-NAV-011, scope=function, role=Verifies)
def test_pid_integral_accumulated_as_f64() -> None:
    """Integral term shall be f64 across the 400 Hz loop.

    Normative clause: "Unbounded PID terms shall be accumulated in f64".
    We assert exact equality against a reference f64 accumulator that is
    driven at 400 Hz for 10 simulated seconds — the accumulated error
    must be bit-identical to the reference.
    """
    from aegis_wasm import PidState, step

    state = PidState(kp=1.0, ki=0.1, kd=0.01, integral=0.0, prev_error=0.0)
    ref_integral = 0.0
    dt = 0.0025  # 400 Hz

    for i in range(4000):  # 10 s
        error = 0.1 * ((i % 7) - 3)
        step(state, error, dt, 2.5)
        ref_integral += error * dt

    # Allow the same clamp-on-windup behavior as the Rust implementation.
    from aegis_wasm import clamp_to_envelope as _clamp
    expected = max(-1.0, min(1.0, ref_integral))
    assert abs(state.integral - expected) < 1e-12
