/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_zephyr-style_test_harness_traceability_across_a_k.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================================
// Exercise 1 — LumenRTOS Semaphore Subsystem
//
// This file is the *entire* governance slice in one place:
//   • the StrictDoc spec (as an embedded string, byte-identical to
//     docs/spec/semaphore.sdoc on disk),
//   • the Tracey config (docs .styx),
//   • the TypeScript equivalent of the WASM-compiled semaphore module,
//   • the Vitest tests with r[verify] annotations,
//   • a miniature Tracey-compatible gate that parses the spec + annotations,
//     computes bidirectional coverage, and reproduces the three failure modes
//     the exercise asks us to provoke.
// ============================================================================

// ---------------------------------------------------------------------------
// 1. SPEC ARTIFACT — docs/spec/semaphore.sdoc
//
// UID scheme: SEM-<AREA>-<NNN>.  Stable, greppable, sortable.  We hand-assign
// every UID (no AUTO_UIDS) because DOCUMENT blocks that use AUTO_UIDS must also
// declare PREFIX, and for a 4-requirement safety slice predictable numbers are
// worth more than automation.
//
// Decomposition: SEM-SAFE-000 is the *emergent* property ("no deadlock") and
// is the parent of SEM-COUNT-002 and SEM-ORDER-004.  In StrictDoc idiom the
// child declares the parent link via `RELATIONS: - TYPE: Parent`, and
// StrictDoc's graph database computes the reverse Child edge automatically.
// ---------------------------------------------------------------------------
export const SEMAPHORE_SDOC = `[DOCUMENT]
TITLE: LumenRTOS Semaphore Subsystem Specification
PREFIX: SEM-
OPTIONS:
  MARKUP: Text
  VIEW_STYLE: Narrative

[[SECTION]]
TITLE: Semaphore Subsystem

[REQUIREMENT]
UID: SEM-SAFE-000
STATUS: Approved
TITLE: Deadlock freedom under concurrent take/give
STATEMENT: >>>
While multiple callers concurrently invoke take and give on the same
semaphore, the semaphore subsystem shall not deadlock, livelock, or leak
permit counts, provided every successful take is eventually matched by a
give.
<<<
RATIONALE: >>>
Firmware tasks routinely share one semaphore across ISR and thread context.
If the permit ledger can be corrupted by an interleaving, a single lost wake
strands a task forever and the watchdog reboots the board.  The emergent
property is therefore stronger than either invariant alone: the counting
invariant guarantees the ledger is consistent, and the ordering invariant
guarantees waiters are drained, and together they preclude starvation.
<<<

[REQUIREMENT]
UID: SEM-COUNT-002
STATUS: Approved
TITLE: Permit count is never negative and never exceeds the initial count
STATEMENT: >>>
When a caller performs take, the semaphore subsystem shall decrement the
permit count no lower than zero, and when a caller performs give, the
semaphore subsystem shall raise the permit count no higher than the initial
count supplied at construction.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: SEM-SAFE-000

[REQUIREMENT]
UID: SEM-ORDER-004
STATUS: Approved
TITLE: Waiters are released in first-in first-out order
STATEMENT: >>>
When there are multiple blocked callers and a give occurs, the semaphore
subsystem shall release the caller that arrived earliest among the blocked
callers.
<<<
RELATIONS:
- TYPE: Parent
  VALUE: SEM-SAFE-000

[REQUIREMENT]
UID: SEM-TIMEOUT-003
STATUS: Approved
TITLE: Bounded waits honour the caller-supplied timeout
STATEMENT: >>>
When a caller invokes take with a finite timeout and no permit becomes
available before the timeout elapses, the semaphore subsystem shall return
failure to the caller without consuming a permit and without placing the
caller on the wait queue.
<<<
[/SECTION]
`;

// ---------------------------------------------------------------------------
// 2. TRACEY CONFIG — .config/tracey/config.styx
//
// Two implementations: production (`rust` label, but scanning .ts here since
// the firmware is compiled to WASM and the shim lives in TypeScript) and a
// test impl scoped via test_include.  Anything under test_include may carry
// ONLY verify annotations; Tracey errors on impl-in-test-file.
// ---------------------------------------------------------------------------
export const TRACEY_CONFIG_STYX = `@schema {id crate:tracey-config@1, cli tracey}

specs (
  {
    name lumenrtos-semaphore
    source_url https://example.invalid/lumenrtos
    include (docs/spec/semaphore.sdoc)
    impls (
      {
        name rust
        include (src/**/*.ts)
        exclude (src/**/*.test.ts src/**/*.spec.ts)
      }
      {
        name vitest
        include (tests/**/*.ts)
        test_include (tests/**/*.ts)
      }
    )
  }
)
`;

// ---------------------------------------------------------------------------
// 3. IMPLEMENTATION — src/semaphore.ts
//
// A counting semaphore with FIFO waiter release.  Every function that
// contributes to satisfying a requirement carries an r[impl] annotation.
// ============================================================================

interface Waiter {
  readonly resolve: (acquired: boolean) => void;
  readonly deadlineMs: number | null; // null => unbounded
}

/**
 * Counting semaphore.  Public boundary is `tryTake`, `take`, `give`.
 *
 * The class declaration itself carries SEM-SAFE-000 because the emergent
 * "no deadlock" property is a property of the *ledger+queue as a whole*, not
 * of any single method.  Per-method annotations below justify the split.
 */
// r[impl SEM-SAFE-000]
export class Semaphore {
  private count: number;
  private readonly initial: number;
  private readonly waiters: Waiter[] = [];

  constructor(initialCount: number) {
    if (!Number.isInteger(initialCount) || initialCount < 0) {
      throw new RangeError("Semaphore initialCount must be a non-negative integer");
    }
    this.initial = initialCount;
    this.count = initialCount;
  }

  // r[impl SEM-COUNT-002]
  tryTake(): boolean {
    if (this.count > 0) {
      this.count -= 1;
      return true;
    }
    return false;
  }

  // r[impl SEM-COUNT-002]
  // r[impl SEM-ORDER-004]
  give(): void {
    if (this.count >= this.initial && this.waiters.length === 0) {
      // Saturating release: preserve the "never exceed initial" invariant
      // instead of throwing, so that a spurious give from a noisy driver
      // cannot wedge the scheduler.
      return;
    }
    const next = this.waiters.shift();
    if (next !== undefined) {
      // We never materialise the permit-and-immediately-reconsume dance:
      // handing it directly to the head waiter is what preserves FIFO.
      next.resolve(true);
      return;
    }
    if (this.count < this.initial) {
      this.count += 1;
    }
  }

  // r[impl SEM-TIMEOUT-003]
  // r[impl SEM-ORDER-004]
  take(timeoutMs: number): Promise<boolean> {
    if (this.count > 0) {
      this.count -= 1;
      return Promise.resolve(true);
    }
    if (timeoutMs <= 0) {
      // The negative-path branch: no permit, no queue entry, immediate
      // failure.  SEM-TIMEOUT-003 is verified specifically against this arm.
      return Promise.resolve(false);
    }
    return new Promise<boolean>((resolve) => {
      const waiter: Waiter = {
        resolve,
        deadlineMs: Date.now() + timeoutMs,
      };
      this.waiters.push(waiter);
      setTimeout(() => {
        const idx = this.waiters.indexOf(waiter);
        if (idx !== -1) {
          this.waiters.splice(idx, 1);
          resolve(false);
        }
      }, timeoutMs);
    });
  }
}

// Convenience helpers consumed by the interleaving test — also annotated.
// r[impl SEM-SAFE-000]
export function ledgerInvariantHolds(s: Semaphore, snapshot: number): boolean {
  // This is intentionally a "witness function": the test calls it after each
  // interleaving step and asserts it holds.  It carries SEM-SAFE-000 because
  // it is literally the executable statement of the composite property.
  return snapshot >= 0 && snapshot <= (s as unknown as { initial: number }).initial;
}
