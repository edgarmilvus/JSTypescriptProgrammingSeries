/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_zephyr-style_test_harness_traceability_across_a_k_part2.ts
Description: Solutions and Explanations
==========================================
*/

// ---------------------------------------------------------------------------
// 4. TESTS — tests/semaphore.spec.ts
//
// Test files may only carry r[verify] annotations (config test_include).
// Every requirement has at least one verifying test.
// ---------------------------------------------------------------------------
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { Semaphore, ledgerInvariantHolds } from "../src/semaphore";

describe("Semaphore", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  // r[verify SEM-COUNT-002]
  it("never lets the ledger go negative on take, nor exceed initial on give", () => {
    const s = new Semaphore(2);
    expect(s.tryTake()).toBe(true);
    expect(s.tryTake()).toBe(true);
    expect(s.tryTake()).toBe(false);   // saturates at zero
    s.give();
    s.give();
    s.give();                          // spurious third give
    // Ledger is back to full but not over.
    expect(s.tryTake()).toBe(true);
    expect(s.tryTake()).toBe(true);
    expect(s.tryTake()).toBe(false);
  });

  // r[verify SEM-TIMEOUT-003]
  it("returns false synchronously when timeout is zero and no permit exists", async () => {
    const s = new Semaphore(0);
    const t0 = Date.now();
    const result = await s.take(0);
    expect(result).toBe(false);
    // No timer was armed — wall clock did not advance.
    expect(Date.now() - t0).toBe(0);
  });

  // r[verify SEM-TIMEOUT-003]
  it("times out after the requested duration and leaves the queue empty", async () => {
    const s = new Semaphore(0);
    const promise = s.take(1_000);
    vi.advanceTimersByTime(1_000);
    await expect(promise).resolves.toBe(false);
    // A later give does not resurrect the dead waiter.
    s.give();
    expect(s.tryTake()).toBe(true);
  });

  // r[verify SEM-ORDER-004]
  it("releases waiters in first-in first-out order", async () => {
    const s = new Semaphore(0);
    const order: number[] = [];
    const p1 = s.take(10_000).then(ok => { if (ok) order.push(1); });
    const p2 = s.take(10_000).then(ok => { if (ok) order.push(2); });
    const p3 = s.take(10_000).then(ok => { if (ok) order.push(3); });

    s.give(); s.give(); s.give();
    await Promise.all([p1, p2, p3]);
    expect(order).toEqual([1, 2, 3]);
  });

  // r[verify SEM-SAFE-000]
  it("preserves the ledger invariant across a re-entrant interleaving", async () => {
    const s = new Semaphore(3);
    // Deterministic interleaving: take, give, take without awaiting.
    const steps = [
      () => s.tryTake(),
      () => { s.give(); },
      () => s.tryTake(),
      () => { s.give(); },
      () => s.tryTake(),
    ];
    for (const step of steps) {
      step();
      // Drain microtasks so any Promise-based waiter resolution is observed.
      await Promise.resolve();
      expect(ledgerInvariantHolds(s, 3)).toBe(true);
    }
  });

  // r[verify SEM-SAFE-000]
  it("does not strand a waiter when give races a timeout", async () => {
    const s = new Semaphore(0);
    const take = s.take(500);
    vi.advanceTimersByTime(499);
    s.give();                       // hand the permit over just before deadline
    await expect(take).resolves.toBe(true);
    // Nothing was lost: the ledger is back to its starting value.
    expect(s.tryTake()).toBe(true);
  });
});
