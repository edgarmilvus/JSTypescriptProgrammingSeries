/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_zephyr-style_test_harness_traceability_across_a_k_part3.ts
Description: Solutions and Explanations
==========================================
*/

// ---------------------------------------------------------------------------
// 5. MINIATURE TRACEY-COMPATIBLE GATE
//
// This is not Tracey — it is a small, honest re-implementation of the four
// checks the exercise asks us to demonstrate:
//   (a) broken reference (typo in UID),
//   (b) orphaned annotation (UID no longer defined),
//   (c) impl-inside-test-file.
// The real toolchain would surface these from LSP diagnostics,
// `tracey query validate`, and `tracey query status` respectively; the
// mapping is spelled out in the assertions below.
// ============================================================================

type Fault =
  | { kind: "broken-reference"; uid: string; file: string; line: number }
  | { kind: "orphan-annotation"; uid: string; file: string; line: number }
  | { kind: "impl-in-test-file"; uid: string; file: string; line: number };

interface CoverageInputs {
  /** Raw source of the sdoc — parsed for UID: lines. */
  readonly sdoc: string;
  /** Map of file path -> raw text.  Only .ts files are looked at. */
  readonly files: ReadonlyMap<string, string>;
  /** Paths matching the test_include glob from config.styx. */
  readonly testFiles: ReadonlySet<string>;
}

const UID_RE = /^UID:\s*([A-Z][A-Z0-9-]*)\s*$/m;
const ANNOT_RE = /\/\/\s*r\[(impl|verify)\s+([A-Z][A-Z0-9-]*)\]/g;

function collectRequirementUids(sdoc: string): Set<string> {
  const uids = new Set<string>();
  for (const match of sdoc.matchAll(new RegExp(UID_RE.source, "gm"))) {
    uids.add(match[1]);
  }
  return uids;
}

function collectAnnotations(
  files: ReadonlyMap<string, string>
): Array<{ verb: "impl" | "verify"; uid: string; file: string; line: number }> {
  const out: Array<{ verb: "impl" | "verify"; uid: string; file: string; line: number }> = [];
  for (const [file, text] of files) {
    const lines = text.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      ANNOT_RE.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = ANNOT_RE.exec(lines[i])) !== null) {
        out.push({ verb: m[1] as "impl" | "verify", uid: m[2], file, line: i + 1 });
      }
    }
  }
  return out;
}

export interface GateResult {
  readonly ok: boolean;
  readonly implCovered: ReadonlySet<string>;
  readonly verifyCovered: ReadonlySet<string>;
  readonly faults: readonly Fault[];
}

export function runGate(inputs: CoverageInputs): GateResult {
  const defined = collectRequirementUids(inputs.sdoc);
  const annotations = collectAnnotations(inputs.files);

  const implCovered = new Set<string>();
  const verifyCovered = new Set<string>();
  const faults: Fault[] = [];

  for (const a of annotations) {
    if (!defined.has(a.uid)) {
      faults.push({ kind: "broken-reference", uid: a.uid, file: a.file, line: a.line });
      continue;
    }
    const isTestFile = inputs.testFiles.has(a.file);
    if (isTestFile && a.verb === "impl") {
      // Tracey treats this as a hard error, not a warning: `validate` exits
      // non-zero, the LSP paints a red squiggle, and the CI gate fails.
      faults.push({ kind: "impl-in-test-file", uid: a.uid, file: a.file, line: a.line });
      continue;
    }
    if (a.verb === "impl") implCovered.add(a.uid);
    if (a.verb === "verify") verifyCovered.add(a.uid);
  }

  // Orphaned annotations (references to rules that no longer exist as *targets*
  // of any file) are captured by the broken-reference branch above when the
  // UID is removed from the .sdoc; the `orphan-annotation` variant fires when
  // an annotation survives in code but the requirement is deleted.  In the
  // mini-gate we can only distinguish them by intent, so we synthesize them
  // explicitly when a UID appears *only* in code:
  const referenced = new Set(annotations.map(a => a.uid));
  for (const uid of referenced) {
    if (!defined.has(uid)) {
      // mark once
      if (!faults.some(f => f.uid === uid && f.kind === "broken-reference")) {
        faults.push({ kind: "orphan-annotation", uid, file: "<unknown>", line: 0 });
      }
    }
  }

  const ok =
    faults.length === 0 &&
    [...defined].every(u => implCovered.has(u) && verifyCovered.has(u));

  return { ok, implCovered, verifyCovered, faults };
}

// ---------------------------------------------------------------------------
// 6. DEMONSTRATION of the three faults, and how each is surfaced.
// ---------------------------------------------------------------------------
export function demonstrateFaults() {
  const testFiles = new Set<string>(["tests/semaphore.spec.ts"]);

  const clean = new Map<string, string>([
    [
      "src/semaphore.ts",
      "// r[impl SEM-COUNT-002]\n// r[impl SEM-TIMEOUT-003]\n// r[impl SEM-ORDER-004]\n// r[impl SEM-SAFE-000]\n" +
        "export class Semaphore {}\n",
    ],
    [
      "tests/semaphore.spec.ts",
      "// r[verify SEM-COUNT-002]\n// r[verify SEM-TIMEOUT-003]\n// r[verify SEM-ORDER-004]\n// r[verify SEM-SAFE-000]\n" +
        "describe('x', () => { it('y', () => {}); });\n",
    ],
  ]);

  // Baseline: 100% impl + verify, zero faults → validate --deny warnings exits 0.
  const baseline = runGate({ sdoc: SEMAPHORE_SDOC, files: clean, testFiles });

  // Fault (a): typo in the UID inside the impl annotation.
  const typo = new Map(clean);
  typo.set("src/semaphore.ts", clean.get("src/semaphore.ts")!.replace("SEM-ORDER-004", "SEM-ORDER-0044"));
  const typoResult = runGate({ sdoc: SEMAPHORE_SDOC, files: typo, testFiles });
  // → reported by LSP as a red squiggle *and* by `tracey query validate`
  //   (Broken reference: Unknown requirement 'SEM-ORDER-0044').

  // Fault (b): orphan — an annotation references a UID that no longer exists.
  const orphaned = new Map(clean);
  orphaned.set(
    "src/semaphore.ts",
    clean.get("src/semaphore.ts")! + "// r[impl SEM-DELETED-999]\n"
  );
  const orphanResult = runGate({ sdoc: SEMAPHORE_SDOC, files: orphaned, testFiles });
  // → `tracey query validate` also reports this; without --deny warnings the
  //   process still exits 0 for a plain warning, which is precisely why the
  //   CI job in the reference architecture runs `validate --deny warnings`.

  // Fault (c): impl inside a file that matched test_include.
  const badTest = new Map(clean);
  badTest.set(
    "tests/semaphore.spec.ts",
    clean.get("tests/semaphore.spec.ts")! + "// r[impl SEM-COUNT-002]\n"
  );
  const badTestResult = runGate({ sdoc: SEMAPHORE_SDOC, files: badTest, testFiles });
  // → `tracey query validate` hard-errors ("Impl in test file"); the LSP also
  //   flags it.  This one is by design the *loudest* because it silently
  //   swaps evidence for assertion if left unchecked.

  return { baseline, typoResult, orphanResult, badTestResult };
}
