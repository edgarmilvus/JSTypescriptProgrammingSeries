/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_do-178c_structural_coverage_pipeline_from_raw_cov.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================================
// src/coverage/types.ts — domain model
// ============================================================================
import { describe, it, expect } from "vitest";

declare const __brand: unique symbol;
type Brand<T, B extends string> = T & { readonly [__brand]: B };

/** Nominal type for a StrictDoc UID.  A plain string is NOT assignable. */
export type RequirementId = Brand<string, "RequirementId">;

/** Runtime constructor.  In practice you'd call this at the spec-reader edge. */
export function toRequirementId(raw: string): RequirementId {
  if (!/^[A-Z][A-Z0-9-]*$/.test(raw)) {
    throw new Error(`Not a valid requirement UID: ${JSON.stringify(raw)}`);
  }
  return raw as RequirementId;
}

/** DO-178C software levels. */
export type Do178Level = "A" | "B" | "C" | "D";

/** The three structural-coverage kinds DO-178C names. */
export type StructuralCoverageKind = "statement" | "decision" | "mcdc";

/**
 * A requirement as seen by the pipeline.  `level` is sourced from a custom
 * grammar field named `DO178_LEVEL` (we document this choice: putting it in
 * the spec means it is diffable and reviewable; burying it in a sidecar JSON
 * would make the level invisible to the very people who must audited it).
 */
export interface RequirementRecord {
  readonly uid: RequirementId;
  readonly level: Do178Level;
  readonly sourceFiles: readonly string[];
  readonly verificationTests: readonly string[];
}

export type CoverageReasonCode =
  | "NO_VERIFICATION"
  | "TEST_NOT_EXECUTED"
  | "UNJUSTIFIED_GAP"
  | "UNJUSTIFIED_GAP_CRITICAL";

export interface JustificationRecord {
  readonly requirementId: RequirementId;
  readonly kind: StructuralCoverageKind;
  readonly reason: string;
  readonly approvedBy: string;
  /** ISO 8601. */
  readonly date: string;
  /** Required when `kind === "mcdc"`. */
  readonly evidenceUri?: string;
}

export type CoverageVerdict =
  | {
      readonly kind: "fully-covered";
      readonly uid: RequirementId;
      readonly kinds: readonly StructuralCoverageKind[];
    }
  | {
      readonly kind: "partially-covered";
      readonly uid: RequirementId;
      readonly missingKinds: readonly StructuralCoverageKind[];
      readonly reason: CoverageReasonCode;
      readonly remediation: string;
    }
  | {
      readonly kind: "justified-gap";
      readonly uid: RequirementId;
      readonly missingKinds: readonly StructuralCoverageKind[];
      readonly justification: JustificationRecord;
    };

/** Raw input to `joinCoverage`.  Shape mirrors what a Vitest/istanbul JSON
 *  provider plus a hand-authored MC/DC annotation sidecar would give us. */
export interface RawCoverageReport {
  readonly executedTests: readonly string[];
  readonly achievedKinds: ReadonlyArray<{
    readonly uid: RequirementId;
    readonly kinds: readonly StructuralCoverageKind[];
  }>;
  readonly justifications: readonly JustificationRecord[];
}

// ============================================================================
// src/coverage/level_map.ts — the level → coverage-kind mapping
// ============================================================================

/**
 * Level A implies the lower-level kinds on purpose.  In practice MC/DC
 * subsumes decision and statement coverage *for the compilers and build
 * toolchains certified against DO-178C*, but auditors still want the full
 * ladder spelled out because the tooling that produces the MC/DC report is
 * not necessarily the same tooling that produces the statement-count report.
 * Making the implication explicit keeps the audit trail uniform.
 */
export function coverageKindsForLevel(
  level: Do178Level
): readonly StructuralCoverageKind[] {
  switch (level) {
    case "A":
      return ["statement", "decision", "mcdc"] as const;
    case "B":
      return ["statement", "decision"] as const;
    case "C":
      return ["statement"] as const;
    case "D":
      return [] as const;
    default: {
      // Exhaustiveness guard: if a level is added upstream, this line fails
      // to compile with "Type 'X' is not assignable to type 'never'".
      const never_: never = level;
      return never_;
    }
  }
}

// ============================================================================
// src/coverage/justification.ts — runtime validator
// ============================================================================

const ISO_8601 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/;

export class JustificationValidationError extends Error {}

export function validateJustification(
  input: unknown,
  now: Date = new Date()
): JustificationRecord {
  if (typeof input !== "object" || input === null) {
    throw new JustificationValidationError("justification must be an object");
  }
  const o = input as Record<string, unknown>;

  if (typeof o.requirementId !== "string") {
    throw new JustificationValidationError("requirementId missing or not a string");
  }
  // Reuse the branded constructor so the invariant is enforced once.
  toRequirementId(o.requirementId);

  const kind = o.kind;
  if (kind !== "statement" && kind !== "decision" && kind !== "mcdc") {
    throw new JustificationValidationError(`unknown coverage kind: ${String(kind)}`);
  }

  if (typeof o.reason !== "string" || o.reason.trim().length === 0) {
    throw new JustificationValidationError("reason must be a non-empty string");
  }
  if (typeof o.approvedBy !== "string" || o.approvedBy.trim().length === 0) {
    throw new JustificationValidationError("approvedBy must be a non-empty string");
  }
  if (typeof o.date !== "string" || !ISO_8601.test(o.date)) {
    throw new JustificationValidationError("date must be ISO 8601");
  }
  const when = Date.parse(o.date);
  if (Number.isNaN(when)) {
    throw new JustificationValidationError("date is not parseable");
  }
  if (when > now.getTime() + 1000) {
    // 1-second tolerance for clock skew between the person who signed and
    // the machine that runs the validator.
    throw new JustificationValidationError("date is in the future");
  }
  if (kind === "mcdc") {
    if (typeof o.evidenceUri !== "string" || o.evidenceUri.length === 0) {
      throw new JustificationValidationError("mcdc justification requires evidenceUri");
    }
  } else if (o.evidenceUri !== undefined && typeof o.evidenceUri !== "string") {
    throw new JustificationValidationError("evidenceUri, when present, must be a string");
  }

  return {
    requirementId: o.requirementId as RequirementId,
    kind,
    reason: o.reason,
    approvedBy: o.approvedBy,
    date: o.date,
    ...(o.evidenceUri !== undefined ? { evidenceUri: o.evidenceUri as string } : {}),
  };
}

// ============================================================================
// src/coverage/join.ts — the pure join
// ============================================================================

export function joinCoverage(
  specRecords: readonly RequirementRecord[],
  report: RawCoverageReport
): readonly CoverageVerdict[] {
  const executed = new Set(report.executedTests);

  const achievedByUid = new Map<RequirementId, Set<StructuralCoverageKind>>();
  for (const { uid, kinds } of report.achievedKinds) {
    const set = achievedByUid.get(uid) ?? new Set<StructuralCoverageKind>();
    for (const k of kinds) set.add(k);
    achievedByUid.set(uid, set);
  }

  const justificationByKey = new Map<string, JustificationRecord>();
  for (const j of report.justifications) {
    justificationByKey.set(`${j.requirementId}::${j.kind}`, j);
  }

  const verdicts: CoverageVerdict[] = [];

  for (const rec of specRecords) {
    const demanded = coverageKindsForLevel(rec.level);

    // --- Edge case 1: no verify annotations at all ---
    if (rec.verificationTests.length === 0) {
      verdicts.push({
        kind: "partially-covered",
        uid: rec.uid,
        missingKinds: demanded,
        reason: "NO_VERIFICATION",
        remediation: `Add a test annotated // r[verify ${rec.uid}]`,
      });
      continue;
    }

    // --- Edge case 2: annotations exist but no test actually ran ---
    const executedForThisReq = rec.verificationTests.filter(t => executed.has(t));
    if (executedForThisReq.length === 0) {
      verdicts.push({
        kind: "partially-covered",
        uid: rec.uid,
        missingKinds: demanded,
        reason: "TEST_NOT_EXECUTED",
        remediation: `Ensure one of [${rec.verificationTests.join(", ")}] runs in the coverage job`,
      });
      continue;
    }

    const achieved = achievedByUid.get(rec.uid) ?? new Set<StructuralCoverageKind>();
    const missing = demanded.filter(k => !achieved.has(k));

    // --- Edge case 3: fully covered ---
    if (missing.length === 0) {
      verdicts.push({ kind: "fully-covered", uid: rec.uid, kinds: demanded });
      continue;
    }

    // --- Edge case 4: every missing kind is justified → justified-gap ---
    const justifications = missing.map(k =>
      justificationByKey.get(`${rec.uid}::${k}`)
    );
    if (justifications.every((j): j is JustificationRecord => j !== undefined)) {
      // NB: emit the first justification as a representative.  A real
      // pipeline would carry the whole array; for the report's purposes one
      // authoritative approver is enough to establish the audit link.
      verdicts.push({
        kind: "justified-gap",
        uid: rec.uid,
        missingKinds: missing,
        justification: justifications[0]!,
      });
      continue;
    }

    // --- Edge case 5: gap with no justification ---
    // A/B gaps are the audit-critical ones; C/D gaps are still real gaps but
    // the reason code distinguishes them so the report can prioritise.
    const critical = rec.level === "A" || rec.level === "B";
    verdicts.push({
      kind: "partially-covered",
      uid: rec.uid,
      missingKinds: missing,
      reason: critical ? "UNJUSTIFIED_GAP_CRITICAL" : "UNJUSTIFIED_GAP",
      remediation: critical
        ? `Close ${missing.join(", ")} on a Level ${rec.level} item or file a justification`
        : `Close ${missing.join(", ")} or file a justification`,
    });
  }

  return verdicts;
}

// ============================================================================
// src/coverage/report.ts — Markdown report emitter
// ============================================================================

export function emitReport(verdicts: readonly CoverageVerdict[]): string {
  const fully = verdicts.filter(v => v.kind === "fully-covered");
  const partial = verdicts.filter(v => v.kind === "partially-covered");
  const justified = verdicts.filter(v => v.kind === "justified-gap");

  const lines: string[] = [];
  lines.push("# Structural Coverage Report");
  lines.push("");
  lines.push("| Category | Count |");
  lines.push("| --- | --- |");
  lines.push(`| Fully covered | ${fully.length} |`);
  lines.push(`| Partially covered | ${partial.length} |`);
  lines.push(`| Justified gaps | ${justified.length} |`);
  lines.push("");

  if (partial.length > 0) {
    lines.push("## Partially covered");
    lines.push("");
    for (const v of partial) {
      if (v.kind !== "partially-covered") continue;
      lines.push(`- **${v.uid}** — missing ${v.missingKinds.join(", ")} ` +
                 `(\`${v.reason}\`). _${v.remediation}_`);
    }
    lines.push("");
  }

  if (justified.length > 0) {
    lines.push("## Justified gaps");
    lines.push("");
    for (const v of justified) {
      if (v.kind !== "justified-gap") continue;
      const j = v.justification;
      lines.push(
        `- **${v.uid}** — missing ${v.missingKinds.join(", ")}; ` +
        `approved by **${j.approvedBy}** on ${j.date}` +
        (j.evidenceUri ? ` ([evidence](${j.evidenceUri}))` : "") +
        `.`
      );
    }
    lines.push("");
  }

  if (fully.length > 0) {
    lines.push("## Fully covered");
    lines.push("");
    for (const v of fully) {
      if (v.kind !== "fully-covered") continue;
      lines.push(`- ${v.uid} (${v.kinds.join(", ") || "traceability only"})`);
    }
    lines.push("");
  }

  return lines.join("\n");
}

// ============================================================================
// src/tracey/mcpClient.ts — shape of the tracey_rule MCP call
//
// We do not open a socket here.  We fix the *shape* so that Exercise 3's
// panel and Exercise 4's analyzer can program against the same contract.
// The overlap with `RequirementRecord` is deliberate: both carry `uid`, and
// after `fetchRuleSummary` the pipeline can enrich a `RequirementRecord` with
// `title`/`statement` without any adapter.
// ============================================================================

export interface RuleSummary {
  readonly uid: RequirementId;
  readonly title: string;
  readonly statement: string;
  readonly implRefCount: number;
  readonly verifyRefCount: number;
}

export interface TraceyRuleRequest {
  readonly uid: RequirementId;
}

export interface TraceyRuleResponse {
  readonly summary: RuleSummary;
  readonly rawText: string; // the human-readable MCP body, unparsed
}

/**
 * Overlap contract:
 *   - `uid` is present in both `RequirementRecord` and `RuleSummary`, so the
 *     two sets can be joined by UID without any conversion.
 *   - `RuleSummary` carries `title`/`statement`, which `RequirementRecord`
 *     deliberately omits: the pipeline that produces `RequirementRecord`
 *     reads only UIDs and metadata from the spec index; the title and
 *     statement are fetched on demand from Tracey so the two sources cannot
 *     diverge on a cached copy of the statement text.
 *   - `implRefCount`/`verifyRefCount` give a first-order signal for the
 *     "TEST_NOT_EXECUTED" edge case: a rule with `verifyRefCount === 0` can
 *     never be verified, regardless of what the coverage report says.
 */
export async function fetchRuleSummary(
  _uid: RequirementId
): Promise<RuleSummary> {
  throw new Error("not wired — see Exercise 3 for the real MCP bridge");
}

// ============================================================================
// Tests
// ============================================================================

describe("coverageKindsForLevel", () => {
  it("implies lower-level kinds as level tightens", () => {
    expect(coverageKindsForLevel("A")).toEqual(["statement", "decision", "mcdc"]);
    expect(coverageKindsForLevel("B")).toEqual(["statement", "decision"]);
    expect(coverageKindsForLevel("C")).toEqual(["statement"]);
    expect(coverageKindsForLevel("D")).toEqual([]);
  });
});

describe("validateJustification", () => {
  const base = {
    requirementId: "SEM-SAFE-000",
    kind: "decision" as const,
    reason: "Unreachable defensive branch",
    approvedBy: "A. Reviewer",
    date: "2024-01-01T00:00:00Z",
  };

  it("accepts a canonical record", () => {
    expect(validateJustification(base, new Date("2025-01-01")).approvedBy).toBe("A. Reviewer");
  });

  it("rejects mcdc without evidenceUri", () => {
    expect(() =>
      validateJustification({ ...base, kind: "mcdc" }, new Date("2025-01-01"))
    ).toThrow(/evidenceUri/);
  });

  it("rejects a future date", () => {
    expect(() =>
      validateJustification(
        { ...base, date: "2999-01-01T00:00:00Z" },
        new Date("2025-01-01")
      )
    ).toThrow(/future/);
  });

  it("rejects a malformed date", () => {
    expect(() =>
      validateJustification({ ...base, date: "yesterday" }, new Date("2025-01-01"))
    ).toThrow(/ISO 8601/);
  });
});

describe("joinCoverage", () => {
  const uid = (s: string) => toRequirementId(s);

  const spec: readonly RequirementRecord[] = [
    { uid: uid("REQ-A"), level: "A", sourceFiles: ["a.c"], verificationTests: [] },
    { uid: uid("REQ-B"), level: "B", sourceFiles: ["b.c"], verificationTests: ["t_b"] },
    { uid: uid("REQ-C"), level: "C", sourceFiles: ["c.c"], verificationTests: ["t_c"] },
    { uid: uid("REQ-D"), level: "A", sourceFiles: ["d.c"], verificationTests: ["t_d"] },
    { uid: uid("REQ-E"), level: "B", sourceFiles: ["e.c"], verificationTests: ["t_e"] },
  ];

  const report: RawCoverageReport = {
    executedTests: ["t_c", "t_d", "t_e"],
    achievedKinds: [
      { uid: uid("REQ-C"), kinds: ["statement"] },
      { uid: uid("REQ-D"), kinds: ["statement", "decision"] },
      { uid: uid("REQ-E"), kinds: ["statement", "decision"] },
    ],
    justifications: [
      {
        requirementId: uid("REQ-D"),
        kind: "mcdc",
        reason: "Compiler-generated branch, already reviewed",
        approvedBy: "K. Safety",
        date: "2024-06-01T10:00:00Z",
        evidenceUri: "https://example.invalid/evidence/REQ-D-mcdc.pdf",
      },
    ],
  };

  it("produces the expected verdict matrix (integration)", () => {
    const verdicts = joinCoverage(spec, report);

    // REQ-A: no verify at all.
    expect(verdicts.find(v => v.uid === uid("REQ-A"))).toMatchObject({
      kind: "partially-covered",
      reason: "NO_VERIFICATION",
    });

    // REQ-B: has a verify annotation, but that test never ran.
    expect(verdicts.find(v => v.uid === uid("REQ-B"))).toMatchObject({
      kind: "partially-covered",
      reason: "TEST_NOT_EXECUTED",
    });

    // REQ-C: level C, statement coverage achieved → fully covered.
    expect(verdicts.find(v => v.uid === uid("REQ-C"))).toMatchObject({
      kind: "fully-covered",
    });

    // REQ-D: level A, only statement+decision achieved, but the missing mcdc
    // kind is justified → justified-gap.
    expect(verdicts.find(v => v.uid === uid("REQ-D"))).toMatchObject({
      kind: "justified-gap",
      missingKinds: ["mcdc"],
    });

    // REQ-E: level B, decision missing with no justification → critical gap.
    expect(verdicts.find(v => v.uid === uid("REQ-E"))).toMatchObject({
      kind: "partially-covered",
      reason: "UNJUSTIFIED_GAP_CRITICAL",
    });
  });

  it("is deterministic and pure", () => {
    const a = joinCoverage(spec, report);
    const b = joinCoverage(spec, report);
    expect(a).toEqual(b);
  });
});

describe("emitReport", () => {
  it("carries approver and date for every justified gap", () => {
    const md = emitReport([
      {
        kind: "justified-gap",
        uid: toRequirementId("REQ-X"),
        missingKinds: ["mcdc"],
        justification: {
          requirementId: toRequirementId("REQ-X"),
          kind: "mcdc",
          reason: "Defensive branch",
          approvedBy: "K. Safety",
          date: "2024-06-01T10:00:00Z",
        },
      },
      {
        kind: "partially-covered",
        uid: toRequirementId("REQ-Y"),
        missingKinds: ["decision"],
        reason: "UNJUSTIFIED_GAP_CRITICAL",
        remediation: "Add a decision test for the timeout branch",
      },
    ]);
    expect(md).toContain("K. Safety");
    expect(md).toContain("2024-06-01T10:00:00Z");
    expect(md).toContain("timeout branch");
  });
});
