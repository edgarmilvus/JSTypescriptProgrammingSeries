/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_react_component_feature_request_the_living_intent.tsx
Description: Solutions and Explanations
==========================================
*/

// ============================================================================
// LivingIntentGraphPanel.tsx
//
// FEATURE REQUEST
// ───────────────
// User story:
//   As a safety lead, I want to see uncovered, untested, and stale
//   requirements in one panel so that I can triage drift before a
//   verification review.
//
// Acceptance criteria (each maps 1:1 to a test in section 7):
//   AC1  Renders four panels labelled Uncovered, Untested, Stale, Summary.
//   AC2  Each of the four panels independently renders exactly one of the
//        states: idle | loading | empty | ready | error.
//   AC3  Every stale row shows referencedVersion AND currentVersion.
//   AC4  Clicking "View diff" on a stale row calls tracey_rule for the UID
//        and renders the returned statement text in an inline diff view.
//   AC5  A single refresh cycle issues exactly one MCP call per tool
//        (tracey_uncovered, tracey_untested, tracey_stale, tracey_status).
//   AC6  Changing `refreshIntervalMs` while mounted clears the previous
//        interval before starting the new one.
//   AC7  Unmounting stops polling entirely.
//   AC8  Each requirement row is focusable; Enter invokes onRequirementSelect.
//   AC9  The component never mutates its panels optimistically; server state
//        is the sole source of truth, visible only after a successful poll.
// ============================================================================

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

// ---------------------------------------------------------------------------
// Public API — deliberately minimal.
// ---------------------------------------------------------------------------

export interface LivingIntentGraphPanelProps {
  /** e.g. "lumenrtos-semaphore/rust" */
  specImpl: string;
  /** Called when a requirement row is activated (click or Enter-key). */
  onRequirementSelect?: (uid: string) => void;
  /** Polling interval in ms. Default 30_000. */
  refreshIntervalMs?: number;
}

// ---------------------------------------------------------------------------
// Domain shapes returned by the MCP tools.
// ---------------------------------------------------------------------------

interface UncoveredItem { readonly uid: string }
interface UntestedItem { readonly uid: string }
interface StaleItem {
  readonly uid: string;
  readonly referencedVersion: number;
  readonly currentVersion: number;
}
interface SummaryShape {
  readonly coveragePercent: number;
  readonly verifyPercent: number;
  readonly specImpl: string;
}

// ---------------------------------------------------------------------------
// The `useMcpTool` primitive we are told to assume exists.  Real version
// would be a WebSocket + request/response correlator; here we only fix the
// shape so that our component and its tests agree on it.
// ---------------------------------------------------------------------------

export interface UseMcpToolApi<TArgs, TResult> {
  readonly messages: readonly unknown[];
  readonly isLoading: boolean;
  readonly error: Error | null;
  send(args: TArgs): Promise<TResult>;
}

export function useMcpTool<TArgs, TResult>(
  _toolName: string
): UseMcpToolApi<TArgs, TResult> {
  throw new Error("real implementation lives in the MCP bridge");
}

// ---------------------------------------------------------------------------
// Per-panel state machine.
// ---------------------------------------------------------------------------

type PanelState<T> =
  | { readonly status: "idle" }
  | { readonly status: "loading"; readonly previous?: readonly T[] }
  | { readonly status: "empty"; readonly loadedAt: number }
  | { readonly status: "ready"; readonly items: readonly T[]; readonly loadedAt: number }
  | { readonly status: "error"; readonly message: string; readonly loadedAt: number };

const IDLE: PanelState<never> = { status: "idle" };

function stateForResult<T>(items: readonly T[], now: number): PanelState<T> {
  return items.length === 0
    ? { status: "empty", loadedAt: now }
    : { status: "ready", items, loadedAt: now };
}

// ---------------------------------------------------------------------------
// The component.
// ---------------------------------------------------------------------------

export function LivingIntentGraphPanel(
  props: LivingIntentGraphPanelProps
): React.ReactElement {
  const { specImpl, onRequirementSelect, refreshIntervalMs = 30_000 } = props;

  const uncovered = useMcpTool<{ specImpl: string }, readonly UncoveredItem[]>(
    "tracey_uncovered"
  );
  const untested = useMcpTool<{ specImpl: string }, readonly UntestedItem[]>(
    "tracey_untested"
  );
  const stale = useMcpTool<{ specImpl: string }, readonly StaleItem[]>(
    "tracey_stale"
  );
  const status = useMcpTool<{ specImpl: string }, SummaryShape>("tracey_status");
  const rule = useMcpTool<{ uid: string }, { statement: string }>("tracey_rule");

  const [uncoveredState, setUncoveredState] = useState<PanelState<UncoveredItem>>(IDLE);
  const [untestedState, setUntestedState] = useState<PanelState<UntestedItem>>(IDLE);
  const [staleState, setStaleState] = useState<PanelState<StaleItem>>(IDLE);
  const [summaryState, setSummaryState] = useState<PanelState<SummaryShape>>(IDLE);

  /** Guards against overlapping refresh cycles. */
  const inFlightRef = useRef(false);

  // The single refresh routine.  Exactly four MCP calls per invocation;
  // no per-row fan-out.  This is the AC5 invariant made mechanical.
  const runRefreshCycle = useCallback(async () => {
    if (inFlightRef.current) return;
    inFlightRef.current = true;

    setUncoveredState(s => ({ status: "loading", ...(s.status === "ready" ? { previous: s.items } : {}) }));
    setUntestedState(s => ({ status: "loading", ...(s.status === "ready" ? { previous: s.items } : {}) }));
    setStaleState(s => ({ status: "loading", ...(s.status === "ready" ? { previous: s.items } : {}) }));
    setSummaryState({ status: "loading" });

    const now = Date.now();
    // Fire all four in parallel — a serial refresh would compound latency
    // and make the polling interval meaningless under slow daemons.
    await Promise.all([
      uncovered.send({ specImpl })
        .then(items => setUncoveredState(stateForResult(items, now)))
        .catch(e => setUncoveredState({ status: "error", message: String(e), loadedAt: now })),
      untested.send({ specImpl })
        .then(items => setUntestedState(stateForResult(items, now)))
        .catch(e => setUntestedState({ status: "error", message: String(e), loadedAt: now })),
      stale.send({ specImpl })
        .then(items => setStaleState(stateForResult(items, now)))
        .catch(e => setStaleState({ status: "error", message: String(e), loadedAt: now })),
      status.send({ specImpl })
        .then(items => setSummaryState(stateForResult([items], now)))
        .catch(e => setSummaryState({ status: "error", message: String(e), loadedAt: now })),
    ]);

    inFlightRef.current = false;
  }, [specImpl, uncovered, untested, stale, status]);

  // Polling.  Both `specImpl` and `refreshIntervalMs` are in the deps array
  // so a change to either tears down the old interval and starts fresh.
  // AC6 and AC7 are satisfied by the cleanup function alone.
  useEffect(() => {
    void runRefreshCycle();
    const handle = window.setInterval(() => {
      void runRefreshCycle();
    }, refreshIntervalMs);
    return () => {
      window.clearInterval(handle);
    };
  }, [runRefreshCycle, refreshIntervalMs]);

  // The stale panel's diff affordance.  We track which UID is open so we can
  // restore focus to its row on close (AC8's return-focus half).
  const [openStaleUid, setOpenStaleUid] = useState<string | null>(null);
  const [openStaleText, setOpenStaleText] = useState<string | null>(null);

  const viewDiff = useCallback(
    async (uid: string) => {
      setOpenStaleUid(uid);
      setOpenStaleText(null);
      try {
        const r = await rule.send({ uid });
        setOpenStaleText(r.statement);
      } catch (e) {
        setOpenStaleText(`error: ${String(e)}`);
      }
    },
    [rule]
  );

  const lastStaleRow = useRef<HTMLButtonElement | null>(null);

  const closeDiff = useCallback(() => {
    setOpenStaleUid(null);
    setOpenStaleText(null);
    // Return focus to the row that opened the diff.  The ref is populated
    // by the row renderer just before `viewDiff` is called.
    lastStaleRow.current?.focus();
  }, []);

  return (
    <section aria-label="Living intent graph">
      <SummaryPanel state={summaryState} specImpl={specImpl} />
      <UncoveredPanel state={uncoveredState} onSelect={onRequirementSelect} />
      <UntestedPanel state={untestedState} onSelect={onRequirementSelect} />
      <StalePanel
        state={staleState}
        onSelect={onRequirementSelect}
        openUid={openStaleUid}
        openText={openStaleText}
        onViewDiff={viewDiff}
        onCloseDiff={closeDiff}
        registerLastRow={(el) => (lastStaleRow.current = el)}
      />
    </section>
  );
}

// ---------------------------------------------------------------------------
// Panels.  Each one is a tiny state-machine renderer.
// ---------------------------------------------------------------------------

function PanelShell(props: {
  label: string;
  status: PanelState<unknown>["status"];
  children: React.ReactNode;
}): React.ReactElement {
  return (
    <div
      role="group"
      aria-label={props.label}
      data-status={props.status}
      className={`panel panel--${props.status}`}
    >
      <h2>{props.label}</h2>
      {props.children}
    </div>
  );
}

function LoadingOrEmpty(props: {
  state: PanelState<unknown>;
  emptyLabel: string;
}): React.ReactElement | null {
  if (props.state.status === "loading") {
    return <p role="status">Loading…</p>;
  }
  if (props.state.status === "empty") {
    // Visually and semantically distinct from `loading` on purpose: a common
    // audit-visible bug is showing a spinner that never resolves, or an empty
    // list that looks identical to "loading".
    return <p role="status" data-empty="true">{props.emptyLabel}</p>;
  }
  if (props.state.status === "error") {
    return <p role="alert">Error: {props.state.message}</p>;
  }
  return null;
}

function RowButton(props: {
  uid: string;
  onSelect?: (uid: string) => void;
  refCb?: (el: HTMLButtonElement | null) => void;
}): React.ReactElement {
  return (
    <li>
      <button
        type="button"
        ref={props.refCb}
        tabIndex={0}
        onClick={() => props.onSelect?.(props.uid)}
        onKeyDown={(e) => {
          if (e.key === "Enter") props.onSelect?.(props.uid);
        }}
      >
        {props.uid}
      </button>
    </li>
  );
}

function UncoveredPanel(props: {
  state: PanelState<UncoveredItem>;
  onSelect?: (uid: string) => void;
}): React.ReactElement {
  return (
    <PanelShell label="Uncovered" status={props.state.status}>
      {props.state.status === "ready" ? (
        <ul>
          {props.state.items.map(i => (
            <RowButton key={i.uid} uid={i.uid} onSelect={props.onSelect} />
          ))}
        </ul>
      ) : (
        // In a healthy project, Uncovered is the panel most often empty:
        // it is the one the sentinel actively drains.
        <LoadingOrEmpty state={props.state} emptyLabel="No uncovered requirements." />
      )}
    </PanelShell>
  );
}

function UntestedPanel(props: {
  state: PanelState<UntestedItem>;
  onSelect?: (uid: string) => void;
}): React.ReactElement {
  return (
    <PanelShell label="Untested" status={props.state.status}>
      {props.state.status === "ready" ? (
        <ul>
          {props.state.items.map(i => (
            <RowButton key={i.uid} uid={i.uid} onSelect={props.onSelect} />
          ))}
        </ul>
      ) : (
        <LoadingOrEmpty state={props.state} emptyLabel="No untested requirements." />
      )}
    </PanelShell>
  );
}

function StalePanel(props: {
  state: PanelState<StaleItem>;
  onSelect?: (uid: string) => void;
  openUid: string | null;
  openText: string | null;
  onViewDiff: (uid: string) => void;
  onCloseDiff: () => void;
  registerLastRow: (el: HTMLButtonElement | null) => void;
}): React.ReactElement {
  return (
    <PanelShell label="Stale" status={props.state.status}>
      {props.state.status === "ready" ? (
        <ul>
          {props.state.items.map((i, idx) => (
            <li key={i.uid}>
              <button
                type="button"
                ref={
                  idx === props.state.items.length - 1 ? props.registerLastRow : undefined
                }
                onClick={() => props.onSelect?.(i.uid)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") props.onSelect?.(i.uid);
                }}
              >
                {i.uid}
              </button>
              {/* AC3: the two-version context is mandatory and rendered
                  inline.  A row that shows only the UID fails the ticket. */}
              <span data-testid={`stale-versions-${i.uid}`}>
                code@{i.referencedVersion} → spec@{i.currentVersion}
              </span>
              <button
                type="button"
                onClick={() => props.onViewDiff(i.uid)}
                aria-expanded={props.openUid === i.uid}
                aria-controls={props.openUid === i.uid ? `diff-${i.uid}` : undefined}
              >
                View diff
              </button>
              {props.openUid === i.uid ? (
                <div
                  id={`diff-${i.uid}`}
                  role="region"
                  aria-label={`Diff for ${i.uid}`}
                  tabIndex={-1}
                  ref={(el) => el?.focus()}
                >
                  {props.openText ?? "Loading…"}
                  <button type="button" onClick={props.onCloseDiff}>
                    Close
                  </button>
                </div>
              ) : null}
            </li>
          ))}
        </ul>
      ) : (
        // In a healthy project Stale is often non-empty during active
        // development; empty means the sentinel has caught up.
        <LoadingOrEmpty state={props.state} emptyLabel="No stale references." />
      )}
    </PanelShell>
  );
}

function SummaryPanel(props: {
  state: PanelState<SummaryShape>;
  specImpl: string;
}): React.ReactElement {
  return (
    <PanelShell label="Summary" status={props.state.status}>
      {props.state.status === "ready" && props.state.items.length > 0 ? (
        <p>
          {props.state.items[0].specImpl}: impl {props.state.items[0].coveragePercent}%,
          verify {props.state.items[0].verifyPercent}%
        </p>
      ) : (
        <LoadingOrEmpty state={props.state} emptyLabel="No summary available." />
      )}
    </PanelShell>
  );
}

// ---------------------------------------------------------------------------
// What we do NOT do, and why.
//
// There is no optimistic update in this component.  When a user clicks a
// row, nothing is removed from any panel; when the agent resolves a stale
// reference, the panel only reflects that after the next successful poll.
//
// Rationale: in a safety-triage context, the panel is evidence.  If an
// operator sees a stale entry disappear because *they* clicked something,
// they cannot then distinguish "the sentinel fixed it" from "the UI decided
// it was fixed."  Any subsequent audit trail that relies on the panel as
// evidence would be fabricated.  Optimistic UI is a UX affordance for
// consumer apps; here it is an evidence-integrity defect.
// ---------------------------------------------------------------------------
