/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_react_component_feature_request_the_living_intent_part2.tsx
Description: Solutions and Explanations
==========================================
*/

// ============================================================================
// LivingIntentGraphPanel.test.tsx
// One test per acceptance criterion.
// ============================================================================

import { render, screen, fireEvent, act } from "@testing-library/react";
import "@testing-library/jest-dom/vitest";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import {
  LivingIntentGraphPanel,
  useMcpTool,
} from "./LivingIntentGraphPanel";

vi.mock("./LivingIntentGraphPanel", async () => {
  const actual = await vi.importActual<typeof import("./LivingIntentGraphPanel")>(
    "./LivingIntentGraphPanel"
  );
  return { ...actual, useMcpTool: vi.fn() };
});

type MockTool = { send: ReturnType<typeof vi.fn> };

function installMcpMock(behavior: (tool: string) => MockTool) {
  const tools = new Map<string, MockTool>();
  (useMcpTool as unknown as ReturnType<typeof vi.fn>).mockImplementation(
    (name: string) => {
      let t = tools.get(name);
      if (!t) {
        t = behavior(name);
        tools.set(name, t);
      }
      return { messages: [], isLoading: false, error: null, send: t.send };
    }
  );
  return tools;
}

describe("LivingIntentGraphPanel", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });
  afterEach(() => {
    vi.useRealTimers();
    vi.clearAllMocks();
  });

  // AC1
  it("renders the four named panels", () => {
    installMcpMock(() => ({ send: vi.fn().mockResolvedValue([]) }));
    render(<LivingIntentGraphPanel specImpl="lum/rust" />);
    for (const label of ["Uncovered", "Untested", "Stale", "Summary"]) {
      expect(screen.getByRole("group", { name: label })).toBeInTheDocument();
    }
  });

  // AC2
  it("shows empty state as distinct from loading", async () => {
    installMcpMock(() => ({ send: vi.fn().mockResolvedValue([]) }));
    render(<LivingIntentGraphPanel specImpl="lum/rust" />);
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });
    expect(screen.getAllByText(/No .* requirements\./).length).toBeGreaterThan(0);
  });

  // AC3
  it("stale rows must show both referenced and current version", async () => {
    installMcpMock((tool) => {
      if (tool === "tracey_stale") {
        return {
          send: vi.fn().mockResolvedValue([
            { uid: "SEM-TIMEOUT-003", referencedVersion: 1, currentVersion: 2 },
          ]),
        };
      }
      return { send: vi.fn().mockResolvedValue([]) };
    });
    render(<LivingIntentGraphPanel specImpl="lum/rust" />);
    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });
    expect(
      screen.getByTestId("stale-versions-SEM-TIMEOUT-003")
    ).toHaveTextContent("code@1 → spec@2");
  });

  // AC4
  it("View diff calls tracey_rule and renders the statement", async () => {
    const ruleSend = vi.fn().mockResolvedValue({ statement: "The subsystem shall..." });
    installMcpMock((tool) => {
      if (tool === "tracey_stale")
        return { send: vi.fn().mockResolvedValue([{ uid: "SEM-X", referencedVersion: 1, currentVersion: 2 }]) };
      if (tool === "tracey_rule") return { send: ruleSend };
      return { send: vi.fn().mockResolvedValue([]) };
    });
    render(<LivingIntentGraphPanel specImpl="lum/rust" />);
    await act(async () => { await Promise.resolve(); await Promise.resolve(); });

    fireEvent.click(screen.getByRole("button", { name: /view diff/i }));
    await act(async () => { await Promise.resolve(); await Promise.resolve(); });

    expect(ruleSend).toHaveBeenCalledWith({ uid: "SEM-X" });
    expect(screen.getByText(/The subsystem shall/)).toBeInTheDocument();
  });

  // AC5 + AC6 + AC7
  it("issues exactly one call per tool per cycle, respects interval changes, and stops on unmount", async () => {
    const counts: Record<string, number> = {};
    installMcpMock((tool) => {
      counts[tool] = 0;
      return {
        send: vi.fn().mockImplementation(() => {
          counts[tool]++;
          return Promise.resolve([]);
        }),
      };
    });

    const { rerender, unmount } = render(
      <LivingIntentGraphPanel specImpl="lum/rust" refreshIntervalMs={1_000} />
    );

    await act(async () => {
      await Promise.resolve();
      await Promise.resolve();
    });
    // Initial refresh.
    for (const t of ["tracey_uncovered", "tracey_untested", "tracey_stale", "tracey_status"]) {
      expect(counts[t]).toBe(1);
    }

    await act(async () => { vi.advanceTimersByTime(3_000); });
    for (const t of ["tracey_uncovered", "tracey_untested", "tracey_stale", "tracey_status"]) {
      expect(counts[t]).toBe(4); // 1 initial + 3 ticks
    }

    // Changing the interval must not leave the old timer alive.
    rerender(
      <LivingIntentGraphPanel specImpl="lum/rust" refreshIntervalMs={2_000} />
    );
    await act(async () => { vi.advanceTimersByTime(2_000); });
    expect(counts.tracey_uncovered).toBe(5);

    unmount();
    await act(async () => { vi.advanceTimersByTime(10_000); });
    expect(counts.tracey_uncovered).toBe(5); // no calls after unmount
  });

  // AC8
  it("Enter on a row fires onRequirementSelect", async () => {
    const onSelect = vi.fn();
    installMcpMock((tool) => {
      if (tool === "tracey_uncovered")
        return { send: vi.fn().mockResolvedValue([{ uid: "SEM-A" }]) };
      return { send: vi.fn().mockResolvedValue([]) };
    });
    render(<LivingIntentGraphPanel specImpl="lum/rust" onRequirementSelect={onSelect} />);
    await act(async () => { await Promise.resolve(); await Promise.resolve(); });
    const row = screen.getByRole("button", { name: "SEM-A" });
    fireEvent.keyDown(row, { key: "Enter" });
    expect(onSelect).toHaveBeenCalledWith("SEM-A");
  });

  // AC9 — no optimistic UI
  it("does not remove a stale row when the user opens its diff", async () => {
    installMcpMock((tool) => {
      if (tool === "tracey_stale")
        return { send: vi.fn().mockResolvedValue([{ uid: "SEM-X", referencedVersion: 1, currentVersion: 2 }]) };
      if (tool === "tracey_rule") return { send: vi.fn().mockResolvedValue({ statement: "s" }) };
      return { send: vi.fn().mockResolvedValue([]) };
    });
    render(<LivingIntentGraphPanel specImpl="lum/rust" />);
    await act(async () => { await Promise.resolve(); await Promise.resolve(); });
    fireEvent.click(screen.getByRole("button", { name: /view diff/i }));
    await act(async () => { await Promise.resolve(); await Promise.resolve(); });
    // Row still present — the panel only reflects server state.
    expect(screen.getByRole("button", { name: "SEM-X" })).toBeInTheDocument();
  });

  // Stale-fixed-between-polls transition: the state-machine exercise.
  it("transitions ready → loading → empty when stale list empties between polls", async () => {
    let poll = 0;
    installMcpMock((tool) => {
      if (tool === "tracey_stale") {
        return {
          send: vi.fn().mockImplementation(() => {
            poll++;
            return Promise.resolve(
              poll === 1 ? [{ uid: "SEM-X", referencedVersion: 1, currentVersion: 2 }] : []
            );
          }),
        };
      }
      return { send: vi.fn().mockResolvedValue([]) };
    });
    render(<LivingIntentGraphPanel specImpl="lum/rust" refreshIntervalMs={1_000} />);
    await act(async () => { await Promise.resolve(); await Promise.resolve(); });
    expect(screen.getByText("SEM-X")).toBeInTheDocument();

    await act(async () => {
      vi.advanceTimersByTime(1_000);
      await Promise.resolve();
      await Promise.resolve();
    });
    expect(screen.getByText("No stale references.")).toBeInTheDocument();
  });
});
