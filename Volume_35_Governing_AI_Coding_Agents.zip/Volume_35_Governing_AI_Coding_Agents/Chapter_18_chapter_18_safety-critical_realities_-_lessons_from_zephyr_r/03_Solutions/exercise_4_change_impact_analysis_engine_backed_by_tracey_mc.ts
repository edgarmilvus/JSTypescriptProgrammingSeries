/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_change_impact_analysis_engine_backed_by_tracey_mc.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================================
// src/cia/index.ts
//
// Change Impact Analyzer (CIA).
//
// Design principle: the intent graph lives in Tracey, so the CIA must not
// reimplement traversal.  It composes the MCP tools that Tracey already
// exposes.  The only thing the CIA owns is the *policy* of the walk:
// which edges to follow, how deep, and — critically — what to do when a
// query fails.
//
// Conservative traversal:
//   The CIA must NEVER under-approximate impact.  If a child-requirement
//   lookup fails, we cannot know that a subtree has no impact; we must
//   therefore include the parent of the failed lookup in the affected set
//   and mark the report with a flag indicating degraded confidence.  In a
//   safety workflow, "we could not verify that there is no impact" is not
//   the same as "there is no impact," and treating the two as equivalent is
//   the dangerous direction.
// ============================================================================

// ---------------------------------------------------------------------------
// MCP client shape
// ---------------------------------------------------------------------------

export interface SourceReference {
  readonly file: string;
  readonly symbol?: string;
  readonly line?: number;
}

export interface RuleDetail {
  readonly uid: string;
  readonly title: string;
  readonly statement: string;
  readonly currentVersion: number;
  readonly parents: readonly string[];
  readonly children: readonly string[];
  readonly implRefs: readonly SourceReference[];
  readonly verifyRefs: readonly SourceReference[];
}

export interface StaleReference {
  readonly uid: string;
  readonly referencedVersion: number;
  readonly currentVersion: number;
}

export interface McpClient {
  traceyRule(uid: string): Promise<RuleDetail>;
  traceyStale(filter?: { prefix?: string }): Promise<readonly StaleReference[]>;
}

// ---------------------------------------------------------------------------
// Report shape
// ---------------------------------------------------------------------------

export interface ImpactReport {
  /**
   * Sort key: `uid` ascending, lexicographic.
   */
  readonly root: RuleDetail;

  /**
   * Sort key: `uid` ascending, lexicographic.
   */
  readonly childRequirements: readonly RuleDetail[];

  /**
   * Sort key: (file asc, symbol asc, line asc).  Missing fields sort first.
   */
  readonly implementations: readonly SourceReference[];

  /**
   * Sort key: (file asc, symbol asc, line asc).
   */
  readonly verifications: readonly SourceReference[];

  /**
   * Sort key: (uid asc, referencedVersion asc).
   */
  readonly staleReferences: readonly StaleReference[];

  /**
   * True when the walk stopped at `maxDepth` before exhausting the graph.
   * Silent truncation under-reports impact and is therefore forbidden.
   */
  readonly truncated: boolean;
  readonly truncationDepth?: number;

  /**
   * True when the root requirement is itself stale.  Impact of a stale
   * root is qualitatively different: the annotation graph may be describing
   * code that implements an older version of the requirement, so the
   * "affected source files" list reflects an older world.  We surface this
   * as a flag rather than folding it into the stale-references list because
   * the root is a distinct audience: anyone triaging the change must read
   * the diff of the root requirement *before* reading the impact list.
   */
  readonly rootIsStale: boolean;

  /** True when one or more MCP calls failed; impact is a superset. */
  readonly degraded: boolean;

  /** UIDs whose child lookup failed and were conservatively included. */
  readonly unresolved: readonly string[];

  readonly generatedAt: string; // ISO 8601
}

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

export interface AnalyzeImpactOptions {
  /** Default 8.  Documented here because silent defaults are the enemy. */
  readonly maxDepth?: number;
}

const DEFAULT_MAX_DEPTH = 8;

export async function analyzeImpact(
  uid: string,
  opts: AnalyzeImpactOptions = {},
  client: McpClient,
  now: () => Date = () => new Date()
): Promise<ImpactReport> {
  const maxDepth = opts.maxDepth ?? DEFAULT_MAX_DEPTH;

  // Deduplicated rule cache — prevents one MCP call per node in the walk.
  const ruleCache = new Map<string, RuleDetail>();
  const unresolved = new Set<string>();
  let degraded = false;

  const getRule = async (id: string): Promise<RuleDetail | null> => {
    const hit = ruleCache.get(id);
    if (hit) return hit;
    try {
      const detail = await client.traceyRule(id);
      ruleCache.set(id, detail);
      return detail;
    } catch {
      degraded = true;
      unresolved.add(id);
      return null;
    }
  };

  const root = await getRule(uid);
  if (!root) {
    // The root itself is unresolvable.  We cannot say anything; emit an
    // honest report that says so rather than a report that pretends the
    // requirement has no impact.
    throw new Error(`Cannot resolve root requirement ${uid}`);
  }

  // ---------- BFS over the child-requirement graph ----------
  const visited = new Set<string>([uid]);
  const childRequirements: RuleDetail[] = [];
  interface Frame { readonly id: string; readonly depth: number }
  const queue: Frame[] = root.children.map(id => ({ id, depth: 1 }));
  let truncationDepth: number | undefined;

  while (queue.length > 0) {
    const frame = queue.shift()!;

    if (frame.depth > maxDepth) {
      truncationDepth = truncationDepth ?? maxDepth;
      continue;
    }
    // Cycle guard: StrictDoc validates against cycles, but a stale daemon or
    // a partially-rebuilt graph can still present one.  We must not hang.
    if (visited.has(frame.id)) continue;
    visited.add(frame.id);

    const detail = await getRule(frame.id);
    if (!detail) {
      // Conservative: we failed to read the child, so we cannot rule it out.
      // Synthesize a placeholder so the affected set remains a superset.
      // Fields the caller cannot trust are marked by their empty values.
      childRequirements.push({
        uid: frame.id,
        title: "<unresolved>",
        statement: "<unresolved — child lookup failed; conservatively included>",
        currentVersion: 0,
        parents: [],
        children: [],
        implRefs: [],
        verifyRefs: [],
      });
      continue;
    }
    childRequirements.push(detail);
    for (const grandchild of detail.children) {
      if (!visited.has(grandchild)) {
        queue.push({ id: grandchild, depth: frame.depth + 1 });
      }
    }
  }

  // ---------- Collate implementations and verifications ----------
  const allRelevant: RuleDetail[] = [root, ...childRequirements];
  const implRefs = dedupeSourceRefs(allRelevant.flatMap(r => r.implRefs));
  const verifyRefs = dedupeSourceRefs(allRelevant.flatMap(r => r.verifyRefs));

  // ---------- Stale references ----------
  const staleAll = await client.traceyStale();
  const relevantUids = new Set(allRelevant.map(r => r.uid));
  const staleReferences = [...staleAll]
    .filter(s => relevantUids.has(s.uid))
    .sort((a, b) =>
      a.uid.localeCompare(b.uid) || a.referencedVersion - b.referencedVersion
    );

  const rootIsStale = staleAll.some(s => s.uid === root.uid);

  // ---------- Deterministic ordering ----------
  childRequirements.sort((a, b) => a.uid.localeCompare(b.uid));

  return {
    root,
    childRequirements,
    implementations: sortSourceRefs(implRefs),
    verifications: sortSourceRefs(verifyRefs),
    staleReferences,
    truncated: truncationDepth !== undefined,
    ...(truncationDepth !== undefined ? { truncationDepth } : {}),
    rootIsStale,
    degraded,
    unresolved: [...unresolved].sort(),
    generatedAt: now().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// Ordering and deduplication helpers — deterministic by construction.
// ---------------------------------------------------------------------------

function dedupeSourceRefs(refs: readonly SourceReference[]): readonly SourceReference[] {
  const seen = new Set<string>();
  const out: SourceReference[] = [];
  for (const r of refs) {
    const key = `${r.file}\u0000${r.symbol ?? ""}\u0000${r.line ?? -1}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(r);
  }
  return out;
}

function sortSourceRefs(refs: readonly SourceReference[]): readonly SourceReference[] {
  return [...refs].sort((a, b) => {
    const f = a.file.localeCompare(b.file);
    if (f !== 0) return f;
    const s = (a.symbol ?? "").localeCompare(b.symbol ?? "");
    if (s !== 0) return s;
    return (a.line ?? -1) - (b.line ?? -1);
  });
}

// ---------------------------------------------------------------------------
// Canonical serialization.
//
// We do not use JSON.stringify directly because its key order follows
// insertion order, which is not stable across refactors.  We rebuild the
// object with an explicit key order and then stringify, so two reports that
// are deeply equal serialize byte-identically.  That is what makes reports
// diffable in Git — which is precisely the audit use case.
// ---------------------------------------------------------------------------

export function serializeReport(report: ImpactReport): string {
  return JSON.stringify(normalize(report));
}

export function deserializeReport(s: string): ImpactReport {
  return JSON.parse(s) as ImpactReport;
}

function normalize(r: ImpactReport): unknown {
  return {
    root: normalizeRule(r.root),
    childRequirements: r.childRequirements.map(normalizeRule),
    implementations: r.implementations.map(normalizeRef),
    verifications: r.verifications.map(normalizeRef),
    staleReferences: [...r.staleReferences]
      .sort((a, b) => a.uid.localeCompare(b.uid) || a.referencedVersion - b.referencedVersion)
      .map(s => ({
        uid: s.uid,
        referencedVersion: s.referencedVersion,
        currentVersion: s.currentVersion,
      })),
    truncated: r.truncated,
    ...(r.truncationDepth !== undefined ? { truncationDepth: r.truncationDepth } : {}),
    rootIsStale: r.rootIsStale,
    degraded: r.degraded,
    unresolved: [...r.unresolved].sort(),
    generatedAt: r.generatedAt,
  };
}

function normalizeRule(r: RuleDetail): unknown {
  return {
    uid: r.uid,
    title: r.title,
    statement: r.statement,
    currentVersion: r.currentVersion,
    parents: [...r.parents].sort(),
    children: [...r.children].sort(),
    implRefs: [...r.implRefs].sort(compareRefs).map(normalizeRef),
    verifyRefs: [...r.verifyRefs].sort(compareRefs).map(normalizeRef),
  };
}

function normalizeRef(r: SourceReference): unknown {
  return {
    file: r.file,
    ...(r.symbol !== undefined ? { symbol: r.symbol } : {}),
    ...(r.line !== undefined ? { line: r.line } : {}),
  };
}

function compareRefs(a: SourceReference, b: SourceReference): number {
  const f = a.file.localeCompare(b.file);
  if (f !== 0) return f;
  const s = (a.symbol ?? "").localeCompare(b.symbol ?? "");
  if (s !== 0) return s;
  return (a.line ?? -1) - (b.line ?? -1);
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

// (imports omitted for brevity)
import { describe, it, expect, vi } from "vitest";

function makeRule(uid: string, overrides: Partial<RuleDetail> = {}): RuleDetail {
  return {
    uid,
    title: `Title ${uid}`,
    statement: `Statement ${uid}`,
    currentVersion: 1,
    parents: [],
    children: [],
    implRefs: [],
    verifyRefs: [],
    ...overrides,
  };
}

describe("analyzeImpact", () => {
  it("produces a superset of the true affected set when a child lookup fails (conservative traversal)", async () => {
    const client: McpClient = {
      traceyRule: vi.fn(async (uid: string) => {
        if (uid === "ROOT") return makeRule("ROOT", { children: ["C1", "C2"] });
        if (uid === "C1") return makeRule("C1", { implRefs: [{ file: "a.c", symbol: "f" }] });
        // C2 deliberately throws — simulating a transient daemon failure.
        throw new Error("daemon unavailable");
      }),
      traceyStale: vi.fn(async () => []),
    };
    const report = await analyzeImpact("ROOT", {}, client);

    // Superset: the true affected set is {ROOT, C1}.  Our report must include
    // both plus C2 (because we could not rule it out).
    const uids = report.childRequirements.map(r => r.uid);
    expect(uids).toContain("C1");
    expect(uids).toContain("C2");
    expect(report.degraded).toBe(true);
    expect(report.unresolved).toEqual(["C2"]);
  });

  it("terminates on a cyclic graph", async () => {
    // ROOT → A → B → A (cycle)
    const client: McpClient = {
      traceyRule: vi.fn(async (uid: string) => {
        switch (uid) {
          case "ROOT": return makeRule("ROOT", { children: ["A"] });
          case "A": return makeRule("A", { children: ["B"] });
          case "B": return makeRule("B", { children: ["A"] });
          default: throw new Error("unexpected uid");
        }
      }),
      traceyStale: vi.fn(async () => []),
    };
    const report = await analyzeImpact("ROOT", {}, client);
    expect(report.childRequirements.map(r => r.uid).sort()).toEqual(["A", "B"]);
  });

  it("flags the root as stale when tracey_stale contains it", async () => {
    const client: McpClient = {
      traceyRule: vi.fn(async (uid: string) =>
        uid === "ROOT" ? makeRule("ROOT") : makeRule(uid)
      ),
      traceyStale: vi.fn(async () => [
        { uid: "ROOT", referencedVersion: 1, currentVersion: 3 },
      ]),
    };
    const report = await analyzeImpact("ROOT", {}, client);
    expect(report.rootIsStale).toBe(true);
    expect(report.staleReferences).toHaveLength(1);
  });

  it("makes at most one tracey_rule call per distinct UID", async () => {
    const client: McpClient = {
      traceyRule: vi.fn(async (uid: string) =>
        makeRule(uid, { children: uid === "ROOT" ? ["A", "B", "A"] : [] })
      ),
      traceyStale: vi.fn(async () => []),
    };
    await analyzeImpact("ROOT", {}, client);
    // ROOT + A + B = 3 calls, not 4 (the duplicate A child is deduped).
    expect((client.traceyRule as ReturnType<typeof vi.fn>).mock.calls).toHaveLength(3);
  });

  it("round-trips through serialize/deserialize", async () => {
    const client: McpClient = {
      traceyRule: vi.fn(async (uid: string) =>
        makeRule(uid, {
          implRefs: [{ file: "z.c", symbol: "f" }, { file: "a.c", symbol: "g" }],
        })
      ),
      traceyStale: vi.fn(async () => []),
    };
    const report = await analyzeImpact("ROOT", {}, client);
    const round = deserializeReport(serializeReport(report));
    expect(round).toEqual(report);
  });

  it("marks truncation when maxDepth is exceeded, without silently dropping nodes", async () => {
    // ROOT → A → B → C; with maxDepth: 1 we see A but not B or C.
    const client: McpClient = {
      traceyRule: vi.fn(async (uid: string) => {
        switch (uid) {
          case "ROOT": return makeRule("ROOT", { children: ["A"] });
          case "A": return makeRule("A", { children: ["B"] });
          case "B": return makeRule("B", { children: ["C"] });
          case "C": return makeRule("C");
          default: throw new Error(uid);
        }
      }),
      traceyStale: vi.fn(async () => []),
    };
    const report = await analyzeImpact("ROOT", { maxDepth: 1 }, client);
    expect(report.truncated).toBe(true);
    expect(report.truncationDepth).toBe(1);
  });
});
