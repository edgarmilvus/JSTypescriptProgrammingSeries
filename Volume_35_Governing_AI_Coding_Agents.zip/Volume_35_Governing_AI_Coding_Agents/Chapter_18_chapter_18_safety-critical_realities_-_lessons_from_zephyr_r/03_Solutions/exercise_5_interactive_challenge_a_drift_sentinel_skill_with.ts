/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_interactive_challenge_a_drift_sentinel_skill_with.ts
Description: Solutions and Explanations
==========================================
*/

// ============================================================================
// Drift Sentinel — design specification expressed as TypeScript.
//
// This file is the contract, not the runner.  Every type and every function
// signature below is normative: two independent engineers implementing to
// this spec must arrive at byte-compatible state transitions.  Anything the
// spec does not pin down is called out in a comment as a decision point.
// ============================================================================

// ---------------------------------------------------------------------------
// § 1  Observation model
//
// The sentinel maintains a state object across iterations.  The invariant is
// that each observation is MERGED into the corresponding set — never
// replacing it — unless the observation is explicitly marked as a full
// refresh.  Merging matters because the daemon may have been rebuilt between
// iterations (or a call may have failed transiently), in which case the
// query result is a partial view and a replacement would hallucinate a
// smaller "problem set" than actually exists.  Replacing is the correct
// behaviour only when the observation is a first response after a
// `tracey_reload`, which is the one case where the caller knows the daemon
// has freshly rebuilt and the result is authoritative.
// ---------------------------------------------------------------------------

export interface SentinelState {
  /** UIDs reported by tracey_uncovered.  Merged incrementally. */
  readonly uncovered: ReadonlySet<string>;
  /** UIDs reported by tracey_untested. */
  readonly untested: ReadonlySet<string>;
  /** uid → { referencedVersion, currentVersion }; last-write-wins on merge. */
  readonly stale: ReadonlyMap<string, { readonly referencedVersion: number; readonly currentVersion: number }>;
  /** File paths reported by tracey_unmapped. */
  readonly unmapped: ReadonlySet<string>;

  /**
   * Rules whose full text has been fetched via tracey_rule THIS iteration.
   * The anti-false-evidence rule keys off this: a patch proposal for UID x is
   * only permitted if `fetchedRules.has(x)` was populated by a call in the
   * current iteration.  Fetched rules do not persist across iterations; the
   * anti-false-evidence invariant is per-iteration, not per-run.
   */
  readonly fetchedRulesThisIteration: ReadonlyMap<string, RuleExcerpt>;

  /** Patch proposals that have been surfaced to a human, keyed by their
   *  canonical signature (uid + kind + target).  Used to prevent duplicate
   *  proposals within a run. */
  readonly proposedPatches: ReadonlyMap<string, PatchProposal>;

  /** Signatures of proposals a human has explicitly rejected.  Persisted
   *  across runs so a rejection is a permanent fact until the requirement
   *  text changes. */
  readonly rejectedPatches: ReadonlySet<string>;

  /** Signature observed at rejection time, to invalidate rejections when the
   *  requirement text changes.  Without this, a genuine fix after a rejection
   *  would never be re-proposed. */
  readonly rejectionAnchors: ReadonlyMap<string, { readonly requirementHash: string }>;

  readonly iteration: number;
  readonly lastRunAt: string | null;

  /** Set when the sentinel halts; read by the next run. */
  readonly halt: HaltRecord | null;
}

export interface RuleExcerpt {
  readonly uid: string;
  readonly title: string;
  /** Verbatim substring of the statement — the excerpt used in patch text. */
  readonly statementExcerpt: string;
  /** Hash of the full statement, used to invalidate stale rejections. */
  readonly statementHash: string;
}

// ---------------------------------------------------------------------------
// § 2  Observations
//
// Note on parsing: Tracey's MCP responses are human-readable text, not JSON.
// The sentinel therefore parses with a tolerant grammar.  We accept the
// fragility and mitigate it in three ways:
//   (a) the parser is factored into one module so a formatting change touches
//       exactly one file;
//   (b) the parser is fuzzed against a corpus of prior MCP responses captured
//       in the test suite; a change in the upstream formatter is caught as a
//       test failure, not as silent data loss;
//   (c) the parser NEVER infers; if it cannot parse a line, it emits a
//       `parse-failure` observation, and the reflection step treats that as a
//       first-class failure — never as an empty result.
// ---------------------------------------------------------------------------

export type ToolName =
  | "tracey_uncovered"
  | "tracey_untested"
  | "tracey_stale"
  | "tracey_unmapped"
  | "tracey_validate"
  | "tracey_rule"
  | "tracey_reload";

export type Observation =
  | { readonly kind: "uncovered"; readonly uids: readonly string[] }
  | { readonly kind: "untested"; readonly uids: readonly string[] }
  | { readonly kind: "stale"; readonly entries: ReadonlyArray<{ readonly uid: string; readonly referencedVersion: number; readonly currentVersion: number }> }
  | { readonly kind: "unmapped"; readonly paths: readonly string[] }
  | { readonly kind: "validate"; readonly errors: readonly string[]; readonly warnings: readonly string[] }
  | { readonly kind: "rule"; readonly excerpt: RuleExcerpt }
  | { readonly kind: "parse-failure"; readonly rawText: string; readonly tool: ToolName }
  | { readonly kind: "mcp-error"; readonly message: string; readonly tool: ToolName };

// ---------------------------------------------------------------------------
// § 3  Next-action policy (pure)
// ---------------------------------------------------------------------------

export type NextAction =
  | { readonly kind: "query"; readonly tool: ToolName; readonly params?: Readonly<Record<string, unknown>> }
  | { readonly kind: "propose-patch"; readonly proposal: PatchProposal; readonly citesFetch: RuleExcerpt }
  | { readonly kind: "halt"; readonly reason: HaltReason }
  | { readonly kind: "halt-with-handoff"; readonly handoff: Handoff };

export type HaltReason =
  | "converged"
  | "iteration-cap"
  | "parse-failure-budget-exceeded";

export interface Handoff {
  readonly uid: string;
  readonly reason: HandoffReason;
  readonly observationStream: readonly Observation[];
  readonly nextStepSuggestion: string;
}

export type HandoffReason =
  | "requirement-too-vague"
  | "ambiguous-target-symbol"
  | "conflicting-evidence"
  | "human-judgment-required";

/**
 * The policy is a pure function of state and the last observation.  No I/O,
 * no time, no randomness.  Every side effect the sentinel performs is
 * mediated by the runner, which is what makes the policy testable and the
 * audit trail reproducible.
 */
export function chooseNextAction(
  state: SentinelState,
  last: Observation | null
): NextAction {
  // ---- Parse failures: never treat as empty ----
  if (last?.kind === "parse-failure") {
    // A parse failure is observation loss.  We do not advance past it and
    // we do not infer emptiness.
    if (state.iteration > 5) {
      return { kind: "halt", reason: "parse-failure-budget-exceeded" };
    }
    return { kind: "query", tool: "tracey_reload" };
  }

  // ---- Transient MCP errors: reload and retry once ----
  if (last?.kind === "mcp-error") {
    return { kind: "query", tool: "tracey_reload" };
  }

  // ---- Convergence: a full pass produced no new facts and no proposals ----
  if (hasConverged(state)) {
    return { kind: "halt", reason: "converged" };
  }

  // ---- Iteration cap ----
  if (state.iteration >= MAX_ITERATIONS) {
    return { kind: "halt", reason: "iteration-cap" };
  }

  // ---- Preference order for the next query.  This is a deliberate policy:
  //      stale first, because a stale requirement's "uncovered" status may be
  //      an artefact of the version skew; then uncovered (the largest
  //      population); then untested; then unmapped (the broadest scope,
  //      called last because it is the most expensive).
  const nextQuery = pickNextQuery(state);
  if (nextQuery !== null) {
    return { kind: "query", tool: nextQuery };
  }

  // ---- If everything is queried, look for a patch opportunity ----
  const patch = findPatchOpportunity(state);
  if (patch !== null) {
    // Anti-false-evidence invariant: the rule MUST have been fetched in
    // this iteration.  If it has not, we downgrade to a query for the rule.
    const fetched = state.fetchedRulesThisIteration.get(patch.uid);
    if (fetched === undefined) {
      return { kind: "query", tool: "tracey_rule", params: { uid: patch.uid } };
    }
    return { kind: "propose-patch", proposal: patch, citesFetch: fetched };
  }

  return { kind: "halt", reason: "converged" };
}

const MAX_ITERATIONS = 20;

function hasConverged(state: SentinelState): boolean {
  // Convergence criterion: iteration > 0 AND all four problem sets have
  // been observed at least once AND no proposal has been generated this
  // iteration.  A "no proposal" pass is what marks convergence, because a
  // proposal means the sentinel found actionable drift.
  return state.iteration > 0 && !proposedAnythingThisIteration(state);
}

function proposedAnythingThisIteration(state: SentinelState): boolean {
  // In the real runner this is a per-iteration counter; here for clarity.
  return state.proposedPatches.size > 0 && state.iteration <= state.proposedPatches.size;
}

function pickNextQuery(state: SentinelState): ToolName | null {
  // The sentinel keeps a per-run query log; when this list covers all
  // tools, further queries are pointless until a new observation invalidates
  // something.  Simplification: we return a tool in preference order if we
  // have not queried it this iteration.
  const queried = new Set<string>(); // populated by the runner in practice
  if (!queried.has("tracey_stale")) return "tracey_stale";
  if (!queried.has("tracey_uncovered")) return "tracey_uncovered";
  if (!queried.has("tracey_untested")) return "tracey_untested";
  if (!queried.has("tracey_unmapped")) return "tracey_unmapped";
  if (!queried.has("tracey_validate")) return "tracey_validate";
  return null;
}

function findPatchOpportunity(state: SentinelState): PatchProposal | null {
  // The only patch the sentinel auto-proposes is "annotate a source location
  // with r[impl …] or r[verify …]" for a requirement that is uncovered or
  // untested AND whose text is unambiguous.  All other drift (stale versions,
  // broken references) is human work and is surfaced, not patched.
  for (const uid of state.uncovered) {
    const excerpt = state.fetchedRulesThisIteration.get(uid);
    if (excerpt === undefined) continue;
    if (isVague(excerpt.statementExcerpt)) continue; // § 8 halt-with-handoff case
    // Actual target discovery requires tracey_unmapped analysis; omitted here.
  }
  return null;
}

function isVague(statement: string): boolean {
  // A per-project tuning heuristic.  Conservative on purpose: too-vague
  // statements cascade into "I don't know" handoffs, which is the safe side.
  const vagueMarkers = ["as appropriate", "reasonable", "as needed", "TBD", "various"];
  return vagueMarkers.some(m => statement.toLowerCase().includes(m.toLowerCase()));
}

// ---------------------------------------------------------------------------
// § 4  Patch proposal format
// ---------------------------------------------------------------------------

export interface PatchProposal {
  readonly uid: string;
  readonly kind: "impl" | "verify";
  readonly targetFile: string;
  readonly targetSymbol: string;
  /** One or two sentences: WHY this code satisfies this requirement. */
  readonly justification: string;
  /** Verbatim substring of the requirement's statement, from the fetch. */
  readonly requirementExcerpt: string;
}

export function proposalSignature(p: PatchProposal): string {
  return `${p.uid}\u0000${p.kind}\u0000${p.targetFile}\u0000${p.targetSymbol}`;
}

// Rejection feedback: when a human rejects a proposal, the sentinel records
// (a) the signature in `rejectedPatches` and (b) a hash of the requirement
// text at rejection time in `rejectionAnchors`.  On subsequent runs, a
// proposal whose signature is in `rejectedPatches` is only re-proposed if
// the current `statementHash` differs from the anchor — i.e. the requirement
// has been edited, invalidating the old rejection.  This is the discriminator
// between "we tried this and it was wrong" and "the world has changed."

export function shouldRepropose(
  state: SentinelState,
  proposal: PatchProposal,
  currentHash: string
): boolean {
  const sig = proposalSignature(proposal);
  if (!state.rejectedPatches.has(sig)) return true;
  const anchor = state.rejectionAnchors.get(sig);
  return anchor === undefined || anchor.requirementHash !== currentHash;
}

// ---------------------------------------------------------------------------
// § 5  Failure taxonomy — four ways reflection goes wrong
//
// (a) Treating a transient MCP error as "no uncovered" — SYMPTOM: a call
//     throws and the sentinel logs "uncovered: 0" in the same iteration.
//     CORRECT REFLECTION: distinguish `Observation.kind === "mcp-error"`
//     from `Observation.kind === "uncovered"` with `uids.length === 0`.
//     INVARIANT: the observation type has no path that collapses errors into
//     empty lists; the compiler enforces the distinction because the two
//     variants are non-overlapping.
//
// (b) Annotating a test with verify for a requirement the test does not
//     actually assert — SYMPTOM: the sentinel proposes `// r[verify REQ-X]`
//     on a function whose body has no assertion touching REQ-X's behavior.
//     CORRECT REFLECTION: the anti-false-evidence rule requires the sentinel
//     to have fetched REQ-X's statement, and to quote a substring of it in
//     the proposal's `requirementExcerpt`.  The excerpt is presented to the
//     human reviewer next to the proposed target, so the reviewer can see
//     whether the excerpt matches the code.  INVARIANT: the excerpt is a
//     verbatim substring — not a paraphrase — because paraphrases leak the
//     sentinel's interpretation, which is what we are trying to prevent.
//
// (c) Treating a stale reference as fresh because tracey_rule returned a
//     rule without version information — SYMPTOM: the sentinel sees "tracey_rule
//     returned REQ-X" and marks it as covered, ignoring tracey_stale.
//     CORRECT REFLECTION: coverage and staleness are orthogonal signals.
//     A rule with verify references but a stale root must be reported as
//     BOTH.  INVARIANT: `stale` is a separate set; the sentinel never
//     removes a UID from `stale` because it was seen in a rule fetch.
//
// (d) Repeatedly proposing the same patch after a validate failure that the
//     patch would not fix — SYMPTOM: identical `propose-patch` actions in
//     consecutive iterations, with validate errors unchanged.  CORRECT
//     REFLECTION: after a validate error, the policy checks whether any
//     outstanding proposal targets a UID mentioned in the error text; if
//     not, the proposal is downgraded to a query for the error's UID so the
//     sentinel learns what the error actually is.  INVARIANT: the per-run
//     `proposedPatches` map prevents proposing the same signature twice in
//     one run; the cross-run `rejectedPatches` set prevents it across runs.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// § 6  Bounded iteration, convergence
// ---------------------------------------------------------------------------

// MAX_ITERATIONS = 20 (declared above).  Rationale: the sentinel's per-cycle
// work is at most five diagnostic queries plus one rule fetch per unresolved
// UID.  A cap of twenty cycles bounds total MCP traffic per run at roughly
// 120 calls, which is small enough not to compete with a developer's
// interactive dashboard session for the daemon's single-threaded rebuild path.
// Without a cap, a pathological requirement set (e.g., a circular unmapped
// dependency that the sentinel cannot fix) becomes a denial-of-service vector
// against the daemon: the sentinel burns CPU on every cycle, the daemon
// rebuilds on every filesystem event, and the developer's LSP latency climbs.

// When the cap is reached, the sentinel emits:
//   { kind: "halt", reason: "iteration-cap" }
// The runner writes the state to disk and surfaces the outstanding work to
// the human.  Nothing is auto-patched on a cap-reaching run — a run that
// could not converge is a run whose model of the graph is incomplete.

// ---------------------------------------------------------------------------
// § 7  Pre-commit hook integration
//
// `tracey pre-commit` blocks a commit if a rule's text changed without a
// version bump.  `tracey bump` performs the bump.  The gap: neither tool
// distinguishes drift that existed BEFORE the index was staged from drift
// INTRODUCED BY the staged changes.  A commit that touches an unrelated
// subsystem must not fail because twenty stale references exist elsewhere.
//
// The sentinel's pre-commit mode solves this with a two-snapshot diff:
//
//   1. Snapshot the graph state at HEAD: run tracey_uncovered / untested /
//      stale / unmapped against the working tree as it is, but *filter the
//      results to the files staged in this commit.*  Any problem whose
//      source location lies outside the staged diff is pre-existing drift
//      and is NOT a blocker.
//
//   2. Snapshot the graph state after staging: re-run the same four queries,
//      again filtered to the staged files.  Any problem whose source location
//      lies inside the staged diff did not exist a moment ago, and is
//      therefore either drift introduced by this commit or a pre-existing
//      drift item whose *file* was touched.  In either case the hook fails,
//      with a message that names both the stale UID and the file.
//
// The filter is the crux: without it, the hook is noise and developers will
// bypass it with --no-verify, which is the actual failure mode of badly tuned
// pre-commit hooks.  With it, the hook is silent on a clean staged diff and
// loud exactly when the developer's own change introduced drift.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// § 8  The "do nothing" path — halt-with-handoff
//
// The sentinel must be able to say "I don't know" and be trusted.  When the
// policy cannot determine whether a given function implements a given
// requirement — typically because the requirement's statement is too vague
// to be mechanistically matched against code — it must NOT guess.  It emits:
//
//   { kind: "halt-with-handoff", handoff: { uid, reason, observationStream,
//                                          nextStepSuggestion } }
//
// The runner writes the handoff to a durable store (a per-UID note in a
// `.tracey/sentinel/handoffs/` directory works) and surfaces it to the human
// with the exact observation stream that led to the handoff.  The next run
// reads the handoffs directory and skips UIDs that already have a handoff
// until the requirement text changes, at which point the handoff is
// automatically cleared — the same invalidation rule as rejected patches,
// keyed on the same statement hash.
//
// Penalizing this outcome is the single most common anti-pattern in
// agentic tooling.  An agent that cannot say "I don't know" will, by
// necessity, say something wrong; in a DO-178C context, a wrong answer
// produces fabricated evidence, which is worse than a missing one.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// § 9  Meta-reflection: self-audit summary
//
// Over the last N runs, the sentinel can emit an audit digest containing:
//
//   • Requirements it has patched more than once (a strong signal of a
//     flaky or over-broad annotation grammar; the same requirement keeps
//     drifting because the annotation does not actually pin what it claims).
//
//   • Tool usage histogram — which diagnostic tools dominated, in which
//     order.  A run that spends most cycles on tracey_unmapped is telling
//     you the codebase has a lot of unannotated code, which is a
//     process problem, not a tool problem.
//
//   • Reconciliation events — the sentinel's model contradicted an
//     observation.  A high count here means either the daemon was unstable
//     (filesystem churn outran the rebuild) or the sentinel's prior model was
//     wrong.  Distinguishing the two requires cross-checking timestamps.
//
//   • Low-confidence regions of the graph — UIDs with more than K handoffs
//     over N runs.  These are requirements whose text is too vague to
//     govern code, and they should be the next items on the specification
//     team's review agenda.
//
// An auditor uses the digest to decide whether the sentinel's automated
// patches can be trusted: if the digest shows the sentinel patching the
// same UID repeatedly and the requirement statement is unchanged, the audit
// conclusion is that the *statement itself* is the problem, and automated
// patience is not going to fix it.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// § 10  Final written defense — one page
//
// CLAIM: A drift sentinel that never annotates code — that only reports —
//        is strictly more valuable in a DO-178C context than one that
//        annotates correctly 95% of the time.
//
// VERDICT: I agree with the claim, with one quantitative caveat about what
//          "strictly more valuable" means in the presence of human review.
//
// The strongest form of the argument is this: an annotation is an assertion
// of *evidence existence*.  "// r[verify REQ-X]" means "this test verifies
// REQ-X."  A wrong assertion of evidence is not a missing artefact; it is a
// fabricated one.  In DO-178C, a fabricated verification record is exactly
// the failure the entire standard is designed to prevent.  The applicant's
// argument to the certification authority is that the evidence in the
// submission supports the claims in the submission; a sentinel that injects
// wrong evidence breaks the argument in a way that *cannot be detected from
// the submission itself*.  That is the worst property an audit defect can
// have: it is invisible from within the artefact.
//
// A reporting-only sentinel loses nothing an auditor can use and gains
// something an auto-annotating one cannot offer: it never contributes a
// claim the human must independently verify.  Every item it surfaces is a
// question ("is this function the right implementation of REQ-X?"), and every
// answer is a human act, and every human act has an author and a date and is
// therefore auditable.
//
// The one quantitative escape hatch: if the annotation is 95% correct AND
// the 5% error rate is *detected* by an independent mechanism before the
// annotation enters the audit trail, then the auto-annotating sentinel can
// plausibly be more valuable, because it converts a slow human review into
// a fast machine review for the 95% of cases.  The exact conditions under
// which this is safe:
//
//   1. Every auto-generated annotation carries a machine-readable provenance
//      marker (e.g. a trailing `// [sentinel run <id>]` comment).
//   2. The sentinel presents each proposal to a human reviewer with the
//      requirement excerpt it used, and the reviewer accepts or rejects —
//      the annotation is not written to source until acceptance.
//   3. An independent second tool (`tracey_validate --deny warnings`) runs on
//      the annotated tree before merge, and any proposal whose annotation
//      causes validate to fail is automatically retracted.
//   4. Rejected proposals are recorded permanently and never re-proposed
//      unless the requirement text changes.
//   5. The sentinel's self-audit (see § 9) is reviewed at every baseline
//      change, and a rejection rate above a project-specific threshold
//      automatically disables auto-proposal mode and drops the sentinel back
//      to reporting-only.
//
// Without every one of those five conditions, the reporting-only sentinel
// dominates.  With all five, the auto-annotating sentinel is a legitimate
// accelerator — but note that the conditions do most of the value-creating
// work, and the sentinel's actual contribution is diff-minimisation.  That
// is a reasonable thing to be, but it is not the same as being the trust
// anchor for the artifact.  The reporting-only sentinel can be trusted; the
// auto-annotating one cannot be, and that asymmetry is what "strictly more
// valuable in a DO-178C context" means.
// ---------------------------------------------------------------------------
