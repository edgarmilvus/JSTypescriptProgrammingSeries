/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

/* =========================================================================
 * checkout-remediation.ts
 * A minimal, self-contained harness that:
 *   1. Reads missing-evidence gaps from Tracey.
 *   2. Converts each gap into a scoped task for a coding assistant.
 *   3. Re-queries Tracey to prove the gap is closed.
 * ========================================================================= */

/* -------------------------------------------------------------------------
 * 1. Domain types
 * ----------------------------------------------------------------------- */

export type GapKind = "uncovered" | "untested";

/** A single piece of missing evidence reported by Tracey. */
export interface Gap {
  /** Requirement UID, e.g. "checkout.tax.calculate". */
  readonly uid: string;
  /** Which kind of evidence is missing. */
  readonly kind: GapKind;
  /** Spec name from the Tracey config, e.g. "checkout". */
  readonly spec: string;
  /** Implementation name from the Tracey config, e.g. "typescript". */
  readonly impl: string;
  /** Candidate files the gap was detected in (may be empty). */
  readonly files: readonly string[];
  /** Optional call-site hint, e.g. "POST /api/checkout". */
  readonly route?: string;
}

/** The normative text backing a requirement. */
export interface RuleDetail {
  readonly uid: string;
  readonly title: string;
  readonly statement: string;
  readonly rationale?: string;
  /** Existing impl/verify references found by Tracey. */
  readonly references: readonly string[];
}

export interface ValidationReport {
  readonly errors: readonly string[];
  readonly warnings: readonly string[];
}

/** The exact, scoped work order handed to a coding assistant. */
export interface RemediationTask {
  readonly gap: Gap;
  readonly rule: RuleDetail;
  /** Human-readable instructions, one line per rule. */
  readonly instructions: string;
  /** Files the assistant is allowed to edit during this task. */
  readonly allowedFiles: readonly string[];
  /** Annotations that MUST appear in the diff for the task to count. */
  readonly requiredAnnotations: readonly string[];
}

export interface FileEdit {
  readonly path: string;
  readonly diff: string;
}

export interface RemediationResult {
  readonly tasksClosed: number;
  readonly tasksDeferred: number;
  readonly errors: readonly string[];
}

/* -------------------------------------------------------------------------
 * 2. External dependencies (MCP-style boundary)
 * ----------------------------------------------------------------------- */

/** Subset of the Tracey MCP surface used by this harness. */
export interface TraceyClient {
  uncovered(filter?: { prefix?: string }): Promise<readonly Gap[]>;
  untested(filter?: { prefix?: string }): Promise<readonly Gap[]>;
  rule(uid: string): Promise<RuleDetail>;
  validate(options?: { denyWarnings?: boolean }): Promise<ValidationReport>;
}

/** Whatever coding assistant is wired in (Claude Code, Codex, Cursor, ...). */
export interface CodingAssistant {
  apply(task: RemediationTask): Promise<readonly FileEdit[]>;
}

/* -------------------------------------------------------------------------
 * 3. Orchestrator
 * ----------------------------------------------------------------------- */

export class RemediationOrchestrator {
  constructor(
    private readonly tracey: TraceyClient,
    private readonly assistant: CodingAssistant,
  ) {}

  /**
   * Discover every missing-evidence gap under a prefix and drive the
   * assistant to close each one. Returns a summary that can be dropped
   * into a CI artifact or a PR comment.
   */
  async closeMissingEvidence(prefix = "checkout."): Promise<RemediationResult> {
    // 3a. Discover gaps in parallel.
    const [uncovered, untested] = await Promise.all([
      this.tracey.uncovered({ prefix }),
      this.tracey.untested({ prefix }),
    ]);

    // 3b. Collapse duplicates — a rule that is both uncovered and
    //     untested only needs one work order.
    const unique = dedupeGaps([...uncovered, ...untested]);

    // 3c. Materialise tasks. Fetching the rule text is what turns a
    //     bare UID into something an assistant can act on.
    const tasks = await Promise.all(unique.map((gap) => this.buildTask(gap)));

    // 3d. Dispatch each task, then immediately re-verify.
    let tasksClosed = 0;
    let tasksDeferred = 0;
    const errors: string[] = [];

    for (const task of tasks) {
      try {
        await this.assistant.apply(task);
        const stillGapped = await this.isStillGapped(task.gap.uid);
        if (stillGapped) {
          tasksDeferred += 1;
          errors.push(`agent did not close gap ${task.gap.uid}`);
        } else {
          tasksClosed += 1;
        }
      } catch (err) {
        tasksDeferred += 1;
        errors.push(`task ${task.gap.uid} failed: ${(err as Error).message}`);
      }
    }

    return { tasksClosed, tasksDeferred, errors };
  }

  /**
   * Turn a gap into a concrete work order.
   * The rule text is fetched from Tracey so the assistant never has to
   * guess what the requirement means.
   */
  private async buildTask(gap: Gap): Promise<RemediationTask> {
    const rule = await this.tracey.rule(gap.uid);
    const lines = [
      `Close the ${gap.kind} gap for ${gap.uid}.`,
      `Requirement: ${rule.statement}`,
      gap.route ? `Call site: ${gap.route}` : "",
      `Add exactly one // r[verify ${gap.uid}] annotation to the test ` +
        `that exercises this behaviour.`,
      "Do not rename the requirement. Do not edit the spec.",
    ].filter((line) => line.length > 0);

    return {
      gap,
      rule,
      instructions: lines.join("\n"),
      allowedFiles: gap.files.length > 0 ? gap.files : ["src/**", "tests/**"],
      requiredAnnotations: [`// r[verify ${gap.uid}]`],
    };
  }

  /** Re-ask Tracey whether the UID is still in any missing-evidence bucket. */
  private async isStillGapped(uid: string): Promise<boolean> {
    const [uncovered, untested] = await Promise.all([
      this.tracey.uncovered(),
      this.tracey.untested(),
    ]);
    return [...uncovered, ...untested].some((g) => g.uid === uid);
  }
}

/** Collapse gaps by UID, keeping the first occurrence. */
function dedupeGaps(gaps: readonly Gap[]): Gap[] {
  const byUid = new Map<string, Gap>();
  for (const gap of gaps) {
    if (!byUid.has(gap.uid)) byUid.set(gap.uid, gap);
  }
  return [...byUid.values()];
}
