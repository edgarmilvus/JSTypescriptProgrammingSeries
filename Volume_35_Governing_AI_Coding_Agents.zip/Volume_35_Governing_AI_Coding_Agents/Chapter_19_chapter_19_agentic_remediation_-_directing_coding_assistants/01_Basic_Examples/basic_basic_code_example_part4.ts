/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

/* =========================================================================
 * checkout-remediation.test.ts
 * ========================================================================= */

import { describe, it, expect } from "vitest";
import {
  RemediationOrchestrator,
  type CodingAssistant,
  type FileEdit,
  type Gap,
  type RemediationTask,
  type RuleDetail,
  type TraceyClient,
  type ValidationReport,
} from "./checkout-remediation";

/* --- A tiny in-memory Tracey stand-in. --------------------------------- */

class FakeTracey implements TraceyClient {
  private readonly gaps = new Map<string, Gap>();

  constructor(seed: readonly Gap[]) {
    for (const gap of seed) this.gaps.set(gap.uid, gap);
  }

  async uncovered(): Promise<readonly Gap[]> {
    return [...this.gaps.values()].filter((g) => g.kind === "uncovered");
  }

  async untested(): Promise<readonly Gap[]> {
    return [...this.gaps.values()].filter((g) => g.kind === "untested");
  }

  async rule(uid: string): Promise<RuleDetail> {
    return {
      uid,
      title: "Tax is calculated at checkout",
      statement:
        "When the user submits checkout, the system shall compute tax " +
        "based on the shipping address and persist it on the order.",
      references: [],
    };
  }

  async validate(): Promise<ValidationReport> {
    return { errors: [], warnings: [] };
  }

  markClosed(uid: string): void {
    this.gaps.delete(uid);
  }
}

/* --- A fake coding assistant that always succeeds. --------------------- */

class FakeAssistant implements CodingAssistant {
  public readonly tasks: RemediationTask[] = [];

  constructor(private readonly tracey: FakeTracey) {}

  async apply(task: RemediationTask): Promise<readonly FileEdit[]> {
    this.tasks.push(task);
    this.tracey.markClosed(task.gap.uid);
    return [
      {
        path: "tests/checkout.test.ts",
        diff: `+  // r[verify ${task.gap.uid}]`,
      },
    ];
  }
}

/* --- The test. -------------------------------------------------------- */

describe("RemediationOrchestrator", () => {
  it("closes an untested requirement with one scoped task", async () => {
    const tracey = new FakeTracey([
      {
        uid: "checkout.tax.calculate",
        kind: "untested",
        spec: "checkout",
        impl: "typescript",
        files: ["src/checkout/tax.ts"],
        route: "POST /api/checkout",
      },
    ]);
    const assistant = new FakeAssistant(tracey);
    const orchestrator = new RemediationOrchestrator(tracey, assistant);

    const result = await orchestrator.closeMissingEvidence("checkout.");

    expect(result.tasksClosed).toBe(1);
    expect(result.tasksDeferred).toBe(0);
    expect(result.errors).toEqual([]);
    expect(assistant.tasks).toHaveLength(1);

    const [task] = assistant.tasks;
    expect(task.requiredAnnotations).toEqual([
      "// r[verify checkout.tax.calculate]",
    ]);
    expect(task.instructions).toContain("checkout.tax.calculate");
    expect(task.instructions).toContain("POST /api/checkout");
  });
});
