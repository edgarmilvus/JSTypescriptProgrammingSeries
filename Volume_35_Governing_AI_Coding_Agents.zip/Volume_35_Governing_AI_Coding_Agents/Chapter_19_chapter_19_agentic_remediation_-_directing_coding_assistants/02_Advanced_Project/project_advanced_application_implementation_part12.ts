/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

// services/remediation/src/policy.ts

/**
 * Guardrail configuration for the remediation director.
 *
 * A policy is deliberately *static* per run — it does not vary per work
 * order, because a varying policy would make post-hoc audit impossible.
 * The policy is also narrow: it caps blast radius (files, lines) and
 * hard-fails on any category of change we have decided is out of scope
 * for automated remediation.
 */
export interface RemediationPolicy {
  /** Tracey `spec_impl` filter (e.g. "nimbus-ledger/api"). */
  readonly specImpl: string;
  /** Requirement ID prefixes eligible for automated remediation. */
  readonly allowedPrefixes: readonly string[];
  /** Hard cap on number of distinct files a single patch may touch. */
  readonly maxFilesTouched: number;
  /** Hard cap on net added lines (excluding test files). */
  readonly maxNetAddedLines: number;
  /** Globs that patches are NEVER permitted to modify. */
  readonly deniedPaths: readonly string[];
  /** When true, the gate fails on warnings as well as errors. */
  readonly denyWarnings: boolean;
  /** Maximum number of work orders to emit per invocation. */
  readonly maxWorkOrdersPerRun: number;
}

export const DEFAULT_NIMBUS_POLICY: RemediationPolicy = Object.freeze({
  specImpl: 'nimbus-ledger/api',
  allowedPrefixes: ['NIMBUS-TENANT-', 'NIMBUS-AUTH-', 'NIMBUS-LEDGER-', 'NIMBUS-WEBHOOK-'],
  maxFilesTouched: 6,
  maxNetAddedLines: 400,
  deniedPaths: [
    '**/*.generated.ts',
    '**/migrations/**',
    '**/postinstall*',
    'package.json',
    'pnpm-lock.yaml',
    '.github/workflows/**',
    'docs/spec/**',
  ],
  denyWarnings: true,
  maxWorkOrdersPerRun: 3,
});
