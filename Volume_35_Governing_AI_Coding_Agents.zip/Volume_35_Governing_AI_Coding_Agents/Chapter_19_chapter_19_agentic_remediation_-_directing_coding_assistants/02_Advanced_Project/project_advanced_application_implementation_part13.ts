/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part13.ts
Description: Advanced Application Implementation
==========================================
*/

// services/remediation/src/tracey-mcp.ts
import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process';

/**
 * Minimal JSON-RPC 2.0 client for the Tracey MCP server over stdio.
 *
 * The client is intentionally minimal: it implements exactly the
 * `tools/list` and `tools/call` verbs, since those are the only verbs the
 * remediation director needs. It buffers unsolicited notifications (of
 * which Tracey emits none today) and correlates responses by request id.
 */
export class TraceyMcpClient {
  private readonly proc: ChildProcessWithoutNullStreams;
  private readonly pending = new Map<number, {
    resolve: (v: unknown) => void;
    reject: (e: unknown) => void;
  }>();
  private nextId = 1;
  private buffer = '';

  constructor(private readonly cwd: string) {
    this.proc = spawn('tracey', ['mcp'], { cwd });
    this.proc.stdout.setEncoding('utf8');
    this.proc.stdout.on('data', (chunk: string) => this.onChunk(chunk));
    this.proc.stderr.setEncoding('utf8');
    this.proc.stderr.on('data', (chunk: string) =>
      process.stderr.write(`[tracey] ${chunk}`),
    );
  }

  private onChunk(chunk: string): void {
    this.buffer += chunk;
    let idx: number;
    while ((idx = this.buffer.indexOf('\n')) >= 0) {
      const line = this.buffer.slice(0, idx).trim();
      this.buffer = this.buffer.slice(idx + 1);
      if (line.length === 0) continue;
      try {
        const msg = JSON.parse(line) as { id?: number; result?: unknown; error?: unknown };
        if (msg.id !== undefined && this.pending.has(msg.id)) {
          const entry = this.pending.get(msg.id)!;
          this.pending.delete(msg.id);
          if (msg.error !== undefined) entry.reject(msg.error);
          else entry.resolve(msg.result);
        }
      } catch {
        // Tracey may emit non-JSON diagnostic lines on stdout; ignore them.
      }
    }
  }

  /** Invoke an MCP tool by name and await its structured result. */
  async call(tool: string, args: Record<string, unknown> = {}): Promise<string> {
    const id = this.nextId++;
    const payload = JSON.stringify({
      jsonrpc: '2.0',
      id,
      method: 'tools/call',
      params: { name: tool, arguments: args },
    });
    this.proc.stdin.write(payload + '\n');
    const result = await new Promise<unknown>((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
    });
    // MCP tool results arrive as { content: [{ type: 'text', text: '...' }] }.
    const asContent = result as { content?: Array<{ text?: string }> };
    return asContent.content?.[0]?.text ?? '';
  }

  /** Read-only helpers used by the planner. */
  status(): Promise<string> { return this.call('tracey_status'); }
  untested(specImpl: string, prefix?: string): Promise<string> {
    return this.call('tracey_untested', {
      spec_impl: specImpl,
      ...(prefix !== undefined ? { prefix } : {}),
    });
  }
  uncovered(specImpl: string, prefix?: string): Promise<string> {
    return this.call('tracey_uncovered', {
      spec_impl: specImpl,
      ...(prefix !== undefined ? { prefix } : {}),
    });
  }
  stale(specImpl: string): Promise<string> {
    return this.call('tracey_stale', { spec_impl: specImpl });
  }
  rule(uid: string): Promise<string> { return this.call('tracey_rule', { uid }); }
  validate(specImpl: string, denyWarnings: boolean): Promise<string> {
    return this.call('tracey_validate', {
      spec_impl: specImpl,
      deny_warnings: denyWarnings,
    });
  }

  close(): void { this.proc.kill('SIGTERM'); }
}
