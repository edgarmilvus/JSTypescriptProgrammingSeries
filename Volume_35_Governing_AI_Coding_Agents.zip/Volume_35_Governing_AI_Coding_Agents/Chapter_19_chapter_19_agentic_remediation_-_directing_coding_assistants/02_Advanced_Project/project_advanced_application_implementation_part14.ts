/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part14.ts
Description: Advanced Application Implementation
==========================================
*/

// services/remediation/src/planner.ts
import type { TraceyMcpClient } from './tracey-mcp.js';
import type { RemediationPolicy } from './policy.js';

export type GapKind = 'untested' | 'uncovered' | 'stale';

export interface WorkOrder {
  readonly kind: GapKind;
  readonly requirementUid: string;
  /** The normative text pulled fresh from the spec — sourced from tracey_rule. */
  readonly requirementText: string;
  /** Which implementation Tracey believes is deficient. */
  readonly specImpl: string;
}

const UID_RE = /\b([A-Z][A-Z0-9]+(?:-[A-Z0-9]+)*-\d+)\b/g;

function extractUids(raw: string): string[] {
  const set = new Set<string>();
  for (const match of raw.matchAll(UID_RE)) {
    set.add(match[1]);
  }
  return [...set];
}

/**
 * Build a bounded list of work orders for this run.
 *
 * The planner deliberately interleaves three gap kinds in priority order:
 *   1. `stale`     — spec text changed; code annotations now lie.
 *   2. `uncovered` — requirement has zero implementation references.
 *   3. `untested`  — requirement is implemented but has no verification.
 *
 * Stale first because a stale annotation is a *correctness* hazard: an
 * agent that later edits nearby code would be reasoning against a
 * outdated requirement text. Uncovered second because a missing impl is
 * a stronger signal than a missing test. Untested last because a
 * missing test is (usually) a smaller blast-radius change.
 */
export async function planWorkOrders(
  client: TraceyMcpClient,
  policy: RemediationPolicy,
): Promise<WorkOrder[]> {
  const orders: WorkOrder[] = [];

  const [staleRaw, uncoveredRaw, untestedRaw] = await Promise.all([
    client.stale(policy.specImpl),
    client.uncovered(policy.specImpl),
    client.untested(policy.specImpl),
  ]);

  const candidates: Array<[GapKind, string]> = [
    ['stale', staleRaw],
    ['uncovered', uncoveredRaw],
    ['untested', untestedRaw],
  ];

  for (const [kind, raw] of candidates) {
    for (const uid of extractUids(raw)) {
      if (orders.length >= policy.maxWorkOrdersPerRun) return orders;
      if (!policy.allowedPrefixes.some((p) => uid.startsWith(p))) continue;

      // Fetch the normative text fresh; do not trust cached copies.
      const ruleText = await client.rule(uid);
      if (!ruleText || ruleText.trim().length === 0) continue;

      orders.push({
        kind,
        requirementUid: uid,
        requirementText: ruleText,
        specImpl: policy.specImpl,
      });
    }
  }

  return orders;
}
