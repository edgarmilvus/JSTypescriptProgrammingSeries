/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part15.ts
Description: Advanced Application Implementation
==========================================
*/

// services/remediation/src/dispatcher.ts
import type { WorkOrder } from './planner.js';
import type { RemediationPolicy } from './policy.js';

export interface AgentTransport {
  /**
   * Apply a work order to the working tree and return a change summary.
   * Implementations MUST NOT commit; the director owns the commit step.
   */
  apply(order: WorkOrder, prompt: string): Promise<{
    filesTouched: readonly string[];
    netAddedLines: number;
    rawDiff: string;
  }>;
}

/**
 * Render the system prompt that frames every agent turn. The prompt is
 * deterministic — identical work orders produce byte-identical prompts,
 * which is what lets us cache and diff agent behaviour over time.
 */
export function buildAgentPrompt(order: WorkOrder, policy: RemediationPolicy): string {
  const guardrailLines = [
    `- Do NOT modify any file under docs/spec/. The spec is human-authored.`,
    `- Do NOT modify any file matched by: ${policy.deniedPaths.join(', ')}.`,
    `- Do NOT exceed ${policy.maxFilesTouched} touched files.`,
    `- Do NOT exceed ${policy.maxNetAddedLines} net added non-test lines.`,
    `- In test files you may ONLY use 'r[verify <UID>]'. 'r[impl <UID>]' in a test file is a build-breaking error.`,
    `- In production files you MUST annotate the code you write with 'r[impl <UID>]' on the line immediately above the function or block.`,
    `- Return a unified diff only. Do not commit.`,
  ].join('\n');

  const verb = order.kind === 'untested' ? 'verification test' : 'implementation';

  return [
    `# Remediation Work Order`,
    ``,
    `Gap kind: ${order.kind}`,
    `Requirement UID: ${order.requirementUid}`,
    `Implementation scope: ${order.specImpl}`,
    `Required artifact: a ${verb} that closes the gap.`,
    ``,
    `## Normative Requirement Text (source of truth)`,
    ``,
    '```',
    order.requirementText.trim(),
    '```',
    ``,
    `## Guardrails`,
    ``,
    guardrailLines,
  ].join('\n');
}

/**
 * Dispatch a single work order and enforce the pre-commit budget.
 * Throws if the agent's change exceeds the policy budget — the director
 * treats budget violations as an agent failure, not a policy failure.
 */
export async function dispatchWorkOrder(
  transport: AgentTransport,
  policy: RemediationPolicy,
  order: WorkOrder,
): Promise<{
  filesTouched: readonly string[];
  netAddedLines: number;
  rawDiff: string;
}> {
  const prompt = buildAgentPrompt(order, policy);
  const result = await transport.apply(order, prompt);

  if (result.filesTouched.length > policy.maxFilesTouched) {
    throw new Error(
      `agent touched ${result.filesTouched.length} files; policy cap is ${policy.maxFilesTouched}`,
    );
  }
  if (result.netAddedLines > policy.maxNetAddedLines) {
    throw new Error(
      `agent added ${result.netAddedLines} net lines; policy cap is ${policy.maxNetAddedLines}`,
    );
  }
  for (const file of result.filesTouched) {
    if (policy.deniedPaths.some((glob) => matchGlob(glob, file))) {
      throw new Error(`agent modified denied path: ${file}`);
    }
  }
  return result;
}

/** Tiny glob matcher supporting `**` and `*` only. */
function matchGlob(glob: string, path: string): boolean {
  const re = new RegExp(
    '^' +
      glob
        .replace(/[.+^${}()|[\]\\]/g, '\\$&')
        .replace(/\*\*/g, '\u0000')
        .replace(/\*/g, '[^/]*')
        .replace(/\u0000/g, '.*') +
      '$',
  );
  return re.test(path);
}
