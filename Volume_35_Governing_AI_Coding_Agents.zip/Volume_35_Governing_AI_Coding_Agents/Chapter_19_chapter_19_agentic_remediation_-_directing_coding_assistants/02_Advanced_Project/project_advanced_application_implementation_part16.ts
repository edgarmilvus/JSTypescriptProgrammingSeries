/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part16.ts
Description: Advanced Application Implementation
==========================================
*/

// services/remediation/src/gate.ts
import type { TraceyMcpClient } from './tracey-mcp.js';
import type { RemediationPolicy } from './policy.js';

export interface CoverageSnapshot {
  readonly raw: string;
}

export interface GateVerdict {
  readonly passed: boolean;
  readonly reason: string;
  readonly deltaUncovered: number;
  readonly deltaUntested: number;
}

/**
 * The gate is the *only* component allowed to decide whether a patch
 * promotes. It compares coverage snapshots before and after patch
 * application, then runs `tracey_validate` with the policy's
 * `denyWarnings` setting.
 *
 * A patch passes iff BOTH conditions hold:
 *   1. `tracey_validate` exits cleanly (no errors, warnings if denied).
 *   2. No coverage metric regressed: uncovered and untested counts
 *      must be less than or equal to their pre-patch values.
 */
export async function evaluateGate(
  client: TraceyMcpClient,
  policy: RemediationPolicy,
  before: CoverageSnapshot,
): Promise<GateVerdict> {
  const validationOutput = await client.validate(policy.specImpl, policy.denyWarnings);
  const lower = validationOutput.toLowerCase();
  const validationFailed =
    lower.includes('error') ||
    (policy.denyWarnings && lower.includes('warning'));

  const afterRaw = await client.status();
  const beforeCounts = parseCoverageCounts(before.raw);
  const afterCounts = parseCoverageCounts(afterRaw);

  const deltaUncovered = afterCounts.uncovered - beforeCounts.uncovered;
  const deltaUntested = afterCounts.untested - beforeCounts.untested;

  if (validationFailed) {
    return {
      passed: false,
      reason: 'tracey_validate reported errors (or warnings under deny_warnings)',
      deltaUncovered,
      deltaUntested,
    };
  }
  if (deltaUncovered > 0 || deltaUntested > 0) {
    return {
      passed: false,
      reason: `coverage regression: uncovered ${deltaUncovered >= 0 ? '+' : ''}${deltaUncovered}, untested ${deltaUntested >= 0 ? '+' : ''}${deltaUntested}`,
      deltaUncovered,
      deltaUntested,
    };
  }
  return {
    passed: true,
    reason: 'no validation errors, no coverage regression',
    deltaUncovered,
    deltaUntested,
  };
}

/**
 * Parse the `tracey status` human-readable report into crude integer
 * counters. The report is line-oriented and stable, but we are defensive:
 * missing fields default to 0 rather than throwing.
 */
function parseCoverageCounts(raw: string): { uncovered: number; untested: number } {
  const grab = (label: string): number => {
    const re = new RegExp(`${label}\\s*[:=]\\s*(\\d+)`, 'i');
    const m = raw.match(re);
    return m ? Number.parseInt(m[1], 10) : 0;
  };
  return { uncovered: grab('uncovered'), untested: grab('untested') };
}
