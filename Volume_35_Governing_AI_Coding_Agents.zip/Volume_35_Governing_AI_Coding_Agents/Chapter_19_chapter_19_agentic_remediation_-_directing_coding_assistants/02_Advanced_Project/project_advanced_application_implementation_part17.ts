/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part17.ts
Description: Advanced Application Implementation
==========================================
*/

// services/remediation/src/director.ts
import { TraceyMcpClient } from './tracey-mcp.js';
import { planWorkOrders } from './planner.js';
import { dispatchWorkOrder, type AgentTransport } from './dispatcher.js';
import { evaluateGate, type CoverageSnapshot } from './gate.js';
import { DEFAULT_NIMBUS_POLICY, type RemediationPolicy } from './policy.js';

export interface RunSummary {
  readonly ordersPlanned: number;
  readonly ordersAttempted: number;
  readonly ordersPassed: number;
  readonly failures: ReadonlyArray<{ uid: string; reason: string }>;
}

/**
 * Top-level entry point. This is the function invoked by both the CI job
 * and the local `pnpm remediate` script.
 *
 * The director owns three pieces of state that the agent does not:
 *   1. The Tracey MCP client (and thus the ground-truth coverage).
 *   2. The pre-patch coverage snapshot (used by the gate).
 *   3. The final promote/rollback decision.
 */
export async function runRemediationCycle(
  cwd: string,
  transport: AgentTransport,
  policy: RemediationPolicy = DEFAULT_NIMBUS_POLICY,
): Promise<RunSummary> {
  const client = new TraceyMcpClient(cwd);
  const failures: Array<{ uid: string; reason: string }> = [];
  let attempted = 0;
  let passed = 0;

  try {
    const before: CoverageSnapshot = { raw: await client.status() };
    const orders = await planWorkOrders(client, policy);

    for (const order of orders) {
      attempted += 1;
      try {
        await dispatchWorkOrder(transport, policy, order);
        const verdict = await evaluateGate(client, policy, before);
        if (verdict.passed) {
          passed += 1;
          // Commit strategy is owned by the calling CI job; the director
          // only records the pass.
        } else {
          failures.push({ uid: order.requirementUid, reason: verdict.reason });
          // Roll back the working tree for this order.
          await transport.apply(order, '# rollback');
        }
      } catch (err) {
        failures.push({
          uid: order.requirementUid,
          reason: err instanceof Error ? err.message : String(err),
        });
      }
    }
  } finally {
    client.close();
  }

  return {
    ordersPlanned: attempted,
    ordersAttempted: attempted,
    ordersPassed: passed,
    failures,
  };
}
