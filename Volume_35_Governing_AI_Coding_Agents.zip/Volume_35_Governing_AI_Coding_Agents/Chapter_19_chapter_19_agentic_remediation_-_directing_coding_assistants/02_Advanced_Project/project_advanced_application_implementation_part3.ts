/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part3.ts
Description: Advanced Application Implementation
==========================================
*/

// services/api/src/context/tenant.ts
import type { FastifyRequest, FastifyReply } from 'fastify';
import { HttpError } from '../errors/http-error.js';
import type { TenantResolver } from './resolver.js';

/**
 * The resolved multi-tenant execution context attached to every request.
 * Downstream ledger operations MUST treat the absence of this context
 * as an unrecoverable programming error.
 */
export interface TenantContext {
  readonly tenantId: string;
  readonly source: 'header' | 'jwt' | 'path';
}

const TENANT_HEADER = 'x-nimbus-tenant';

/**
 * Resolve the tenant context for an inbound request.
 *
 * Fail-closed behaviour: if multiple tenant sources are present and
 * disagree, the request is rejected without mutating any state.
 *
 * @param req  The inbound Fastify request.
 * @param resolver  Strategy object that knows how to read a tenant
 *                  identifier out of a JWT claim or a path parameter.
 * @returns A frozen `TenantContext` when exactly one source resolves.
 * @throws HttpError with `TENANT_CONTEXT_MISSING` when no source resolves.
 * @throws HttpError with `TENANT_CONTEXT_CONFLICT` when sources disagree.
 */
// r[impl NIMBUS-TENANT-001]
// r[impl NIMBUS-TENANT-002]
export function resolveTenantContext(
  req: FastifyRequest,
  resolver: TenantResolver,
): TenantContext {
  const candidates: Array<{ source: TenantContext['source']; value: string }> = [];

  const headerValue = req.headers[TENANT_HEADER];
  if (typeof headerValue === 'string' && headerValue.length > 0) {
    candidates.push({ source: 'header', value: headerValue });
  }

  const jwtValue = resolver.readTenantFromJwt(req);
  if (jwtValue !== null) {
    candidates.push({ source: 'jwt', value: jwtValue });
  }

  const pathValue = resolver.readTenantFromPath(req);
  if (pathValue !== null) {
    candidates.push({ source: 'path', value: pathValue });
  }

  if (candidates.length === 0) {
    req.log.warn({ url: req.url }, 'tenant context missing');
    throw new HttpError(400, 'TENANT_CONTEXT_MISSING');
  }

  const distinct = new Set(candidates.map((c) => c.value));
  if (distinct.size > 1) {
    req.log.error(
      { candidates: candidates.map((c) => c.source) },
      'conflicting tenant sources',
    );
    throw new HttpError(400, 'TENANT_CONTEXT_CONFLICT');
  }

  const [first] = candidates;
  return Object.freeze({ tenantId: first.value, source: first.source });
}

/**
 * Fastify `preHandler` hook that materializes tenant context onto the
 * request object. Any downstream route handler may assume
 * `req.tenant` is defined.
 */
// r[impl NIMBUS-TENANT-001]
export async function attachTenantContext(
  req: FastifyRequest,
  _reply: FastifyReply,
  resolver: TenantResolver,
): Promise<void> {
  (req as FastifyRequest & { tenant: TenantContext }).tenant =
    resolveTenantContext(req, resolver);
}
