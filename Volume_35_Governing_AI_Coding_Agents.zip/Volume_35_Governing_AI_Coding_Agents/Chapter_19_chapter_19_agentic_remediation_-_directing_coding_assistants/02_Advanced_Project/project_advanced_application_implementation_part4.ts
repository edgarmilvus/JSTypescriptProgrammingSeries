/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part4.ts
Description: Advanced Application Implementation
==========================================
*/

// services/api/src/auth/jwt.ts
import type { JwtVerifier } from './verifier.js';
import { HttpError } from '../errors/http-error.js';

const CLOCK_SKEW_SECONDS = 30;

/**
 * Validate a JWT's temporal claims against a configurable skew window.
 *
 * We compensate for NTP drift in both directions rather than only in
 * the past: `nbf` may be slightly in the future, and `exp` may have
 * have just elapsed. Both directions use the same 30-second window.
 *
 * @param token  A compact-serialized JWS.
 * @param verifier  Signature + claim verifier.
 * @param now  Injectable clock for deterministic testing.
 * @returns The decoded, minimal claims payload on success.
 * @throws HttpError with `TOKEN_EXPIRED` when the compensated window elapses.
 */
// r[impl NIMBUS-AUTH-001]
export function enforceClockSkew(
  token: string,
  verifier: JwtVerifier,
  now: () => number = Date.now,
): { sub: string; exp: number; nbf: number } {
  const claims = verifier.decode(token);
  const nowSeconds = Math.floor(now() / 1000);
  const skew = CLOCK_SKEW_SECONDS;

  if (claims.nbf !== undefined && claims.nbf - skew > nowSeconds) {
    throw new HttpError(401, 'TOKEN_NOT_YET_VALID');
  }

  if (claims.exp + skew < nowSeconds) {
    throw new HttpError(401, 'TOKEN_EXPIRED');
  }

  return { sub: claims.sub, exp: claims.exp, nbf: claims.nbf ?? 0 };
}
