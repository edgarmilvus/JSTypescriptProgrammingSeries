/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part5.ts
Description: Advanced Application Implementation
==========================================
*/

// services/api/src/ledger/rounding.ts

/**
 * Round a monetary amount to a currency minor unit using round-half-to-even
 * semantics ("bankers' rounding"). This is the ONLY sanctioned rounding
 * implementation in the ledger service; any ad-hoc `Math.round` call in
 * the codebase is a bug.
 *
 * @param amount  A high-precision decimal amount as a Number of major units.
 * @param minorUnitDigits  Usually 2 for fiat, 0 for JPY, 3 for BHD.
 * @returns The rounded amount expressed in major units.
 */
// r[impl NIMBUS-LEDGER-001]
export function roundBankers(amount: number, minorUnitDigits: number): number {
  const factor = 10 ** minorUnitDigits;
  const scaled = amount * factor;
  const floor = Math.floor(scaled);
  const fraction = scaled - floor;

  // Strictly less than half: round down.
  // Strictly greater than half: round up.
  // Exactly half: round to the nearest EVEN integer.
  if (fraction < 0.5) {
    return floor / factor;
  }
  if (fraction > 0.5) {
    return (floor + 1) / factor;
  }
  return (floor % 2 === 0 ? floor : floor + 1) / factor;
}
