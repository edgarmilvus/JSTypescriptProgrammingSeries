/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part6.ts
Description: Advanced Application Implementation
==========================================
*/

// services/api/src/webhooks/backoff.ts

/**
 * Compute the delay (in milliseconds) before the Nth webhook retry.
 *
 * Backoff is 1s * 2^(attempt-1) capped at 15 minutes. The `attempt`
 * parameter is 1-indexed: attempt 1 is the first retry after the
 * initial delivery failure.
 *
 * @param attempt  Retry ordinal, 1-indexed.
 * @returns Milliseconds to sleep before the next delivery attempt.
 */
// r[impl NIMBUS-WEBHOOK-001]
export function webhookBackoffMs(attempt: number): number {
  if (attempt < 1) {
    throw new RangeError('attempt must be >= 1');
  }
  const base = 1_000;
  const cap = 15 * 60 * 1_000;
  return Math.min(base * 2 ** (attempt - 1), cap);
}

/**
 * Total number of delivery attempts (including the initial one).
 */
// r[impl NIMBUS-WEBHOOK-001]
export const WEBHOOK_MAX_ATTEMPTS = 8;
