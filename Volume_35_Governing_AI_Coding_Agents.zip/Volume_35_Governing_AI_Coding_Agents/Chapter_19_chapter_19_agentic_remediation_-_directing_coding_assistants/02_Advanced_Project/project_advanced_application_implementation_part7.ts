/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

// services/api/tests/context/tenant.test.ts
import { describe, it, expect, vi } from 'vitest';
import { resolveTenantContext } from '../../src/context/tenant.js';
import { HttpError } from '../../src/errors/http-error.js';
import type { FastifyRequest } from 'fastify';
import { NoopTenantResolver } from '../fixtures/noop-resolver.js';

function makeReq(headers: Record<string, string> = {}): FastifyRequest {
  return {
    headers,
    url: '/v1/invoices',
    log: { warn: vi.fn(), error: vi.fn() },
  } as unknown as FastifyRequest;
}

// r[verify NIMBUS-TENANT-001]
describe('resolveTenantContext — tenant scoping', () => {
  it('returns a frozen context when the header is present', () => {
    const ctx = resolveTenantContext(
      makeReq({ 'x-nimbus-tenant': 'acme' }),
      new NoopTenantResolver(),
    );
    expect(ctx.tenantId).toBe('acme');
    expect(Object.isFrozen(ctx)).toBe(true);
  });

  it('rejects with TENANT_CONTEXT_MISSING when no source resolves', () => {
    expect(() =>
      resolveTenantContext(makeReq(), new NoopTenantResolver()),
    ).toThrowError(HttpError);
    try {
      resolveTenantContext(makeReq(), new NoopTenantResolver());
    } catch (err) {
      expect((err as HttpError).code).toBe('TENANT_CONTEXT_MISSING');
    }
  });
});

// r[verify NIMBUS-TENANT-002]
describe('resolveTenantContext — conflicting sources', () => {
  it('rejects when header and JWT disagree', () => {
    const resolver = new NoopTenantResolver({ jwt: 'globex' });
    expect(() =>
      resolveTenantContext(makeReq({ 'x-nimbus-tenant': 'acme' }), resolver),
    ).toThrow(/TENANT_CONTEXT_CONFLICT/);
  });
});
