/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.ts
Description: Advanced Application Implementation
==========================================
*/

// services/api/tests/auth/jwt.test.ts
import { describe, it, expect } from 'vitest';
import { enforceClockSkew } from '../../src/auth/jwt.js';
import { FakeVerifier } from '../fixtures/fake-verifier.js';

// r[verify NIMBUS-AUTH-001]
describe('enforceClockSkew', () => {
  const NOW = 1_700_000_000_000; // ms

  it('accepts an exp that elapsed within the 30s window', () => {
    const verifier = new FakeVerifier({
      sub: 'user-1',
      exp: NOW / 1000 - 15, // 15s ago
      nbf: NOW / 1000 - 3600,
    });
    expect(() => enforceClockSkew('tok', verifier, () => NOW)).not.toThrow();
  });

  it('rejects an exp that elapsed beyond the 30s window', () => {
    const verifier = new FakeVerifier({
      sub: 'user-1',
      exp: NOW / 1000 - 31,
      nbf: NOW / 1000 - 3600,
    });
    expect(() => enforceClockSkew('tok', verifier, () => NOW)).toThrow(
      /TOKEN_EXPIRED/,
    );
  });

  it('accepts an nbf up to 30s in the future', () => {
    const verifier = new FakeVerifier({
      sub: 'user-1',
      exp: NOW / 1000 + 3600,
      nbf: NOW / 1000 + 28,
    });
    expect(() => enforceClockSkew('tok', verifier, () => NOW)).not.toThrow();
  });
});
