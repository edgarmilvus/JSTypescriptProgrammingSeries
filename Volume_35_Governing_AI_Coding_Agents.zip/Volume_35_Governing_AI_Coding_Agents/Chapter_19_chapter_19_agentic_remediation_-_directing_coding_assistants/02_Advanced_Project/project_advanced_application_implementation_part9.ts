/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

// services/api/tests/ledger/rounding.test.ts
import { describe, it, expect } from 'vitest';
import { roundBankers } from '../../src/ledger/rounding.js';

// r[verify NIMBUS-LEDGER-001]
describe('roundBankers — half-to-even', () => {
  it.each([
    [2.5, 0, 2],
    [3.5, 0, 4],
    [2.675, 2, 2.68],
    [2.665, 2, 2.66],
    [-2.5, 0, -2],
    [100.125, 2, 100.12],
  ])('rounds %f to %f with %i minor digits', (input, digits, expected) => {
    expect(roundBankers(input as number, digits as number)).toBeCloseTo(
      expected as number,
      6,
    );
  });

  it('is not equivalent to naive Math.round', () => {
    // Math.round(2.5) === 3, but bankers rounding gives 2.
    expect(Math.round(2.5)).toBe(3);
    expect(roundBankers(2.5, 0)).toBe(2);
  });
});
