/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_the_evidence_gap_panel.tsx
Description: Solutions and Explanations
==========================================
*/

// src/components/EvidenceGapPanel.tsx
import React, { useCallback, useEffect, useRef, useState } from "react";

// ---- Public types ---------------------------------------------------------

export type GapClass = "uncovered" | "untested" | "stale" | "unmapped";
export type TraceyTool =
  | "tracey_uncovered"
  | "tracey_untested"
  | "tracey_stale"
  | "tracey_unmapped";

export type RemediationBrief = {
  schemaVersion: "1";
  gapClass: GapClass;
  requirementUid: string;
  specImpl: string;
  detectedAt: string; // ISO 8601 UTC, captured at observation time
  toolInvocation: {
    tool: TraceyTool;
    args: Record<string, string | undefined>;
  };
  expectedEvidence: {
    verb: "impl" | "verify";
    annotationForm: string;
  };
  guardrails: string[];
};

export interface McpClient {
  callTool<T = unknown>(name: string, args: Record<string, unknown>): Promise<T>;
}

export type AnnotationStyle = "r-native" | "sdoc-relation";

// ---- Minimal Tracey response shapes (per reference corpus) ----------------

interface TraceyStatusResponse {
  specs: Array<{ name: string; prefix: string; impls: Array<{ name: string }> }>;
}
interface TraceyGapResponse {
  items: Array<{ uid: string; specImpl?: string; sectionHeading?: string }>;
}

// ---- Guardrails -----------------------------------------------------------

const BASE_GUARDRAILS: ReadonlyArray<string> = [
  "The agent must not modify the requirement text in any .md or .sdoc file to satisfy the gap.",
  "The agent must not delete or weaken any existing test that currently references the requirement.",
  "The agent must not edit .config/tracey/config.styx to exclude the file that is producing the gap.",
  "The agent must not bump a requirement's version suffix unless the code change is accompanied by a matching change to the requirement's statement.",
];

// ---- Serialization (stable key ordering, 2-space indent) ------------------

function serializeBrief(brief: RemediationBrief): string {
  // Constructing an object literal with a fixed field order gives us a
  // byte-stable serialization: two otherwise-identical briefs will diff to
  // zero bytes.
  const stable = {
    schemaVersion: brief.schemaVersion,
    gapClass: brief.gapClass,
    requirementUid: brief.requirementUid,
    specImpl: brief.specImpl,
    detectedAt: brief.detectedAt,
    toolInvocation: {
      tool: brief.toolInvocation.tool,
      args: brief.toolInvocation.args,
    },
    expectedEvidence: {
      verb: brief.expectedEvidence.verb,
      annotationForm: brief.expectedEvidence.annotationForm,
    },
    guardrails: [...brief.guardrails],
  };
  return JSON.stringify(stable, null, 2);
}

// ---- Annotation form selection --------------------------------------------
// The panel cannot guess which style a project uses without asking. We
// require the caller to declare the style explicitly rather than infer a
// heuristic from the file extension, because the wrong form produces
// "unknown prefix" diagnostics later.
function annotationForm(
  style: AnnotationStyle,
  verb: "impl" | "verify",
  uid: string,
): string {
  if (style === "sdoc-relation") {
    const role = verb === "verify" ? "Verifies" : "Implements";
    return `// @relation(${uid}, scope=function, role=${role})`;
  }
  return `// r[${verb} ${uid}]`;
}

// ---- Component ------------------------------------------------------------

type ObservedGap = {
  uid: string;
  specImpl: string;
  sectionHeading?: string;
  gapClass: "uncovered" | "untested";
  tool: "tracey_uncovered" | "tracey_untested";
  args: Record<string, string | undefined>;
  observedAt: string;
};

interface ToolFailure {
  tool: string;
  message: string;
}

interface EvidenceGapPanelProps {
  mcpClient: McpClient;
  onBriefCopied: (brief: RemediationBrief) => void;
  specImpl?: string;
  annotationStyle?: AnnotationStyle;
}

export function EvidenceGapPanel({
  mcpClient,
  onBriefCopied,
  specImpl,
  annotationStyle = "r-native",
}: EvidenceGapPanelProps) {
  const [emptyConfig, setEmptyConfig] = useState(false);
  const [gaps, setGaps] = useState<ObservedGap[]>([]);
  const [failures, setFailures] = useState<ToolFailure[]>([]);
  const [toast, setToast] = useState<string | null>(null);

  // In-memory ledger — never persisted. Provenance persistence is the parent
  // application's responsibility.
  const ledgerRef = useRef<RemediationBrief[]>([]);

  useEffect(() => {
    let cancelled = false;
    const args: Record<string, string | undefined> = specImpl
      ? { spec_impl: specImpl }
      : {};

    async function run() {
      setFailures([]);
      setGaps([]);

      // Step 1: tracey_status. If zero specs, stop here — no further calls.
      let status: TraceyStatusResponse;
      try {
        status = await mcpClient.callTool<TraceyStatusResponse>(
          "tracey_status",
          {},
        );
      } catch (err) {
        if (cancelled) return;
        setFailures([{ tool: "tracey_status", message: String(err) }]);
        return;
      }
      if (cancelled) return;

      const couples = (status.specs ?? []).flatMap((s) =>
        s.impls.map((i) => `${s.name}/${i.name}`),
      );
      if (couples.length === 0) {
        setEmptyConfig(true);
        return;
      }

      // Step 2: fan-out uncovered + untested in parallel. We do NOT await a
      // combined promise that rejects on the first failure — allSettled keeps
      // partial render possible.
      const [uRes, tRes] = await Promise.allSettled([
        mcpClient.callTool<TraceyGapResponse>("tracey_uncovered", args),
        mcpClient.callTool<TraceyGapResponse>("tracey_untested", args),
      ]);
      if (cancelled) return;

      // Timestamp is captured the moment the responses land — NOT at copy time.
      const observedAt = new Date().toISOString();
      const nextGaps: ObservedGap[] = [];
      const nextFailures: ToolFailure[] = [];

      if (uRes.status === "fulfilled") {
        for (const item of uRes.value.items ?? []) {
          nextGaps.push({
            uid: item.uid,
            specImpl: item.specImpl ?? specImpl ?? "",
            sectionHeading: item.sectionHeading,
            gapClass: "uncovered",
            tool: "tracey_uncovered",
            args,
            observedAt,
          });
        }
      } else {
        nextFailures.push({
          tool: "tracey_uncovered",
          message: String(uRes.reason),
        });
      }

      if (tRes.status === "fulfilled") {
        for (const item of tRes.value.items ?? []) {
          nextGaps.push({
            uid: item.uid,
            specImpl: item.specImpl ?? specImpl ?? "",
            sectionHeading: item.sectionHeading,
            gapClass: "untested",
            tool: "tracey_untested",
            args,
            observedAt,
          });
        }
      } else {
        nextFailures.push({
          tool: "tracey_untested",
          message: String(tRes.reason),
        });
      }

      setGaps(nextGaps);
      setFailures(nextFailures);
    }

    void run();
    return () => {
      cancelled = true;
    };
  }, [mcpClient, specImpl]);

  const draftBrief = useCallback(
    async (gap: ObservedGap) => {
      const verb: "impl" | "verify" =
        gap.gapClass === "uncovered" ? "impl" : "verify";
      const brief: RemediationBrief = {
        schemaVersion: "1",
        gapClass: gap.gapClass,
        requirementUid: gap.uid,
        specImpl: gap.specImpl,
        detectedAt: gap.observedAt, // observation time, not copy time
        toolInvocation: { tool: gap.tool, args: gap.args },
        expectedEvidence: {
          verb,
          annotationForm: annotationForm(annotationStyle, verb, gap.uid),
        },
        guardrails: [...BASE_GUARDRAILS],
      };

      try {
        if (
          typeof navigator === "undefined" ||
          !navigator.clipboard ||
          typeof navigator.clipboard.writeText !== "function"
        ) {
          throw new Error("Clipboard API unavailable");
        }
        await navigator.clipboard.writeText(serializeBrief(brief));
      } catch (err) {
        // A brief that was never copied is not provenance.
        setToast(`Failed to copy brief: ${String(err)}`);
        return;
      }

      ledgerRef.current.push(brief);
      onBriefCopied(brief);
    },
    [annotationStyle, onBriefCopied],
  );

  if (emptyConfig) {
    return (
      <div role="status" data-testid="empty-config">
        No specs configured. Create <code>.config/tracey/config.styx</code>.
      </div>
    );
  }

  return (
    <div className="evidence-gap-panel">
      {failures.map((f) => (
        <div key={f.tool} role="alert" data-testid={`failure-${f.tool}`}>
          {f.tool} failed: {f.message}
        </div>
      ))}

      <ul>
        {gaps.map((g) => (
          <li key={`${g.gapClass}:${g.uid}`} data-testid={`gap-${g.uid}`}>
            <span>{g.uid}</span>
            <span>{g.gapClass}</span>
            <span>{g.specImpl}</span>
            {/* Never fabricate a heading the tool did not return. */}
            {g.sectionHeading && <span>{g.sectionHeading}</span>}
            <button
              type="button"
              data-testid={`draft-${g.uid}`}
              onClick={() => void draftBrief(g)}
            >
              Draft Remediation Brief
            </button>
          </li>
        ))}
      </ul>

      {toast && (
        <div role="alert" data-testid="toast">
          {toast}
          <button type="button" onClick={() => setToast(null)}>
            Dismiss
          </button>
        </div>
      )}
    </div>
  );
}
