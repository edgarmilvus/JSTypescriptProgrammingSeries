/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_the_evidence_gap_panel_part2.tsx
Description: Solutions and Explanations
==========================================
*/

// src/components/EvidenceGapPanel.test.tsx
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import {
  EvidenceGapPanel,
  type McpClient,
  type RemediationBrief,
} from "./EvidenceGapPanel";

function makeClient(overrides: Partial<Record<string, unknown>> = {}): McpClient {
  return {
    callTool: vi.fn(async (name: string) => {
      if (name in overrides) return overrides[name];
      if (name === "tracey_status")
        return { specs: [{ name: "app", prefix: "r", impls: [{ name: "rust" }] }] };
      if (name === "tracey_uncovered") return { items: [] };
      if (name === "tracey_untested") return { items: [] };
      throw new Error(`unexpected tool ${name}`);
    }),
  } as McpClient;
}

describe("EvidenceGapPanel", () => {
  beforeEach(() => {
    Object.assign(navigator, {
      clipboard: { writeText: vi.fn().mockResolvedValue(undefined) },
    });
  });
  afterEach(() => vi.restoreAllMocks());

  it("renders empty-config state and stops calling when no specs are configured", async () => {
    const client = makeClient({ tracey_status: { specs: [] } });
    render(<EvidenceGapPanel mcpClient={client} onBriefCopied={() => {}} />);
    await screen.findByTestId("empty-config");
    expect(client.callTool).toHaveBeenCalledTimes(1);
  });

  it("renders partial results when one of the gap tools fails", async () => {
    const client = makeClient({
      tracey_uncovered: { items: [{ uid: "auth.login", specImpl: "app/rust" }] },
    });
    (client.callTool as any).mockImplementation(async (name: string) => {
      if (name === "tracey_status")
        return { specs: [{ name: "app", prefix: "r", impls: [{ name: "rust" }] }] };
      if (name === "tracey_uncovered")
        return { items: [{ uid: "auth.login", specImpl: "app/rust" }] };
      if (name === "tracey_untested") throw new Error("daemon offline");
      throw new Error("unexpected");
    });
    render(<EvidenceGapPanel mcpClient={client} onBriefCopied={() => {}} />);
    await screen.findByTestId("gap-auth.login");
    expect(await screen.findByTestId("failure-tracey_untested")).toBeTruthy();
  });

  it("emits the correct brief for an uncovered markdown gap", async () => {
    const captured: RemediationBrief[] = [];
    const client = makeClient({
      tracey_uncovered: { items: [{ uid: "auth.login", specImpl: "app/rust" }] },
    });
    render(
      <EvidenceGapPanel
        mcpClient={client}
        annotationStyle="r-native"
        onBriefCopied={(b) => captured.push(b)}
      />,
    );
    fireEvent.click(await screen.findByTestId("draft-auth.login"));
    await waitFor(() => expect(captured).toHaveLength(1));
    expect(captured[0].expectedEvidence.verb).toBe("impl");
    expect(captured[0].expectedEvidence.annotationForm).toBe(
      "// r[impl auth.login]",
    );
    const text = (navigator.clipboard.writeText as any).mock.calls[0][0];
    expect(text).toContain('"schemaVersion": "1"');
    expect(JSON.parse(text).guardrails).toHaveLength(4);
  });

  it("emits an @relation form for a .sdoc project when configured", async () => {
    const captured: RemediationBrief[] = [];
    const client = makeClient({
      tracey_untested: { items: [{ uid: "CH-001", specImpl: "chan/rust" }] },
    });
    render(
      <EvidenceGapPanel
        mcpClient={client}
        annotationStyle="sdoc-relation"
        onBriefCopied={(b) => captured.push(b)}
      />,
    );
    fireEvent.click(await screen.findByTestId("draft-CH-001"));
    await waitFor(() => expect(captured).toHaveLength(1));
    expect(captured[0].expectedEvidence.annotationForm).toBe(
      "// @relation(CH-001, scope=function, role=Verifies)",
    );
  });

  it("does NOT invoke onBriefCopied when the clipboard write fails", async () => {
    (navigator.clipboard.writeText as any).mockRejectedValue(
      new Error("denied"),
    );
    const onBriefCopied = vi.fn();
    const client = makeClient({
      tracey_uncovered: { items: [{ uid: "auth.login", specImpl: "app/rust" }] },
    });
    render(
      <EvidenceGapPanel mcpClient={client} onBriefCopied={onBriefCopied} />,
    );
    fireEvent.click(await screen.findByTestId("draft-auth.login"));
    await screen.findByTestId("toast");
    expect(onBriefCopied).not.toHaveBeenCalled();
  });
});
