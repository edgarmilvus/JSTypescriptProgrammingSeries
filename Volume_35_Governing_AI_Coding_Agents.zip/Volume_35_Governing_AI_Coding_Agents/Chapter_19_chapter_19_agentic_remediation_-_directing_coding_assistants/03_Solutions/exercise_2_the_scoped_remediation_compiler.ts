/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_the_scoped_remediation_compiler.ts
Description: Solutions and Explanations
==========================================
*/

// src/remediation/compiler.ts
import type { RemediationBrief } from "../components/EvidenceGapPanel";

// ---- Manifest types -------------------------------------------------------

export interface CompilerClock {
  now(): Date;
}

export interface CompileInput {
  briefs: RemediationBrief[];
  rootDir: string;
  clock: CompilerClock;
  client: McpClient; // narrow interface, see Exercise 1
}

export interface RequirementSnapshot {
  uid: string;
  title?: string;
  statement: string;
  rationale?: string;
  existingReferences: Array<{ verb: string; file: string; line: number }>;
}

export type Precondition =
  | { kind: "uid-exists"; uid: string }
  | { kind: "gap-class-still-present"; uid: string; gapClass: "uncovered" | "untested" }
  | { kind: "no-impl-reference"; uid: string }
  | { kind: "no-verify-reference"; uid: string }
  | { kind: "candidate-targets-nonempty"; taskIndex: number };

export type Postcondition =
  | { kind: "gap-closed"; uid: string; gapClass: "uncovered" | "untested" }
  | { kind: "validate-zero-errors" }
  | { kind: "impl-count-increased"; uid: string; deltaAtLeast: 1 }
  | { kind: "verify-count-increased"; uid: string; deltaAtLeast: 1 }
  | { kind: "no-new-stale"; uid: string };

export interface RemediationTask {
  brief: RemediationBrief;
  requirement: RequirementSnapshot;
  candidateTargets: string[]; // sorted, deduplicated
  preconditions: Precondition[];
  postconditions: Postcondition[];
}

export interface ProvenanceBlock {
  traceyStatus: { args: Record<string, unknown>; response: unknown };
  traceyConfig: { args: Record<string, unknown>; response: unknown };
  traceyUncovered: { args: Record<string, unknown>; response: unknown };
  traceyUntested: { args: Record<string, unknown>; response: unknown };
  traceyRule: Array<{ args: { uid: string }; response: unknown }>;
}

export interface RemediationTaskManifest {
  schemaVersion: "1";
  compilerVersion: string;
  generatedAt: string;
  tasks: RemediationTask[];
  provenance: ProvenanceBlock;
  permittedEvidenceDecreases: never[]; // compiler must never populate
}

// ---- Typed error ----------------------------------------------------------

export type CompileErrorReason =
  | "stale-not-supported"
  | "tool-gap-mismatch"
  | "rule-uid-mismatch"
  | "unknown-spec-impl";

export class RemediationCompileError extends Error {
  readonly reason: CompileErrorReason;
  readonly brief?: RemediationBrief;
  constructor(reason: CompileErrorReason, brief?: RemediationBrief) {
    super(`Remediation compile error: ${reason}`);
    this.name = "RemediationCompileError";
    this.reason = reason;
    this.brief = brief;
  }
}

// ---- Narrow MCP client ----------------------------------------------------

export interface McpClient {
  callTool<T = unknown>(name: string, args: Record<string, unknown>): Promise<T>;
}

// ---- Internals ------------------------------------------------------------

const COMPILER_VERSION = "compile-1.0.0";

const EXPECTED_TOOL_FOR_GAP: Record<string, string> = {
  uncovered: "tracey_uncovered",
  untested: "tracey_untested",
  stale: "tracey_stale",
  unmapped: "tracey_unmapped",
};

/** Resolve the include/exclude globs for a spec_impl block. */
function resolveConcept(config: any, specImpl: string): { include: string[]; exclude: string[] } | null {
  const [specName, implName] = specImpl.split("/");
  const spec = (config?.specs ?? []).find((s: any) => s.name === specName);
  if (!spec) return null;
  const impl = (spec.impls ?? []).find((i: any) => i.name === implName);
  if (!impl) return null;
  return { include: impl.include ?? [], exclude: impl.exclude ?? [] };
}

/**
 * Expand the candidate target set. We deliberately do NOT intersect with
 * tracey_unmapped output — an unmapped code unit today may be mapped by the
 * very change we ask for, which would break idempotency across codebase
 * evolutions.
 */
function expandTargets(include: string[], exclude: string[]): string[] {
  // A real implementation would use a gitignore-aware glob library. We model
  // the shape here so tests can exercise the contract with a fixture walker.
  const raw = include.flatMap((g) => fixtureGlob(g));
  const filtered = raw.filter((p) => !exclude.some((e) => fixtureMatch(e, p)));
  return Array.from(new Set(filtered)).sort();
}

// Stubbed glob helpers standing in for a globset/ignore integration.
declare function fixtureGlob(g: string): string[];
declare function fixtureMatch(g: string, p: string): boolean;

// ---- Compiler -------------------------------------------------------------

export async function compileRemediationTask(
  input: CompileInput,
): Promise<RemediationTaskManifest> {
  const { briefs, client, clock } = input;

  // Fetch config once for the whole pass.
  const config = await client.callTool<any>("tracey_config", {});
  const status = await client.callTool<any>("tracey_status", {});

  // Distinct (specImpl, gapClass) combos → at most two gap tool calls per couple.
  const uncoveredBySpec = new Map<string, Set<string>>();
  const untestedBySpec = new Map<string, Set<string>>();
  const staleBySpec = new Map<string, Set<string>>();

  const groupsBySpec = new Map<string, RemediationBrief[]>();
  for (const b of briefs) {
    const arr = groupsBySpec.get(b.specImpl) ?? [];
    arr.push(b);
    groupsBySpec.set(b.specImpl, arr);
  }

  for (const [specImpl, group] of groupsBySpec) {
    const needsUncovered = group.some((g) => g.gapClass === "uncovered");
    const needsUntested = group.some((g) => g.gapClass === "untested");
    const args = { spec_impl: specImpl };
    if (needsUncovered) {
      const res = await client.callTool<any>("tracey_uncovered", args);
      uncoveredBySpec.set(specImpl, new Set((res?.items ?? []).map((i: any) => i.uid)));
    }
    if (needsUntested) {
      const res = await client.callTool<any>("tracey_untested", args);
      untestedBySpec.set(specImpl, new Set((res?.items ?? []).map((i: any) => i.uid)));
    }
    const stale = await client.callTool<any>("tracey_stale", args);
    staleBySpec.set(specImpl, new Set((stale?.items ?? []).map((i: any) => i.uid)));
  }

  const tasks: RemediationTask[] = [];
  const ruleProvenance: ProvenanceBlock["traceyRule"] = [];

  for (let i = 0; i < briefs.length; i++) {
    const brief = briefs[i];

    if (brief.gapClass === "stale") {
      throw new RemediationCompileError("stale-not-supported", brief);
    }
    if (EXPECTED_TOOL_FOR_GAP[brief.gapClass] !== brief.toolInvocation.tool) {
      throw new RemediationCompileError("tool-gap-mismatch", brief);
    }

    const couple = resolveConcept(config, brief.specImpl);
    if (!couple) {
      throw new RemediationCompileError("unknown-spec-impl", brief);
    }

    const ruleArgs = { uid: brief.requirementUid };
    const rule = await client.callTool<any>("tracey_rule", ruleArgs);
    ruleProvenance.push({ args: ruleArgs, response: rule });

    if (String(rule?.uid) !== brief.requirementUid) {
      throw new RemediationCompileError("rule-uid-mismatch", brief);
    }

    const requirement: RequirementSnapshot = {
      uid: rule.uid,
      title: rule.title,
      statement: rule.statement, // verbatim; no truncation
      rationale: rule.rationale,
      existingReferences: Array.isArray(rule.references)
        ? [...rule.references]
            .map((r: any) => ({ verb: r.verb, file: r.file, line: r.line }))
            .sort((a, b) =>
              `${a.file}:${a.line}:${a.verb}`.localeCompare(
                `${b.file}:${b.line}:${b.verb}`,
              ),
            )
        : [],
    };

    const candidateTargets = expandTargets(couple.include, couple.exclude);

    const preconditions: Precondition[] = [
      { kind: "uid-exists", uid: brief.requirementUid },
      {
        kind: "gap-class-still-present",
        uid: brief.requirementUid,
        gapClass: brief.gapClass as "uncovered" | "untested",
      },
      { kind: "candidate-targets-nonempty", taskIndex: i },
    ];
    if (brief.gapClass === "uncovered") {
      preconditions.push({ kind: "no-impl-reference", uid: brief.requirementUid });
    } else {
      preconditions.push({ kind: "no-verify-reference", uid: brief.requirementUid });
    }

    const postconditions: Postcondition[] = [
      {
        kind: "gap-closed",
        uid: brief.requirementUid,
        gapClass: brief.gapClass as "uncovered" | "untested",
      },
      { kind: "validate-zero-errors" },
      {
        kind:
          brief.gapClass === "uncovered"
            ? "impl-count-increased"
            : "verify-count-increased",
        uid: brief.requirementUid,
        deltaAtLeast: 1,
      } as Postcondition,
      { kind: "no-new-stale", uid: brief.requirementUid },
    ];

    tasks.push({ brief, requirement, candidateTargets, preconditions, postconditions });
  }

  const manifest: RemediationTaskManifest = {
    schemaVersion: "1",
    compilerVersion: COMPILER_VERSION,
    generatedAt: clock.now().toISOString(),
    tasks,
    provenance: {
      traceyStatus: { args: {}, response: status },
      traceyConfig: { args: {}, response: config },
      traceyUncovered: {
        args: {},
        response: Object.fromEntries(uncoveredBySpec),
      },
      traceyUntested: {
        args: {},
        response: Object.fromEntries(untestedBySpec),
      },
      traceyRule: ruleProvenance,
    },
    permittedEvidenceDecreases: [],
  };

  return manifest;
}

/** Stable serialization for tests asserting byte identity. */
export function serializeManifest(m: RemediationTaskManifest): string {
  return JSON.stringify(m, null, 2);
}
