/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_the_scoped_remediation_compiler_part2.ts
Description: Solutions and Explanations
==========================================
*/

// src/remediation/compiler.test.ts
import { describe, it, expect, vi } from "vitest";
import {
  compileRemediationTask,
  RemediationCompileError,
  serializeManifest,
  type McpClient,
} from "./compiler";
import type { RemediationBrief } from "../components/EvidenceGapPanel";

const frozen = () => new Date("2026-01-01T00:00:00.000Z");
const clock = { now: frozen };

function brief(over: Partial<RemediationBrief> = {}): RemediationBrief {
  const base: RemediationBrief = {
    schemaVersion: "1",
    gapClass: "uncovered",
    requirementUid: "auth.login",
    specImpl: "app/rust",
    detectedAt: "2026-01-01T00:00:00.000Z",
    toolInvocation: { tool: "tracey_uncovered", args: { spec_impl: "app/rust" } },
    expectedEvidence: { verb: "impl", annotationForm: "// r[impl auth.login]" },
    guardrails: ["a", "b", "c", "d"],
  };
  return { ...base, ...over };
}

function makeClient(): McpClient {
  return {
    callTool: vi.fn(async (name: string, args: any) => {
      if (name === "tracey_config")
        return {
          specs: [
            {
              name: "app",
              include: ["docs/spec/**/*.md"],
              impls: [
                { name: "rust", include: ["src/**/*.rs"], exclude: ["src/gen/**"] },
              ],
            },
          ],
        };
      if (name === "tracey_status") return { specs: [{ name: "app", impls: [{ name: "rust" }] }] };
      if (name === "tracey_uncovered")
        return { items: [{ uid: "auth.login" }] };
      if (name === "tracey_untested") return { items: [] };
      if (name === "tracey_stale") return { items: [] };
      if (name === "tracey_rule")
        return {
          uid: args.uid,
          title: "Login",
          statement: "The system MUST authenticate users.",
          references: [],
        };
      throw new Error(`unexpected ${name}`);
    }),
  } as McpClient;
}

describe("compileRemediationTask", () => {
  it("is byte-identical across two runs with a frozen clock", async () => {
    const m1 = await compileRemediationTask({
      briefs: [brief()],
      rootDir: "/proj",
      clock,
      client: makeClient(),
    });
    const m2 = await compileRemediationTask({
      briefs: [brief()],
      rootDir: "/proj",
      clock,
      client: makeClient(),
    });
    expect(serializeManifest(m1)).toBe(serializeManifest(m2));
    expect(m1.compilerVersion).toBe("compile-1.0.0");
    expect(m1.schemaVersion).toBe("1");
  });

  it("rejects a stale brief with a typed error", async () => {
    await expect(
      compileRemediationTask({
        briefs: [brief({ gapClass: "stale", toolInvocation: { tool: "tracey_stale", args: {} } })],
        rootDir: "/proj",
        clock,
        client: makeClient(),
      }),
    ).rejects.toBeInstanceOf(RemediationCompileError);
  });

  it("rejects a brief whose tool does not match its gap class", async () => {
    await expect(
      compileRemediationTask({
        briefs: [brief({ gapClass: "uncovered", toolInvocation: { tool: "tracey_untested", args: {} } })],
        rootDir: "/proj",
        clock,
        client: makeClient(),
      }),
    ).rejects.toMatchObject({ reason: "tool-gap-mismatch" } as any);
  });

  it("rejects a rule whose UID does not match the brief", async () => {
    const client: McpClient = {
      callTool: vi.fn(async (name: string) => {
        if (name === "tracey_config")
          return { specs: [{ name: "app", impls: [{ name: "rust", include: ["src/**/*.rs"] }] }] };
        if (name === "tracey_status") return { specs: [] };
        if (name === "tracey_uncovered") return { items: [] };
        if (name === "tracey_untested") return { items: [] };
        if (name === "tracey_stale") return { items: [] };
        if (name === "tracey_rule") return { uid: "WRONG", statement: "..." };
        throw new Error("unexpected");
      }),
    } as any;
    await expect(
      compileRemediationTask({ briefs: [brief()], rootDir: "/proj", clock, client }),
    ).rejects.toMatchObject({ reason: "rule-uid-mismatch" } as any);
  });

  it("rejects an unresolvable specImpl", async () => {
    await expect(
      compileRemediationTask({
        briefs: [brief({ specImpl: "unknown/rust" })],
        rootDir: "/proj",
        clock,
        client: makeClient(),
      }),
    ).rejects.toMatchObject({ reason: "unknown-spec-impl" } as any);
  });

  it("preserves the provenance block through JSON round-trip", async () => {
    const m = await compileRemediationTask({
      briefs: [brief()],
      rootDir: "/proj",
      clock,
      client: makeClient(),
    });
    const round = JSON.parse(JSON.stringify(m));
    expect(round.provenance).toEqual(m.provenance);
    expect(round.tasks[0].requirement.statement).toBe(
      "The system MUST authenticate users.",
    );
  });
});
