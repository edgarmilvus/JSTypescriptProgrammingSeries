/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_the_stale_reference_bailiwick.ts
Description: Solutions and Explanations
==========================================
*/

// src/remediation/triage.ts

export type Verdict =
  | "code-must-change"
  | "annotation-bump-only"
  | "requires-human-review";

export interface StaleReference {
  uid: string;
  annotationVersion: number;
  currentSpecVersion: number;
  sourceSpan: { file: string; line: number; length: number };
}

export interface Bailiwick {
  /** What the agent is permitted to change. */
  allowedEdits: Array<
    | { kind: "bump-annotation-version"; uid: string; to: number }
    | { kind: "edit-code-unit"; file: string; line: number }
  >;
  /** Machine-checkable refusals; the agent must not violate these. */
  forbiddenEdits: Array<
    | { kind: "delete-requirement-text" }
    | { kind: "weaken-existing-test" }
    | { kind: "exclude-file-in-config" }
  >;
  /** Human gate. When true, no brief may be emitted. */
  blocked: boolean;
}

export interface StaleTriageReport {
  reference: StaleReference;
  verdict: Verdict;
  priorStatementAvailable: boolean;
  priorStatement?: string;
  currentStatement: string;
  bailiwick: Bailiwick;
  anomaly: boolean;
  rationale: string;
}

export interface McpClient {
  callTool<T = unknown>(name: string, args: Record<string, unknown>): Promise<T>;
}

// ---- Decision table -------------------------------------------------------

export interface DecisionRow {
  id: string;
  description: string;
  matches: (ctx: TriageContext) => boolean;
  verdict: Verdict;
  anomaly?: boolean;
}

export interface TriageContext {
  reference: StaleReference;
  priorStatement?: string;
  currentStatement: string;
  /** Names/signatures extracted from the code unit covering the annotation span. */
  codeUnitNamesNearSpan: string[];
}

export const DECISION_TABLE: ReadonlyArray<DecisionRow> = [
  {
    id: "R1-reverted-spec",
    description:
      "Annotation version > current spec version — a state that is impossible under normal operation.",
    matches: (c) => c.reference.annotationVersion > c.reference.currentSpecVersion,
    verdict: "requires-human-review",
    anomaly: true,
  },
  {
    id: "R2-text-unchanged",
    description:
      "Prior and current statements are byte-identical except for the version suffix.",
    matches: (c) =>
      c.priorStatement !== undefined &&
      stripVersionSuffix(c.priorStatement) === stripVersionSuffix(c.currentStatement),
    verdict: "annotation-bump-only",
  },
  {
    id: "R3-weak-signal",
    description:
      "Statements differ and the code unit's name/signature appears in the current statement.",
    matches: (c) =>
      c.priorStatement !== undefined &&
      stripVersionSuffix(c.priorStatement) !== stripVersionSuffix(c.currentStatement) &&
      c.codeUnitNamesNearSpan.some((n) => c.currentStatement.includes(n)),
    verdict: "requires-human-review",
  },
  {
    id: "R4-text-changed-no-code-signal",
    description:
      "Statements differ and no code unit name near the annotation appears in the new text.",
    matches: (c) =>
      c.priorStatement !== undefined &&
      stripVersionSuffix(c.priorStatement) !== stripVersionSuffix(c.currentStatement) &&
      !c.codeUnitNamesNearSpan.some((n) => c.currentStatement.includes(n)),
    verdict: "code-must-change",
  },
  {
    id: "R5-no-prior",
    description:
      "No prior statement is available — the tool did not expose a diff and we refuse to reconstruct one.",
    matches: (c) => c.priorStatement === undefined,
    verdict: "requires-human-review",
  },
];

// Strip the trailing "+N" version suffix so we compare only the substantive text.
function stripVersionSuffix(s: string): string {
  return s.replace(/\+\d+\s*$/, "").trim();
}

// ---- Bailiwick construction ----------------------------------------------

function bailiwickFor(
  verdict: Verdict,
  ref: StaleReference,
): Bailiwick {
  const forbidden: Bailiwick["forbiddenEdits"] = [
    { kind: "delete-requirement-text" },
    { kind: "weaken-existing-test" },
    { kind: "exclude-file-in-config" },
  ];

  switch (verdict) {
    case "annotation-bump-only":
      // Narrowest possible license: bump the version, change nothing else.
      return {
        allowedEdits: [
          { kind: "bump-annotation-version", uid: ref.uid, to: ref.currentSpecVersion },
        ],
        forbiddenEdits: forbidden,
        blocked: false,
      };
    case "code-must-change":
      return {
        allowedEdits: [
          { kind: "edit-code-unit", file: ref.sourceSpan.file, line: ref.sourceSpan.line },
        ],
        // Note: we deliberately do NOT include bump-annotation-version here.
        // The bump is authorized only AFTER a follow-up status check confirms
        // the reference is fresh. That gate lives in the guardrail harness.
        forbiddenEdits: forbidden,
        blocked: false,
      };
    case "requires-human-review":
      return {
        allowedEdits: [],
        forbiddenEdits: forbidden,
        blocked: true,
      };
  }
}

// ---- Public API -----------------------------------------------------------

export async function triageStaleReferences(input: {
  specImpl: string;
  mcpClient: McpClient;
  now: () => Date;
}): Promise<StaleTriageReport[]> {
  const { specImpl, mcpClient } = input;
  const stale = await mcpClient.callTool<{ items: StaleReference[] }>(
    "tracey_stale",
    { spec_impl: specImpl },
  );

  const reports: StaleTriageReport[] = [];

  for (const reference of stale.items ?? []) {
    const rule = await mcpClient.callTool<{
      uid: string;
      statement: string;
      priorStatement?: string;
      codeUnitNamesNearSpan?: string[];
    }>("tracey_rule", { uid: reference.uid });

    const ctx: TriageContext = {
      reference,
      priorStatement: rule.priorStatement,
      currentStatement: rule.statement,
      codeUnitNamesNearSpan: rule.codeUnitNamesNearSpan ?? [],
    };

    const row = DECISION_TABLE.find((r) => r.matches(ctx));
    if (!row) {
      // Should be unreachable given the table's coverage, but a defensive
      // fallthrough keeps the module total.
      throw new Error(`No decision row matched for UID ${reference.uid}`);
    }

    reports.push({
      reference: { ...reference },
      verdict: row.verdict,
      priorStatementAvailable: row.id !== "R5-no-prior",
      priorStatement: row.id === "R5-no-prior" ? undefined : rule.priorStatement,
      currentStatement: rule.statement,
      bailiwick: bailiwickFor(row.verdict, reference),
      anomaly: row.anomaly === true,
      rationale: row.description,
    });
  }

  return reports;
}

/** Human-readable rationale for a report. Stable given stable inputs. */
export function explainVerdict(report: StaleTriageReport): {
  tableRowFired: string;
  evidenceSummary: string;
  humanQuestion?: string;
} {
  const row = DECISION_TABLE.find((r) => r.description === report.rationale);
  return {
    tableRowFired: row?.id ?? "unknown",
    evidenceSummary: `verdict=${report.verdict} anomaly=${report.anomaly} prior=${report.priorStatementAvailable}`,
    humanQuestion:
      report.verdict === "requires-human-review"
        ? report.anomaly
          ? "Why is the annotation version higher than the current spec version? This state should be impossible."
          : "Does the current code unit still implement the current statement, even though no nearby name appears in the text?"
        : undefined,
  };
}
