/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_the_stale_reference_bailiwick_part2.ts
Description: Solutions and Explanations
==========================================
*/

// src/remediation/triage.test.ts
import { describe, it, expect } from "vitest";
import { triageStaleReferences, explainVerdict, DECISION_TABLE } from "./triage";

const now = () => new Date("2026-03-01T00:00:00Z");

function client(map: Record<string, any>) {
  return {
    callTool: async (name: string, args: any) => {
      if (name === "tracey_stale") return map.stale;
      if (name === "tracey_rule") return map.rules[args.uid];
      throw new Error(`unexpected ${name}`);
    },
  };
}

const ref = (over: Partial<any> = {}) => ({
  uid: "auth.login",
  annotationVersion: 2,
  currentSpecVersion: 3,
  sourceSpan: { file: "src/auth.rs", line: 10, length: 5 },
  ...over,
});

describe("triageStaleReferences", () => {
  it("verdicts annotation-bump-only when text is unchanged apart from the suffix", async () => {
    const c = client({
      stale: { items: [ref()] },
      rules: {
        "auth.login": {
          uid: "auth.login",
          statement: "The system MUST accept tokens.",
          priorStatement: "The system MUST accept tokens.",
          codeUnitNamesNearSpan: ["accept_tokens"],
        },
      },
    });
    const [r] = await triageStaleReferences({ specImpl: "app/rust", mcpClient: c, now });
    expect(r.verdict).toBe("annotation-bump-only");
    // Bailiwick must NOT authorize editing the code unit.
    expect(r.bailiwick.allowedEdits).toEqual([
      { kind: "bump-annotation-version", uid: "auth.login", to: 3 },
    ]);
  });

  it("verdicts code-must-change when the text diverges and no code signal appears", async () => {
    const c = client({
      stale: { items: [ref()] },
      rules: {
        "auth.login": {
          uid: "auth.login",
          statement: "The system MUST validate JWTs with RS256.",
          priorStatement: "The system MUST accept plaintext passwords.",
          codeUnitNamesNearSpan: ["hash_password"],
        },
      },
    });
    const [r] = await triageStaleReferences({ specImpl: "app/rust", mcpClient: c, now });
    expect(r.verdict).toBe("code-must-change");
    expect(r.bailiwick.allowedEdits.map((e) => e.kind)).toEqual(["edit-code-unit"]);
    // No bump authorization in code-must-change.
    expect(r.bailiwick.allowedEdits.some((e) => e.kind === "bump-annotation-version")).toBe(false);
  });

  it("raises anomaly and blocks when annotation version exceeds spec version", async () => {
    const c = client({
      stale: { items: [ref({ annotationVersion: 5, currentSpecVersion: 3 })] },
      rules: {
        "auth.login": {
          uid: "auth.login",
          statement: "X",
          priorStatement: "Y",
          codeUnitNamesNearSpan: [],
        },
      },
    });
    const [r] = await triageStaleReferences({ specImpl: "app/rust", mcpClient: c, now });
    expect(r.verdict).toBe("requires-human-review");
    expect(r.anomaly).toBe(true);
    expect(r.bailiwick.blocked).toBe(true);
  });

  it("does not mutate the input responses", async () => {
    const staleItems = [{ ...ref() }];
    const stale = { items: staleItems };
    const ruleResponse = {
      uid: "auth.login",
      statement: "X",
      priorStatement: "X",
      codeUnitNamesNearSpan: [],
    };
    const c = client({ stale, rules: { "auth.login": ruleResponse } });
    const snapshot = JSON.stringify({ stale, ruleResponse });
    const out = await triageStaleReferences({ specImpl: "app/rust", mcpClient: c, now });
    expect(JSON.stringify({ stale, ruleResponse })).toBe(snapshot);
    expect(out[0].reference).not.toBe(staleItems[0]);
  });

  it("explainVerdict exposes the human question for blocked verdicts", async () => {
    const c = client({
      stale: { items: [ref({ annotationVersion: 9, currentSpecVersion: 3 })] },
      rules: {
        "auth.login": { uid: "auth.login", statement: "X", priorStatement: "Y", codeUnitNamesNearSpan: [] },
      },
    });
    const [r] = await triageStaleReferences({ specImpl: "app/rust", mcpClient: c, now });
    const ex = explainVerdict(r);
    expect(ex.tableRowFired).toBe("R1-reverted-spec");
    expect(ex.humanQuestion).toMatch(/impossible/);
  });

  it("the decision table itself is exported and inspectable", () => {
    expect(DECISION_TABLE.map((r) => r.id)).toEqual([
      "R1-reverted-spec",
      "R2-text-unchanged",
      "R3-weak-signal",
      "R4-text-changed-no-code-signal",
      "R5-no-prior",
    ]);
  });
});
