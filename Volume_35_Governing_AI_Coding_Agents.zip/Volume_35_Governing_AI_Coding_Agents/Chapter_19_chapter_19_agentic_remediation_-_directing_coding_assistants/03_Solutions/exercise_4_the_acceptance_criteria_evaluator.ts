/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_the_acceptance_criteria_evaluator.ts
Description: Solutions and Explanations
==========================================
*/

// src/remediation/guardrails.ts
import type { RemediationTaskManifest, RemediationTask } from "./compiler";
import type { RemediationBrief } from "../components/EvidenceGapPanel";

// ---- Snapshots ------------------------------------------------------------

export interface GraphSnapshot {
  status: unknown;
  uncovered: { items: Array<{ uid: string }> };
  untested: { items: Array<{ uid: string }> };
  stale: { items: Array<{ uid: string; annotationVersion: number; currentSpecVersion: number }> };
  validate: { errors: string[]; warnings: string[] };
}

// ---- Policy ---------------------------------------------------------------

export interface GuardrailPolicy {
  version: string;
  denyStale: boolean;
  forbidNewGaps: boolean;
  requireZeroValidateErrors: boolean;
  forbidEvidenceRegression: boolean;
}

// ---- Verdicts -------------------------------------------------------------

export type Violation =
  | { kind: "preconditionViolated"; taskIndex: number; precondition: string; detail: string }
  | { kind: "postconditionFailed"; taskIndex: number; postcondition: string; detail: string }
  | { kind: "newGapIntroduced"; uid: string; gapClass: "uncovered" | "untested" }
  | { kind: "evidenceRegression"; uid: string; before: number; after: number }
  | { kind: "staleNotAllowed"; uid: string }
  | { kind: "validateErrorsPresent"; errors: string[] }
  | { kind: "provenanceTampered"; detail: string }
  | { kind: "compilerAuthorizedDecrease"; uid: string }
  | { kind: "dryRunViolation"; detail: string };

export interface ClosedGap {
  uid: string;
  gapClass: "uncovered" | "untested";
  taskIndex: number;
}

export interface TaskEvaluation {
  taskIndex: number;
  brief: RemediationBrief;
  preconditions: Array<{ precondition: string; ok: boolean; detail: string }>;
  postconditions: Array<{ postcondition: string; ok: boolean; detail: string }>;
  policyChecks: Array<{ name: string; ok: boolean; detail: string }>;
}

export interface GuardrailReport {
  schemaVersion: "1";
  policyVersion: string;
  verdict: "accept" | "reject";
  closedGaps: ClosedGap[];
  violations: Violation[];
  tasks: TaskEvaluation[];
}

export interface GuardrailVerdict {
  verdict: "accept" | "reject";
  closedGaps: ClosedGap[];
  violations: Violation[];
  report: GuardrailReport;
}

// ---- Helpers --------------------------------------------------------------

function toUidSet(items: Array<{ uid: string }> | undefined): Set<string> {
  return new Set((items ?? []).map((i) => i.uid));
}

function uidSetCount(s: Set<string>): number {
  return s.size;
}

/** Stable fingerprint of a snapshot for tamper detection. */
function fingerprint(snapshot: GraphSnapshot): string {
  return JSON.stringify(snapshot, Object.keys(snapshot).sort());
}

// ---- Public API -----------------------------------------------------------

export function evaluateGuardrails(input: {
  manifest: RemediationTaskManifest;
  before: GraphSnapshot;
  after: GraphSnapshot;
  policy: GuardrailPolicy;
  dryRun?: boolean;
}): GuardrailVerdict {
  const { manifest, before, after, policy } = input;
  const violations: Violation[] = [];
  const closedGaps: ClosedGap[] = [];
  const taskEvaluations: TaskEvaluation[] = [];

  // ---- 1. Tamper detection -----------------------------------------------
  // Reconstruct what the manifest's compiler saw; if it disagrees with
  // `before`, the harness is looking at a manifest not derived from this
  // snapshot, or a manipulated manifest.
  const manifestFingerprint = JSON.stringify({
    uncovered: manifest.provenance.traceyUncovered.response,
    untested: manifest.provenance.traceyUntested.response,
    status: manifest.provenance.traceyStatus.response,
  });
  const beforeFingerprint = JSON.stringify({
    uncovered: before.uncovered,
    untested: before.untested,
    status: before.status,
  });
  if (manifestFingerprint !== beforeFingerprint) {
    violations.push({
      kind: "provenanceTampered",
      detail: "manifest provenance does not match before snapshot",
    });
  }

  // ---- 2. Compiler cannot authorize evidence decreases --------------------
  if ((manifest as any).permittedEvidenceDecreases?.length) {
    for (const uid of (manifest as any).permittedEvidenceDecreases) {
      violations.push({ kind: "compilerAuthorizedDecrease", uid: String(uid) });
    }
  }

  // ---- 3. Preconditions (against `before`) --------------------------------
  before.uncovered.items.forEach((i) => void i); // sanity

  const beforeUncoveredUids = toUidSet(before.uncovered.items);
  const beforeUntestedUids = toUidSet(before.untested.items);
  const beforeStaleUids = new Set(before.stale.items.map((s) => s.uid));

  for (let ti = 0; ti < manifest.tasks.length; ti++) {
    const task = manifest.tasks[ti];
    const pre: TaskEvaluation["preconditions"] = [];

    // uid-exists + gap still present
    const uid = task.requirement.uid;
    const gapClass = task.brief.gapClass as "uncovered" | "untested";
    const stillInGapSet = gapClass === "uncovered"
      ? beforeUncoveredUids.has(uid)
      : beforeUntestedUids.has(uid);

    pre.push({
      precondition: `uid-exists:${uid}`,
      ok: true,
      detail: "assumed; the rule response in provenance asserts existence",
    });
    pre.push({
      precondition: `gap-class-still-present:${uid}:${gapClass}`,
      ok: stillInGapSet,
      detail: stillInGapSet
        ? "present in before snapshot"
        : "absent from before snapshot — possibly already closed",
    });
    if (!stillInGapSet) {
      violations.push({
        kind: "preconditionViolated",
        taskIndex: ti,
        precondition: "gap-class-still-present",
        detail: `${uid} not in ${gapClass} set of before snapshot`,
      });
    }

    // no-impl / no-verify reference
    const noImpl = !task.requirement.existingReferences.some((r) => r.verb === "impl");
    const noVerify = !task.requirement.existingReferences.some((r) => r.verb === "verify");
    const refPre = gapClass === "uncovered" ? noImpl : noVerify;
    pre.push({
      precondition: gapClass === "uncovered" ? `no-impl-reference:${uid}` : `no-verify-reference:${uid}`,
      ok: refPre,
      detail: refPre
        ? "no conflicting reference present"
        : "a conflicting reference already exists",
    });
    if (!refPre) {
      violations.push({
        kind: "preconditionViolated",
        taskIndex: ti,
        precondition: gapClass === "uncovered" ? "no-impl-reference" : "no-verify-reference",
        detail: `reference already present for ${uid}`,
      });
    }

    // candidate-targets-nonempty
    const targetsOk = task.candidateTargets.length > 0;
    pre.push({
      precondition: "candidate-targets-nonempty",
      ok: targetsOk,
      detail: targetsOk
        ? `${task.candidateTargets.length} targets`
        : "no matched files — glob resolve failure",
    });
    if (!targetsOk) {
      violations.push({
        kind: "preconditionViolated",
        taskIndex: ti,
        precondition: "candidate-targets-nonempty",
        detail: `no candidate targets for ${uid}`,
      });
    }

    // ---- 4. Postconditions (increments against before) -------------------
    const post: TaskEvaluation["postconditions"] = [];

    const afterUncoveredUids = toUidSet(after.uncovered.items);
    const afterUntestedUids = toUidSet(after.untested.items);

    const gapStillPresent =
      gapClass === "uncovered"
        ? afterUncoveredUids.has(uid)
        : afterUntestedUids.has(uid);
    post.push({
      postcondition: `gap-closed:${uid}`,
      ok: !gapStillPresent,
      detail: gapStillPresent ? "still present in after snapshot" : "closed",
    });
    if (!gapStillPresent) {
      closedGaps.push({ uid, gapClass, taskIndex: ti });
    } else {
      violations.push({
        kind: "postconditionFailed",
        taskIndex: ti,
        postcondition: "gap-closed",
        detail: `${uid} still in ${gapClass} set`,
      });
    }

    // Increment-based count check requires reference counts in the snapshot.
    const beforeCount = (before as any).referenceCounts?.[uid] ?? 0;
    const afterCount = (after as any).referenceCounts?.[uid] ?? 0;
    post.push({
      postcondition: gapClass === "uncovered"
        ? `impl-count-increased:${uid}`
        : `verify-count-increased:${uid}`,
      ok: afterCount - beforeCount >= 1,
      detail: `delta=${afterCount - beforeCount}`,
    });
    if (afterCount - beforeCount < 1) {
      violations.push({
        kind: "postconditionFailed",
        taskIndex: ti,
        postcondition: gapClass === "uncovered" ? "impl-count-increased" : "verify-count-increased",
        detail: `annotation count did not increase for ${uid}`,
      });
    }

    // no new stale
    const afterStaleUids = new Set(after.stale.items.map((s) => s.uid));
    const newStale = !beforeStaleUids.has(uid) && afterStaleUids.has(uid);
    post.push({
      postcondition: `no-new-stale:${uid}`,
      ok: !newStale,
      detail: newStale ? "new stale reference appeared" : "no new stale",
    });
    if (newStale) {
      violations.push({
        kind: "postconditionFailed",
        taskIndex: ti,
        postcondition: "no-new-stale",
        detail: `new stale reference for ${uid}`,
      });
    }

    taskEvaluations.push({
      taskIndex: ti,
      brief: task.brief,
      preconditions: pre,
      postconditions: post,
      policyChecks: [], // filled below
    });
  }

  // ---- 5. Policy checks ---------------------------------------------------
  for (const te of taskEvaluations) {
    te.policyChecks.push({
      name: "requireZeroValidateErrors",
      ok: !policy.requireZeroValidateErrors || after.validate.errors.length === 0,
      detail: `${after.validate.errors.length} errors`,
    });
    te.policyChecks.push({
      name: "denyStale",
      ok: !policy.denyStale || after.stale.items.length === 0,
      detail: `${after.stale.items.length} stale refs`,
    });
  }

  if (policy.requireZeroValidateErrors && after.validate.errors.length > 0) {
    violations.push({
      kind: "validateErrorsPresent",
      errors: after.validate.errors,
    });
  }

  if (policy.denyStale && after.stale.items.length > 0) {
    for (const s of after.stale.items) {
      violations.push({ kind: "staleNotAllowed", uid: s.uid });
    }
  }

  if (policy.forbidNewGaps) {
    // A "new gap" is a UID in after's gap set that was not in before's and
    // was not targeted for closure by the manifest.
    const intendedClosures = new Set(
      manifest.tasks.map((t) => `${t.brief.gapClass}:${t.requirement.uid}`),
    );
    const beforeAll = new Set([
      ...[...beforeUncoveredUids].map((u) => `uncovered:${u}`),
      ...[...beforeUntestedUids].map((u) => `untested:${u}`),
    ]);
    const afterAll = new Set([
      ...[...toUidSet(after.uncovered.items)].map((u) => `uncovered:${u}`),
      ...[...toUidSet(after.untested.items)].map((u) => `untested:${u}`),
    ]);
    for (const key of afterAll) {
      if (!beforeAll.has(key) && !intendedClosures.has(key)) {
        const [gapClass, uid] = key.split(":") as ["uncovered" | "untested", string];
        violations.push({ kind: "newGapIntroduced", uid, gapClass });
      }
    }
  }

  if (policy.forbidEvidenceRegression) {
    const beforeCounts: Record<string, number> = (before as any).referenceCounts ?? {};
    const afterCounts: Record<string, number> = (after as any).referenceCounts ?? {};
    const union = new Set([...Object.keys(beforeCounts), ...Object.keys(afterCounts)]);
    for (const uid of union) {
      const b = beforeCounts[uid] ?? 0;
      const a = afterCounts[uid] ?? 0;
      if (a < b) {
        violations.push({ kind: "evidenceRegression", uid, before: b, after: a });
      }
    }
  }

  // ---- 6. Determine verdict ----------------------------------------------
  const isDryRun = input.dryRun === true;
  if (isDryRun) {
    return {
      verdict: "reject",
      closedGaps,
      violations: [
        ...violations,
        { kind: "dryRunViolation", detail: "dry-run never accepts" },
      ],
      report: {
        schemaVersion: "1",
        policyVersion: policy.version,
        verdict: "reject",
        closedGaps,
        violations,
        tasks: taskEvaluations,
      },
    };
  }

  const verdict = violations.length === 0 ? "accept" : "reject";
  return {
    verdict,
    closedGaps,
    violations,
    report: {
      schemaVersion: "1",
      policyVersion: policy.version,
      verdict,
      closedGaps,
      violations,
      tasks: taskEvaluations,
    },
  };
}
