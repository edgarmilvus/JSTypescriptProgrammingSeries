/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_the_hierarchical_remediation_orchestrator.ts
Description: Solutions and Explanations
==========================================
*/

// src/remediation/orchestrator.ts
import type { RemediationTaskManifest, RemediationTask } from "./compiler";

// ---- Types ----------------------------------------------------------------

export interface OrchestrationBudget {
  maxEnvelopes: number;
  maxTasksPerEnvelope: number;
  maxDistinctLanguagesPerEnvelope: number;
}

export type ExecutorCapabilities = Record<string, boolean>;

export interface DelegationEnvelope {
  id: string;
  tasks: RemediationTask[];
  languages: string[];
  guardrails: string[];
  requirements: Array<{ uid: string; statement: string }>;
  provenanceSubset: {
    traceyUncovered: unknown;
    traceyUntested: unknown;
    traceyRule: Array<{ args: { uid: string }; response: unknown }>;
  };
}

export interface DeferredEntry {
  taskIndex: number;
  uid: string;
  reason:
    | "no-executor-for-language"
    | "requires-multilanguage-executor"
    | "budget-exhausted"
    | "empty-candidate-target-requires-human-review";
  suggestion: {
    kind: "add-capability" | "raise-budget" | "human-split-task" | "human-define-targets";
    detail: string;
  };
}

export interface OrchestrationPlan {
  envelopes: DelegationEnvelope[];
  deferred: DeferredEntry[];
  executionOrder: string[];
  provenance: {
    budget: OrchestrationBudget;
    capabilities: ExecutorCapabilities;
    planHash: string;
  };
}

export class OrchestrationError extends Error {
  constructor(public readonly reason: string, public readonly detail: string) {
    super(`Orchestration error: ${reason} — ${detail}`);
    this.name = "OrchestrationError";
  }
}

// ---- Language mapping -----------------------------------------------------

const EXT_TO_LANGUAGE: Readonly<Record<string, string>> = {
  ".rs": "rust",
  ".ts": "typescript",
  ".tsx": "typescript",
  ".js": "javascript",
  ".jsx": "javascript",
  ".py": "python",
  ".go": "go",
  ".c": "c",
  ".cc": "cpp",
  ".cpp": "cpp",
  ".cxx": "cpp",
  ".h": "c-or-cpp", // ambiguous; treated as its own bucket
  ".hpp": "cpp",
  ".java": "java",
  ".kt": "kotlin",
  ".swift": "swift",
};

function languageOf(path: string): string | undefined {
  const dot = path.lastIndexOf(".");
  if (dot < 0) return undefined;
  return EXT_TO_LANGUAGE[path.slice(dot).toLowerCase()];
}

// ---- Deterministic hashing ------------------------------------------------

function stableStringify(value: unknown): string {
  // Sort keys recursively so that planHash is insensitive to insertion order.
  if (Array.isArray(value)) return "[" + value.map(stableStringify).join(",") + "]";
  if (value && typeof value === "object") {
    const keys = Object.keys(value as object).sort();
    return (
      "{" +
      keys.map((k) => JSON.stringify(k) + ":" + stableStringify((value as any)[k])).join(",") +
      "}"
    );
  }
  return JSON.stringify(value);
}

function hashString(s: string): string {
  // Deterministic FNV-1a; caller may substitute any stable hash.
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return "h" + (h >>> 0).toString(16).padStart(8, "0");
}

// ---- Partitioning ---------------------------------------------------------

interface TaskMeta {
  task: RemediationTask;
  taskIndex: number;
  uid: string;
  targets: string[];
  langs: string[]; // sorted
}

function analyze(tasks: RemediationTask[]): TaskMeta[] {
  return tasks.map((task, taskIndex) => {
    const targets = [...task.candidateTargets].sort();
    const langSet = new Set<string>();
    for (const t of targets) {
      const l = languageOf(t);
      if (l) langSet.add(l);
    }
    return {
      task,
      taskIndex,
      uid: task.requirement.uid,
      targets,
      langs: [...langSet].sort(),
    };
  });
}

/**
 * Greedy group-by-target-file partition. Tasks sharing any candidate target
 * file are merged into the same bucket, then buckets are packed into
 * envelopes under the budget.
 *
 * The over-merging concern: if two tasks share a single file but are
 * otherwise independent, they are still merged. That is deliberate — the
 * envelope's job is to avoid concurrent edits to the same file. The design
 * note explains this trade-off.
 */
function mergeBySharedTargets(metas: TaskMeta[]): TaskMeta[][] {
  const buckets: TaskMeta[][] = [];
  for (const m of metas) {
    const targetSet = new Set(m.targets);
    let placed = false;
    for (const b of buckets) {
      const bTargets = new Set(b.flatMap((x) => x.targets));
      const overlap = [...targetSet].some((t) => bTargets.has(t));
      if (overlap) {
        b.push(m);
        placed = true;
        break;
      }
    }
    if (!placed) buckets.push([m]);
  }
  // Sort within buckets by task index for determinism.
  for (const b of buckets) b.sort((a, b) => a.taskIndex - b.taskIndex);
  // Sort buckets by the smallest taskIndex they contain for determinism.
  buckets.sort((a, b) => Math.min(...a.map((x) => x.taskIndex)) - Math.min(...b.map((x) => x.taskIndex)));
  return buckets;
}

// ---- Public API -----------------------------------------------------------

export function orchestrateRemediation(input: {
  manifest: RemediationTaskManifest;
  budget: OrchestrationBudget;
  capabilities: ExecutorCapabilities;
}): OrchestrationPlan {
  const { manifest, budget, capabilities } = input;
  const metas = analyze(manifest.tasks);

  const deferred: DeferredEntry[] = [];
  const schedulable: TaskMeta[] = [];

  // ---- Per-task prefilter: empty targets and multi-language oversize ------
  for (const m of metas) {
    if (m.targets.length === 0) {
      deferred.push({
        taskIndex: m.taskIndex,
        uid: m.uid,
        reason: "empty-candidate-target-requires-human-review",
        suggestion: {
          kind: "human-define-targets",
          detail: "Add an include glob that matches at least one file for this impl block.",
        },
      });
      continue;
    }

    if (m.langs.length > budget.maxDistinctLanguagesPerEnvelope) {
      deferred.push({
        taskIndex: m.taskIndex,
        uid: m.uid,
        reason: "requires-multilanguage-executor",
        suggestion: {
          kind: "human-split-task",
          detail: `Task spans ${m.langs.length} languages (${m.langs.join(", ")}); budget allows ${budget.maxDistinctLanguagesPerEnvelope}.`,
        },
      });
      continue;
    }

    const missingLang = m.langs.find((l) => capabilities[l] !== true);
    if (missingLang) {
      deferred.push({
        taskIndex: m.taskIndex,
        uid: m.uid,
        reason: "no-executor-for-language",
        suggestion: {
          kind: "add-capability",
          detail: `No executor capability configured for '${missingLang}'.`,
        },
      });
      continue;
    }

    schedulable.push(m);
  }

  // ---- Merge by shared targets -------------------------------------------
  const buckets = mergeBySharedTargets(schedulable);

  // ---- Pack buckets into envelopes under budget --------------------------
  const envelopes: DelegationEnvelope[] = [];
  let budgetExhausted = false;

  const provenanceByUid = new Map<string, { args: { uid: string }; response: unknown }>();
  for (const entry of manifest.provenance.traceyRule) {
    provenanceByUid.set(entry.args.uid, entry);
  }

  const envelopeId = (i: number) => `env-${String(i).padStart(3, "0")}`;

  for (const bucket of buckets) {
    if (budgetExhausted) break;

    // Chunk the bucket to satisfy maxTasksPerEnvelope; each chunk still
    // carries the shared-target guarantee because bucket members were merged.
    for (let off = 0; off < bucket.length; off += budget.maxTasksPerEnvelope) {
      if (envelopes.length >= budget.maxEnvelopes) {
        budgetExhausted = true;
        // Defer the remaining chunks explicitly.
        for (const m of bucket.slice(off)) {
          deferred.push({
            taskIndex: m.taskIndex,
            uid: m.uid,
            reason: "budget-exhausted",
            suggestion: {
              kind: "raise-budget",
              detail: `Raise maxEnvelopes (currently ${budget.maxEnvelopes}) to schedule this task.`,
            },
          });
        }
        break;
      }

      const chunk = bucket.slice(off, off + budget.maxTasksPerEnvelope);

      // Runtime disjointness assertion: no shared target file across envelopes.
      const chunkTargets = new Set(chunk.flatMap((x) => x.targets));
      for (const existing of envelopes) {
        const eTargets = new Set(existing.tasks.flatMap((t) => t.candidateTargets));
        for (const t of chunkTargets) {
          if (eTargets.has(t)) {
            throw new OrchestrationError(
              "target-not-disjoint",
              `target ${t} appears in envelope ${existing.id} and would also appear in a new envelope`,
            );
          }
        }
      }

      const langSet = new Set(chunk.flatMap((x) => x.langs));
      const guardrails = [
        ...new Set(
          chunk.flatMap((m) => (m.task.brief.guardrails ?? []) as string[]),
        ),
      ].sort();

      envelopes.push({
        id: envelopeId(envelopes.length),
        tasks: chunk.map((m) => m.task),
        languages: [...langSet].sort(),
        guardrails,
        requirements: chunk.map((m) => ({
          uid: m.uid,
          statement: m.task.requirement.statement,
        })),
        provenanceSubset: {
          traceyUncovered: manifest.provenance.traceyUncovered.response,
          traceyUntested: manifest.provenance.traceyUntested.response,
          traceyRule: chunk
            .map((m) => provenanceByUid.get(m.uid))
            .filter((x): x is NonNullable<typeof x> => x !== undefined),
        },
      });
    }
  }

  // ---- Execution order ---------------------------------------------------
  // We order envelopes by the smallest task index they contain. Two
  // envelopes with no shared targets and non-overlapping dependency sets
  // are independent — their relative order in the partition we produce
  // happens to be index-monotone, but the contract does not guarantee it.
  const executionOrder = envelopes
    .slice()
    .sort(
      (a, b) =>
        Math.min(...a.tasks.map((_t, i) => i)) -
        Math.min(...b.tasks.map((_t, i) => i)),
    )
    .map((e) => e.id);

  // ---- Plan hash ---------------------------------------------------------
  const hashablePayload = {
    budget,
    capabilities: Object.keys(capabilities).sort().reduce((acc, k) => {
      (acc as any)[k] = capabilities[k];
      return acc;
    }, {} as ExecutorCapabilities),
    envelopes: envelopes.map((e) => ({
      id: e.id,
      languages: e.languages,
      uids: e.tasks.map((t) => t.requirement.uid).sort(),
    })),
    deferred: deferred.map((d) => ({ taskIndex: d.taskIndex, reason: d.reason })),
  };
  const planHash = hashString(stableStringify(hashablePayload));

  return {
    envelopes,
    deferred,
    executionOrder,
    provenance: {
      budget,
      capabilities,
      planHash,
    },
  };
}
