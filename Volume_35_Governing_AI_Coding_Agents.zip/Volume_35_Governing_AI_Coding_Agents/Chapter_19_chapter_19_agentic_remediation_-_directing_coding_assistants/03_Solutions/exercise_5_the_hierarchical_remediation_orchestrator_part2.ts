/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_the_hierarchical_remediation_orchestrator_part2.ts
Description: Solutions and Explanations
==========================================
*/

// src/remediation/orchestrator.test.ts
import { describe, it, expect } from "vitest";
import {
  orchestrateRemediation,
  OrchestrationError,
  type OrchestrationBudget,
} from "./orchestrator";
import type { RemediationTaskManifest, RemediationTask } from "./compiler";

function task(uid: string, targets: string[], statement = "S"): RemediationTask {
  return {
    brief: {
      schemaVersion: "1",
      gapClass: "uncovered",
      requirementUid: uid,
      specImpl: "app/rust",
      detectedAt: "2026-01-01T00:00:00Z",
      toolInvocation: { tool: "tracey_uncovered", args: {} },
      expectedEvidence: { verb: "impl", annotationForm: `// r[impl ${uid}]` },
      guardrails: ["g1", "g2"],
    },
    requirement: {
      uid,
      statement,
      existingReferences: [],
    },
    candidateTargets: targets,
    preconditions: [],
    postconditions: [],
  };
}

function manifest(tasks: RemediationTask[]): RemediationTaskManifest {
  return {
    schemaVersion: "1",
    compilerVersion: "compile-1.0.0",
    generatedAt: "2026-01-01T00:00:00Z",
    tasks,
    provenance: {
      traceyStatus: { args: {}, response: {} },
      traceyConfig: { args: {}, response: {} },
      traceyUncovered: { args: {}, response: {} },
      traceyUntested: { args: {}, response: {} },
      traceyRule: tasks.map((t) => ({
        args: { uid: t.requirement.uid },
        response: { uid: t.requirement.uid },
      })),
    },
    permittedEvidenceDecreases: [],
  };
}

const budget: OrchestrationBudget = {
  maxEnvelopes: 4,
  maxTasksPerEnvelope: 3,
  maxDistinctLanguagesPerEnvelope: 2,
};

const caps: Record<string, boolean> = { rust: true, python: true };

describe("orchestrateRemediation", () => {
  it("produces disjoint candidate target sets across envelopes", () => {
    const plan = orchestrateRemediation({
      manifest: manifest([
        task("a", ["src/a.rs"]),
        task("b", ["src/b.rs"]),
        task("c", ["src/a.rs"]), // shares with a — must merge
      ]),
      budget,
      capabilities: caps,
    });
    const targets = plan.envelopes.flatMap((e) => e.tasks.flatMap((t) => t.candidateTargets));
    expect(new Set(targets).size).toBe(targets.length);
    expect(plan.envelopes).toHaveLength(2);
  });

  it("groups by language under the envelope budget", () => {
    const plan = orchestrateRemediation({
      manifest: manifest([
        task("a", ["src/a.rs"]),
        task("b", ["src/b.rs"]),
      ]),
      budget,
      capabilities: caps,
    });
    expect(plan.envelopes[0].languages).toEqual(["rust"]);
  });

  it("defers tasks with missing language capabilities", () => {
    const plan = orchestrateRemediation({
      manifest: manifest([task("a", ["scripts/tool.py"])]),
      budget,
      capabilities: { rust: true },
    });
    expect(plan.deferred).toHaveLength(1);
    expect(plan.deferred[0].reason).toBe("no-executor-for-language");
  });

  it("defers a multi-language task when the envelope budget is 1", () => {
    const plan = orchestrateRemediation({
      manifest: manifest([task("a", ["src/a.rs", "scripts/a.py"])]),
      budget: { ...budget, maxDistinctLanguagesPerEnvelope: 1 },
      capabilities: caps,
    });
    expect(plan.deferred[0].reason).toBe("requires-multilanguage-executor");
    expect(plan.envelopes).toHaveLength(0);
  });

  it("emits a stable planHash across runs", () => {
    const m = manifest([task("a", ["src/a.rs"])]);
    const p1 = orchestrateRemediation({ manifest: m, budget, capabilities: caps });
    const p2 = orchestrateRemediation({ manifest: m, budget, capabilities: caps });
    expect(p1.provenance.planHash).toBe(p2.provenance.planHash);
    const p3 = orchestrateRemediation({
      manifest: m,
      budget: { ...budget, maxEnvelopes: 5 },
      capabilities: caps,
    });
    expect(p3.provenance.planHash).not.toBe(p1.provenance.planHash);
  });

  it("throws a typed OrchestrationError on disjointness failure", () => {
    // Build a manifest where two tasks have identical targets but the
    // internal merge step is bypassed via sorting. This is a structural
    // test — in practice the merge prevents overlap. We simulate by
    // testing the error class exists and is thrown only on real conflicts.
    expect(new OrchestrationError("target-not-disjoint", "x")).toBeInstanceOf(Error);
    expect(new OrchestrationError("target-not-disjoint", "x").name).toBe("OrchestrationError");
  });
});
