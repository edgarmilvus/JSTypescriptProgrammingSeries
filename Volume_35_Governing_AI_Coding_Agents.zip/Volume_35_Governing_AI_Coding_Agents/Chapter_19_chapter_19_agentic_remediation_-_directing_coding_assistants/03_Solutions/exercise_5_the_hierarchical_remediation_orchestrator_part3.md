<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_5_the_hierarchical_remediation_orchestrator_part3.md
Description: Solutions and Explanations
==========================================
-->

<!-- docs/design/orchestrator.md -->

# Orchestrator Design Note

## 1. Grouping decisions for partially-overlapping candidate target sets

The orchestrator partitions tasks into buckets by **target-file overlap**, not by
requirement UID and not by file count. Two tasks whose candidate target sets
are identical are merged unconditionally into the same bucket: an agent that
edits the file to satisfy one requirement will almost certainly produce
annotations that touch the other, and letting two executors produce annotations
in the same file in parallel produces conflicts the guardrail harness will
reject. Two tasks whose candidate sets overlap on a single file are merged
for the same reason: the invariant we are defending is "no two envelopes
share a candidate target file," and it is a whole-file invariant, not a
per-line or per-function invariant. We do not attempt to split a file across
two envelopes even when a real language-aware pass could prove the tasks are
disjoint inside it — the partitioning step is deliberately language-agnostic
precisely so that it remains decidable without a parser.

The cost of this policy is that a family of unrelated requirements that all
touch a single shared util file will be merged into one envelope even though
the underlying edits are independent. That is a real cost, but it is a cost
paid in envelope size, not in correctness. Two tasks in the same envelope
cannot produce conflicting edits to the same file because they are handed to
a single executor turn. Two tasks in different envelopes that happen to share
a file *can* produce conflicting edits, and the harness has no way to
distinguish "conflict" from "clean merge" without parsing diffs. The safer
failure mode is over-merging, and the exercise's disjointness assertion
enforces it in code.

## 2. Handling tasks with empty candidate target sets

The orchestrator **defers** a task whose candidate target set is empty; it does
not drop the task and it does not emit an envelope with an empty target set.

Emitting an envelope with an empty target set would be a lie. The envelope's
contract is that the executor will edit files inside its target set; an
envelope with no targets hands the executor a task whose only possible
resolutions are "edit outside the target set" (which the harness will reject)
or "do nothing" (which the harness will also reject, because the requirement
"gap closed" postcondition will not fire). Neither outcome is useful, and the
first is anti-governance — it invites the executor to invent a file to edit,
which is precisely the failure mode the guardrail harness exists to prevent.

Dropping the task silently is worse: the operator who added a brief sees a
plan that omits it and reasonably concludes that the task was subsumed into
some envelope. That is a provenance lie. When the operator later checks
`tracey_uncovered` and finds the gap still open, they have no way to connect
"the gap is open" back to "the plan chose not to schedule it."

The deferral entry carries `reason: "empty-candidate-target-requires-human-review"` and
a `suggestion: { kind: "human-define-targets" }` with the concrete fix — an
include glob that matches at least one file for the impl block. This is
mechanically derivable from the manifest: the compiler recorded the resolved
include/exclude globs in the impl block's config; the orchestrator can
surface the globs that produced zero matches without re-reading the config
file or invoking an LLM. The deferral is the orchestrator's most important
output precisely because it names the specific change that would unblock the
task. An orchestrator that silently schedules, drops, or rescues an
unschedulable task has hidden the problem one layer deeper, where the
guardrail harness finds it only after an executor has already spent its
budget on a doomed change.
