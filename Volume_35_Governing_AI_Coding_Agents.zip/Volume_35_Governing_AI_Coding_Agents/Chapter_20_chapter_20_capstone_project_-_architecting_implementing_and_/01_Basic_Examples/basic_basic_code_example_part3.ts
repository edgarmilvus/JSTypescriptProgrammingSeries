/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part3.ts
Description: Basic Code Example
==========================================
*/

// src/invites/inviteService.ts
import type { SupabaseClient } from '@supabase/supabase-js';

/* ============================================================
 * 1. Persistence shapes — the contract with Postgres
 * ============================================================ */

export type InviteRow = {
  readonly id: string;
  readonly workspace_id: string;
  readonly email: string;
  readonly token: string;
  readonly created_at: string;
  readonly expires_at: string;
  readonly redeemed_at: string | null;
};

export type InviteInsert = Pick<
  InviteRow,
  'workspace_id' | 'email' | 'token' | 'expires_at'
>;

export type InvitePatch = Partial<Omit<InviteRow, 'id' | 'workspace_id'>>;

export type Database = {
  public: {
    Tables: {
      invites: {
        Row: InviteRow;
        Insert: InviteInsert;
        Update: InvitePatch;
      };
    };
  };
};

/* ============================================================
 * 2. Traceability primitives
 * ============================================================ */

export type Result<T, E = Error> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

declare const requirementBrand: unique symbol;

export type RequirementId<T extends string> = T & {
  readonly [requirementBrand]: true;
};

/* ============================================================
 * 3. Ports
 * ============================================================ */

export interface Repository<TRow extends { id: string }, TInsert> {
  insert(row: TInsert): Promise<Result<TRow>>;
  findById(id: string): Promise<Result<TRow | null>>;
  update(id: string, patch: Partial<TRow>): Promise<Result<TRow>>;
}

export interface InviteRepository extends Repository<InviteRow, InviteInsert> {
  findByToken(token: string): Promise<Result<InviteRow | null>>;
}

/* ============================================================
 * 4. Supabase adapter
 * ============================================================ */

export class SupabaseInviteRepository implements InviteRepository {
  public constructor(private readonly client: SupabaseClient<Database>) {}

  public async insert(row: InviteInsert): Promise<Result<InviteRow>> {
    const { data, error } = await this.client
      .from('invites')
      .insert(row)
      .select()
      .single();

    if (error !== null) {
      return { ok: false, error: new Error(`invite insert failed: ${error.message}`) };
    }

    return { ok: true, value: data };
  }

  public async findById(id: string): Promise<Result<InviteRow | null>> {
    const { data, error } = await this.client
      .from('invites')
      .select()
      .eq('id', id)
      .maybeSingle();

    if (error !== null) {
      return { ok: false, error: new Error(`invite lookup failed: ${error.message}`) };
    }

    return { ok: true, value: data };
  }

  public async findByToken(token: string): Promise<Result<InviteRow | null>> {
    const { data, error } = await this.client
      .from('invites')
      .select()
      .eq('token', token)
      .maybeSingle();

    if (error !== null) {
      return { ok: false, error: new Error(`token lookup failed: ${error.message}`) };
    }

    return { ok: true, value: data };
  }

  public async update(id: string, patch: Partial<InviteRow>): Promise<Result<InviteRow>> {
    const { data, error } = await this.client
      .from('invites')
      .update(patch)
      .eq('id', id)
      .select()
      .single();

    if (error !== null) {
      return { ok: false, error: new Error(`invite update failed: ${error.message}`) };
    }

    return { ok: true, value: data };
  }
}

/* ============================================================
 * 5. Domain service — the governed surface
 * ============================================================ */

export const INVITE_TTL_MS = 72 * 60 * 60 * 1_000;

export type Clock = { readonly now: () => number };

export const systemClock: Clock = { now: () => Date.now() };

export type CreateInviteInput = {
  readonly workspaceId: string;
  readonly email: string;
  readonly actorIsOwner: boolean;
};

export type IssuedInvite = Readonly<
  Pick<InviteRow, 'id' | 'token' | 'expires_at'>
>;

export type RedeemOutcome =
  | { readonly status: 'redeemed'; readonly email: string }
  | { readonly status: 'already-redeemed' }
  | { readonly status: 'expired' }
  | { readonly status: 'not-found' };

/**
 * Mints a pending invitation for a workspace.
 *
 * @param repository - persistence port; swapped in tests for an in-memory map.
 * @param input      - workspace, invitee email, and the actor's role claim.
 * @param clock      - injectable time source; production uses {@link systemClock}.
 */
// r[impl INVITE-001]
export async function createInvite(
  repository: InviteRepository,
  input: CreateInviteInput,
  clock: Clock = systemClock,
): Promise<Result<IssuedInvite>> {
  if (!input.actorIsOwner) {
    return {
      ok: false,
      error: new Error('forbidden: actor does not hold the owner role'),
    };
  }

  const expiresAt = new Date(clock.now() + INVITE_TTL_MS).toISOString();

  const inserted = await repository.insert({
    workspace_id: input.workspaceId,
    email: input.email,
    token: globalThis.crypto.randomUUID(),
    expires_at: expiresAt,
  });

  if (!inserted.ok) {
    return inserted;
  }

  return {
    ok: true,
    value: Object.freeze({
      id: inserted.value.id,
      token: inserted.value.token,
      expires_at: inserted.value.expires_at,
    }),
  };
}

/**
 * Redeems an invitation token.
 *
 * @returns a discriminated outcome rather than a thrown error, so that
 *          "already redeemed" and "expired" are ordinary control flow.
 */
// r[impl INVITE-002]
// r[impl INVITE-003]
export async function redeemInvite(
  repository: InviteRepository,
  token: string,
  clock: Clock = systemClock,
): Promise<Result<RedeemOutcome>> {
  const lookup = await repository.findByToken(token);

  if (!lookup.ok) {
    return lookup;
  }

  const invite = lookup.value;

  if (invite === null) {
    return { ok: true, value: { status: 'not-found' } };
  }

  if (invite.redeemed_at !== null) {
    return { ok: true, value: { status: 'already-redeemed' } };
  }

  if (isExpired(invite, clock)) {
    return { ok: true, value: { status: 'expired' } };
  }

  const redeemed = await repository.update(invite.id, {
    redeemed_at: new Date(clock.now()).toISOString(),
  });

  if (!redeemed.ok) {
    return redeemed;
  }

  return { ok: true, value: { status: 'redeemed', email: invite.email } };
}

/**
 * Predicate used by {@link redeemInvite}. Exposed separately so the
 * boundary condition can be tested without a repository.
 */
// r[impl INVITE-003]
export function isExpired(
  invite: Readonly<Pick<InviteRow, 'expires_at'>>,
  clock: Clock = systemClock,
): boolean {
  return Date.parse(invite.expires_at) <= clock.now();
}
