/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// tests/invites/inviteService.spec.ts
import { describe, expect, it } from 'vitest';

import {
  createInvite,
  isExpired,
  redeemInvite,
  INVITE_TTL_MS,
  type Clock,
  type CreateInviteInput,
  type InviteInsert,
  type InviteRepository,
  type InviteRow,
  type Result,
} from '../../src/invites/inviteService';

/* ---------------------------------------------------------------
 * Test doubles
 * --------------------------------------------------------------- */

class InMemoryInviteRepository implements InviteRepository {
  private readonly rows = new Map<string, InviteRow>();
  private sequence = 0;

  public async insert(row: InviteInsert): Promise<Result<InviteRow>> {
    this.sequence += 1;
    const stored: InviteRow = {
      id: `inv_${this.sequence}`,
      created_at: new Date(0).toISOString(),
      redeemed_at: null,
      ...row,
    };
    this.rows.set(stored.id, stored);
    return { ok: true, value: stored };
  }

  public async findById(id: string): Promise<Result<InviteRow | null>> {
    return { ok: true, value: this.rows.get(id) ?? null };
  }

  public async findByToken(token: string): Promise<Result<InviteRow | null>> {
    for (const row of this.rows.values()) {
      if (row.token === token) {
        return { ok: true, value: row };
      }
    }
    return { ok: true, value: null };
  }

  public async update(
    id: string,
    patch: Partial<InviteRow>,
  ): Promise<Result<InviteRow>> {
    const existing = this.rows.get(id);
    if (existing === undefined) {
      return { ok: false, error: new Error(`no invite with id ${id}`) };
    }
    const next: InviteRow = { ...existing, ...patch };
    this.rows.set(id, next);
    return { ok: true, value: next };
  }
}

function fixedClock(atMs: number): Clock {
  return { now: () => atMs };
}

function assertOk<T>(result: Result<T>): T {
  if (!result.ok) {
    throw new Error(`expected Ok, received Err: ${result.error.message}`);
  }
  return result.value;
}

/* ---------------------------------------------------------------
 * Fixtures
 * --------------------------------------------------------------- */

const EPOCH = Date.parse('2026-01-01T00:00:00.000Z');

const OWNER: CreateInviteInput = {
  workspaceId: 'ws_acme',
  email: 'newcomer@acme.test',
  actorIsOwner: true,
};

const INTRUDER: CreateInviteInput = { ...OWNER, actorIsOwner: false };

/* ---------------------------------------------------------------
 * INVITE-001 — only owners may mint invitations
 * --------------------------------------------------------------- */

describe('createInvite', () => {
  // r[verify INVITE-001]
  it('rejects the request when the actor is not an owner', async () => {
    const repository = new InMemoryInviteRepository();

    const result = await createInvite(repository, INTRUDER, fixedClock(EPOCH));

    expect(result.ok).toBe(false);
  });

  // r[verify INVITE-001]
  it('mints a pending invite that expires 72 hours after creation', async () => {
    const repository = new InMemoryInviteRepository();
    const clock = fixedClock(EPOCH);

    const issued = assertOk(await createInvite(repository, OWNER, clock));

    expect(Date.parse(issued.expires_at)).toBe(EPOCH + INVITE_TTL_MS);
    expect(issued.token).toMatch(/[0-9a-f-]{36}/);
  });
});

/* ---------------------------------------------------------------
 * INVITE-002 — tokens are single-use
 * --------------------------------------------------------------- */

describe('redeemInvite', () => {
  // r[verify INVITE-002]
  it('redeems a fresh token exactly once', async () => {
    const repository = new InMemoryInviteRepository();
    const clock = fixedClock(EPOCH);
    const issued = assertOk(await createInvite(repository, OWNER, clock));

    const first = assertOk(await redeemInvite(repository, issued.token, clock));
    expect(first.status).toBe('redeemed');

    const second = assertOk(await redeemInvite(repository, issued.token, clock));
    expect(second.status).toBe('already-redeemed');
  });

  // r[verify INVITE-002]
  it('does not mutate the row on a repeated redemption attempt', async () => {
    const repository = new InMemoryInviteRepository();
    const clock = fixedClock(EPOCH);
    const issued = assertOk(await createInvite(repository, OWNER, clock));

    assertOk(await redeemInvite(repository, issued.token, clock));
    const afterFirst = assertOk(await repository.findById(issued.id));

    assertOk(await redeemInvite(repository, issued.token, clock));
    const afterSecond = assertOk(await repository.findById(issued.id));

    expect(afterSecond?.redeemed_at).toBe(afterFirst?.redeemed_at);
  });
});

/* ---------------------------------------------------------------
 * INVITE-003 — 72-hour expiry, inclusive boundary
 * --------------------------------------------------------------- */

describe('expiry', () => {
  // r[verify INVITE-003]
  it('refuses to redeem a token one millisecond past the TTL', async () => {
    const repository = new InMemoryInviteRepository();
    const issued = assertOk(
      await createInvite(repository, OWNER, fixedClock(EPOCH)),
    );

    const later = fixedClock(EPOCH + INVITE_TTL_MS + 1);
    const outcome = assertOk(await redeemInvite(repository, issued.token, later));

    expect(outcome.status).toBe('expired');
  });

  // r[verify INVITE-003]
  it('treats the exact expiry instant as expired', () => {
    const clock = fixedClock(EPOCH);

    expect(isExpired({ expires_at: new Date(EPOCH).toISOString() }, clock)).toBe(true);
  });
});
