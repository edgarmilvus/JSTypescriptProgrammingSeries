/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation.ts
Description: Advanced Application Implementation
==========================================
*/

aegis-gateway/
├── .config/tracey/config.styx          # Tracey: specs ↔ implementations binding
├── .cursor/mcp.json                    # Tracey MCP server registration
├── .cursorrules                        # Agent governance prompt
├── .github/workflows/spec-assurance.yml# CI drift gate (annotated!)
├── docs/spec/aegis/                    # StrictDoc intent spine (.sdoc)
│   ├── 00_intent.sdoc
│   ├── 10_architecture.sdoc
│   ├── 20_tenancy.sdoc
│   ├── 30_quantization.sdoc
│   ├── 40_streaming.sdoc
│   ├── 50_orchestration.sdoc
│   └── 60_observability.sdoc
├── docs/spec/vendor/openai-compat.md   # External spec (prefix: oa)
├── edge/src/sse.rs                     # Rust data-plane framer
├── src/
│   ├── core/{result.ts,clock.ts}
│   ├── tenancy/quota-ledger.ts
│   ├── quantization/registry.ts
│   ├── streaming/sse-writer.ts
│   ├── agents/parallel-tool-executor.ts
│   ├── observability/{logger.ts,event-loop-monitor.ts}
│   └── gateway.ts
├── tests/
│   ├── support/manual-clock.ts
│   ├── tenancy/quota-ledger.test.ts
│   ├── quantization/registry.test.ts
│   ├── streaming/sse-writer.test.ts
│   ├── agents/parallel-tool-executor.test.ts
│   ├── observability/logger.test.ts
│   ├── architecture/single-process.test.ts
│   └── gateway.integration.test.ts
├── tools/governance_report.py          # Python MCP client
├── vitest.config.ts
└── package.json
