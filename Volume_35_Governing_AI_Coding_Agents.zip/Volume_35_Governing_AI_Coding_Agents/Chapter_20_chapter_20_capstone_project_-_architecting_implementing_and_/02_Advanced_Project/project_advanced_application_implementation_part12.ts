/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Explicit success/failure envelopes used at every request-path boundary.
 *
 * Expected rejection conditions (quota exhaustion, unknown tenant, no viable
 * variant) are control flow on this service, not exceptional events. Modelling
 * them as a discriminated union keeps every branch visible to the type checker.
 */

// r[impl AEGIS-ARCH-004]

/** Successful outcome carrying a value. */
export type Ok<T> = { readonly ok: true; readonly value: T };

/** Failed outcome carrying a typed error. */
export type Err<E> = { readonly ok: false; readonly error: E };

/** Discriminated union of the two outcomes. */
export type Result<T, E> = Ok<T> | Err<E>;

/** Construct a successful outcome. */
export function ok<T>(value: T): Ok<T> {
  return { ok: true, value };
}

/** Construct a failed outcome. */
export function err<E>(error: E): Err<E> {
  return { ok: false, error };
}

/** Narrow a {@link Result} to its success case. */
export function isOk<T, E>(result: Result<T, E>): result is Ok<T> {
  return result.ok;
}

/** Return the wrapped value, or a fallback when the result is a failure. */
export function unwrapOr<T, E>(result: Result<T, E>, fallback: T): T {
  return result.ok ? result.value : fallback;
}
