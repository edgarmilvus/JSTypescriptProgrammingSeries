/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part14.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Token-bucket quota ledger implementing tenant admission control.
 *
 * Each tenant owns one bucket with a burst capacity and a continuous refill
 * rate. Refill is computed lazily from elapsed time rather than on a timer, so
 * an idle gateway performs no work on behalf of idle tenants.
 */

import type { Clock } from '../core/clock.js';
import { systemClock } from '../core/clock.js';
import { err, ok, type Result } from '../core/result.js';

// r[impl AEGIS-TEN-001]
// r[impl AEGIS-ARCH-004]

/** Static configuration for one tenant's compute budget. */
export interface TenantQuota {
  readonly tenantId: string;
  /** Maximum units that may be consumed instantaneously. */
  readonly burstUnits: number;
  /** Sustained refill expressed in units per second. */
  readonly refillUnitsPerSecond: number;
}

/** Machine-readable failure codes returned by the ledger. */
export type QuotaErrorCode =
  | 'INVALID_QUOTA'
  | 'DUPLICATE_TENANT'
  | 'UNKNOWN_TENANT'
  | 'INVALID_UNITS'
  | 'QUOTA_EXCEEDED';

/** Failure payload for {@link QuotaLedger} operations. */
export interface QuotaError {
  readonly code: QuotaErrorCode;
  readonly message: string;
  /** Present only for `QUOTA_EXCEEDED`. */
  readonly retryAfterMs?: number;
}

/** Successful admission decision. */
export interface QuotaDecision {
  readonly tenantId: string;
  readonly requestId: string;
  readonly units: number;
  readonly burstUnits: number;
  /** Whole units still available immediately after this grant. */
  readonly remainingUnits: number;
}

/** Immutable audit record emitted for every decision. */
export interface QuotaAuditEvent {
  readonly type: 'quota.decision';
  readonly at: number;
  readonly tenantId: string;
  readonly requestId: string;
  readonly units: number;
  readonly allowed: boolean;
  readonly remainingUnits: number;
}

/** Sink for audit records. Implementations must not throw. */
export interface AuditSink {
  emit(event: QuotaAuditEvent): void;
}

/** Audit sink that discards everything; used in tests and local dev. */
export const nullAuditSink: AuditSink = { emit() {} };

interface Bucket {
  tokens: number;
  updatedAt: number;
}

/**
 * Token-bucket admission controller for multi-tenant compute budgets.
 *
 * The ledger is intentionally synchronous: it mutates in-memory state and
 * performs no I/O, which keeps it compatible with the single-event-loop
 * constraint in `AEGIS-ARCH-001`.
 */
export class QuotaLedger {
  private readonly quotas = new Map<string, TenantQuota>();
  private readonly buckets = new Map<string, Bucket>();

  constructor(
    private readonly clock: Clock = systemClock,
    private readonly audit: AuditSink = nullAuditSink,
  ) {}

  /**
   * Register a tenant's budget.
   *
   * @returns the registered quota, or a typed failure when the quota is
   * malformed or the tenant is already registered.
   */
  // r[impl AEGIS-TEN-001]
  register(quota: TenantQuota): Result<TenantQuota, QuotaError> {
    if (quota.tenantId.trim().length === 0) {
      return err({ code: 'INVALID_QUOTA', message: 'tenantId must not be empty' });
    }
    if (!Number.isFinite(quota.burstUnits) || quota.burstUnits <= 0) {
      return err({ code: 'INVALID_QUOTA', message: 'burstUnits must be positive' });
    }
    if (!Number.isFinite(quota.refillUnitsPerSecond) || quota.refillUnitsPerSecond <= 0) {
      return err({ code: 'INVALID_QUOTA', message: 'refillUnitsPerSecond must be positive' });
    }
    if (this.quotas.has(quota.tenantId)) {
      return err({
        code: 'DUPLICATE_TENANT',
        message: `tenant '${quota.tenantId}' is already registered`,
      });
    }

    this.quotas.set(quota.tenantId, quota);
    this.buckets.set(quota.tenantId, {
      tokens: quota.burstUnits,
      updatedAt: this.clock.now(),
    });
    return ok(quota);
  }

  /**
   * Attempt to reserve `units` from `tenantId`'s bucket.
   *
   * An unknown tenant is denied, not auto-provisioned: see `AEGIS-TEN-003`.
   * Every path — grant or denial — emits exactly one audit record.
   */
  // r[impl AEGIS-TEN-002]
  // r[impl AEGIS-TEN-003]
  // r[impl AEGIS-TEN-004]
  tryConsume(tenantId: string, units: number, requestId: string): Result<QuotaDecision, QuotaError> {
    if (!Number.isInteger(units) || units <= 0) {
      return err({ code: 'INVALID_UNITS', message: 'units must be a positive integer' });
    }

    const quota = this.quotas.get(tenantId);
    const bucket = this.buckets.get(tenantId);
    if (quota === undefined || bucket === undefined) {
      this.audit.emit({
        type: 'quota.decision',
        at: this.clock.now(),
        tenantId,
        requestId,
        units,
        allowed: false,
        remainingUnits: 0,
      });
      return err({ code: 'UNKNOWN_TENANT', message: 'tenant is not provisioned' });
    }

    const now = this.clock.now();
    const refilled = this.refill(quota, bucket, now);
    const remainingUnits = Math.floor(refilled);

    if (refilled < units) {
      const deficit = units - refilled;
      const refillPerMs = quota.refillUnitsPerSecond / 1000;
      const retryAfterMs = Math.ceil(deficit / refillPerMs);

      this.audit.emit({
        type: 'quota.decision',
        at: now,
        tenantId,
        requestId,
        units,
        allowed: false,
        remainingUnits,
      });
      return err({
        code: 'QUOTA_EXCEEDED',
        message: `request requires ${units} units but only ${remainingUnits} are available`,
        retryAfterMs,
      });
    }

    bucket.tokens = refilled - units;
    bucket.updatedAt = now;

    this.audit.emit({
      type: 'quota.decision',
      at: now,
      tenantId,
      requestId,
      units,
      allowed: true,
      remainingUnits: Math.floor(bucket.tokens),
    });

    return ok({
      tenantId,
      requestId,
      units,
      burstUnits: quota.burstUnits,
      remainingUnits: Math.floor(bucket.tokens),
    });
  }

  /**
   * Return reserved capacity that was never delivered to the caller.
   *
   * @returns the number of whole units actually returned to the bucket.
   */
  // r[impl AEGIS-TEN-005]
  refund(tenantId: string, units: number): number {
    const quota = this.quotas.get(tenantId);
    const bucket = this.buckets.get(tenantId);
    if (quota === undefined || bucket === undefined) return 0;
    if (!Number.isInteger(units) || units <= 0) return 0;

    const now = this.clock.now();
    const refilled = this.refill(quota, bucket, now);
    const capped = Math.min(quota.burstUnits, refilled + units);
    const returned = Math.floor(capped - refilled);

    bucket.tokens = capped;
    bucket.updatedAt = now;
    return returned;
  }

  /** Read-only view of a tenant's currently available whole units. */
  available(tenantId: string): number {
    const quota = this.quotas.get(tenantId);
    const bucket = this.buckets.get(tenantId);
    if (quota === undefined || bucket === undefined) return 0;
    return Math.floor(this.refill(quota, bucket, this.clock.now()));
  }

  /**
   * Lazily bring a bucket up to date. Never reads a clock more than once per
   * public call, which keeps refill arithmetic reproducible in tests.
   */
  private refill(quota: TenantQuota, bucket: Bucket, now: number): number {
    const elapsedMs = Math.max(0, now - bucket.updatedAt);
    const gained = (quota.refillUnitsPerSecond * elapsedMs) / 1000;
    bucket.tokens = Math.min(quota.burstUnits, bucket.tokens + gained);
    bucket.updatedAt = now;
    return bucket.tokens;
  }
}
