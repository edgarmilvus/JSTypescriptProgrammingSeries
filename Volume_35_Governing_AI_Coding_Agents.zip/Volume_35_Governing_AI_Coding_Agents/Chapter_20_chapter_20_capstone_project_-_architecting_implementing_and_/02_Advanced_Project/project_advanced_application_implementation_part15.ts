/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part15.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Quantization registry and routing policy evaluation.
 *
 * A quantization scheme reduces the numeric precision of a model's weights and
 * activations (for example 32-bit float to 8-bit integer) to shrink the
 * artifact and speed up inference at some cost in fidelity. The gateway must
 * therefore treat scheme selection as a *policy* decision with an auditable
 * outcome, not as a lookup.
 */

import { err, ok, type Result } from '../core/result.js';

// r[impl AEGIS-QNT-001]
// r[impl AEGIS-QNT-002]

/** Quantization schemes the registry accepts. */
export type QuantizationScheme = 'fp32' | 'fp16' | 'int8' | 'q4_k_m';

/** Canonical scheme labels, ordered from highest to lowest numeric fidelity. */
export const SUPPORTED_SCHEMES: readonly QuantizationScheme[] = [
  'fp32',
  'fp16',
  'int8',
  'q4_k_m',
];

/**
 * Explicit total order used to break ties during variant selection.
 *
 * Lower rank wins. Higher precision is preferred when quality and size are
 * equal, because precision is the property least likely to be compensated for
 * by other layers of the stack.
 */
const SCHEME_RANK: Readonly<Record<QuantizationScheme, number>> = {
  fp32: 0,
  fp16: 1,
  int8: 2,
  q4_k_m: 3,
};

/** One registered artifact. */
export interface QuantizedVariant {
  readonly modelId: string;
  readonly scheme: QuantizationScheme;
  /** Weight bytes on disk. */
  readonly sizeBytes: number;
  /** Measured quality score in the closed interval [0, 1]. */
  readonly qualityScore: number;
}

/** Routing input supplied per request. */
export interface RoutingPolicy {
  readonly modelId: string;
  /** Hard ceiling on resident memory for this request. */
  readonly maxResidentBytes: number;
  /** Minimum acceptable measured quality. */
  readonly minQualityScore: number;
  /** Projected key/value cache bytes for the requested context. */
  readonly kvCacheBytes: number;
  /** Optional allow-list of schemes for this tenant. */
  readonly allowedSchemes?: readonly QuantizationScheme[];
}

/** Failure codes returned by the registry. */
export type RegistryErrorCode =
  | 'UNKNOWN_SCHEME'
  | 'INVALID_VARIANT'
  | 'DUPLICATE_VARIANT'
  | 'NO_VIABLE_VARIANT';

/** Failure payload for registry operations. */
export interface RegistryError {
  readonly code: RegistryErrorCode;
  readonly message: string;
  /** Populated for `NO_VIABLE_VARIANT`: how many candidates were eliminated. */
  readonly eliminatedCandidates?: number;
}

/**
 * Resident memory estimate for serving a variant with a given context.
 *
 * Weights alone are not a sufficient estimate: the key/value cache grows with
 * context length and is frequently the term that pushes a variant over the
 * ceiling. See `AEGIS-QNT-003`.
 */
export function estimateResidentBytes(variant: QuantizedVariant, kvCacheBytes: number): number {
  return variant.sizeBytes + Math.max(0, kvCacheBytes);
}

/** Registry of quantized variants with deterministic routing. */
export class QuantizationRegistry {
  private readonly variants = new Map<string, QuantizedVariant>();

  /** Composite key so one model may carry several schemes. */
  private static key(modelId: string, scheme: QuantizationScheme): string {
    return `${modelId}\u0000${scheme}`;
  }

  /**
   * Register a variant.
   *
   * @returns the registered variant, or a typed failure when the scheme is not
   * supported or the variant is malformed.
   */
  // r[impl AEGIS-QNT-002]
  register(variant: QuantizedVariant): Result<QuantizedVariant, RegistryError> {
    if (!SUPPORTED_SCHEMES.includes(variant.scheme)) {
      return err({
        code: 'UNKNOWN_SCHEME',
        message: `quantization scheme '${variant.scheme}' is not supported`,
      });
    }
    if (variant.modelId.trim().length === 0) {
      return err({ code: 'INVALID_VARIANT', message: 'modelId must not be empty' });
    }
    if (!Number.isInteger(variant.sizeBytes) || variant.sizeBytes <= 0) {
      return err({ code: 'INVALID_VARIANT', message: 'sizeBytes must be a positive integer' });
    }
    if (variant.qualityScore < 0 || variant.qualityScore > 1) {
      return err({ code: 'INVALID_VARIANT', message: 'qualityScore must be within [0, 1]' });
    }

    const key = QuantizationRegistry.key(variant.modelId, variant.scheme);
    if (this.variants.has(key)) {
      return err({
        code: 'DUPLICATE_VARIANT',
        message: `variant ${variant.modelId}/${variant.scheme} is already registered`,
      });
    }

    this.variants.set(key, variant);
    return ok(variant);
  }

  /**
   * Select the best variant for a routing policy.
   *
   * Selection order: highest quality score, then smallest resident footprint,
   * then lowest scheme rank. The third key exists purely so that the ordering
   * is total: without it, two variants with identical quality and identical
   * size would be selected by `Map` insertion order, which is an accident of
   * configuration loading rather than a documented policy.
   */
  // r[impl AEGIS-QNT-003]
  // r[impl AEGIS-QNT-004]
  // r[impl AEGIS-QNT-005]
  resolve(policy: RoutingPolicy): Result<QuantizedVariant, RegistryError> {
    const candidates: QuantizedVariant[] = [];

    for (const variant of this.variants.values()) {
      if (variant.modelId !== policy.modelId) continue;
      if (policy.allowedSchemes !== undefined && !policy.allowedSchemes.includes(variant.scheme)) {
        continue;
      }
      if (variant.qualityScore < policy.minQualityScore) continue;
      if (estimateResidentBytes(variant, policy.kvCacheBytes) > policy.maxResidentBytes) continue;
      candidates.push(variant);
    }

    if (candidates.length === 0) {
      return err({
        code: 'NO_VIABLE_VARIANT',
        message: `no variant of '${policy.modelId}' satisfies the routing policy`,
        eliminatedCandidates: this.countForModel(policy.modelId) - candidates.length,
      });
    }

    candidates.sort((left, right) => {
      if (right.qualityScore !== left.qualityScore) return right.qualityScore - left.qualityScore;
      const leftResident = estimateResidentBytes(left, policy.kvCacheBytes);
      const rightResident = estimateResidentBytes(right, policy.kvCacheBytes);
      if (leftResident !== rightResident) return leftResident - rightResident;
      return SCHEME_RANK[left.scheme] - SCHEME_RANK[right.scheme];
    });

    return ok(candidates[0]);
  }

  /** All variants registered for a model, in deterministic order. */
  list(modelId: string): readonly QuantizedVariant[] {
    return [...this.variants.values()]
      .filter((variant) => variant.modelId === modelId)
      .sort((left, right) => SCHEME_RANK[left.scheme] - SCHEME_RANK[right.scheme]);
  }

  private countForModel(modelId: string): number {
    let count = 0;
    for (const variant of this.variants.values()) {
      if (variant.modelId === modelId) count += 1;
    }
    return count;
  }
}
