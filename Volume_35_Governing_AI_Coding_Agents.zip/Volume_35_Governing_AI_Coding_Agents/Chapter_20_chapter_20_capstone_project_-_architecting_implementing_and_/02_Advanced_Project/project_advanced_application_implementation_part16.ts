/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part16.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Server-Sent Events framing and lifecycle for the Aegis data plane.
 *
 * The writer owns a bounded outbound queue. When the sink reports
 * backpressure, the writer stops appending and suppresses heartbeats until the
 * queue drains, so a slow client cannot convert a healthy gateway into an
 * out-of-memory event.
 */

import type { Timer } from '../core/clock.js';
import { err, ok, type Result } from '../core/result.js';

// r[impl AEGIS-STR-001]
// r[impl AEGIS-ARCH-003]
// r[impl oa[chat.completions.stream-delta]]

/** One server-sent event. */
export interface SseEvent {
  /** Optional `event:` name, for example `delta`. */
  readonly event?: string;
  /** Optional monotonic `id:`. */
  readonly id?: string;
  /** Payload. Objects are JSON-encoded; strings are emitted verbatim. */
  readonly data: unknown;
}

/** Terminal frame required by the OpenAI-compatible streaming contract. */
export const SSE_SENTINEL_FRAME = 'data: [DONE]\n\n';

/** Comment frame used to keep intermediaries from reaping an idle stream. */
export const SSE_HEARTBEAT_FRAME = ': heartbeat\n\n';

/**
 * Encode one event as an SSE frame.
 *
 * Multi-line payloads are split so that every physical line is emitted as its
 * own `data:` field; the client reassembles them by joining with `\n`. Without
 * this, an embedded newline would terminate the event early.
 */
export function encodeSseFrame(event: SseEvent): string {
  const lines: string[] = [];
  if (event.id !== undefined) lines.push(`id: ${event.id}`);
  if (event.event !== undefined) lines.push(`event: ${event.event}`);

  const payload = typeof event.data === 'string' ? event.data : JSON.stringify(event.data);
  for (const line of payload.split(/\r\n|\r|\n/)) {
    lines.push(`data: ${line}`);
  }
  return `${lines.join('\n')}\n\n`;
}

/** Sink the writer pushes frames into. */
export interface SseSink {
  /** @returns `false` when the sink cannot accept more bytes right now. */
  write(chunk: string): boolean;
}

/** Writer lifecycle states. */
export type SseState = 'idle' | 'open' | 'closed' | 'aborted';

/** Writer failure codes. */
export type SseErrorCode = 'SSE_NOT_OPEN' | 'SSE_BACKPRESSURE' | 'SSE_TERMINATED';

/** Writer failure payload. */
export interface SseError {
  readonly code: SseErrorCode;
  readonly message: string;
}

/** Construction options for {@link SseWriter}. */
export interface SseWriterOptions {
  readonly sink: SseSink;
  readonly timer: Timer;
  readonly heartbeatIntervalMs?: number;
  readonly maxBufferedBytes?: number;
}

/**
 * Single-use SSE writer for one streaming response.
 */
export class SseWriter {
  private state: SseState = 'idle';
  private queue: string[] = [];
  private queuedBytes = 0;
  private cancelHeartbeat: (() => void) | null = null;
  private readonly heartbeatIntervalMs: number;
  private readonly maxBufferedBytes: number;

  constructor(private readonly options: SseWriterOptions) {
    this.heartbeatIntervalMs = options.heartbeatIntervalMs ?? 15_000;
    this.maxBufferedBytes = options.maxBufferedBytes ?? 256 * 1024;
  }

  /** Current lifecycle state. */
  get currentState(): SseState {
    return this.state;
  }

  /** Bytes currently held in the outbound queue. */
  get pendingBytes(): number {
    return this.queuedBytes;
  }

  /** Open the stream and arm the idle heartbeat. */
  open(): void {
    if (this.state !== 'idle') return;
    this.state = 'open';
    this.armHeartbeat();
  }

  /**
   * Enqueue one event.
   *
   * @returns the number of bytes now pending, or a typed failure when the
   * stream is not open or the queue ceiling has been reached.
   */
  // r[impl AEGIS-STR-001]
  emit(event: SseEvent): Result<number, SseError> {
    if (this.state !== 'open') {
      return err({ code: 'SSE_NOT_OPEN', message: `cannot emit while ${this.state}` });
    }
    if (this.queuedBytes >= this.maxBufferedBytes) {
      return err({
        code: 'SSE_BACKPRESSURE',
        message: `outbound queue holds ${this.queuedBytes} bytes`,
      });
    }

    this.queue.push(encodeSseFrame(event));
    this.drain();
    return ok(this.queuedBytes);
  }

  /** Emit the terminal sentinel and close the stream. */
  // r[impl AEGIS-STR-003]
  done(): void {
    if (this.state !== 'open') return;
    this.queue.push(SSE_SENTINEL_FRAME);
    this.drain();
    this.stopHeartbeat();
    this.state = 'closed';
  }

  /**
   * Abandon the stream. Called when the client disconnects.
   *
   * Cancels scheduled heartbeats and discards buffered frames so that a
   * disconnected client cannot pin memory.
   */
  // r[impl AEGIS-STR-004]
  abort(reason: string): void {
    if (this.state === 'closed' || this.state === 'aborted') return;
    this.stopHeartbeat();
    this.queue = [];
    this.queuedBytes = 0;
    this.state = 'aborted';
    void reason;
  }

  /** Attempt to push queued frames into the sink. */
  drain(): void {
    while (this.queue.length > 0) {
      const frame = this.queue[0];
      if (!this.options.sink.write(frame)) return;
      this.queue.shift();
      this.queuedBytes = Math.max(0, this.queuedBytes - frame.length);
    }
    this.queuedBytes = 0;
  }

  /** Emit a heartbeat immediately; exposed for deterministic tests. */
  // r[impl AEGIS-STR-002]
  heartbeat(): void {
    if (this.state !== 'open') return;
    // Suppress heartbeats once the queue is more than half full: the client is
    // already behind, and more bytes will not help it catch up.
    if (this.queuedBytes * 2 >= this.maxBufferedBytes) return;
    this.options.sink.write(SSE_HEARTBEAT_FRAME);
  }

  private armHeartbeat(): void {
    this.cancelHeartbeat = this.options.timer.schedule(this.heartbeatIntervalMs, () => {
      this.heartbeat();
      if (this.state === 'open') this.armHeartbeat();
    });
  }

  private stopHeartbeat(): void {
    if (this.cancelHeartbeat !== null) {
      this.cancelHeartbeat();
      this.cancelHeartbeat = null;
    }
  }
}
