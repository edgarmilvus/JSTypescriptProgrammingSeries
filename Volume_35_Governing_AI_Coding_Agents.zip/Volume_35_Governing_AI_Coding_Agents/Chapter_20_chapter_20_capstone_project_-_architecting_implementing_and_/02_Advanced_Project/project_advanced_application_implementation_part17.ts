/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part17.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Bounded, deterministic fan-out for agent tool calls.
 *
 * A single model turn may request several independent tool calls. Executing
 * them sequentially multiplies tail latency by the fan-out width; executing
 * them with an unbounded `Promise.all` hands an untrusted caller control over
 * socket and file-descriptor consumption. This executor does neither.
 */

import type { Clock, Timer } from '../core/clock.js';
import { systemClock, systemTimer } from '../core/clock.js';

// r[impl AEGIS-ORC-001]
// r[impl AEGIS-ARCH-005]

/** One tool invocation requested by the model. */
export interface ToolCall {
  readonly id: string;
  readonly name: string;
  readonly args: unknown;
}

/** Execution context handed to every tool handler. */
export interface ToolContext {
  readonly callId: string;
  readonly signal: AbortSignal;
  readonly timeoutMs: number;
}

/** A tool implementation. */
export type ToolHandler<R = unknown> = (args: unknown, context: ToolContext) => Promise<R>;

/** Failure codes reported per call. */
export type ToolErrorCode = 'UNKNOWN_TOOL' | 'TIMEOUT' | 'TOOL_FAILURE';

/** Per-call failure payload. */
export interface ToolError {
  readonly code: ToolErrorCode;
  readonly message: string;
}

/** Outcome of one call, always produced — never thrown. */
export interface ToolResult<R = unknown> {
  readonly id: string;
  readonly name: string;
  readonly status: 'fulfilled' | 'rejected';
  readonly value?: R;
  readonly error?: ToolError;
  readonly durationMs: number;
}

/** Aggregate report for one fan-out. */
export interface ToolExecutionReport<R = unknown> {
  readonly results: readonly ToolResult<R>[];
  readonly wallClockMs: number;
  /** Peak simultaneous in-flight calls, a direct measure of `AEGIS-ARCH-005`. */
  readonly maxObservedConcurrency: number;
}

/** Construction options for {@link ParallelToolExecutor}. */
export interface ParallelToolExecutorOptions {
  readonly tools: ReadonlyMap<string, ToolHandler>;
  readonly maxConcurrency: number;
  readonly defaultTimeoutMs: number;
  readonly clock?: Clock;
  readonly timer?: Timer;
}

/**
 * Worker-pool style executor.
 *
 * The implementation launches exactly `min(maxConcurrency, callCount)` workers
 * that pull indices from a shared cursor. This is deliberately not
 * `chunk()`-based: chunking would serialise on the slowest call within each
 * chunk and would under-utilise the ceiling whenever per-call latency is
 * uneven.
 */
export class ParallelToolExecutor {
  private readonly tools: ReadonlyMap<string, ToolHandler>;
  private readonly maxConcurrency: number;
  private readonly defaultTimeoutMs: number;
  private readonly clock: Clock;
  private readonly timer: Timer;

  constructor(options: ParallelToolExecutorOptions) {
    if (!Number.isInteger(options.maxConcurrency) || options.maxConcurrency < 1) {
      throw new RangeError('maxConcurrency must be a positive integer');
    }
    this.tools = options.tools;
    this.maxConcurrency = options.maxConcurrency;
    this.defaultTimeoutMs = options.defaultTimeoutMs;
    this.clock = options.clock ?? systemClock;
    this.timer = options.timer ?? systemTimer;
  }

  /**
   * Execute a batch of tool calls.
   *
   * @returns a report whose `results` array is positionally aligned with the
   * input `calls` array, regardless of completion order.
   */
  // r[impl AEGIS-ORC-001]
  // r[impl AEGIS-ORC-002]
  // r[impl AEGIS-ORC-005]
  async execute(
    calls: readonly ToolCall[],
    options: { readonly timeoutMs?: number } = {},
  ): Promise<ToolExecutionReport> {
    const startedAt = this.clock.now();
    const timeoutMs = options.timeoutMs ?? this.defaultTimeoutMs;
    const results = new Array<ToolResult>(calls.length);

    let cursor = 0;
    let inFlight = 0;
    let maxObservedConcurrency = 0;

    const worker = async (): Promise<void> => {
      for (;;) {
        const index = cursor;
        cursor += 1;
        if (index >= calls.length) return;

        inFlight += 1;
        if (inFlight > maxObservedConcurrency) maxObservedConcurrency = inFlight;
        try {
          results[index] = await this.runOne(calls[index], timeoutMs);
        } finally {
          inFlight -= 1;
        }
      }
    };

    const width = Math.min(this.maxConcurrency, calls.length);
    await Promise.all(Array.from({ length: width }, () => worker()));

    return {
      results,
      wallClockMs: this.clock.now() - startedAt,
      maxObservedConcurrency,
    };
  }

  /**
   * Run one call with an individual deadline.
   *
   * Failures are converted into rejected results rather than propagated: a
   * single misbehaving tool must not cancel its siblings.
   */
  // r[impl AEGIS-ORC-003]
  // r[impl AEGIS-ORC-004]
  private async runOne(call: ToolCall, timeoutMs: number): Promise<ToolResult> {
    const startedAt = this.clock.now();
    const elapsed = (): number => this.clock.now() - startedAt;

    const handler = this.tools.get(call.name);
    if (handler === undefined) {
      return {
        id: call.id,
        name: call.name,
        status: 'rejected',
        error: { code: 'UNKNOWN_TOOL', message: `tool '${call.name}' is not registered` },
        durationMs: elapsed(),
      };
    }

    const controller = new AbortController();
    const cancel = this.timer.schedule(timeoutMs, () => controller.abort());

    try {
      const value = await handler(call.args, {
        callId: call.id,
        signal: controller.signal,
        timeoutMs,
      });
      return { id: call.id, name: call.name, status: 'fulfilled', value, durationMs: elapsed() };
    } catch (caught) {
      const timedOut = controller.signal.aborted;
      return {
        id: call.id,
        name: call.name,
        status: 'rejected',
        error: {
          code: timedOut ? 'TIMEOUT' : 'TOOL_FAILURE',
          message: timedOut
            ? `tool '${call.name}' exceeded its ${timeoutMs}ms deadline`
            : messageOf(caught),
        },
        durationMs: elapsed(),
      };
    } finally {
      cancel();
    }
  }
}

/** Extract a human-readable message from an unknown thrown value. */
function messageOf(caught: unknown): string {
  if (caught instanceof Error) return caught.message;
  return typeof caught === 'string' ? caught : 'tool threw a non-Error value';
}
