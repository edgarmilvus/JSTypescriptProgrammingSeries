/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part18.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Structured JSON logging with correlation bindings and secret redaction.
 */

import type { Clock } from '../core/clock.js';
import { systemClock } from '../core/clock.js';

// r[impl AEGIS-OBS-001]
// r[impl AEGIS-INT-005]

/** Severity levels in ascending order of importance. */
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const LEVEL_WEIGHT: Readonly<Record<LogLevel, number>> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

/** Keys whose values are always redacted. */
export const REDACT_KEY_PATTERN = /(authorization|api[_-]?key|token|secret|password|cookie)/i;

/** Replacement marker written in place of a sensitive value. */
export const REDACTION_MARKER = '[redacted]';

/** Destination for rendered log lines. */
export interface LogSink {
  write(line: string): void;
}

/** Construction options for {@link createLogger}. */
export interface LoggerOptions {
  readonly sink: LogSink;
  readonly level?: LogLevel;
  readonly clock?: Clock;
  readonly bindings?: Readonly<Record<string, unknown>>;
  /** Literal secret values that must never appear in output. */
  readonly secrets?: readonly string[];
}

/** Logger facade. */
export interface Logger {
  readonly level: LogLevel;
  /** Derive a logger that merges additional bindings into every record. */
  child(bindings: Readonly<Record<string, unknown>>): Logger;
  debug(message: string, fields?: Readonly<Record<string, unknown>>): void;
  info(message: string, fields?: Readonly<Record<string, unknown>>): void;
  warn(message: string, fields?: Readonly<Record<string, unknown>>): void;
  error(message: string, fields?: Readonly<Record<string, unknown>>): void;
}

/** Redact a value tree by key name and by known secret literals. */
export function redact(
  value: unknown,
  secrets: readonly string[] = [],
  depth = 0,
): unknown {
  if (depth > 6) return '[depth-limit]';
  if (typeof value === 'string') {
    return secrets.some((secret) => secret.length > 0 && value.includes(secret))
      ? REDACTION_MARKER
      : value;
  }
  if (value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map((item) => redact(item, secrets, depth + 1));

  const output: Record<string, unknown> = {};
  for (const [key, entry] of Object.entries(value as Record<string, unknown>)) {
    output[key] = REDACT_KEY_PATTERN.test(key) ? REDACTION_MARKER : redact(entry, secrets, depth + 1);
  }
  return output;
}

/**
 * Build a logger.
 *
 * Correlation identifiers are ordinary bindings: a request-scoped logger is
 * created once with `child({ requestId, tenantId })` and every record emitted
 * through it or its descendants carries them.
 */
// r[impl AEGIS-OBS-002]
// r[impl AEGIS-OBS-003]
export function createLogger(options: LoggerOptions): Logger {
  const clock = options.clock ?? systemClock;
  const threshold = LEVEL_WEIGHT[options.level ?? 'info'];
  const bindings = options.bindings ?? {};
  const secrets = options.secrets ?? [];

  const emit = (level: LogLevel, message: string, fields?: Readonly<Record<string, unknown>>): void => {
    if (LEVEL_WEIGHT[level] < threshold) return;
    const record = {
      level,
      msg: message,
      at: clock.now(),
      ...(bindings as Record<string, unknown>),
      ...((redact(fields ?? {}, secrets) as Record<string, unknown>) ?? {}),
    };
    options.sink.write(`${JSON.stringify(record)}\n`);
  };

  return {
    level: options.level ?? 'info',
    child: (extra) =>
      createLogger({ ...options, bindings: { ...bindings, ...extra } }),
    debug: (message, fields) => emit('debug', message, fields),
    info: (message, fields) => emit('info', message, fields),
    warn: (message, fields) => emit('warn', message, fields),
    error: (message, fields) => emit('error', message, fields),
  };
}
