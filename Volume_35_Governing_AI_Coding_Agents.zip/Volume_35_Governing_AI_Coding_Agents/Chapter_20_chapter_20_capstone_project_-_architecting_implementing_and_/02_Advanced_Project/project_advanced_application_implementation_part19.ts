/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part19.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Event-loop lag estimation.
 *
 * Node.js handles asynchronous work on a single event loop. A synchronous call
 * that blocks for 200ms delays every tenant's streamed token by 200ms. There is
 * no way to observe that from inside the blocking frame, so the monitor
 * measures it from outside: schedule a timer, measure how late it actually
 * fired, and treat lateness as lag.
 */

import type { Clock, Timer } from '../core/clock.js';
import { systemClock, systemTimer } from '../core/clock.js';

// r[impl AEGIS-ARCH-002]

/** Rolling lag statistics. */
export interface LagSnapshot {
  readonly samples: number;
  readonly p50Ms: number;
  readonly p99Ms: number;
  readonly maxMs: number;
  readonly degraded: boolean;
}

/** Construction options for {@link EventLoopMonitor}. */
export interface EventLoopMonitorOptions {
  readonly sampleIntervalMs: number;
  readonly degradedThresholdMs: number;
  readonly windowSize: number;
  readonly timer?: Timer;
  readonly clock?: Clock;
}

/** Periodic event-loop lag sampler. */
export class EventLoopMonitor {
  private readonly samples: number[] = [];
  private readonly intervalMs: number;
  private readonly thresholdMs: number;
  private readonly windowSize: number;
  private readonly timer: Timer;
  private readonly clock: Clock;
  private cancel: (() => void) | null = null;
  private scheduledAt = 0;

  constructor(options: EventLoopMonitorOptions) {
    this.intervalMs = options.sampleIntervalMs;
    this.thresholdMs = options.degradedThresholdMs;
    this.windowSize = options.windowSize;
    this.timer = options.timer ?? systemTimer;
    this.clock = options.clock ?? systemClock;
  }

  /** Begin sampling. Idempotent. */
  start(): void {
    if (this.cancel !== null) return;
    this.schedule();
  }

  /** Stop sampling and release the timer. */
  stop(): void {
    if (this.cancel !== null) {
      this.cancel();
      this.cancel = null;
    }
  }

  /**
   * Record one lag observation.
   *
   * Exposed so that tests can drive the window without a real timer, and so
   * that an operator can inject an observation from an external probe.
   */
  observe(lagMs: number): void {
    this.samples.push(Math.max(0, lagMs));
    while (this.samples.length > this.windowSize) this.samples.shift();
  }

  /** Compute the current rolling snapshot. */
  snapshot(): LagSnapshot {
    if (this.samples.length === 0) {
      return { samples: 0, p50Ms: 0, p99Ms: 0, maxMs: 0, degraded: false };
    }
    const sorted = [...this.samples].sort((left, right) => left - right);
    const p99Ms = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.99))];
    return {
      samples: sorted.length,
      p50Ms: sorted[Math.floor(sorted.length / 2)],
      p99Ms,
      maxMs: sorted[sorted.length - 1],
      degraded: p99Ms > this.thresholdMs,
    };
  }

  private schedule(): void {
    this.scheduledAt = this.clock.now();
    this.cancel = this.timer.schedule(this.intervalMs, () => {
      this.observe(this.clock.now() - this.scheduledAt - this.intervalMs);
      this.schedule();
    });
  }
}
