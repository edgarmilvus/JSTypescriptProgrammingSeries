/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part20.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Gateway composition root.
 *
 * Ordering here is load-bearing. Variant resolution happens *before* quota
 * consumption so that a request which cannot be served never burns tenant
 * budget. Quota consumption happens before streaming starts so that
 * over-budget requests never occupy a socket.
 */

import type { Clock, Timer } from './core/clock.js';
import type { Logger } from './observability/logger.js';
import type { QuantizationRegistry, QuantizedVariant } from './quantization/registry.js';
import type { QuotaLedger } from './tenancy/quota-ledger.js';
import type { ParallelToolExecutor, ToolCall, ToolExecutionReport } from './agents/parallel-tool-executor.js';
import { SseWriter } from './streaming/sse-writer.js';

// r[impl AEGIS-INT-001]
// r[impl AEGIS-INT-002]
// r[impl AEGIS-ARCH-001]
// r[impl oa[errors.rate-limit-shape]]
// r[impl oa[chat.completions.request-shape]]

/** Default memory ceiling when the caller does not supply one. */
export const DEFAULT_MAX_RESIDENT_BYTES = 24 * 1024 ** 3;

/** Normalized inbound request. */
export interface InferenceRequest {
  readonly requestId: string;
  readonly tenantId: string;
  readonly modelId: string;
  readonly units: number;
  readonly kvCacheBytes?: number;
  readonly maxResidentBytes?: number;
  readonly toolCalls?: readonly ToolCall[];
}

/** Dependencies injected into the gateway. */
export interface GatewayDeps {
  readonly quotas: QuotaLedger;
  readonly registry: QuantizationRegistry;
  readonly tools: ParallelToolExecutor;
  readonly logger: Logger;
  readonly clock: Clock;
  readonly timer: Timer;
  readonly heartbeatIntervalMs?: number;
  readonly maxBufferedBytes?: number;
}

/** A rejected request, fully materialized for the HTTP layer. */
export interface RejectedInference {
  readonly kind: 'rejected';
  readonly status: number;
  readonly headers: Readonly<Record<string, string>>;
  readonly body: Readonly<Record<string, unknown>>;
}

/** An accepted request with a live stream writer. */
export interface AcceptedInference {
  readonly kind: 'accepted';
  readonly variant: QuantizedVariant;
  readonly writer: SseWriter;
  readonly toolReport: ToolExecutionReport | null;
  /** Returns unused capacity to the tenant. Idempotent at the ledger level. */
  readonly refundUnused: (deliveredUnits: number) => number;
}

/** Discriminated union of gateway outcomes. */
export type GatewayOutcome = RejectedInference | AcceptedInference;

/**
 * Handle one inference request end to end.
 *
 * @returns a rejected outcome carrying an HTTP-shaped error, or an accepted
 * outcome carrying a live {@link SseWriter} and the routing decision.
 */
export async function handleInferenceRequest(
  deps: GatewayDeps,
  request: InferenceRequest,
): Promise<GatewayOutcome> {
  const log = deps.logger.child({ requestId: request.requestId, tenantId: request.tenantId });

  // 1. Shape validation. Cheap, local, and deliberately first: never touch
  //    shared state on behalf of a malformed request.
  if (!Number.isInteger(request.units) || request.units <= 0) {
    log.warn('rejected malformed request', { reason: 'invalid_units' });
    return rejection(400, {
      error: {
        message: 'units must be a positive integer',
        type: 'invalid_request_error',
        code: 'invalid_units',
      },
    });
  }
  if (request.modelId.trim().length === 0) {
    log.warn('rejected malformed request', { reason: 'empty_model' });
    return rejection(400, {
      error: {
        message: 'model must be a non-empty string',
        type: 'invalid_request_error',
        code: 'invalid_model',
      },
    });
  }

  // 2. Variant resolution precedes admission so that an unservable request
  //    does not consume budget.
  const variant = deps.registry.resolve({
    modelId: request.modelId,
    maxResidentBytes: request.maxResidentBytes ?? DEFAULT_MAX_RESIDENT_BYTES,
    minQualityScore: 0,
    kvCacheBytes: request.kvCacheBytes ?? 0,
  });

  if (!variant.ok) {
    log.warn('no viable variant', { modelId: request.modelId, code: variant.error.code });
    return rejection(404, {
      error: {
        message: variant.error.message,
        type: 'invalid_request_error',
        code: 'model_not_available',
      },
    });
  }

  // 3. Admission control. Denials are indistinguishable for unresolved
  //    tenants, and every path emits an audit record inside the ledger.
  const decision = deps.quotas.tryConsume(request.tenantId, request.units, request.requestId);

  if (!decision.ok) {
    if (decision.error.code === 'UNKNOWN_TENANT') {
      log.warn('denied unresolved tenant');
      return rejection(403, {
        error: {
          message: 'the caller is not authorized to use this gateway',
          type: 'invalid_request_error',
          code: 'forbidden',
        },
      });
    }

    if (decision.error.code === 'QUOTA_EXCEEDED') {
      const retryAfterSeconds = Math.max(1, Math.ceil((decision.error.retryAfterMs ?? 1000) / 1000));
      log.warn('denied over budget', { retryAfterSeconds });
      return rejection(
        429,
        {
          error: {
            message: decision.error.message,
            type: 'rate_limit_error',
            code: 'rate_limit_exceeded',
          },
        },
        { 'retry-after': String(retryAfterSeconds) },
      );
    }

    log.error('admission failure', { code: decision.error.code });
    return rejection(400, {
      error: { message: decision.error.message, type: 'invalid_request_error', code: decision.error.code },
    });
  }

  // 4. Agent tool fan-out. Independent calls execute concurrently under a
  //    bounded ceiling; results are positionally aligned with the request.
  let toolReport: ToolExecutionReport | null = null;
  if (request.toolCalls !== undefined && request.toolCalls.length > 0) {
    toolReport = await deps.tools.execute(request.toolCalls);
    const rejected = toolReport.results.filter((entry) => entry.status === 'rejected').length;
    log.info('tool fan-out complete', {
      calls: request.toolCalls.length,
      rejected,
      maxObservedConcurrency: toolReport.maxObservedConcurrency,
    });
  }

  // 5. Open the stream only after admission succeeded.
  const writer = new SseWriter({
    sink: {
      write: () => true,
    },
    timer: deps.timer,
    ...(deps.heartbeatIntervalMs !== undefined ? { heartbeatIntervalMs: deps.heartbeatIntervalMs } : {}),
    ...(deps.maxBufferedBytes !== undefined ? { maxBufferedBytes: deps.maxBufferedBytes } : {}),
  });

  log.info('admitted', {
    variant: variant.value.scheme,
    remainingUnits: decision.value.remainingUnits,
  });

  return {
    kind: 'accepted',
    variant: variant.value,
    writer,
    toolReport,
    refundUnused: (deliveredUnits: number) => {
      const unused = Math.max(0, request.units - deliveredUnits);
      return unused > 0 ? deps.quotas.refund(request.tenantId, unused) : 0;
    },
  };
}

/** Build a rejection outcome with JSON content type by default. */
function rejection(
  status: number,
  body: Readonly<Record<string, unknown>>,
  headers: Readonly<Record<string, string>> = {},
): RejectedInference {
  return {
    kind: 'rejected',
    status,
    headers: { 'content-type': 'application/json', ...headers },
    body,
  };
}
