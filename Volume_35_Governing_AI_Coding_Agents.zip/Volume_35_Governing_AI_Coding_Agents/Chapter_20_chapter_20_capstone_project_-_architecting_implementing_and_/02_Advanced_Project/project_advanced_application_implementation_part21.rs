/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part21.rs
Description: Advanced Application Implementation
==========================================
*/

// edge/src/sse.rs
//! Zero-allocation SSE framing for the edge data plane.
//!
//! The edge tier terminates TLS and frames bytes; the control plane decides
//! what those bytes mean. Both tiers must agree on the wire format, so both
//! tiers reference the same requirement.

/// Terminal frame required by the streaming contract.
// r[impl AEGIS-STR-003]
pub const SENTINEL_FRAME: &str = "data: [DONE]\n\n";

/// Comment frame used to keep idle streams alive through intermediaries.
// r[impl AEGIS-STR-002]
pub const HEARTBEAT_FRAME: &str = ": heartbeat\n\n";

/// Encode a JSON payload as an SSE frame.
///
/// Every physical line of the payload becomes its own `data:` field so that
/// embedded newlines survive transport.
// r[impl AEGIS-STR-001]
pub fn encode_frame(payload: &str) -> String {
    let mut encoded = String::with_capacity(payload.len() + 16);
    for line in payload.split('\n') {
        encoded.push_str("data: ");
        encoded.push_str(line.trim_end_matches('\r'));
        encoded.push('\n');
    }
    encoded.push('\n');
    encoded
}

#[cfg(test)]
mod tests {
    use super::*;

    // r[verify AEGIS-STR-001]
    #[test]
    fn multi_line_payloads_are_split_into_data_fields() {
        assert_eq!(encode_frame("a\nb"), "data: a\ndata: b\n\n");
    }

    // r[verify AEGIS-STR-001]
    #[test]
    fn carriage_returns_are_stripped() {
        assert_eq!(encode_frame("a\r\nb"), "data: a\ndata: b\n\n");
    }

    // r[verify AEGIS-STR-003]
    #[test]
    fn sentinel_is_a_complete_frame() {
        assert!(SENTINEL_FRAME.ends_with("\n\n"));
        assert!(SENTINEL_FRAME.contains("[DONE]"));
    }
}
