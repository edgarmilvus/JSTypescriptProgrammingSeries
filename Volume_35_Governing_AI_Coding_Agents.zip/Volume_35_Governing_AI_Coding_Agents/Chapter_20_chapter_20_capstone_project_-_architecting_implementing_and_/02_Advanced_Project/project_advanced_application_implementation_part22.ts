/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part22.ts
Description: Advanced Application Implementation
==========================================
*/

/**
 * @file Deterministic clock and timer for the Aegis test suite.
 *
 * Time is never ambient in tests. Both the ledger's refill arithmetic and the
 * SSE heartbeat schedule read the injected clock, so advancing time is an
 * explicit, synchronous act.
 */

import type { Clock, Timer } from '../../src/core/clock.js';

/** Controllable wall clock. */
export class ManualClock implements Clock {
  private current = 1_700_000_000_000;

  now(): number {
    return this.current;
  }

  advance(ms: number): void {
    this.current += ms;
  }
}

interface Scheduled {
  due: number;
  callback: () => void;
  cancelled: boolean;
}

/** Controllable timer driven by a {@link ManualClock}. */
export class ManualTimer implements Timer {
  private scheduled: Scheduled[] = [];

  constructor(private readonly clock: ManualClock) {}

  schedule(delayMs: number, callback: () => void): () => void {
    const entry: Scheduled = { due: this.clock.now() + delayMs, callback, cancelled: false };
    this.scheduled.push(entry);
    return () => {
      entry.cancelled = true;
    };
  }

  /** Advance the clock and fire every callback that fell due. */
  advance(ms: number): void {
    this.clock.advance(ms);
    const due = this.scheduled.filter((entry) => !entry.cancelled && entry.due <= this.clock.now());
    this.scheduled = this.scheduled.filter((entry) => !entry.cancelled && entry.due > this.clock.now());
    for (const entry of due) entry.callback();
  }

  /** Number of outstanding, uncancelled schedules. */
  get pending(): number {
    return this.scheduled.filter((entry) => !entry.cancelled).length;
  }
}
