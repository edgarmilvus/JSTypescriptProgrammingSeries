/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part23.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it, beforeEach } from 'vitest';
import { QuotaLedger, type QuotaAuditEvent } from '../../src/tenancy/quota-ledger.js';
import { ManualClock } from '../support/manual-clock.js';

// r[verify AEGIS-TEN-001]
// r[verify AEGIS-TEN-002]
// r[verify AEGIS-TEN-003]
// r[verify AEGIS-TEN-004]
// r[verify AEGIS-TEN-005]

describe('QuotaLedger', () => {
  let clock: ManualClock;
  let events: QuotaAuditEvent[];
  let ledger: QuotaLedger;

  beforeEach(() => {
    clock = new ManualClock();
    events = [];
    ledger = new QuotaLedger(clock, { emit: (event) => events.push(event) });
    const registered = ledger.register({
      tenantId: 'acme',
      burstUnits: 1000,
      refillUnitsPerSecond: 100,
    });
    expect(registered.ok).toBe(true);
  });

  it('grants a request within the burst capacity', () => {
    const decision = ledger.tryConsume('acme', 400, 'req-1');
    expect(decision.ok).toBe(true);
    if (decision.ok) expect(decision.value.remainingUnits).toBe(600);
  });

  it('rejects an over-budget request and reports the retry delay', () => {
    ledger.tryConsume('acme', 400, 'req-1');
    const second = ledger.tryConsume('acme', 700, 'req-2');

    expect(second.ok).toBe(false);
    if (!second.ok) {
      expect(second.error.code).toBe('QUOTA_EXCEEDED');
      // 100 units short at 100 units/second => 1000ms.
      expect(second.error.retryAfterMs).toBe(1000);
    }
  });

  it('refills continuously as time passes', () => {
    ledger.tryConsume('acme', 1000, 'req-1');
    expect(ledger.available('acme')).toBe(0);

    clock.advance(3000);
    expect(ledger.available('acme')).toBe(300);

    const decision = ledger.tryConsume('acme', 300, 'req-2');
    expect(decision.ok).toBe(true);
  });

  it('never exceeds the burst capacity when refilling', () => {
    clock.advance(60_000);
    expect(ledger.available('acme')).toBe(1000);
  });

  it('fails closed for an unprovisioned tenant', () => {
    const decision = ledger.tryConsume('globex', 10, 'req-3');
    expect(decision.ok).toBe(false);
    if (!decision.ok) expect(decision.error.code).toBe('UNKNOWN_TENANT');
  });

  it('emits exactly one audit record per decision', () => {
    ledger.tryConsume('acme', 400, 'req-1');
    ledger.tryConsume('acme', 700, 'req-2');
    ledger.tryConsume('globex', 10, 'req-3');

    expect(events).toHaveLength(3);
    expect(events.map((event) => event.allowed)).toEqual([true, false, false]);
    expect(events[0]).toMatchObject({ tenantId: 'acme', requestId: 'req-1', units: 400 });
  });

  it('returns unused capacity on refund, capped at the burst size', () => {
    ledger.tryConsume('acme', 900, 'req-1');
    expect(ledger.available('acme')).toBe(100);

    expect(ledger.refund('acme', 500)).toBe(500);
    expect(ledger.available('acme')).toBe(600);

    expect(ledger.refund('acme', 1000)).toBe(400);
    expect(ledger.available('acme')).toBe(1000);
  });

  it('rejects a malformed quota at registration', () => {
    const bad = ledger.register({ tenantId: 'initech', burstUnits: 0, refillUnitsPerSecond: 10 });
    expect(bad.ok).toBe(false);
    if (!bad.ok) expect(bad.error.code).toBe('INVALID_QUOTA');
  });
});
