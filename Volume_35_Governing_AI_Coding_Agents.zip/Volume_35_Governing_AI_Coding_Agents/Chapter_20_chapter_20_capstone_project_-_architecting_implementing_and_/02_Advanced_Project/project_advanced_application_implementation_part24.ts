/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part24.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it, beforeEach } from 'vitest';
import {
  QuantizationRegistry,
  estimateResidentBytes,
  type QuantizationScheme,
} from '../../src/quantization/registry.js';

// r[verify AEGIS-QNT-001]
// r[verify AEGIS-QNT-002]
// r[verify AEGIS-QNT-003]
// r[verify AEGIS-QNT-004]
// r[verify AEGIS-QNT-005]
// r[verify oa[models.quantization-label]]

const GiB = 1024 ** 3;
const KV_CACHE = 1 * GiB;

describe('QuantizationRegistry', () => {
  let registry: QuantizationRegistry;

  beforeEach(() => {
    registry = new QuantizationRegistry();
    registry.register({ modelId: 'llama-70b', scheme: 'fp16', sizeBytes: 16 * GiB, qualityScore: 0.98 });
    registry.register({ modelId: 'llama-70b', scheme: 'int8', sizeBytes: 8 * GiB, qualityScore: 0.95 });
    registry.register({ modelId: 'llama-70b', scheme: 'q4_k_m', sizeBytes: 5 * GiB, qualityScore: 0.9 });
  });

  it('rejects an unsupported quantization scheme at registration', () => {
    const outcome = registry.register({
      modelId: 'llama-70b',
      scheme: 'q2_k' as QuantizationScheme,
      sizeBytes: 3 * GiB,
      qualityScore: 0.7,
    });
    expect(outcome.ok).toBe(false);
    if (!outcome.ok) expect(outcome.error.code).toBe('UNKNOWN_SCHEME');
  });

  it('rejects a duplicate model/scheme pair', () => {
    const outcome = registry.register({
      modelId: 'llama-70b',
      scheme: 'int8',
      sizeBytes: 8 * GiB,
      qualityScore: 0.95,
    });
    expect(outcome.ok).toBe(false);
    if (!outcome.ok) expect(outcome.error.code).toBe('DUPLICATE_VARIANT');
  });

  it('includes the KV cache in the residency estimate', () => {
    const int8 = registry.list('llama-70b').find((variant) => variant.scheme === 'int8')!;
    expect(estimateResidentBytes(int8, KV_CACHE)).toBe(9 * GiB);
  });

  it('prefers the highest quality variant that fits', () => {
    const outcome = registry.resolve({
      modelId: 'llama-70b',
      maxResidentBytes: 10 * GiB,
      minQualityScore: 0.85,
      kvCacheBytes: KV_CACHE,
    });
    expect(outcome.ok).toBe(true);
    if (outcome.ok) expect(outcome.value.scheme).toBe('int8');
  });

  it('falls back to the only variant that fits the ceiling', () => {
    const outcome = registry.resolve({
      modelId: 'llama-70b',
      maxResidentBytes: 6 * GiB,
      minQualityScore: 0,
      kvCacheBytes: KV_CACHE,
    });
    expect(outcome.ok).toBe(true);
    if (outcome.ok) expect(outcome.value.scheme).toBe('q4_k_m');
  });

  it('is deterministic across repeated resolutions', () => {
    const policy = {
      modelId: 'llama-70b',
      maxResidentBytes: 64 * GiB,
      minQualityScore: 0,
      kvCacheBytes: KV_CACHE,
    };
    const first = registry.resolve(policy);
    const second = registry.resolve(policy);
    expect(first.ok && second.ok && first.value.scheme === second.value.scheme).toBe(true);
  });

  it('reports how many candidates the policy eliminated', () => {
    const outcome = registry.resolve({
      modelId: 'llama-70b',
      maxResidentBytes: 4 * GiB,
      minQualityScore: 0,
      kvCacheBytes: KV_CACHE,
    });
    expect(outcome.ok).toBe(false);
    if (!outcome.ok) {
      expect(outcome.error.code).toBe('NO_VIABLE_VARIANT');
      expect(outcome.error.eliminatedCandidates).toBe(3);
    }
  });

  it('honours a tenant allow-list of schemes', () => {
    const outcome = registry.resolve({
      modelId: 'llama-70b',
      maxResidentBytes: 64 * GiB,
      minQualityScore: 0,
      kvCacheBytes: KV_CACHE,
      allowedSchemes: ['q4_k_m'],
    });
    expect(outcome.ok).toBe(true);
    if (outcome.ok) expect(outcome.value.scheme).toBe('q4_k_m');
  });
});
