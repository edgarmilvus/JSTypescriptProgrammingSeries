/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part25.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it, beforeEach } from 'vitest';
import {
  SseWriter,
  SSE_HEARTBEAT_FRAME,
  SSE_SENTINEL_FRAME,
  encodeSseFrame,
} from '../../src/streaming/sse-writer.js';
import { ManualClock, ManualTimer } from '../support/manual-clock.js';

// r[verify AEGIS-STR-001]
// r[verify AEGIS-STR-002]
// r[verify AEGIS-STR-003]
// r[verify AEGIS-STR-004]
// r[verify oa[chat.completions.stream-delta]]

/** Sink that records frames and can be flipped to backpressure. */
class RecordingSink {
  readonly frames: string[] = [];
  accepting = true;

  write(chunk: string): boolean {
    if (!this.accepting) return false;
    this.frames.push(chunk);
    return true;
  }

  get text(): string {
    return this.frames.join('');
  }
}

describe('encodeSseFrame', () => {
  it('splits multi-line payloads into separate data fields', () => {
    expect(encodeSseFrame({ data: 'alpha\nbeta' })).toBe('data: alpha\ndata: beta\n\n');
  });

  it('emits an event name when supplied', () => {
    expect(encodeSseFrame({ event: 'delta', data: 'x' })).toBe('event: delta\ndata: x\n\n');
  });
});

describe('SseWriter', () => {
  let clock: ManualClock;
  let timer: ManualTimer;
  let sink: RecordingSink;
  let writer: SseWriter;

  beforeEach(() => {
    clock = new ManualClock();
    timer = new ManualTimer(clock);
    sink = new RecordingSink();
    writer = new SseWriter({ sink, timer, heartbeatIntervalMs: 15_000 });
    writer.open();
  });

  it('refuses to emit before the stream is open', () => {
    const fresh = new SseWriter({ sink, timer });
    const outcome = fresh.emit({ data: 'x' });
    expect(outcome.ok).toBe(false);
    if (!outcome.ok) expect(outcome.error.code).toBe('SSE_NOT_OPEN');
  });

  it('emits a vendor-shaped delta frame', () => {
    writer.emit({ data: { choices: [{ delta: { content: 'hel' } }] } });
    expect(sink.text).toContain('data: {"choices":[{"delta":{"content":"hel"}}]}');
  });

  it('terminates a normal stream with the sentinel', () => {
    writer.emit({ data: { choices: [{ delta: { content: 'ok' } }] } });
    writer.done();
    expect(sink.text.endsWith(SSE_SENTINEL_FRAME)).toBe(true);
    expect(writer.currentState).toBe('closed');
  });

  it('emits heartbeats while idle', () => {
    timer.advance(15_000);
    expect(sink.frames).toContain(SSE_HEARTBEAT_FRAME);

    timer.advance(15_000);
    expect(sink.frames.filter((frame) => frame === SSE_HEARTBEAT_FRAME)).toHaveLength(2);
  });

  it('suppresses heartbeats when the consumer is behind', () => {
    sink.accepting = false;
    // Fill the queue above the 50% suppression threshold.
    writer.emit({ data: { blob: 'x'.repeat(200_000) } });
    const before = sink.frames.length;

    timer.advance(15_000);
    expect(sink.frames.length).toBe(before);
  });

  it('stops emitting and drops buffered frames after abort', () => {
    writer.emit({ data: 'first' });
    writer.abort('client disconnected');

    expect(writer.currentState).toBe('aborted');
    expect(writer.pendingBytes).toBe(0);

    const after = writer.emit({ data: 'second' });
    expect(after.ok).toBe(false);

    const framesAfterAbort = sink.frames.length;
    timer.advance(60_000);
    expect(sink.frames.length).toBe(framesAfterAbort);
  });

  it('cancels the heartbeat timer on abort', () => {
    expect(timer.pending).toBe(1);
    writer.abort('client disconnected');
    expect(timer.pending).toBe(0);
  });
});
