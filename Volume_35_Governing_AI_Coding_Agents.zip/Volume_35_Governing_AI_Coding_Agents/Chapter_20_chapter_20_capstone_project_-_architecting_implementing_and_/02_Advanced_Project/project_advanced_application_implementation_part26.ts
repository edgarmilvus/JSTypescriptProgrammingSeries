/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part26.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it, beforeEach } from 'vitest';
import {
  ParallelToolExecutor,
  type ToolCall,
  type ToolContext,
  type ToolHandler,
} from '../../src/agents/parallel-tool-executor.js';
import { ManualClock, ManualTimer } from '../support/manual-clock.js';

// r[verify AEGIS-ORC-001]
// r[verify AEGIS-ORC-002]
// r[verify AEGIS-ORC-003]
// r[verify AEGIS-ORC-004]
// r[verify AEGIS-ORC-005]
// r[verify AEGIS-ARCH-005]

describe('ParallelToolExecutor', () => {
  let clock: ManualClock;
  let timer: ManualTimer;

  beforeEach(() => {
    clock = new ManualClock();
    timer = new ManualTimer(clock);
  });

  /** Build a handler that records overlap and resolves after `afterMs`. */
  function probeHandler(overlap: { current: number; peak: number }, afterMs = 0): ToolHandler {
    return async (_args: unknown, context: ToolContext) => {
      overlap.current += 1;
      overlap.peak = Math.max(overlap.peak, overlap.current);
      await new Promise<void>((resolve) => {
        const cancel = timer.schedule(afterMs, () => {
          overlap.current -= 1;
          resolve();
        });
        context.signal.addEventListener('abort', () => {
          cancel();
          overlap.current -= 1;
          resolve();
        });
      });
      return `ok:${context.callId}`;
    };
  }

  it('dispatches independent calls concurrently', async () => {
    const overlap = { current: 0, peak: 0 };
    const executor = new ParallelToolExecutor({
      tools: new Map([['search', probeHandler(overlap, 100)]]),
      maxConcurrency: 4,
      defaultTimeoutMs: 5_000,
      clock,
      timer,
    });

    const calls: ToolCall[] = [
      { id: 'a', name: 'search', args: {} },
      { id: 'b', name: 'search', args: {} },
      { id: 'c', name: 'search', args: {} },
    ];

    const pending = executor.execute(calls);
    await Promise.resolve();
    timer.advance(100);
    const report = await pending;

    expect(overlap.peak).toBe(3);
    expect(report.maxObservedConcurrency).toBe(3);
    expect(report.results.every((entry) => entry.status === 'fulfilled')).toBe(true);
  });

  it('never exceeds the configured concurrency ceiling', async () => {
    const overlap = { current: 0, peak: 0 };
    const executor = new ParallelToolExecutor({
      tools: new Map([['search', probeHandler(overlap, 50)]]),
      maxConcurrency: 2,
      defaultTimeoutMs: 5_000,
      clock,
      timer,
    });

    const calls = Array.from({ length: 6 }, (_, index) => ({
      id: `c${index}`,
      name: 'search',
      args: {},
    }));

    const pending = executor.execute(calls);
    await Promise.resolve();
    timer.advance(200);
    const report = await pending;

    expect(overlap.peak).toBeLessThanOrEqual(2);
    expect(report.maxObservedConcurrency).toBeLessThanOrEqual(2);
  });

  it('orders results by request position, not completion order', async () => {
    const delays = new Map([
      ['slow', 500],
      ['fast', 10],
    ]);

    const executor = new ParallelToolExecutor({
      tools: new Map([
        ['slow', async () => 'slow-value'],
        ['fast', async () => 'fast-value'],
      ]),
      maxConcurrency: 2,
      defaultTimeoutMs: 5_000,
      clock,
      timer,
    });

    const calls: ToolCall[] = [
      { id: '1', name: 'slow', args: delays.get('slow') },
      { id: '2', name: 'fast', args: delays.get('fast') },
    ];

    const report = await executor.execute(calls);
    expect(report.results.map((entry) => entry.id)).toEqual(['1', '2']);
    expect(report.results[0].value).toBe('slow-value');
    expect(report.results[1].value).toBe('fast-value');
  });

  it('reports a per-call timeout without cancelling siblings', async () => {
    const hang: ToolHandler = (_args, context) =>
      new Promise((_resolve, reject) => {
        context.signal.addEventListener('abort', () => reject(new Error('aborted')));
      });

    const executor = new ParallelToolExecutor({
      tools: new Map([
        ['hang', hang],
        ['instant', async () => 'done'],
      ]),
      maxConcurrency: 2,
      defaultTimeoutMs: 250,
      clock,
      timer,
    });

    const calls: ToolCall[] = [
      { id: 'h', name: 'hang', args: {} },
      { id: 'i', name: 'instant', args: {} },
    ];

    const pending = executor.execute(calls);
    await Promise.resolve();
    timer.advance(250);
    const report = await pending;

    expect(report.results[0].status).toBe('rejected');
    expect(report.results[0].error?.code).toBe('TIMEOUT');
    expect(report.results[1].status).toBe('fulfilled');
    expect(report.results[1].value).toBe('done');
  });

  it('reports an unknown tool as an individual rejection', async () => {
    const executor = new ParallelToolExecutor({
      tools: new Map([['known', async () => 'ok']]),
      maxConcurrency: 2,
      defaultTimeoutMs: 1000,
      clock,
      timer,
    });

    const report = await executor.execute([
      { id: '1', name: 'known', args: {} },
      { id: '2', name: 'missing', args: {} },
    ]);

    expect(report.results[1].status).toBe('rejected');
    expect(report.results[1].error?.code).toBe('UNKNOWN_TOOL');
    expect(report.results[0].status).toBe('fulfilled');
  });

  it('rejects an invalid concurrency ceiling at construction', () => {
    expect(
      () =>
        new ParallelToolExecutor({
          tools: new Map(),
          maxConcurrency: 0,
          defaultTimeoutMs: 1000,
        }),
    ).toThrow(RangeError);
  });
});
