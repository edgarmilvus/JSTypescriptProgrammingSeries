/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part27.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it } from 'vitest';
import { createLogger, REDACTION_MARKER, redact } from '../../src/observability/logger.js';
import { ManualClock } from '../support/manual-clock.js';

// r[verify AEGIS-OBS-001]
// r[verify AEGIS-OBS-002]
// r[verify AEGIS-OBS-003]

describe('logger', () => {
  it('writes one parseable JSON record per call', () => {
    const lines: string[] = [];
    const clock = new ManualClock();
    const logger = createLogger({ sink: { write: (line) => lines.push(line) }, clock });

    logger.info('admitted', { variant: 'int8' });

    expect(lines).toHaveLength(1);
    const record = JSON.parse(lines[0]);
    expect(record).toMatchObject({ level: 'info', msg: 'admitted', variant: 'int8' });
    expect(typeof record.at).toBe('number');
  });

  it('propagates bindings through child loggers', () => {
    const lines: string[] = [];
    const logger = createLogger({ sink: { write: (line) => lines.push(line) } });
    const requestLogger = logger.child({ requestId: 'req-9', tenantId: 'acme' });

    requestLogger.info('admitted');
    requestLogger.child({ attempt: 2 }).warn('retrying');

    expect(JSON.parse(lines[0])).toMatchObject({ requestId: 'req-9', tenantId: 'acme' });
    expect(JSON.parse(lines[1])).toMatchObject({ requestId: 'req-9', tenantId: 'acme', attempt: 2 });
  });

  it('respects the level threshold', () => {
    const lines: string[] = [];
    const logger = createLogger({ sink: { write: (line) => lines.push(line) }, level: 'warn' });
    logger.info('ignored');
    logger.error('kept');
    expect(lines).toHaveLength(1);
    expect(JSON.parse(lines[0]).level).toBe('error');
  });

  it('redacts by key name', () => {
    const redacted = redact({ authorization: 'Bearer abc', nested: { api_key: 'k' } }) as Record<string, unknown>;
    expect(redacted.authorization).toBe(REDACTION_MARKER);
    expect((redacted.nested as Record<string, unknown>).api_key).toBe(REDACTION_MARKER);
  });

  it('redacts registered secret values wherever they appear', () => {
    const lines: string[] = [];
    const logger = createLogger({
      sink: { write: (line) => lines.push(line) },
      secrets: ['sk-live-9f2c'],
    });

    logger.info('upstream rejected', { detail: 'token sk-live-9f2c was refused' });

    expect(lines[0]).not.toContain('sk-live-9f2c');
    expect(lines[0]).toContain(REDACTION_MARKER);
  });

  it('survives a cyclic field tree', () => {
    const cyclic: Record<string, unknown> = { name: 'root' };
    cyclic.self = cyclic;
    const logger = createLogger({ sink: { write: () => undefined } });
    expect(() => logger.info('cyclic', cyclic)).not.toThrow();
  });
});
