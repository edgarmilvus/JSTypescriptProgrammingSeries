/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part29.ts
Description: Advanced Application Implementation
==========================================
*/

import { describe, expect, it, beforeEach } from 'vitest';
import { handleInferenceRequest, type GatewayDeps } from '../../src/gateway.js';
import { QuotaLedger } from '../../src/tenancy/quota-ledger.js';
import { QuantizationRegistry } from '../../src/quantization/registry.js';
import { ParallelToolExecutor, type ToolHandler } from '../../src/agents/parallel-tool-executor.js';
import { createLogger } from '../../src/observability/logger.js';
import { ManualClock, ManualTimer } from '../support/manual-clock.js';
import { SseWriter, SSE_SENTINEL_FRAME } from '../../src/streaming/sse-writer.js';

// r[verify AEGIS-INT-001]
// r[verify AEGIS-INT-002]
// r[verify AEGIS-TEN-002]
// r[verify AEGIS-TEN-003]
// r[verify AEGIS-TEN-005]
// r[verify oa[chat.completions.request-shape]]
// r[verify oa[errors.rate-limit-shape]]
// r[verify oa[chat.completions.stream-delta]]

const GiB = 1024 ** 3;

describe('gateway', () => {
  let clock: ManualClock;
  let timer: ManualTimer;
  let deps: GatewayDeps;

  beforeEach(() => {
    clock = new ManualClock();
    timer = new ManualTimer(clock);

    const quotas = new QuotaLedger(clock);
    quotas.register({ tenantId: 'acme', burstUnits: 1000, refillUnitsPerSecond: 100 });

    const registry = new QuantizationRegistry();
    registry.register({ modelId: 'llama-70b', scheme: 'int8', sizeBytes: 8 * GiB, qualityScore: 0.95 });

    const echo: ToolHandler = async (args) => ({ echoed: args });

    deps = {
      quotas,
      registry,
      tools: new ParallelToolExecutor({
        tools: new Map([['echo', echo]]),
        maxConcurrency: 4,
        defaultTimeoutMs: 5000,
        clock,
        timer,
      }),
      logger: createLogger({ sink: { write: () => undefined } }),
      clock,
      timer,
      heartbeatIntervalMs: 15_000,
    };
  });

  it('rejects a malformed request before touching shared state', async () => {
    const outcome = await handleInferenceRequest(deps, {
      requestId: 'r1',
      tenantId: 'acme',
      modelId: 'llama-70b',
      units: -5,
    });

    expect(outcome.kind).toBe('rejected');
    if (outcome.kind === 'rejected') {
      expect(outcome.status).toBe(400);
      expect(outcome.body).toMatchObject({ error: { type: 'invalid_request_error', code: 'invalid_units' } });
    }
  });

  it('denies an unresolved tenant without disclosing existence', async () => {
    const outcome = await handleInferenceRequest(deps, {
      requestId: 'r2',
      tenantId: 'globex',
      modelId: 'llama-70b',
      units: 10,
    });

    expect(outcome.kind).toBe('rejected');
    if (outcome.kind === 'rejected') {
      expect(outcome.status).toBe(403);
      expect(JSON.stringify(outcome.body)).not.toContain('globex');
    }
  });

  it('returns a 429 with a whole-second Retry-After when over budget', async () => {
    await handleInferenceRequest(deps, {
      requestId: 'r3',
      tenantId: 'acme',
      modelId: 'llama-70b',
      units: 400,
    });

    const outcome = await handleInferenceRequest(deps, {
      requestId: 'r4',
      tenantId: 'acme',
      modelId: 'llama-70b',
      units: 700,
    });

    expect(outcome.kind).toBe('rejected');
    if (outcome.kind === 'rejected') {
      expect(outcome.status).toBe(429);
      expect(outcome.headers['retry-after']).toBe('1');
      expect(outcome.body).toMatchObject({ error: { type: 'rate_limit_error', code: 'rate_limit_exceeded' } });
    }
  });

  it('admits, routes, and streams a vendor-shaped response', async () => {
    const outcome = await handleInferenceRequest(deps, {
      requestId: 'r5',
      tenantId: 'acme',
      modelId: 'llama-70b',
      units: 100,
      kvCacheBytes: 0,
    });

    expect(outcome.kind).toBe('accepted');
    if (outcome.kind !== 'accepted') return;

    expect(outcome.variant.scheme).toBe('int8');

    const frames: string[] = [];
    const writer = new SseWriter({
      sink: { write: (chunk) => (frames.push(chunk), true) },
      timer,
      heartbeatIntervalMs: 15_000,
    });
    writer.open();
    writer.emit({ data: { choices: [{ delta: { content: 'hello' } }] } });
    writer.done();

    const stream = frames.join('');
    expect(stream).toContain('"delta"');
    expect(stream.endsWith(SSE_SENTINEL_FRAME)).toBe(true);
  });

  it('returns unused capacity when a stream is abandoned', async () => {
    const outcome = await handleInferenceRequest(deps, {
      requestId: 'r6',
      tenantId: 'acme',
      modelId: 'llama-70b',
      units: 500,
    });

    expect(outcome.kind).toBe('accepted');
    if (outcome.kind !== 'accepted') return;

    expect(deps.quotas.available('acme')).toBe(500);
    expect(outcome.refundUnused(100)).toBe(400);
    expect(deps.quotas.available('acme')).toBe(900);
  });

  it('executes tool calls concurrently within the request', async () => {
    const outcome = await handleInferenceRequest(deps, {
      requestId: 'r7',
      tenantId: 'acme',
      modelId: 'llama-70b',
      units: 50,
      toolCalls: [
        { id: 't1', name: 'echo', args: { n: 1 } },
        { id: 't2', name: 'echo', args: { n: 2 } },
      ],
    });

    expect(outcome.kind).toBe('accepted');
    if (outcome.kind !== 'accepted') return;

    expect(outcome.toolReport?.results.map((entry) => entry.id)).toEqual(['t1', 't2']);
    expect(outcome.toolReport?.maxObservedConcurrency).toBe(2);
  });
});
