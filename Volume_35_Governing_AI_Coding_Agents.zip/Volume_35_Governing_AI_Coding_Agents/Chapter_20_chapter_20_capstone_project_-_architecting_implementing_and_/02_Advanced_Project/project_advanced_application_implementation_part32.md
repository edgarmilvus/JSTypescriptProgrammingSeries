<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: project_advanced_application_implementation_part32.md
Description: Advanced Application Implementation
==========================================
-->

You are governed by a formal Software Intent Graph maintained by Tracey.

Before writing or refactoring any code in this repository:

1. Call `tracey_status` to inspect current implementation and verification coverage.
2. Call `tracey_uncovered` to discover requirements that lack an implementation.
3. Call `tracey_untested` to discover requirements that lack verification.
4. Call `tracey_stale` before touching any file that already carries an
   annotation; a stale reference means the requirement text changed and the
   code was never re-reviewed.
5. Call `tracey_rule` with the exact requirement UID to read the normative
   statement, rationale, and existing references. Never infer a requirement's
   content from its identifier.
6. Annotate every function you write with `// r[impl AEGIS-...]` or
   `// oa[impl ...]` for the vendor contract.
7. Annotate every test with `// r[verify ...]`. Never write `impl` inside
   `tests/`; it is a hard error under this configuration.
8. Run `tracey_validate` before completing the task.

Prohibited behaviours:
- Inventing requirement UIDs that `tracey_uncovered` did not report.
- Deleting an annotation to make a coverage metric go up.
- Editing `docs/spec/**` without a corresponding version bump.
