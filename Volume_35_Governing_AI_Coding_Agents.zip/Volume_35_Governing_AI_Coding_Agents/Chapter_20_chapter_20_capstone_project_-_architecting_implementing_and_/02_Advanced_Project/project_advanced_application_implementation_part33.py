# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_implementation_part33.py
# Description: Advanced Application Implementation
# ==========================================

#!/usr/bin/env python3
"""Generate a governance report from the Tracey MCP server.

This is an independent implementation of AEGIS-INT-006 (enforced drift gate):
where the CI workflow enforces the gate synchronously on every push, this tool
produces the evidence package that a reviewer reads asynchronously.
"""

from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Any

# r[impl AEGIS-INT-006]

PROTOCOL_VERSION = "2025-06-18"
CLIENT_NAME = "aegis-governance-report"
CLIENT_VERSION = "0.1.0"


@dataclass
class McpClient:
    """Minimal newline-delimited JSON-RPC 2.0 client for a stdio MCP server."""

    command: list[str]
    process: subprocess.Popen | None = None
    next_id: int = 1
    capabilities: dict[str, Any] = field(default_factory=dict)

    def __enter__(self) -> "McpClient":
        self.process = subprocess.Popen(
            self.command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            bufsize=1,
        )
        self.initialize()
        return self

    def __exit__(self, *exc_info: object) -> None:
        if self.process is None:
            return
        self.process.terminate()
        self.process.wait(timeout=5)
        self.process = None

    def _send(self, message: dict[str, Any]) -> None:
        assert self.process is not None and self.process.stdin is not None
        self.process.stdin.write(json.dumps(message) + "\n")
        self.process.stdin.flush()

    def _receive(self) -> dict[str, Any]:
        assert self.process is not None and self.process.stdout is not None
        while True:
            line = self.process.stdout.readline()
            if not line:
                raise RuntimeError("MCP server closed the stream")
            line = line.strip()
            if not line:
                continue
            return json.loads(line)

    def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        """Send a JSON-RPC request and block until its matching response."""
        request_id = self.next_id
        self.next_id += 1
        self._send({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})

        while True:
            message = self._receive()
            if message.get("id") == request_id:
                if "error" in message:
                    raise RuntimeError(f"{method} failed: {message['error']}")
                return message.get("result", {})
            # Notifications (no id) are intentionally ignored.

    def notify(self, method: str, params: dict[str, Any]) -> None:
        """Send a JSON-RPC notification, which must never be answered."""
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    def initialize(self) -> None:
        """Perform the MCP handshake."""
        result = self.request(
            "initialize",
            {
                "protocolVersion": PROTOCOL_VERSION,
                "clientInfo": {"name": CLIENT_NAME, "version": CLIENT_VERSION},
                "capabilities": {},
            },
        )
        self.capabilities = result.get("capabilities", {})
        self.notify("notifications/initialized", {})

    def list_tools(self) -> list[str]:
        """Return the names of every tool the server exposes."""
        result = self.request("tools/list", {})
        return [tool["name"] for tool in result.get("tools", [])]

    def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> str:
        """Invoke a tool and flatten its text content blocks into one string."""
        result = self.request(
            "tools/call",
            {"name": name, "arguments": arguments or {}},
        )
        blocks = result.get("content", [])
        return "\n".join(block.get("text", "") for block in blocks if block.get("type") == "text")


def build_report(client: McpClient) -> str:
    """Render the governance report from live graph queries."""
    tools = set(client.list_tools())
    required = {"tracey_status", "tracey_uncovered", "tracey_untested", "tracey_stale", "tracey_validate"}
    missing = required - tools
    if missing:
        raise RuntimeError(f"Tracey MCP server is missing tools: {sorted(missing)}")

    sections = [
        ("Specification Coverage", client.call_tool("tracey_status")),
        ("Unimplemented Requirements", client.call_tool("tracey_uncovered")),
        ("Unverified Requirements", client.call_tool("tracey_untested")),
        ("Stale References (drift detected)", client.call_tool("tracey_stale")),
        ("Validation", client.call_tool("tracey_validate")),
    ]

    lines = ["# Aegis Gateway — Specification Assurance Report", ""]
    for title, body in sections:
        lines.append(f"## {title}")
        lines.append("")
        lines.append("```")
        lines.append(body.strip() or "(nothing to report)")
        lines.append("```")
        lines.append("")
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    """Entry point. Exits non-zero when drift is detected and --fail-on-stale is set."""
    fail_on_stale = "--fail-on-stale" in argv
    server_command = ["tracey", "mcp"]

    with McpClient(server_command) as client:
        report = build_report(client)
        stale_output = client.call_tool("tracey_stale")

    sys.stdout.write(report + "\n")
    if fail_on_stale and "nothing to report" not in stale_output.lower() and stale_output.strip():
        print("governance: stale references detected", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
