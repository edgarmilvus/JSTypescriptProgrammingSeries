<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: project_advanced_application_implementation_part9.md
Description: Advanced Application Implementation
==========================================
-->

<!-- docs/spec/vendor/openai-compat.md -->

# OpenAI-Compatible HTTP Surface

Aegis re-exposes a strict subset of the OpenAI REST surface so that existing
client SDKs continue to work when a tenant is migrated onto the gateway.

oa[chat.completions.request-shape]
A chat completion request MUST carry a non-empty `model` string and a positive
integer budget hint. Requests violating this shape MUST be rejected with HTTP
400 and an error object of type `invalid_request_error`.

oa[chat.completions.stream-delta]
While streaming is enabled, incremental content MUST be delivered as SSE frames
whose JSON payload carries a `choices[0].delta` object, and the stream MUST be
terminated by the sentinel `data: [DONE]`.

oa[errors.rate-limit-shape]
A rate-limited response MUST use HTTP status 429 and MUST include a
`Retry-After` header whose value is a whole number of seconds, rounded up from
the remaining deficit.

oa[models.quantization-label]
The quantization scheme of the serving variant MUST be reported to the client
using the canonical scheme label (`fp32`, `fp16`, `int8`, `q4_k_m`).
