<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_2_wiring_the_governance_fabric_tracey_configuration_part2.md
Description: Solutions and Explanations
==========================================
-->

<!-- docs/spec/admin-console.md -->
# Admin Console — UX Requirements

Prefix: `adm`. These requirements govern the operator experience of the
Meridian admin console. They are deliberately separate from the ledger-core
families (`LEDGER-*`) so that `tracey query uncovered --prefix adm.` yields a
clean signal.

> adm[adm.trial-balance-banner]
> The admin console must display a persistent red banner at the top of every
> ledger view when the trial balance is off.
>
> The banner must include the absolute discrepancy amount and the timestamp
> of the most recent successful reconciliation. The banner must remain until
> the discrepancy is resolved on the server; it must not be dismissible by
> the operator.

adm[adm.balance-drilldown]
Clicking an account row in the trial balance view must open a drilldown
showing the five most recent postings against that account.

adm[adm.ledger-search]
The admin console must provide a search input that finds accounts by
identifier or by human-readable name.

adm[adm.session-expiry]
When an operator session has been idle for thirty minutes, the admin console
must display a modal warning and offer a re-authentication affordance.

adm[adm.csv-export]
The admin console must allow exporting the current trial balance to CSV
with one click from the trial balance view.

adm[adm.state-transitions]
The trial balance view must reflect the following state transition lifecycle:

```mermaid
stateDiagram-v2
    [*] --> Loading
    Loading --> Ready: fetch ok
    Loading --> Error: fetch fail
    Ready --> Stale: poll fail
    Stale --> Ready: poll ok
    Stale --> Error: manual refresh fail
    Error --> Loading: retry
