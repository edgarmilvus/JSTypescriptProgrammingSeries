/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_building_the_governancedashboard_react_component.tsx
Description: Solutions and Explanations
==========================================
*/

// apps/admin-console/src/features/governance/types.ts

export type ImplName = "rust-core" | "typescript-admin" | "go-ingress";

export interface OffendingRef {
  uid: string;
  title: string;
}

export interface ImplSnapshot {
  implCoverage: number;         // 0..1
  verifyCoverage: number;       // 0..1
  uncoveredRequirements: OffendingRef[]; // capped at 5 by server
  untestedRequirements: OffendingRef[];  // capped at 5 by server
  staleReferences: OffendingRef[];
}

export interface GovernanceSnapshot {
  fetchedAt: number;
  impls: Record<ImplName, ImplSnapshot>;
}

export interface GovernanceDashboardProps {
  governanceApiBaseUrl?: string;
  pollIntervalMs?: number;         // default 60_000
  implThresholds?: Partial<Record<ImplName, { target: number; tolerance: number }>>;
}

// Discriminated union of component states. `degraded` is deliberately
// distinct from `error`: degraded means "we have a stale snapshot we can
// still show, labelled as such"; error means "we have nothing".
export type DashboardState =
  | { kind: "loading" }
  | { kind: "ready"; snapshot: GovernanceSnapshot }
  | { kind: "degraded"; snapshot: GovernanceSnapshot; lastError: string }
  | { kind: "error"; message: string };

// apps/admin-console/src/features/governance/deriveMetrics.ts
//
// Pure, side-effect-free. Top-five truncation lives here — NOT in the
// rendering layer — so it can be unit-tested independently of React.
// r[impl ADM-GOV-006]
export function topFive<T extends { uid: string }>(xs: T[]): T[] {
  return xs.slice(0, 5);
}

export function classifyCoverage(
  value: number,
  target: number,
  tolerance: number,
): "green" | "amber" | "red" {
  if (value >= target) return "green";
  if (value >= target - tolerance) return "amber";
  return "red";
}

// apps/admin-console/src/features/governance/GovernanceDashboard.tsx
import { useEffect, useRef, useState } from "react";
// r[impl ADM-GOV-001]
// r[impl ADM-GOV-007]

export function GovernanceDashboard(props: GovernanceDashboardProps) {
  const {
    governanceApiBaseUrl = "/api/governance",
    pollIntervalMs = 60_000,
    implThresholds = {},
  } = props;

  const [state, setState] = useState<DashboardState>({ kind: "loading" });
  const mountFetches = useRef(0);

  async function fetchOnce(isInitial: boolean) {
    mountFetches.current += 1;
    try {
      const res = await fetch(`${governanceApiBaseUrl}/snapshot`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const snapshot = (await res.json()) as GovernanceSnapshot;
      // r[impl ADM-GOV-004] — a successful poll after a failed one
      // promotes degraded → ready.
      setState({ kind: "ready", snapshot });
    } catch (err) {
      const message = err instanceof Error ? err.message : "unknown";
      setState((prev) => {
        if (prev.kind === "ready" || prev.kind === "degraded") {
          // r[impl ADM-GOV-008] — reconcile stale data, do NOT wipe it.
          return { kind: "degraded", snapshot: prev.snapshot, lastError: message };
        }
        return isInitial ? { kind: "error", message } : prev;
      });
    }
  }

  useEffect(() => {
    // r[impl ADM-GOV-005] — exactly ONE fetch on mount, then poll.
    void fetchOnce(true);
    const id = setInterval(() => void fetchOnce(false), pollIntervalMs);
    return () => clearInterval(id);
  }, [governanceApiBaseUrl, pollIntervalMs]);

  if (state.kind === "loading") return <DashboardSkeleton />;
  if (state.kind === "error") {
    return (
      <ErrorState
        message={state.message}
        onRetry={() => setState({ kind: "loading" })}
      />
    );
  }

  return (
    <div role="region" aria-label="Governance dashboard">
      {hasAnyStale(state.snapshot) && <StaleBanner />}
      <SummaryRow snapshot={state.snapshot} thresholds={implThresholds} />
      <ImplTable snapshot={state.snapshot} />
      {state.kind === "degraded" && <DegradedBadge lastError={state.lastError} />}
    </div>
  );
}

// r[impl ADM-GOV-006]
function hasAnyStale(s: GovernanceSnapshot): boolean {
  return Object.values(s.impls).some((i) => i.staleReferences.length > 0);
}
