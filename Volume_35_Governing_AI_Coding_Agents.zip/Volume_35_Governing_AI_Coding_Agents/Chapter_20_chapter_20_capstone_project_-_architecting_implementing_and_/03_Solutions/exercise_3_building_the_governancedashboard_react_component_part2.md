<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_3_building_the_governancedashboard_react_component_part2.md
Description: Solutions and Explanations
==========================================
-->

<!-- docs/spec/admin-console.md — appended ADM-GOV block -->

> adm[ADM-GOV-001]
> The GovernanceDashboard component shall render the impl coverage, verify
> coverage, uncovered count, untested count, and stale count for each
> governed implementation.
>
> **Rationale:** release managers are frequently paged at 02:00 and need a
> ten-second answer to "is tonight's deploy safe?" without opening a
> terminal.

> adm[ADM-GOV-002]
> When impl coverage falls below the configured target minus tolerance, the
> GovernanceDashboard shall color-code the metric red; when it falls within
> the tolerance band, amber; otherwise green.
>
> **Rationale:** color-coding is a decision-compression mechanism at
> incident-response speed.

> adm[ADM-GOV-003]
> While a stale reference exists for any governed implementation, the
> GovernanceDashboard shall display a persistent banner reading "Spec drift
> detected — review before deploy."
>
> **Rationale:** spec drift is the failure mode regulators and auditors
> most often cite after an incident.

> adm[ADM-GOV-004]
> When a polling fetch succeeds after a prior failure, the
> GovernanceDashboard shall transition from the degraded state to the ready
> state and replace the stale numbers.

> adm[ADM-GOV-005]
> The GovernanceDashboard shall perform exactly one network fetch on mount
> and shall not perform more than one additional fetch per
> ``pollIntervalMs`` while mounted.

> adm[ADM-GOV-006]
> If the governance API returns more than five uncovered requirement
> references for an implementation, then the GovernanceDashboard shall
> render only the first five in the per-implementation expandable row.

> adm[ADM-GOV-007]
> The GovernanceDashboard shall be keyboard-accessible: each
> per-implementation row must be reachable via Tab and must expand on
> Enter.
>
> **Verification:** Inspection (see test plan item 4).

> adm[ADM-GOV-008]
> When a poll fails after a successful load, the GovernanceDashboard shall
> remain in a degraded state that surfaces the last known-good snapshot
> with a visible "stale data" label.
>
> **Rationale:** mirrors the reconciliation semantics of the React Server
> Action model — optimistic client state reconciles against an
> authoritative response; on failure, the client must not silently roll
> back to an empty view.

adm[ADM-GOV-009]
The GovernanceDashboard module shall not export any function whose name
matches ``/^(mutate|create|update|delete)/i``.

adm[ADM-GOV-010]
The GovernanceDashboard shall render within 200 milliseconds on a fixture
containing one thousand requirement references, measured from first render
call to committed paint.

adm[ADM-GOV-011]
The GovernanceDashboard shall not exceed one network fetch on mount and
shall not poll more frequently than once every 60 seconds unless
``pollIntervalMs`` overrides the default.
