<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_4_spec_drift_as_a_first-class_concern_version_bumpi_part2.md
Description: Solutions and Explanations
==========================================
-->

<!-- governance/drift-log.md (excerpt) -->

## Drift entry #1 — LEDGER-INV-002 enforcement boundary

### Original (v1)
> The ledger service shall enforce that the sum of debits equals the sum of
> credits after every posting.

### New (v2)
> The ledger service shall enforce that the sum of debits equals the sum of
> credits after every **batch** of postings.

### Prose diff
The enforcement boundary moved from per-posting to per-batch. Downstream
treasury reconciliation reads trial balance delta, so the change means the
implementation may batch N postings before conservation is checked. This
must be reflected in `posting.rs::commit_batch()` *before* the annotation is
bumped.

### Wrong way (rejected in review)
- Change `// r[impl LEDGER-INV-002]` to `// r[impl LEDGER-INV-002+2]` with
  no code edit.
- Why wrong: Tracey's message is "Implementation must be changed to match
  updated rule text — and ONLY ONCE THAT'S DONE must the code annotation be
  bumped." Bumping without editing the implementation is a self-declared lie
  that hides a real semantic regression from the coverage dashboard.

### Right way (accepted)
1. Edit `commit_batch()` to check conservation at batch boundaries.
2. Add a test in `tests/inv_002_batch.rs` with
   `// r[verify LEDGER-INV-002+2]`.
3. Bump the annotation in `posting.rs` to `// r[impl LEDGER-INV-002+2]`.
4. Run `tracey query stale` — expect empty output.
5. Run `tracey query validate --deny warnings` — expect exit 0.
6. Commit.

## Drift entry #2 — LEDGER-NFR-001 latency budget

Original: 50 ms p99.
New: 75 ms p99 (bumped to `+2`).

## Drift entry #3 — LEDGER-QRY-002 new durability clause

Original: read-your-writes only.
New: read-your-writes **and** trial balance persisted before response.
Bumped to `+2`.

## Validation semantics reference

| Check | Class |
|-------|-------|
| Broken reference (unknown UID) | Error |
| Unknown prefix | Error |
| Unknown verb | Warning |
| Stale reference (version mismatch) | Warning |
| Duplicate UID in one spec | Error |
| Cycle in dependency graph | Error |
| Orphaned requirement | Error |
| `impl` annotation in test file | Error |
