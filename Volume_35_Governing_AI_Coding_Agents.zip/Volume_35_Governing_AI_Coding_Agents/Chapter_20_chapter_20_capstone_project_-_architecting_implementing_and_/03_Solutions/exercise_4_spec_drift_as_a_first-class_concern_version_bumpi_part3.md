<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_4_spec_drift_as_a_first-class_concern_version_bumpi_part3.md
Description: Solutions and Explanations
==========================================
-->

<!-- governance/drift-runbook.md (excerpt) -->

# Drift Remediation Runbook

## When the pre-commit hook fires

1. Read the hook output; identify the affected UID(s).
2. Open the requirement in the `.sdoc` file with `git diff --cached` to
   see the text change.
3. Edit the *implementation* first to match the new semantics.
4. Edit or add the corresponding `verify` test.
5. Run `tracey bump` (this auto-increments version suffixes and re-stages).
6. Re-run `tracey query validate --deny warnings`.
7. Commit.

## When CI fails on `tracey query validate`

Same as above, but with one difference: because the commit is already on the
branch, the engineering manager must be looped in so that any real drift is
tracked in the sprint board until resolved.

## When you discover a stale reference post-merge

Escalate to the on-call ledger architect. The drift-log entry becomes a
post-mortem artifact. Backfill a test that would have caught the drift.

## When an agent under governance produces a stale annotation

Ask three questions in the PR review:
1. Did the agent call `tracey_stale` before proposing the change?
2. Did the agent call `tracey_rule <UID>` to read the current spec text?
3. Was the code changed *before* the annotation was bumped?

## Why we do not whitelist impls from --deny warnings

The LEDGER-NFR-001 latency change from 50 ms to 75 ms looks innocuous.
Treasury reconciliation jobs size their batch windows against the p99
latency budget. If the budget is loosened without a version bump, downstream
batch windows silently drift out of tolerance, and the reconciliation job
begins reporting phantom mismatches. Whitelisting an impl from `--deny
warnings` would allow exactly this change to slip through on the theory that
"we'll fix it later." There is no later; there is only production.

## Metrics

### Drift Escape Rate (DER)
Fraction of post-merge commits that later required a drift correction.
Computation: walk `git log --reverse --since=<window>`, identify commits
touching `docs/spec/**` where the next commit touching the same UID
contains only a version-bump change, and divide by total spec-touching
commits. Target: zero, with an acknowledged measurement noise floor of
~1% from rebase-ordering ambiguity.

### Stale Mean Time To Remediate (Stale-MTTR)
Median wall-clock time between a UID appearing in `tracey query stale`
output and that UID disappearing from it. Timestamps come from periodic
snapshots of `tracey_stale` written to `governance/stale-snapshots/`.
Alert if rolling 7-day median exceeds 48 hours. Measure per requirement
family (INV, ING, QRY, OBS, NFR) so that critical sections can have tighter
SLOs than non-functional ones.

### Why DER beats coverage percentage
Coverage percentage is trivially gameable — a stub with `impl` looks like
coverage. DER can only be improved by tightening the gate or improving
engineer discipline, because it measures events that *escaped* the gate.
