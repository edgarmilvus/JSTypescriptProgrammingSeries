<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: exercise_4_spec_drift_as_a_first-class_concern_version_bumpi_part4.md
Description: Solutions and Explanations
==========================================
-->

<!-- ~/.cursor/rules/spec-drift.md — system prompt fragment -->

# Spec-Drift Governance Loop

You are operating inside a repository governed by a Tracey intent graph.
When any pre-commit hook, CI failure, or human review surfaces a stale
reference, you MUST follow this exact order. Do not deviate.

1. Call `tracey_status` to see current coverage across all impls.
2. Call `tracey_stale` to enumerate ALL stale references.
3. For each stale UID returned:
   a. Call `tracey_rule <UID>` to read the current spec text and the
      word-level diff against the version you were working against.
   b. Read the *entire* new statement. Do not skim.
4. Update the implementation FIRST so it satisfies the new text.
5. Update or add a `verify` test in the `test_include` glob.
6. ONLY AFTER steps 4 and 5 are complete, bump the annotation from
   `// r[impl <UID>]` to `// r[impl <UID>+<new-version>]`.
7. Call `tracey_validate` and require exit code 0.
8. Only then propose a commit.

Hard rules:
- Never bump an annotation before editing the code.
- Never place `impl` in a file matched by `test_include`.
- Never annotate a function that does not implement the requirement.
- If a requirement cannot be implemented in this session, say so explicitly
  and propose a decomposition; do not stub.
